import { generateOpenApiDocument } from "trpc-openapi";
import { appRouter } from "./trpc/router.js";

// Generate OpenAPI schema document
export const openApiDocument = generateOpenApiDocument(appRouter, {
  baseUrl: "/api",
  description: "OpenAPI compliant REST API built using tRPC with Fastify",
  docsUrl: "https://github.com/jlalmes/trpc-openapi",
  securitySchemes: {
    basicAuth: {
      scheme: "basic",
      type: "http",
    },
  },
  tags: [],
  title: "Twilio TwiML APIs Service APIs",
  version: "1.0.0",
});
