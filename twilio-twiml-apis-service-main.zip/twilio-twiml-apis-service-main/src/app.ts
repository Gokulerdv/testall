import AutoLoad, { AutoloadPluginOptions } from "@fastify/autoload";
import cors from "@fastify/cors";
import fastifySwagger from "@fastify/swagger";
import fastifySwaggerUi from "@fastify/swagger-ui";
import fastifyApiReference from "@scalar/fastify-api-reference";
import {
  FastifyTRPCPluginOptions,
  fastifyTRPCPlugin,
} from "@trpc/server/adapters/fastify";
import { FastifyPluginAsync, FastifyServerOptions } from "fastify";
import { dirname, join } from "path";
import {
  fastifyTRPCOpenApiPlugin,
  type CreateOpenApiFastifyPluginOptions,
} from "trpc-openapi";
import { fileURLToPath } from "url";
import { openApiDocument } from "./open-api.js";
import { createContext } from "./trpc/context.js";
import { appRouter, type AppRouter } from "./trpc/router.js";

export interface AppOptions
  extends FastifyServerOptions,
    Partial<AutoloadPluginOptions> {}

// eslint-disable-next-line max-lines-per-function
const app: FastifyPluginAsync<AppOptions> = async (
    fastify,
    opts,
    // eslint-disable-next-line require-await
  ): Promise<void> => {
    // Place here your custom code!
    fastify.register(cors, {
      credentials: true,
      origin: "*",
    });

    // Do not touch the following lines

    /*
     * This loads all plugins defined in plugins
     * those should be support plugins that are reused
     * through your application
     */
    fastify.register(AutoLoad, {
      dir: join(dirname(fileURLToPath(import.meta.url)), "plugins"),
      options: opts,
    });

    /*
     * This loads all plugins defined in routes
     * define your routes in one of these
     */
    fastify.register(AutoLoad, {
      dir: join(dirname(fileURLToPath(import.meta.url)), "routes"),
      options: opts,
    });

    fastify.register(fastifyTRPCPlugin, {
      prefix: "/trpc",
      trpcOptions: {
        createContext,
        onError({ path, error }) {
          // Report to error monitoring
          fastify.log.error(`Error in tRPC handler on path '${path}':`, error);
        },
        router: appRouter,
      } satisfies FastifyTRPCPluginOptions<AppRouter>["trpcOptions"],
    });

    fastify.register(fastifyTRPCOpenApiPlugin, {
      basePath: "/api",
      createContext,
      onError: (({ error, path }) => {
        // Report to error monitoring
        fastify.log.error(`Error in tRPC handler on path '${path}':`, error);
      }) satisfies FastifyTRPCPluginOptions<AppRouter>["trpcOptions"]["onError"],
      router: appRouter,
    } as unknown as CreateOpenApiFastifyPluginOptions<AppRouter>);

    // Server Swagger UI
    fastify.register(fastifySwagger, {
      mode: "static",
      specification: { document: openApiDocument },
    });

    fastify.register(fastifySwaggerUi, {
      routePrefix: "/docs",
      uiConfig: { displayOperationId: true },
    });

    fastify.register(fastifyApiReference, {
      routePrefix: "/reference",
    });
  },
  // Pass --options via CLI arguments in command to enable these options.
  options: AppOptions = {};

export default app;
export { app, options };
