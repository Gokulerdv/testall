export const isAValidPhoneNumber = (number: string): boolean =>
  /^[\d+\-() ]+$/u.test(number);
