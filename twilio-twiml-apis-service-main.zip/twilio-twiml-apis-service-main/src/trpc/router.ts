import { inferRouterInputs, inferRouterOutputs } from "@trpc/server";
import { recordingList } from "./routes/recording-list/index.js";
import { trpc } from "./trpc.js";

export const appRouter = trpc.router({ recordingList });

export type AppRouter = typeof appRouter;

export type RouterInputs = inferRouterInputs<AppRouter>;
export type RouterOutputs = inferRouterOutputs<AppRouter>;
