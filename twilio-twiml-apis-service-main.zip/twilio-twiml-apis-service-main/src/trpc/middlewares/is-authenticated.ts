import { TRPCError } from "@trpc/server";
import { getErrorMessage } from "../../utils/get-error-message.js";
import type { TRPC } from "../trpc.js";

export const isAuthenticated = (trpc: TRPC) =>
  trpc.middleware(({ ctx, next }) => {
    try {
      if (!ctx.req.isAuthenticated)
        throw new TRPCError({ code: "UNAUTHORIZED" });

      return next({ ctx });
    } catch (error) {
      ctx.req.log.error(getErrorMessage(error));

      throw new TRPCError({ code: "UNAUTHORIZED" });
    }
  });
