import { CreateFastifyContextOptions } from "@trpc/server/adapters/fastify";

export const createContext = ({ req, res }: CreateFastifyContextOptions) => ({
  req,
  res,
});

export type Context = ReturnType<typeof createContext>;
