import { isAuthenticated } from "../middlewares/is-authenticated.js";
import { trpc } from "../trpc.js";

export const protectedProcedure = trpc.procedure.use(isAuthenticated(trpc));
