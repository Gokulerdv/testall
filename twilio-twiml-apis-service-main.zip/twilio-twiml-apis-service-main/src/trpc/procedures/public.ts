import { trpc } from "../trpc.js";

export const publicProcedure = trpc.procedure;
