import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { twilioCallListSchema } from "../../../../generated/db/types.zod.js";
import { db } from "../../../db/kysely.js";
import { getErrorMessage } from "../../../utils/get-error-message.js";
import { protectedProcedure } from "../../procedures/protected.js";

export const getAll = protectedProcedure
  .meta({
    openapi: {
      description: "Get all recording list",
      method: "GET",
      path: "/recording-list/get-all",
      protect: true,
      tags: ["recording-list"],
    },
  })
  .input(z.void())
  .output(
    z.array(
      twilioCallListSchema.merge(z.object({ createdAt: z.coerce.date() })),
    ),
  )
  .query(async ({ ctx }) => {
    try {
      const data = await db.selectFrom("twiliocall.List").selectAll().execute();

      return data;
    } catch (error) {
      const message = getErrorMessage(error);

      ctx.req.log.error(message);

      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message });
    }
  });
