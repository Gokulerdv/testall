import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { twilioCallListSchema } from "../../../../generated/db/types.zod.js";
import { db } from "../../../db/kysely.js";
import { getErrorMessage } from "../../../utils/get-error-message.js";
import { protectedProcedure } from "../../procedures/protected.js";

export const getById = protectedProcedure
  .meta({
    openapi: {
      description: "Get recording by id from recording list",
      method: "GET",
      path: "/recording-list/get-by-id",
      protect: true,
      tags: ["recording-list"],
    },
  })
  .input(
    z.object({
      callId: z.string(),
    }),
  )
  .output(twilioCallListSchema.merge(z.object({ createdAt: z.coerce.date() })))
  .query(async ({ ctx, input }) => {
    try {
      const data = await db
        .selectFrom("twiliocall.List")
        .selectAll()
        .where("callId", "=", input.callId)
        .executeTakeFirstOrThrow();

      return data;
    } catch (error) {
      const message = getErrorMessage(error);

      ctx.req.log.error(message);

      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message });
    }
  });
