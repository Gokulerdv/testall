import { trpc } from "../../trpc.js";
import { getAll } from "./get-all.js";
import { getById } from "./get-by-id.js";

export const recordingList = trpc.router({
  getAll,
  getById,
});
