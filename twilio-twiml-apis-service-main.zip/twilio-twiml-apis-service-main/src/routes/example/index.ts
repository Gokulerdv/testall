import { FastifyPluginAsync } from "fastify";

// eslint-disable-next-line require-await
const example: FastifyPluginAsync = async (fastify): Promise<void> => {
  fastify.get("/", () => "this is an example");
};

export default example;
