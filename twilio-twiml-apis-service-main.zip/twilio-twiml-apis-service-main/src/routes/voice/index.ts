import { FastifyPluginAsync } from "fastify";
import { ZodTypeProvider } from "fastify-type-provider-zod";
import twilio from "twilio";
import { z } from "zod";
import { db } from "../../db/kysely.js";
import { envVariables } from "../../environment/variables.js";
import { isAValidPhoneNumber } from "../../utils/is-valid-phone-number.js";

// eslint-disable-next-line require-await, max-lines-per-function
const root: FastifyPluginAsync = async (fastify): Promise<void> => {
  fastify.withTypeProvider<ZodTypeProvider>().post("/", {
    handler: async (req) => {
      const twiml = new twilio.twiml.VoiceResponse();

      req.log.info(req.body);

      await db
        .insertInto("twiliocall.List")
        .values({
          callEventData: JSON.stringify(req.body),
          callId: req.body.CallSid,
          customerId: req.body.clubitsCustomerId,
          modifiedAt: new Date(),
          userId: req.body.clubitsUserId,
        })
        .executeTakeFirstOrThrow();

      if (req.body.To) {
        // eslint-disable-next-line no-ternary
        const attr = isAValidPhoneNumber(req.body.To) ? "number" : "client",
          dial = twiml.dial({
            answerOnBridge: true,
            callerId: envVariables.TWILIO_FROM_PHONE_NUMBER,
            record: "record-from-answer-dual",
            recordingStatusCallback: "/voice/record",
            recordingStatusCallbackEvent: ["completed"],
            recordingStatusCallbackMethod: "POST",
          });

        dial[attr]({}, req.body.To);
      } else {
        twiml.say("Thanks for calling!");
      }

      return twiml.toString();
    },
    schema: {
      body: z
        .object({
          AccountSid: z.string(),
          ApiVersion: z.string(),
          ApplicationSid: z.string().optional(),
          CallSid: z.string(),
          CallStatus: z.string(),
          Called: z.string(),
          Caller: z.string(),
          Direction: z.string(),
          From: z.string(),
          RecordingDuration: z.string().optional(),
          RecordingSid: z.string().optional(),
          RecordingUrl: z.string().optional(),
          To: z.string(),
          callerId: z.string().optional(),
          clubitsCustomerId: z.coerce.number(),
          clubitsUserId: z.coerce.number(),
        })
        .passthrough(),
    },
  });
};

export default root;
