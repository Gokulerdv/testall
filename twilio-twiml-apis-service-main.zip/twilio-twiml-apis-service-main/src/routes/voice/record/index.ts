import { FastifyPluginAsync } from "fastify";
import { ZodTypeProvider } from "fastify-type-provider-zod";
import { request } from "undici";
import { z } from "zod";
import { db } from "../../../db/kysely.js";
import { envVariables } from "../../../environment/variables.js";
import { getErrorMessage } from "../../../utils/get-error-message.js";

// eslint-disable-next-line require-await, max-lines-per-function
const root: FastifyPluginAsync = async (fastify): Promise<void> => {
  fastify.withTypeProvider<ZodTypeProvider>().post("/", {
    // eslint-disable-next-line consistent-return
    handler: async (req, res) => {
      try {
        req.log.info(req.body);

        const { statusCode, body } = await request(
            `${envVariables.STORAGE_SERVICE_HOSTNAME}/api/upload/from-url`,
            {
              body: JSON.stringify({
                headers: {
                  Authorization: `Basic ${Buffer.from(`${envVariables.TWILIO_ACCOUNT_SID}:${envVariables.TWILIO_ACCOUNT_AUTH_TOKEN}`).toString("base64")}`,
                },
                url: req.body.RecordingUrl,
              }),
              headers: {
                Authorization: `Basic ${Buffer.from(`${envVariables.STORAGE_SERVICE_BASIC_AUTH_USERNAME}:${envVariables.STORAGE_SERVICE_BASIC_AUTH_PASSWORD}`).toString("base64")}`,
                "Content-Type": "application/json",
              },
              method: "POST",
            },
          ),
          data = z
            .object({ url: z.string() })
            .passthrough()
            .parse(await body.json());

        await db
          .updateTable("twiliocall.List")
          .set({
            azureBlobResponse: JSON.stringify(data),
            azureBlobUrl: data.url,
            modifiedAt: new Date(),
            recordingEvent: "completed",
            recordingEventData: JSON.stringify(req.body),
            recordingUrl: req.body.RecordingUrl,
          })
          .where("callId", "=", req.body.CallSid)
          .executeTakeFirstOrThrow();

        req.log.info({ data, statusCode });

        return { success: true };
      } catch (error) {
        const message = getErrorMessage(error);

        req.log.error(message);

        res.internalServerError(message);
      }
    },
    schema: {
      body: z
        .object({
          CallSid: z.string(),
          RecordingUrl: z.string(),
        })
        .passthrough(),
    },
  });
};

export default root;
