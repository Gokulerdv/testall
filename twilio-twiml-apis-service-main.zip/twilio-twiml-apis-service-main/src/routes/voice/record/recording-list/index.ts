import { FastifyPluginAsync } from "fastify";
import { fetch } from "undici";
import { envVariables } from "../../../../environment/variables.js";
import { getErrorMessage } from "../../../../utils/get-error-message.js";

export type Recording = {
  sid: string;
  [key: string]: unknown;
};

export type RecordingResponse = {
  recordings: Recording[];
};

// eslint-disable-next-line require-await
const recordingList: FastifyPluginAsync = async (fastify): Promise<void> => {
  fastify.get("/", async (request, reply) => {
    try {
      const url = `https://api.twilio.com/2010-04-01/Accounts/${envVariables.TWILIO_ACCOUNT_SID}/Recordings.json`,
        // eslint-disable-next-line sort-vars
        response = await fetch(url, {
          headers: {
            Authorization: `Basic ${Buffer.from(`${envVariables.TWILIO_ACCOUNT_SID}:${envVariables.TWILIO_ACCOUNT_AUTH_TOKEN}`).toString("base64")}`,
          },
        }),
        // eslint-disable-next-line sort-vars
        data = (await response.json()) as RecordingResponse,
        // eslint-disable-next-line sort-vars
        sids = data.recordings.map((recording) => recording.sid);

      reply.send({ sids });
    } catch (error) {
      const message = getErrorMessage(error);

      request.log.error(message);

      reply.internalServerError(message);
    }
  });
};

export default recordingList;
