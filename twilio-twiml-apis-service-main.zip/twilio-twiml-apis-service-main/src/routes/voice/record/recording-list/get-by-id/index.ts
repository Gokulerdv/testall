/* eslint-disable max-statements */
import { FastifyPluginAsync } from "fastify";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { z } from "zod";
import { envVariables } from "../../../../../environment/variables.js";
import { getErrorMessage } from "../../../../../utils/get-error-message.js";

export const requestParamsSchema = z.object({
  recordingSid: z.coerce.string(),
});

export type RequestParams = z.infer<typeof requestParamsSchema>;

// eslint-disable-next-line require-await, max-lines-per-function, one-var
const getById: FastifyPluginAsync = async (fastify): Promise<void> => {
  fastify.get("/:recordingSid", {
    handler: async (request, reply) => {
      try {
        reply.header("Content-Type", "audio/mpeg");

        const url = `https://api.twilio.com/2010-04-01/Accounts/${envVariables.TWILIO_ACCOUNT_SID}/Recordings/${(request.params as RequestParams).recordingSid}.mp3`,
          // eslint-disable-next-line sort-vars
          response = await fetch(url, {
            headers: {
              Authorization: `Basic ${Buffer.from(`${envVariables.TWILIO_ACCOUNT_SID}:${envVariables.TWILIO_ACCOUNT_AUTH_TOKEN}`).toString("base64")}`,
            },
          }),
          // eslint-disable-next-line sort-vars
          readableWebStream = response.body!,
          // eslint-disable-next-line sort-vars
          readableNodeStream = Readable.fromWeb(readableWebStream as never);

        await pipeline(readableNodeStream, reply.raw);

        reply.raw.end();
        reply.sent = true;

        readableNodeStream.on("end", () => {
          if (!reply.sent) {
            reply.sent = true;
          }
        });

        readableNodeStream.on("error", (error: Error) => {
          if (!reply.sent) {
            const message = getErrorMessage(error);

            fastify.log.error(message);

            reply.send(message);
          }
        });
      } catch (error) {
        if (!reply.sent) {
          const message = getErrorMessage(error);

          fastify.log.error(message);

          reply.internalServerError(message);
        }
      }
    },
    schema: {
      params: requestParamsSchema,
    },
  });
};

export default getById;
