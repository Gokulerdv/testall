import { FastifyPluginAsync } from "fastify";
import { ZodTypeProvider } from "fastify-type-provider-zod";
import twilio from "twilio";
import { z } from "zod";

// eslint-disable-next-line require-await
const root: FastifyPluginAsync = async (fastify): Promise<void> => {
  fastify.withTypeProvider<ZodTypeProvider>().post("/", {
    handler: (req) => {
      const twiml = new twilio.twiml.VoiceResponse();

      if (req.body.To) {
        const dial = twiml.dial({
          callerId: req.body.Caller,
        });

        dial.client({}, "GLQp8fwlvYMw89qA4zn_C");
      } else {
        twiml.say("Thanks for calling!");
      }

      return twiml.toString();
    },
    schema: {
      body: z
        .object({
          AccountSid: z.string(),
          ApiVersion: z.string(),
          ApplicationSid: z.string().optional(),
          CallSid: z.string(),
          CallStatus: z.string(),
          Called: z.string(),
          Caller: z.string(),
          Direction: z.string(),
          From: z.string(),
          To: z.string(),
          callerId: z.string().optional(),
        })
        .passthrough(),
    },
  });
};

export default root;
