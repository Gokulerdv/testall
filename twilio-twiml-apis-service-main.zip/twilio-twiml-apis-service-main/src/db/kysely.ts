// This is the Database interface we defined earlier
import {
  Kysely,
  MssqlDialect,
  type Tedious,
  type TediousConnection,
} from "kysely";
import * as tarn from "tarn";
import * as tedious from "tedious";
import type { DB as Database } from "../../generated/db/types.js";
import { envVariables } from "../environment/variables.js";

export const dialect = new MssqlDialect({
    tarn: {
      ...tarn,
      options: {
        max: 10,
        min: 0,
      },
    },
    tedious: {
      ...tedious,
      connectionFactory: () =>
        new tedious.Connection({
          authentication: {
            options: {
              password: envVariables.DATABASE_PASSWORD,
              userName: envVariables.DATABASE_USER,
            },
            type: "default",
          },
          options: {
            database: envVariables.DATABASE_NAME,
            encrypt: true,
            port: 1433,
            trustServerCertificate: true,
          },
          server: envVariables.DATABASE_HOST,
        }) as unknown as TediousConnection,
    } as unknown as Tedious,
  }),
  /*
   * Database interface is passed to Kysely's constructor, and from now on, Kysely
   * knows your database structure.
   * Dialect is passed to Kysely's constructor, and from now on, Kysely knows how
   * to communicate with your database.
   */
  // eslint-disable-next-line sort-vars
  db = new Kysely<Database>({
    dialect,
  });
