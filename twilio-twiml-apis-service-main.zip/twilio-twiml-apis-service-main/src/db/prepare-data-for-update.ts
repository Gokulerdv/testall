export const prepareDataForUpdate = <T extends Record<string, unknown>>(
  data: T,
) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { id, ...preparedData } = data;
  return preparedData;
};
