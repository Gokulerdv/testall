import { z } from "zod";

export const operationResultSchema = z.union([
  z.object({
    data: z.unknown().optional(),
    message: z.string().optional(),
    status: z.literal("success"),
  }),
  z.object({
    error: z.unknown().optional(),
    message: z.string().optional(),
    status: z.literal("error"),
  }),
]);

export type OperationResult = z.infer<typeof operationResultSchema>;

// eslint-disable-next-line one-var
export const generateErrorOperationResult = (
    message?: string,
    error?: unknown,
  ): OperationResult => ({
    error,
    message,
    status: "error",
  }),
  generateSuccessOperationResult = (
    message?: string,
    data?: unknown,
  ): OperationResult => ({
    data,
    message,
    status: "success",
  });
