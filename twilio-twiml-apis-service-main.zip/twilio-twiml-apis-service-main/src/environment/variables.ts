import { z } from "zod";

export const toBoolean = (secure: unknown) =>
    String(secure).toLowerCase() === "true",
  toNumber = z.coerce.number(),
  // eslint-disable-next-line sort-vars
  envVariablesSchema = z.object({
    COOKIE_HTTP_ONLY: z.preprocess(toBoolean, z.boolean()),
    COOKIE_SAME_SITE: z.preprocess(toBoolean, z.boolean()),
    COOKIE_SECURE: z.preprocess(toBoolean, z.boolean()),
    DATABASE_HOST: z.string(),
    DATABASE_NAME: z.string(),
    DATABASE_PASSWORD: z.string(),
    DATABASE_URL: z.string(),
    DATABASE_USER: z.string(),
    PORT: toNumber,
    SERVICE_BASIC_AUTH_PASSWORD: z.string(),
    SERVICE_BASIC_AUTH_USERNAME: z.string(),
    STORAGE_SERVICE_BASIC_AUTH_PASSWORD: z.string(),
    STORAGE_SERVICE_BASIC_AUTH_USERNAME: z.string(),
    STORAGE_SERVICE_HOSTNAME: z.string(),
    TWILIO_ACCOUNT_AUTH_TOKEN: z.string(),
    TWILIO_ACCOUNT_SID: z.string(),
    TWILIO_FROM_PHONE_NUMBER: z.string(),
  }),
  // eslint-disable-next-line sort-vars
  envVariables = envVariablesSchema.parse(process.env);

export type EnvVariables = z.infer<typeof envVariablesSchema>;

declare global {
  export namespace NodeJS {
    export interface ProcessEnv extends EnvVariables {}
  }
}
