import formbody from "@fastify/formbody";
import { FastifyPluginOptions } from "fastify";
import fp from "fastify-plugin";

// eslint-disable-next-line require-await
export default fp<FastifyPluginOptions>(async (fastify) => {
  fastify.register(formbody);
});
