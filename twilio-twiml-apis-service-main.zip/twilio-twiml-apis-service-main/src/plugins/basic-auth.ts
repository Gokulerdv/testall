import basicAuth, { FastifyBasicAuthOptions } from "@fastify/basic-auth";
import fp from "fastify-plugin";
import { envVariables } from "../environment/variables.js";

// eslint-disable-next-line require-await
export default fp<FastifyBasicAuthOptions>(async (fastify) => {
  fastify.register(basicAuth, {
    // eslint-disable-next-line require-await
    validate: async (username, password, req) => {
      req.isAuthenticated =
        username === envVariables.SERVICE_BASIC_AUTH_USERNAME &&
        password === envVariables.SERVICE_BASIC_AUTH_PASSWORD;
    },
  });

  fastify.after(() => {
    // eslint-disable-next-line max-params
    fastify.addHook("preParsing", (req, _res, _payload, done) => {
      if (!req.headers.authorization)
        req.headers.authorization = `Basic ${Buffer.from(":").toString("base64")}`;

      done();
    });
    fastify.addHook("preHandler", fastify.basicAuth);
  });
});

// When using .decorate you have to specify added properties for Typescript
declare module "fastify" {
  export interface FastifyRequest {
    isAuthenticated: boolean;
  }
}
