"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODProcedureLog",
            {
              ProcNum: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              PatNum: {
                type: Sequelize.STRING,
              },
              AptNum: {
                type: Sequelize.STRING,
              },
              ProvNum: {
                type: Sequelize.STRING
              },
              procCode: {
                type: Sequelize.STRING,
              },
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODProcedureLog");
    }
};