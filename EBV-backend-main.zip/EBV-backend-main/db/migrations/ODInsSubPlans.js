"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODInsSub",
            {
              PlanNum: {
                type: Sequelize.STRING,
              },
              InsSubNum: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              Subscriber: {
                type: Sequelize.STRING
              },
              SubscriberID: Sequelize.STRING,
              BenefitNotes: {
                type: Sequelize.TEXT
              },
              ReleaseInfo: {
                type: Sequelize.TEXT
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODInsSub");
    }
};