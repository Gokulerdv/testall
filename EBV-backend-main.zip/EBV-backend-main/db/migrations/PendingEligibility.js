"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "PendingEligibilityReports", {
            id: {
              type: Sequelize.INTEGER,
              primaryKey: true,
              autoIncrement: true
            },
            filterName: {
              type: Sequelize.STRING,
              allowNull: false
            },
            fromDate: {
              type: Sequelize.DATE,
              allowNull: false
            },
            toDate: {
              type: Sequelize.DATE,
              allowNull: false
            },
            insuranceHierarchy: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("insuranceHierarchy");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("insuranceHierarchy", JSON.stringify(value));
              }
            },
            location: {
              type: Sequelize.STRING,
              get() {
                const value = this.getDataValue("location");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("location", JSON.stringify(value));
              }
            },
            patients: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("patients");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("patients", JSON.stringify(value));
              }
        
            },
            provider: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("provider");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("provider", JSON.stringify(value));
              }
            },
            lastEligibility: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("lastEligibility");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("lastEligibility", JSON.stringify(value));
              }
            },
            insuranceStatus: {
              type: Sequelize.STRING
            },
            daysGreaterThan: {
              type: Sequelize.STRING,
              allowNull: false
            },
            insuranceType: {
              type: Sequelize.STRING
            },
            columns: {
              type: Sequelize.TEXT,
              allowNull: false,
              get() {
                const value = this.getDataValue("columns");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("columns", JSON.stringify(value));
              }
            },
            payer: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("payer");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("payer", JSON.stringify(value));
              }
            },
            isFavorite: {
              type: Sequelize.BOOLEAN,
              defaultValue: false
            }
          },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("PendingEligibility");
    }
};