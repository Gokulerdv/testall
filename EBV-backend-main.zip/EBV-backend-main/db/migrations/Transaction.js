"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "TransactionReports", {
            filterName: {
                type: Sequelize.STRING,
                allowNull: false
            },
            fromDate: {
                type: Sequelize.DATE,
                allowNull: false
            },
            toDate: {
                type: Sequelize.DATE,
                allowNull: false
            },
            benefitsTypes: {
                type: Sequelize.TEXT,
                get() {
                    const value = this.getDataValue("benefitsTypes");
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue("benefitsTypes", JSON.stringify(value));
                }
            },
            location: {
                type: Sequelize.TEXT,
                get() {
                    const value = this.getDataValue("location");
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue("location", JSON.stringify(value));
                }
            },
            patientType: {
                type: Sequelize.STRING
            },
            provider: {
                type: Sequelize.TEXT,
                get() {
                    return JSON.parse(this.getDataValue("provider"));
                },
                set(value) {
                    this.setDataValue("provider", JSON.stringify(value));
                }
            },
            appStatus: {
                type: Sequelize.TEXT,
                get() {
                    return JSON.parse(this.getDataValue("appStatus"));
                },
                set(value) {
                    this.setDataValue("appStatus", JSON.stringify(value));
                }
            },
            patients: {
                type: Sequelize.TEXT,
                get() {
                    return JSON.parse(this.getDataValue("patient"));
                },
                set(value) {
                    this.setDataValue("patient", JSON.stringify(value));
                }
            },
            isFavorite: {
                type: Sequelize.BOOLEAN,
                defaultValue: false
            }
        },
            {
                timestamps: true
            }
        )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("Transaction");
    }
};