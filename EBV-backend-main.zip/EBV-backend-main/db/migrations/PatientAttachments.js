"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "PatientAttachments",
            {
              uniqueId: {
                type: Sequelize.INTEGER,
                primaryKey: true,
                autoIncrement: true
              },
              patientId: Sequelize.STRING,
              fileName: Sequelize.STRING,
              base64File: Sequelize.TEXT('long'),
              description: Sequelize.STRING,
              isPatientCard: Sequelize.STRING
            },
            {
              // Sequelize options
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("PatientAttachments");
    }
};