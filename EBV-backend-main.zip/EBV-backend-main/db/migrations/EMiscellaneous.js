"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "EMiscellaneous",
            {
              patientId: {
                type: Sequelize.STRING
              },
              eligibilityId: {
                type: Sequelize.STRING
              },
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true,
                unique: true
              },
              question: {
                type: Sequelize.STRING
              },
              answer: {
                type: Sequelize.STRING
              },
              statusflag: {
                type: Sequelize.STRING
              },
              scheduledPatientId:{
                type:Sequelize.STRING,
                references:{
                  model:'SchedulePatients',
                  key:'patientId'
                },
                onUpdate: 'CASCADE',
                onDelete: 'SET NULL'
              },
              manualPatientId:{
                type:Sequelize.STRING,
                references:{
                  model:'ManualPatients',
                  key:'patientId'
                },
                onUpdate: 'CASCADE',
                onDelete: 'SET NULL'
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("EMiscellaneous");
    }
};