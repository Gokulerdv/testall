"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable(
      "auditlog",
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true,
        },
        successType: { type: Sequelize.STRING },
        patientId: { type: Sequelize.STRING },
        sourceFrom: { type: Sequelize.STRING },
        verificationType: { type: Sequelize.STRING },
        verificationType: { type: Sequelize.STRING },
        appointmentDate: { type: Sequelize.DATE },
        lastVerified: { type: Sequelize.DATE },
        startDate: { type: Sequelize.DATE },
        endDate: { type: Sequelize.DATE },
        patientCreatedTime: { type: Sequelize.DATE },
        adminId: { type: Sequelize.STRING },
      },
      {
        timestamps: true,
      }
    );
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("auditlog");
  },
};
