"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "InsurancePayer",
            {
              payerId: {
                type: Sequelize.STRING
              },
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true
              },
              payerName: {
                type: Sequelize.STRING
              },
              clearingHouse: {
                type: Sequelize.STRING
              },
              payerLogo: {
                type: Sequelize.TEXT("long")
              },
              adminId: {
                type: Sequelize.STRING
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("InsurancePayer");
    }
};