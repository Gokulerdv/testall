"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "PayerCredential",
            {
              payer: {
                type: Sequelize.STRING
              },
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true
              },
              website: {
                type: Sequelize.STRING
              },
              username: {
                type: Sequelize.STRING
              },
              password: {
                type: Sequelize.STRING
              },
              payerLogo: {
                type: Sequelize.TEXT("long")
              },
              adminId: {
                  type: Sequelize.STRING
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("PayerCredential");
    }
};