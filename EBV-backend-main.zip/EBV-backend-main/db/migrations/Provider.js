"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "Provider",
            {
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
              },
              adminId: {
                type: Sequelize.STRING
              },
              uniqueId: {
                type: Sequelize.STRING
              },
              doctorName: {
                type: Sequelize.STRING
              },
              ssn: {
                type: Sequelize.INTEGER
              },
              npiId: {
                type: Sequelize.INTEGER
              },
              taxId: {
                type: Sequelize.INTEGER
              },
              deaNumber: {
                type: Sequelize.INTEGER
              },
              practiceName: {
                type: Sequelize.STRING
              },
              providerType: {
                type: Sequelize.STRING
              },
              location: {
                type: Sequelize.STRING
              },
              status: {
                type: Sequelize.BOOLEAN
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("Provider");
    }
};