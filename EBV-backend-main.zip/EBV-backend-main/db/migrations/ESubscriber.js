"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            'ESubscriber', {
            id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              primaryKey: true,
              autoIncrement: true
            },
            patientId: {
              type: Sequelize.STRING,
            },
            eligibilityId: {
              type: Sequelize.STRING
            },
            firstName: {
              type: Sequelize.STRING,
            },
            lastName: {
              type: Sequelize.STRING,
            },
            dateOfBirth: {
              type: Sequelize.DATE
            },
            gender: {
              type: Sequelize.STRING,
            },
            address: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("address");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("address", JSON.stringify(value));
              }
            },
            plan: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("plan");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("plan", JSON.stringify(value));
              }
            },
            statusflag: {
              type: Sequelize.STRING
            },
            isManual: {
              type: Sequelize.BOOLEAN
            },
            effectiveEndDate: {
              type: Sequelize.DATE
            },
            scheduledPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'SchedulePatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            },
            manualPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'ManualPatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            }
          }, {
            timestamps: true
          }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ESubscriber");
    }
};