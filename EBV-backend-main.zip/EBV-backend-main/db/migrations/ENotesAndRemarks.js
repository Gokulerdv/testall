"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            'ENotesAndRemark', {
            patientId: {
              type: Sequelize.STRING,
            },
            id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              primaryKey: true,
              autoIncrement: true,
              unique: true
            },
            eligibilityId: {
              type: Sequelize.STRING
            },
            data: {
              type: Sequelize.TEXT,
            },
            statusflag: {
              type: Sequelize.STRING
            },
            isManual: {
              type: Sequelize.BOOLEAN
            },
            scheduledPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'SchedulePatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            },
            manualPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'ManualPatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            }
          }, {
            timestamps: true
          }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ENotesAndRemark");
    }
};