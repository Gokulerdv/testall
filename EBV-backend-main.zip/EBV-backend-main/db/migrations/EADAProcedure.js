"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('EADAProcedure', {
            id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              primaryKey: true,
              autoIncrement:true
            },
            eligibilityId: {
              type: Sequelize.STRING
            },
            patientId: {
              type: Sequelize.STRING,
            },
            serviceType: {
              type: Sequelize.STRING,
            },
            auth: {
              type: Sequelize.STRING,
            },
            network: {
              type: Sequelize.STRING,
            },
            coverageLevel: {
              type: Sequelize.STRING,
            },
            percent: {
              type: Sequelize.STRING,
            },
            message: {
              type: Sequelize.TEXT,
            },
            insuranceType: {
              type: Sequelize.STRING,
            },
            code: {
              type: Sequelize.STRING
            },
            statusflag: {
              type: Sequelize.STRING
            },
            frequency: {
              type: Sequelize.STRING
            },
            ageLimit: {
              type: Sequelize.STRING
            },
            isManual: {
              type: Sequelize.BOOLEAN
            },
            description: {
              type: Sequelize.STRING
            },
            scheduledPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'SchedulePatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            },
            manualPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'ManualPatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            }
          }, {
            timestamps: true
          }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("EADAProcedure");
    }
};
