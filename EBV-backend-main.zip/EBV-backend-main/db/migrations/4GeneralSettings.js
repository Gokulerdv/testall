"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "GeneralSettings",
            {
              adminId: {
                type: Sequelize.STRING,
                allowNull: false,
                primaryKey: true
              },
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                autoIncrement: true,
              },
              isverifyautomatically: {
                type: Sequelize.BOOLEAN
              },
              verifyschedulestandard: {
                type: Sequelize.INTEGER
              },
              verifyschedulemedicaid: {
                type: Sequelize.INTEGER
              },
              benefitsummarystandard: {
                type: Sequelize.INTEGER
              },
              benefitsummarymedicaid: {
                type: Sequelize.INTEGER
              },
              excludeclone: {
                type: Sequelize.BOOLEAN
              },
              verifiedinpast: {
                type: Sequelize.INTEGER
              },
              warningdays: {
                type: Sequelize.INTEGER
              },
              userhistoryname: {
                type: Sequelize.STRING
              },
              ishistory: {
                type: Sequelize.BOOLEAN
              },
              verificationcodes:  {
                type: Sequelize.TEXT,
                get() {
                  const value = this.getDataValue("verificationcodes");
                  return value ? JSON.parse(value) : null;
                },
                set(value) {
                  this.setDataValue("verificationcodes", JSON.stringify(value));
                }
              },
             
            },
        
            {
              timestamps: true
            },
            
            )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("GeneralSettings");
    }
};