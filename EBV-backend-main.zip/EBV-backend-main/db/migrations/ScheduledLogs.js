"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ScheduledLog",
            {
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
              },
              adminId: {
                type: Sequelize.STRING,
                allowNull: false
              },
              scheduledaction: {
                type: Sequelize.STRING,
                allowNull: false
              },
              timeToRun: {
                type: Sequelize.STRING,
                allowNull: false
              },
              noOfPatients: {
                type: Sequelize.INTEGER,
                allowNull: false
              },
              isWeekly: {
                type: Sequelize.BOOLEAN,
                allowNull: false,
                defaultValue: false
              },
              isMonthly: {
                type: Sequelize.BOOLEAN,
                allowNull: false,
                defaultValue: false
              },
              isDaily: {
                type: Sequelize.BOOLEAN,
                allowNull: false,
                defaultValue: false
              },
              timeOfLastRun: {
                type: Sequelize.DATE,
                allowNull: true
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ScheduledLog");
    }
};