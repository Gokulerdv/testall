"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "NewPatient", {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                filtername: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                appointmentDate: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                fromDate: {
                    type: Sequelize.DATE,
                    allowNull: false
                },
                toDate: {
                    type: Sequelize.DATE,
                    allowNull: false
                },
                location: {
                    type: Sequelize.TEXT,
                    allowNull: false,
                    get() {
                        const value = this.getDataValue('location');
                        return value ? JSON.parse(value) : null;
                    },
                    set(value) {
                        this.setDataValue('location', JSON.stringify(value));
                    }
                },
                provider: {
                    type: Sequelize.TEXT,
                    get() {
                        const value = this.getDataValue('provider');
                        return value ? JSON.parse(value) : null;
                    },
                    set(value) {
                        this.setDataValue('provider', JSON.stringify(value));
                    }
                },
                patientType: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                patients: {
                    type: Sequelize.TEXT,
                    get() {
                        const value = this.getDataValue('patient');
                        return value ? JSON.parse(value) : null;
                    },
                    set(value) {
                        this.setDataValue('patient', JSON.stringify(value));
                    }
                },
                columns: {
                    type: Sequelize.TEXT,
                    allowNull: false,
                    get() {
                        const value = this.getDataValue('columns');
                        return value ? JSON.parse(value) : null;
                    },
                    set(value) {
                        this.setDataValue('columns', JSON.stringify(value));
                    }
                },
                isFavorite:{
                    type: Sequelize.BOOLEAN,
                    defaultValue: false
                }
            },
            {
                timestamps: true
            }
        )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("NewPatient");
    }
};