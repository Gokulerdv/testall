"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "UserNotification", {
            id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            typeofnotify: {
                type: Sequelize.STRING
            },
            notifyinapp: {
                type: Sequelize.TEXT,
                get() {
                    const value = this.getDataValue("notifyinapp");
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue("notifyinapp", JSON.stringify(value));
                }
            },
            timefilter: { type: Sequelize.DATE },
            isinapp: { type: Sequelize.BOOLEAN, defaultValue: false },
            isemail: { type: Sequelize.BOOLEAN, defaultValue: false },
            issms: { type: Sequelize.BOOLEAN, defaultValue: false },
        },
            {
                timestamps: true
            }
        )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("UserNotification");
    }
};