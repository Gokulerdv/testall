"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
      try{
        await queryInterface.createTable(
          "ScheduleSettings",
          {
            id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
            },
            adminId: {
              type: Sequelize.STRING,
              allowNull: false,
            },
            GeneralSettingsAdminId: {
              type: Sequelize.STRING, 
              allowNull:false,
              references: {
                model: 'GeneralSettings',
                key: 'adminId'
              }
            },
            scheduledaction: {
              type: Sequelize.STRING
            },
            timetorun: {
              type: Sequelize.STRING
            },
            numberofpatients: {
              type: Sequelize.INTEGER
            },
            statusflag: {
              type: Sequelize.STRING
            },
            weeklydays: {
              type: Sequelize.STRING // Mon-1, Tue-2, Wed-3, Thurs-4, Fri -5
            },
            isweekly: {
              type: Sequelize.BOOLEAN // whether it is weekly
            },
            ismonthly: {
              type: Sequelize.BOOLEAN // whether it is monthy
            },
            isdaily: {
              type: Sequelize.BOOLEAN // whether it is daily
            },
            everyweek: { type: Sequelize.STRING }, // Repeat for every week(twice the week)
            everymonth: { type: Sequelize.STRING }, // Repeat for Every Month (2 months once)
            oncountofdays: { type: Sequelize.STRING }, // On the day of 1st or 2nd
            oncountofweekdays: { type: Sequelize.STRING }, // On the Mon/Tue/Wed/Thurs/Fri
            oncountofweeks: { type: Sequelize.STRING } // On the weeks - first/second/third/fourth
          },
          {
            timestamps: true
          }
        )
      }catch(err){
        console.log(err)
      }
       
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ScheduleSettings");
    }
};