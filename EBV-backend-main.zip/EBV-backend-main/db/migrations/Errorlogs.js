"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "Errorlogs",
            {
              id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
              },
              adminId: {
                type: Sequelize.STRING,
                allowNull: false,
              },
              scheduleId: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references:{
                  model:{
                    tableName:'ScheduleSettings',
                    as:'ScheduleSettings'
                  },
                  key:'id'
                }
              },
              date: {
                type: Sequelize.DATE
              },
              logfile: {
                type: Sequelize.TEXT('long'),
              },
              size: {
                type: Sequelize.STRING
              }
            },
            {
              timestamps: true
            },
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("Errorlogs");
    }
};