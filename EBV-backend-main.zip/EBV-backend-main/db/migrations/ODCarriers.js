"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODCarriers",
            {
              CarrierNum: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              payersName: Sequelize.STRING,
              state: Sequelize.STRING,
              city: Sequelize.STRING,
              zipCode: Sequelize.STRING,
              address1: Sequelize.STRING,
              address2: Sequelize.STRING,
              payerIdCode: Sequelize.STRING,
              Phone: Sequelize.STRING
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODCarriers");
    }
};