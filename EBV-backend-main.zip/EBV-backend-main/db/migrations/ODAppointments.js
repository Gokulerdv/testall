"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODAppointments",
            {
              patientId: {
                type: Sequelize.STRING,
              },
              addedFrom: Sequelize.STRING,
              AptDateTime: Sequelize.TEXT("long"),
              AppointmentTypeNum: Sequelize.STRING,
              AptNum: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              ProvNum: Sequelize.STRING
            },
            {
              // Sequelize options
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODAppointments");
    }
};