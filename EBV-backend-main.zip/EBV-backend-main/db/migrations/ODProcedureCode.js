"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODProcedureCode",
          
            {
              ProcCode: {
                type: Sequelize.STRING,
              },
              CodeNum: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              description: Sequelize.STRING,
              AbbrDesc: Sequelize.STRING,
              ProcTime: Sequelize.STRING,
              procCat: Sequelize.STRING,
              ProcTime: Sequelize.STRING,
              DateTStamp: Sequelize.DATE,
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODProcedureCode");
    }
};