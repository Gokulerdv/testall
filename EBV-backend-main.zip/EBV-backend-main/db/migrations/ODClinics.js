"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODClinics",
            {
              ClinicNum: {
                type: Sequelize.INTEGER,
                primaryKey: true,
                allowNull: false
              },
              Description: Sequelize.STRING,
              State: Sequelize.STRING,
              Address: Sequelize.STRING,
              Address2: Sequelize.STRING,
              City: Sequelize.STRING,
              Zip: Sequelize.STRING,
              Phone: Sequelize.STRING,
              BillingAddress: Sequelize.STRING,
              Abbr: Sequelize.STRING
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODClinics");
    }
};