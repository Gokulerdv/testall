"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODPatients",
            {
              patientId: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              lastName: {
                type: Sequelize.STRING
              },
              firstName: {
                type: Sequelize.STRING
              },
              MiddleI: {
                type: Sequelize.STRING
              },
              Preferred: {
                type: Sequelize.STRING
              },
              PatStatus: {
                type: Sequelize.STRING
              },
              Gender: {
                type: Sequelize.STRING
              },
              Position: {
                type: Sequelize.STRING
              },
              dateOfBirth: {
                type: Sequelize.STRING
              },
              SSN: {
                type: Sequelize.STRING
              },
              Address: {
                type: Sequelize.STRING(1000)
              },
              Address2: {
                type: Sequelize.STRING(1000)
              },
              City: {
                type: Sequelize.STRING
              },
              State: {
                type: Sequelize.STRING
              },
              Zip: {
                type: Sequelize.STRING
              },
              HmPhone: {
                type: Sequelize.STRING
              },
              WkPhone: {
                type: Sequelize.STRING
              },
              WirelessPhone: {
                type: Sequelize.STRING
              },
              Guarantor: {
                type: Sequelize.INTEGER
              },
              email: {
                type: Sequelize.STRING
              },
              EstBalance: {
                type: Sequelize.STRING
              },
              PriProv: {
                type: Sequelize.STRING
              },
              priProvAbbr: {
                type: Sequelize.STRING
              },
              SecProv: {
                type: Sequelize.STRING
              },
              secProvAbbr: {
                type: Sequelize.STRING
              },
              BillingType: {
                type: Sequelize.STRING
              },
              ImageFolder: {
                type: Sequelize.STRING
              },
              FamFinUrgNote: {
                type: Sequelize.STRING
              },
              ChartNumber: {
                type: Sequelize.STRING
              },
              MedicaidID: {
                type: Sequelize.STRING
              },
              BalTotal: {
                type: Sequelize.STRING
              },
              DateFirstVisit: {
                type: Sequelize.STRING
              },
              ClinicNum: {
                type: Sequelize.INTEGER
              },
              clinicAbbr: {
                type: Sequelize.STRING
              },
              PreferConfirmMethod: {
                type: Sequelize.STRING
              },
              PreferContactMethod: {
                type: Sequelize.STRING
              },
              PreferRecallMethod: {
                type: Sequelize.STRING
              },
              Language: {
                type: Sequelize.STRING
              },
              siteDesc: {
                type: Sequelize.STRING
              },
              statusflag: {
                type: Sequelize.STRING(10)
              },
              isScheduled: {
                type: Sequelize.BOOLEAN
              },
              SuperFamily: {
                type: Sequelize.INTEGER
              },
              TxtMsgOk: {
                type: Sequelize.STRING
              },
              SecDateEntry: {
                type: Sequelize.STRING
              },
              PatCreatedAt: {
                type: Sequelize.DATE
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODPatients");
    }
};