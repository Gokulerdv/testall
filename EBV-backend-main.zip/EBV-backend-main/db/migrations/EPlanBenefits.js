"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            'EPlanBenfit', {
              patientId: {
              type: Sequelize.STRING,
            },
            id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              primaryKey: true,
              autoIncrement:true
            },
            eligibilityId: {
              type: Sequelize.STRING
            },
            data: {
              type: Sequelize.TEXT,
              get() {
                const value = this.getDataValue("data");
                return value ? JSON.parse(value) : null;
              },
              set(value) {
                this.setDataValue("data", JSON.stringify(value));
              }
            },
            statusflag: {
              type: Sequelize.STRING
            },
            isManual: {
              type: Sequelize.BOOLEAN
            }
          }, {
            timestamps: true
          }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("EPlanBenfit");
    }
};