"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODFamilyModules",
            {
              patientId: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              InsSubNum: Sequelize.STRING,
              Subscriber: Sequelize.STRING,
              subscriberName: Sequelize.STRING,
              SubscriberID: Sequelize.STRING,
              Relationship: Sequelize.STRING,
              CarrierNum: Sequelize.STRING,
              CarrierName: Sequelize.STRING,
              PlanNum: Sequelize.STRING,
              GroupName: Sequelize.STRING,
              GroupNum: Sequelize.STRING,
              planType: Sequelize.STRING,
              EmployerNum: Sequelize.STRING,
              employer: Sequelize.STRING,
              PatPlanNum: Sequelize.STRING,
              CopayFeeSched: Sequelize.STRING,
              Ordinal: Sequelize.STRING,
              Ordinaltype: Sequelize.STRING
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODFamilyModules");
    }
};