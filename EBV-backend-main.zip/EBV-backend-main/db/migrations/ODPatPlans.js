"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODPatPlans",
            {
              PatPlanNum: {
                type: Sequelize.INTEGER,
                primaryKey: true
              },
              patientId: Sequelize.INTEGER,
              Relationship: Sequelize.STRING,
              PatID: Sequelize.STRING,
              InsSubNum: Sequelize.STRING,
              PatNum: Sequelize.STRING
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODPatPlans");
    }
};