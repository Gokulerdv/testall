"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            'EPayer', {
            id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              primaryKey: true,
              autoIncrement: true
            },
            eligibilityId: {
              type: Sequelize.STRING
            },
            patientId: {
              type: Sequelize.STRING,
            },
            payerId: {
              type: Sequelize.STRING,
            },
            name: {
              type: Sequelize.STRING
            },
            statusflag: {
              type: Sequelize.STRING
            },
            isManual: {
              type: Sequelize.BOOLEAN
            },
            scheduledPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'SchedulePatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            },
            manualPatientId:{
              type:Sequelize.STRING,
              references:{
                model:'ManualPatients',
                key:'patientId'
              },
              onUpdate: 'CASCADE',
              onDelete: 'SET NULL'
            }
          }, {
            timestamps: true
          }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("EPayer");
    }
};