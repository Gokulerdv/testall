"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "SchedulePatients",
            {
              id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                allowNull: false
              },
              patientId: {
                type: Sequelize.STRING,
                allowNull: false,
                primaryKey: true
              },
              uniqueId: {
                type: Sequelize.STRING
              },
              eligibilityId: {
                type: Sequelize.STRING
              },
              addedFrom: {
                type: Sequelize.STRING
              },
              adminId: {
                type: Sequelize.STRING
              },
              verificationType: {
                type: Sequelize.STRING
              },
              statusflag: {
                type: Sequelize.STRING
              },
              firstName: {
                type: Sequelize.STRING
              },
              lastName: {
                type: Sequelize.STRING
              },
              dateOfBirth: {
                type: Sequelize.DATE
              },
              memberId: {
                type: Sequelize.STRING
              },
              groupId: {
                type: Sequelize.STRING
              },
              relationship: {
                type: Sequelize.STRING
              },
              procedureCode: {
                type: Sequelize.STRING
              },
              provider: {
                type: Sequelize.STRING
              },
              providerFirstName: {
                type: Sequelize.STRING
              },
              providerLastName: {
                type: Sequelize.STRING
              },
              providerNpi: {
                type: Sequelize.STRING
              },
              providerTaxId: {
                type: Sequelize.STRING
              },
              insurancePayer: {
                type: Sequelize.STRING
              },
              payerIdCode: {
                type: Sequelize.STRING
              },
              subscriberFirstName: {
                type: Sequelize.STRING
              },
              subscriberLastName: {
                type: Sequelize.STRING
              },
              subscriberDateOfBirth: {
                type: Sequelize.DATE
              },
              subscriberAddress: {
                type: Sequelize.STRING
              },
              subscriberAddress1: {
                type: Sequelize.STRING
              },
              subscriberCity: {
                type: Sequelize.STRING
              },
              subscriberZip: {
                type: Sequelize.STRING
              },
              subscriberState: {
                type: Sequelize.STRING
              },
              dependentFirstName: {
                type: Sequelize.STRING
              },
              dependentLastName: {
                type: Sequelize.STRING
              },
              dependentDateOfBirth: {
                type: Sequelize.DATE
              },
              typeOfService: {
                type: Sequelize.STRING
              },
              practiceNameAndLoc: {
                type: Sequelize.STRING
              },
              appointmentType: {
                type: Sequelize.STRING
              },
              scheduleAppointment: {
                type: Sequelize.DATE
              },
              speciality: {
                type: Sequelize.STRING
              },
              isVerified: {
                type: Sequelize.BOOLEAN
              },
              isVerifiedManually: {
                type: Sequelize.BOOLEAN
              },
              lastVerified: {
                type: Sequelize.DATE
              },
              remainingBenefits: {
                type: Sequelize.TEXT,
                get() {
                  const value = this.getDataValue("remainingBenefits");
                  return value ? JSON.parse(value) : null;
                },
                set(value) {
                  this.setDataValue("remainingBenefits", JSON.stringify(value));
                }
              },
              effectiveDateFrom: {
                type: Sequelize.DATE
              },
              effectiveEndDate: {
                type: Sequelize.DATE
              },
              insuranceDateOfBirth: {
                type: Sequelize.DATE
              },
              insuranceLastName: {
                type: Sequelize.STRING
              },
              insurancePhoneNumber: {
                type: Sequelize.STRING
              },
              EmpName: {
                type: Sequelize.STRING
              },
              EmployerNum: {
                type: Sequelize.STRING
              },
              planType: {
                type: Sequelize.STRING
              },
              email: {
                type: Sequelize.STRING
              },
              WirelessPhone: {
                type: Sequelize.STRING
              },
              Address: {
                type: Sequelize.STRING
              },
              Address2: {
                type: Sequelize.STRING
              },
              City: {
                type: Sequelize.STRING
              },
              Zip: {
                type: Sequelize.STRING
              },
              State: {
                type: Sequelize.STRING
              },
              gender: {
                type: Sequelize.STRING
              },
              appointmentRenderingProvider: {
                type: Sequelize.STRING
              },
              isScheduled: {
                type: Sequelize.BOOLEAN
              },
              insuranceName: {
                type: Sequelize.STRING
              },
              insurancePlan: {
                type: Sequelize.STRING
              },
              verificationError: {
                type: Sequelize.STRING
              },
              verificationErrCode: {
                type: Sequelize.STRING
              },
              verificationErrMessages: {
                type: Sequelize.TEXT,
                get() {
                  const value = this.getDataValue("verificationErrMessages");
                  return value ? JSON.parse(value) : null;
                },
                set(value) {
                  this.setDataValue("verificationErrMessages", JSON.stringify(value));
                }
              },
              empenrollmentstatus: {
                type: Sequelize.STRING
              },
              employerId: {
                type: Sequelize.STRING
              },
              employeeId: {
                type: Sequelize.STRING
              },
              empnetworkstatus: {
                type: Sequelize.STRING
              },
              empemail: {
                type: Sequelize.STRING
              },
              empWirelessPhone: {
                type: Sequelize.STRING
              },
              empAddress: {
                type: Sequelize.STRING
              },
              empAddress2: {
                type: Sequelize.STRING
              },
              empCity: {
                type: Sequelize.STRING
              },
              empZip: {
                type: Sequelize.STRING
              },
              empState: {
                type: Sequelize.STRING
              },
              empWebSite: {
                type: Sequelize.STRING
              },
              medicaidId: {
                type: Sequelize.STRING
              },
              medical:{
                type:Sequelize.BOOLEAN,
                defaultValue: false
              },
              dental:{
                type:Sequelize.BOOLEAN,
                defaultValue: false
              },
              others:{
                type:Sequelize.BOOLEAN,
                defaultValue: false
              },
              primary:{
                type:Sequelize.BOOLEAN,
                defaultValue: false
              },
              sceondary:{
                type:Sequelize.BOOLEAN,
                defaultValue: false
              },
              tertiary:{
                type:Sequelize.BOOLEAN,
                defaultValue: false
              }
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("SchedulePatients");
    }
};