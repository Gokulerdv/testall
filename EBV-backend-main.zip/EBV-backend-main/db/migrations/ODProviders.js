"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable(
            "ODProvider",
            {
              id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
              },
              ProvNum: {
                type: Sequelize.STRING,
                primaryKey: true
              },
              lastName: Sequelize.STRING,
              firstName: Sequelize.STRING,
              SSN: Sequelize.STRING,
              StateLicense: Sequelize.STRING,
              PreferredName: Sequelize.STRING,
              Specialty: Sequelize.STRING,
              NationalProvID: Sequelize.STRING
            },
            {
              timestamps: true
            }
          )
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable("ODProvider");
    }
};