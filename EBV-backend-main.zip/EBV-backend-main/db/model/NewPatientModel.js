module.exports = (sequelize, DataTypes) => {
    const newpatientModel = sequelize.define(
        "NewPatientReports", {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true
            },
            filtername: {
                type: DataTypes.STRING,
                allowNull: false, 
                unique: true
            },
            appointmentDate: {
                type: DataTypes.STRING,
                allowNull: false
            },
            fromDate: {
                type: DataTypes.DATE,
                allowNull: false
            },
            toDate: {
                type: DataTypes.DATE,
                allowNull: false
            },
            location: {
                type: DataTypes.TEXT,
                get() {
                    const value = this.getDataValue('location');
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue('location', JSON.stringify(value));
                }
            },
            provider: {
                type: DataTypes.TEXT,
                get() {
                    const value = this.getDataValue('provider');
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue('provider', JSON.stringify(value));
                }
            },
            patientType: {
                type: DataTypes.STRING,
                get() {
                    const value = this.getDataValue('patientType');
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue('patientType', JSON.stringify(value));
                }
            },
            patients: {
                type: DataTypes.TEXT,
                get() {
                    const value = this.getDataValue('patients');
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue('patients', JSON.stringify(value));
                }
            },
            columns: {
                type: DataTypes.TEXT,
                get() {
                    const value = this.getDataValue('columns');
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue('columns', JSON.stringify(value));
                }
            },
            pdf: {
                type: DataTypes.TEXT,
                get() {
                    const value = this.getDataValue('pdf');
                    return value ? JSON.parse(value) : null;
                },
                set(value) {
                    this.setDataValue('pdf', JSON.stringify(value));
                }
            },
            isFavorite:{
                type: DataTypes.BOOLEAN,
                defaultValue: false
            }
        },
        {
            timestamps: true
        }
    );
    return newpatientModel;
};
