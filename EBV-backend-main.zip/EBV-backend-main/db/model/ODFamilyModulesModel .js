module.exports = (sequelize, DataTypes) => {
  const ODFamilyModulesModel = sequelize.define(
    "ODFamilyModules",//tablename
    {
      patientId: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      InsSubNum: DataTypes.STRING,
      Subscriber: DataTypes.STRING,
      subscriberName: DataTypes.STRING,
      SubscriberID: DataTypes.STRING,
      Relationship: DataTypes.STRING,
      CarrierNum: DataTypes.STRING,
      CarrierName: DataTypes.STRING,
      PlanNum: DataTypes.STRING,
      GroupName: DataTypes.STRING,
      GroupNum: DataTypes.STRING,
      planType: DataTypes.STRING,
      EmployerNum: DataTypes.STRING,
      employer: DataTypes.STRING,
      PatPlanNum: DataTypes.STRING,
      CopayFeeSched: DataTypes.STRING,
      Ordinal: DataTypes.STRING,
      Ordinaltype: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODFamilyModulesModel.associate = function (models) {
    // associations can be defined here
    //   ODFamilyModulesModel.belongsTo(models.product);
  };
  return ODFamilyModulesModel;
};
