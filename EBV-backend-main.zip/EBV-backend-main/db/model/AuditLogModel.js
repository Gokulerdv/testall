module.exports = (sequelize, DataTypes) => {
  const AudilogModel = sequelize.define(
    "auditlog",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      successType: {
        type: DataTypes.STRING, // Success, Technical Error, Invalid Demographic, Not Linked_red, Not Verified_blue
      },
      patientId: {
        type: DataTypes.STRING,
      },
      sourceFrom: {
        type: DataTypes.STRING, // PMS, IMPORT, MANUAL
      },
      verificationType: {
        type: DataTypes.STRING,
      },
      appointmentDate: {
        type: DataTypes.DATE,
      },
      lastVerified: {
        type: DataTypes.DATE,
      },
      startDate: {
        type: DataTypes.DATE
      },
      endDate: {
        type: DataTypes.DATE,
      },
      patientCreatedTime: {
        type: DataTypes.DATE,
      },
      adminId: {
        type: DataTypes.STRING,
      },
    },
    {
      timestamps: true,
    }
  );
  return AudilogModel;
};
