module.exports = (sequelize, DataTypes) => {
  const PendingEligibility = sequelize.define(
    "PendingEligibilityReports", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    filterName: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    fromDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    toDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    insuranceHierarchy: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("insuranceHierarchy");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("insuranceHierarchy", JSON.stringify(value));
      }
    },
    location: {
      type: DataTypes.STRING,
      get() {
        const value = this.getDataValue("location");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("location", JSON.stringify(value));
      }
    },
    patients: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("patients");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("patients", JSON.stringify(value));
      }

    },
    provider: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("provider");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("provider", JSON.stringify(value));
      }
    },
    lastEligibility: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("lastEligibility");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("lastEligibility", JSON.stringify(value));
      }
    },
    insuranceStatus: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("insuranceStatus");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("insuranceStatus", JSON.stringify(value));
      }
    },
    daysGreaterThan: {
      type: DataTypes.STRING,
      allowNull: false
    },
    insuranceType: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("insuranceType");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("insuranceType", JSON.stringify(value));
      }
    },
    columns: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("columns");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("columns", JSON.stringify(value));
      }
    },
    payer: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("payer");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("payer", JSON.stringify(value));
      }
    },
    pdf: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("pdf");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("pdf", JSON.stringify(value));
      }
    },
    isFavorite: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }
  },
    {
      timestamps: true
    }
  )
  return PendingEligibility
}