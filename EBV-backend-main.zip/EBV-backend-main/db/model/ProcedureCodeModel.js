module.exports = (sequelize, DataTypes) => {
  const ProcedureCodeModel = sequelize.define(
    "ProcedureCode", //tablename
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      procedureCode: {
        type: DataTypes.STRING
      },
      description: DataTypes.STRING,
      AbbrDesc: DataTypes.STRING,
      procedureType: DataTypes.STRING
    },
    {
      timestamps: true
    }
  );
  ProcedureCodeModel.associate = function (models) {
    // associations can be defined here
    //   ProcedureCodeModel.belongsTo(models.product);
  };
  return ProcedureCodeModel;
};
