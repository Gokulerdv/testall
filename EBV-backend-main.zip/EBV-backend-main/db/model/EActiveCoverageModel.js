module.exports = (sequelize, DataTypes) => {
  const ActiveCoverageModel = sequelize.define(
    'EActiveCoverages', {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement:true
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    patientId: {
      type: DataTypes.STRING,
    },
    serviceType: {
      type: DataTypes.STRING,
    },
    planCoverageDescription: {
      type: DataTypes.STRING,
    },
    message: {
      type: DataTypes.TEXT,
    },
    insuranceType: {
      type: DataTypes.STRING
    },
    statusflag: {
      type: DataTypes.STRING
    },
    code: {
      type: DataTypes.STRING
    },
    effectiveDateFrom: {
      type: DataTypes.STRING
    },
    planPeriod: {
      type: DataTypes.STRING
    },
    percent: {
      type: DataTypes.STRING
    },
    waitingPeriodApplies: {
      type: DataTypes.STRING
    },
    auth: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    },
    network: {
      type: DataTypes.STRING
    },
    coverageLevel: {
      type: DataTypes.STRING
    },
    waitingPeriod:{
      type: DataTypes.STRING
    }
  }, {
    timestamps: true
  }
  )
  ActiveCoverageModel.associate = function (models) {
    // associations can be defined here
  };
  return ActiveCoverageModel;
};
