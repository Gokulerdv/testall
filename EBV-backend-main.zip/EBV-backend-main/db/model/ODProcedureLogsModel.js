module.exports = (sequelize, DataTypes) => {
  const ODProcedureLogsModel = sequelize.define(
    "ODProcedureLog",//tablename
    {
      ProcNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      PatNum: {
        type: DataTypes.STRING,
      },
      AptNum: {
        type: DataTypes.STRING,
      },
      ProvNum: {
        type: DataTypes.STRING
      },
      procCode: {
        type: DataTypes.STRING,
      },
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODProcedureLogsModel.associate = function (models) {
    // associations can be defined here
    //   ODProcedureLogsModel.belongsTo(models.product);
  };
  return ODProcedureLogsModel;
};
