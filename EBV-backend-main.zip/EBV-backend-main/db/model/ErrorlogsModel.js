module.exports = (sequelize, DataTypes) => {
  const ErrorlogModel = sequelize.define(
    "Errorlogs",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      adminId: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      scheduleId: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      date: {
        type: DataTypes.DATE
      },
      logfile: {
        type: DataTypes.TEXT('long'),
      },
      size: {
        type: DataTypes.STRING
      }
    },
    {
      timestamps: true
    },
  )
  ErrorlogModel.associate = function (models) {
    ErrorlogModel.belongsTo(models.ScheduleSettings, {
      foreignKey: 'scheduleId',
    });
  }
  return ErrorlogModel;
};