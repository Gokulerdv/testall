module.exports = (sequelize, DataTypes) => {
  const ODPatientsModel = sequelize.define(
    "ODPatients",
    {
      patientId: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      lastName: {
        type: DataTypes.STRING
      },
      firstName: {
        type: DataTypes.STRING
      },
      MiddleI: {
        type: DataTypes.STRING
      },
      Preferred: {
        type: DataTypes.STRING
      },
      PatStatus: {
        type: DataTypes.STRING
      },
      Gender: {
        type: DataTypes.STRING
      },
      Position: {
        type: DataTypes.STRING
      },
      dateOfBirth: {
        type: DataTypes.STRING
      },
      SSN: {
        type: DataTypes.STRING
      },
      Address: {
        type: DataTypes.STRING(1000)
      },
      Address2: {
        type: DataTypes.STRING(1000)
      },
      City: {
        type: DataTypes.STRING
      },
      State: {
        type: DataTypes.STRING
      },
      Zip: {
        type: DataTypes.STRING
      },
      HmPhone: {
        type: DataTypes.STRING
      },
      WkPhone: {
        type: DataTypes.STRING
      },
      WirelessPhone: {
        type: DataTypes.STRING
      },
      Guarantor: {
        type: DataTypes.INTEGER
      },
      email: {
        type: DataTypes.STRING
      },
      EstBalance: {
        type: DataTypes.STRING
      },
      PriProv: {
        type: DataTypes.STRING
      },
      priProvAbbr: {
        type: DataTypes.STRING
      },
      SecProv: {
        type: DataTypes.STRING
      },
      secProvAbbr: {
        type: DataTypes.STRING
      },
      BillingType: {
        type: DataTypes.STRING
      },
      ImageFolder: {
        type: DataTypes.STRING
      },
      FamFinUrgNote: {
        type: DataTypes.STRING
      },
      ChartNumber: {
        type: DataTypes.STRING
      },
      MedicaidID: {
        type: DataTypes.STRING
      },
      BalTotal: {
        type: DataTypes.STRING
      },
      DateFirstVisit: {
        type: DataTypes.STRING
      },
      ClinicNum: {
        type: DataTypes.INTEGER
      },
      clinicAbbr: {
        type: DataTypes.STRING
      },
      PreferConfirmMethod: {
        type: DataTypes.STRING
      },
      PreferContactMethod: {
        type: DataTypes.STRING
      },
      PreferRecallMethod: {
        type: DataTypes.STRING
      },
      Language: {
        type: DataTypes.STRING
      },
      siteDesc: {
        type: DataTypes.STRING
      },
      statusflag: {
        type: DataTypes.STRING(10)
      },
      isScheduled: {
        type: DataTypes.BOOLEAN
      },
      SuperFamily: {
        type: DataTypes.INTEGER
      },
      TxtMsgOk: {
        type: DataTypes.STRING
      },
      SecDateEntry: {
        type: DataTypes.STRING
      },
      PatCreatedAt: {
        type: DataTypes.DATE
      }
    },
    {
      timestamps: true
      // Model options (if any)
    }
  );
  ODPatientsModel.associate = function (models) {
    // associations can be defined here
    //   ODPatientsModel.belongsTo(models.product);
  };
  return ODPatientsModel;
};
