module.exports = (sequelize, DataTypes) => {
  const ODProvidersModel = sequelize.define(
    "ODProvider",//tablename
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
      },
      ProvNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      lastName: DataTypes.STRING,
      firstName: DataTypes.STRING,
      SSN: DataTypes.STRING,
      StateLicense: DataTypes.STRING,
      PreferredName: DataTypes.STRING,
      Specialty: DataTypes.STRING,
      NationalProvID: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODProvidersModel.associate = function (models) {
    // associations can be defined here
    //   ODProvidersModel.belongsTo(models.product);
  };
  return ODProvidersModel;
};
