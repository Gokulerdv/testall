module.exports = (sequelize, DataTypes) => {
  const ODAppointmentsTypesModel = sequelize.define(
    "ODAppointmentTypes", //tablename
    {
      AppointmentTypeNum: {
        type: DataTypes.INTEGER,
        primaryKey: true
      },
      AppointmentTypeName: DataTypes.STRING,
      appointmentTypeColor: DataTypes.STRING,
      RequiredProcCodesNeeded: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODAppointmentsTypesModel.associate = function (models) {
    // associations can be defined here
    //   ODAppointmentsTypesModel.belongsTo(models.product);
  };
  return ODAppointmentsTypesModel;
};
