module.exports = (sequelize, DataTypes) => {
  const InsurancePayerModel = sequelize.define(
    "InsurancePayer",
    {
      payerId: {
        type: DataTypes.STRING
      },
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      payerName: {
        type: DataTypes.STRING
      },
      clearingHouse: {
        type: DataTypes.STRING
      },
      payerLogo: {
        type: DataTypes.TEXT("long")
      },
      adminId: {
        type: DataTypes.STRING
      }
    },
    {
      timestamps: true
    }
  );
  return InsurancePayerModel;
};
