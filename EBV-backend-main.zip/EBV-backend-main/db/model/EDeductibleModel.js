module.exports = (sequelize, DataTypes) => {
  const DeductibleModel = sequelize.define(
    'EDeductible', {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement:true
    },
    patientId: {
      type: DataTypes.STRING,
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    serviceType: {
      type: DataTypes.STRING,
    },
    network: {
      type: DataTypes.STRING,
    },
    coverageLevel: {
      type: DataTypes.STRING,
    },
    planPeriod: {
      type: DataTypes.STRING,
    },
    amount: {
      type: DataTypes.STRING,
    },
    insuranceType: {
      type: DataTypes.STRING
    },
    statusflag: {
      type: DataTypes.STRING
    },
    code: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    },
    planCoverageDescription: {
      type: DataTypes.STRING
    },
    message: {
      type: DataTypes.TEXT,
    }
  }, {
    timestamps: true
  }
  )
  DeductibleModel.associate = function (models) {
    // associations can be defined here
  };
  return DeductibleModel;
};
