module.exports = (sequelize, DataTypes) => {
    const TransactionModel = sequelize.define(
        "TransactionReports", {
        filterName: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        fromDate: {
            type: DataTypes.DATE,
            allowNull: false
        },
        toDate: {
            type: DataTypes.DATE,
            allowNull: false
        },
        benefitsTypes: {
            type: DataTypes.TEXT,
            get() {
                const value = this.getDataValue("benefitsTypes");
                return value ? JSON.parse(value) : null;
            },
            set(value) {
                this.setDataValue("benefitsTypes", JSON.stringify(value));
            }
        },
        location: {
            type: DataTypes.TEXT,
            get() {
                const value = this.getDataValue("location");
                return value ? JSON.parse(value) : null;
            },
            set(value) {
                this.setDataValue("location", JSON.stringify(value));
            }
        },
        patientType: {
            type: DataTypes.STRING,
            get() {
                const value = this.getDataValue("patientType");
                return value ? JSON.parse(value) : null;
            },
            set(value) {
                this.setDataValue("patientType", JSON.stringify(value));
            }
        },
        provider: {
            type: DataTypes.TEXT,
            get() {
                const value = this.getDataValue("provider");
                return value ? JSON.parse(value) : null;
            },
            set(value) {
                this.setDataValue("provider", JSON.stringify(value));
            }
        },
        pdf: {
            type: DataTypes.TEXT,
            get() {
              const value = this.getDataValue("pdf");
              return value ? JSON.parse(value) : null;
            },
            set(value) {
              this.setDataValue("pdf", JSON.stringify(value));
            }
          },
        appStatus: {
            type: DataTypes.TEXT,
            get() {
                const value = this.getDataValue("appStatus");
                return value ? JSON.parse(value) : null;
            },
            set(value) {
                this.setDataValue("appStatus", JSON.stringify(value));
            }
        },
        patients: {
            type: DataTypes.TEXT,
            get() {
                const value = this.getDataValue("patients");
                return value ? JSON.parse(value) : null;
            },
            set(value) {
                this.setDataValue("patients", JSON.stringify(value));
            }
        },
        isFavorite: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        }
    },
        {
            timestamps: true
        }
    );

    return TransactionModel;
};
