module.exports = (sequelize, DataTypes) => {
  const GeneralSettingsModel = sequelize.define(
    "GeneralSettings",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
      },
      adminId: {
        type: DataTypes.STRING,
        primaryKey: true,
        allowNull: false
      },
      // Toggle button in General settings screen
      isverifyautomatically: {
        type: DataTypes.BOOLEAN
      },
      // Date until scheduled appointment - standard
      verifyschedulestandard: {
        type: DataTypes.INTEGER
      },
      // Date until scheduled appointment - medicaid
      verifyschedulemedicaid: {
        type: DataTypes.INTEGER
      },
      // Benefit summary not verified in - standard
      benefitsummarystandard: {
        type: DataTypes.INTEGER
      },
      // Benefit summary not verified in - medicaid
      benefitsummarymedicaid: {
        type: DataTypes.INTEGER
      },
      excludeclone: {
        type: DataTypes.BOOLEAN
      },
      // Do not verify patients that have been verified in the past 
      verifiedinpast: {
        type: DataTypes.INTEGER
      },
      warningdays: {
        type: DataTypes.INTEGER
      },
      userhistoryname: {
        type: DataTypes.STRING
      },
      ishistory: {
        type: DataTypes.BOOLEAN
      },
      activedays: {
        type: DataTypes.INTEGER
      },
      verificationcodes: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("verificationcodes");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("verificationcodes", JSON.stringify(value));
        }
      },
    },

    {
      timestamps: true
    },
  );

  GeneralSettingsModel.associate = function (models) {
    // associations can be defined here
    GeneralSettingsModel.hasMany(models.ScheduleSettings, {
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
  };
  return GeneralSettingsModel;
};
