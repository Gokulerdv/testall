module.exports = (sequelize, DataTypes) => {
  const SubscriberModel = sequelize.define(
    'ESubscriber', {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    patientId: {
      type: DataTypes.STRING,
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    firstName: {
      type: DataTypes.STRING,
    },
    lastName: {
      type: DataTypes.STRING,
    },
    dateOfBirth: {
      type: DataTypes.DATE
    },
    gender: {
      type: DataTypes.STRING,
    },
    address: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("address");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("address", JSON.stringify(value));
      }
    },
    plan: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("plan");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("plan", JSON.stringify(value));
      }
    },
    statusflag: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    },
    effectiveEndDate: {
      type: DataTypes.DATE
    }
  }, {
    timestamps: true
  }
  )
  SubscriberModel.associate = function (models) {
    // associations can be defined here
  };
  return SubscriberModel;
};
