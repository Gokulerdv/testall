module.exports = (sequelize, DataTypes) => {
  const PlanBenefitsModel = sequelize.define(
    'EPlanBenfit', {
      patientId: {
      type: DataTypes.STRING,
    },
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement:true
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    data: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("data");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("data", JSON.stringify(value));
      }
    },
    statusflag: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    }
  }, {
    timestamps: true
  }
  )
 PlanBenefitsModel.associate = function (models) {
    // associations can be defined here
  };
  return PlanBenefitsModel;
};
