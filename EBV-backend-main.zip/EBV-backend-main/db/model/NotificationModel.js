module.exports = (sequelize, DataTypes) => {
  const NotificationModel = sequelize.define("Notification", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    iscsv: {
      type: DataTypes.BOOLEAN
    },
    isScheduled: {
      type: DataTypes.BOOLEAN
    },
    isSuccess: {
      type: DataTypes.BOOLEAN
    },
    istechnical: {
      type: DataTypes.BOOLEAN
    },
    notlinked: {
      type: DataTypes.BOOLEAN
    },
    demographic: {
      type: DataTypes.BOOLEAN
    },
    message: {
      type: DataTypes.STRING
    },
    adminId: {
      type: DataTypes.STRING
    },
    patientId: {
      type: DataTypes.STRING
    },
    patientName: {
      type: DataTypes.STRING
    },
    isPatientUpdate: {
      type: DataTypes.BOOLEAN
    },
    isPatientDelete: {
      type: DataTypes.BOOLEAN
    },
    isRead: {
      type: DataTypes.BOOLEAN
    }
  });

  return NotificationModel;
};
