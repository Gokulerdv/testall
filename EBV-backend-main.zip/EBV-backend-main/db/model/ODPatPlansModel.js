module.exports = (sequelize, DataTypes) => {
  const ODPatPlansModel = sequelize.define(
    "ODPatPlans",//tablename
    {
      PatPlanNum: {
        type: DataTypes.INTEGER,
        primaryKey: true
      },
      patientId: DataTypes.INTEGER,
      Relationship: DataTypes.STRING,
      PatID: DataTypes.STRING,
      InsSubNum: DataTypes.STRING,
      PatNum: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODPatPlansModel.associate = function (models) {
    // associations can be defined here
    //   ODPatPlansModel.belongsTo(models.product);
  };
  return ODPatPlansModel;
};
