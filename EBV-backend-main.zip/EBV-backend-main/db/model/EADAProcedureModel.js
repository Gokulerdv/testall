module.exports = (sequelize, DataTypes) => {
  const ADAProcedureModel = sequelize.define(
    'EADAProcedure', {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement:true
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    patientId: {
      type: DataTypes.STRING,
    },
    serviceType: {
      type: DataTypes.STRING,
    },
    auth: {
      type: DataTypes.STRING,
    },
    network: {
      type: DataTypes.STRING,
    },
    coverageLevel: {
      type: DataTypes.STRING,
    },
    percent: {
      type: DataTypes.STRING,
    },
    message: {
      type: DataTypes.TEXT,
    },
    insuranceType: {
      type: DataTypes.STRING,
    },
    code: {
      type: DataTypes.STRING
    },
    statusflag: {
      type: DataTypes.STRING
    },
    frequency: {
      type: DataTypes.STRING
    },
    ageLimit: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    },
    description: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true
  }
  )
  ADAProcedureModel.associate = function (models) {
    // associations can be defined here
  };
  return ADAProcedureModel;
};
