module.exports = (sequelize, DataTypes) => {
  const MiscellaneousModel = sequelize.define(
    "EMiscellaneous",
    {
      patientId: {
        type: DataTypes.STRING
      },
      eligibilityId: {
        type: DataTypes.STRING
      },
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        unique: true
      },
      question: {
        type: DataTypes.STRING
      },
      answer: {
        type: DataTypes.STRING
      },
      statusflag: {
        type: DataTypes.STRING
      }
    },
    {
      timestamps: true
    }
  );
  MiscellaneousModel.associate = function (models) {
    // associations can be defined here
  };
  return MiscellaneousModel;
};
