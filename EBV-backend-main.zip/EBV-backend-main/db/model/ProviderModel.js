module.exports = (sequelize, DataTypes) => {
  const ProviderModel = sequelize.define(
    "Provider",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      adminId: {
        type: DataTypes.STRING
      },
      uniqueId: {
        type: DataTypes.STRING
      },
      doctorName: {
        type: DataTypes.STRING
      },
      ssn: {
        type: DataTypes.STRING
      },
      npiId: {
        type: DataTypes.STRING,
        unique: true
      },
      taxId: {
        type: DataTypes.STRING,
        unique: true
      },
      deaNumber: {
        type: DataTypes.STRING
      },
      practiceName: {
        type: DataTypes.STRING
      },
      providerType: {
        type: DataTypes.STRING
      },
      location: {
        type: DataTypes.STRING
      },
      status: {
        type: DataTypes.BOOLEAN
      }
    },
    {
      timestamps: true
    }
  );
  ProviderModel.associate = function (models) {
    // associations can be defined here
  };
  return ProviderModel;
};
