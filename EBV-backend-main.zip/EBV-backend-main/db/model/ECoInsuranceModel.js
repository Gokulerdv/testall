module.exports = (sequelize, DataTypes) => {
  const CoInsuranceModel = sequelize.define(
    "ECoInsurance",
    {
      eligibilityId: {
        type: DataTypes.STRING
      },
      patientId: {
        type: DataTypes.STRING
      },
      serviceType: {
        type: DataTypes.STRING
      },
      network: {
        type: DataTypes.STRING
      },
      coverageLevel: {
        type: DataTypes.STRING
      },
      percent: {
        type: DataTypes.STRING
      },
      insuranceType: {
        type: DataTypes.STRING
      },
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        unique: true
      },
      code: {
        type: DataTypes.STRING
      },
      planPeriod: {
        type: DataTypes.STRING
      },
      amount: {
        type: DataTypes.STRING
      },
      statusflag: {
        type: DataTypes.STRING
      },
      isManual: {
        type: DataTypes.BOOLEAN
      },
      planCoverageDescription: {
        type: DataTypes.STRING
      },
      message: {
        type: DataTypes.TEXT
      }, 
      type: {
        type: DataTypes.STRING
      }
    },
    {
      timestamps: true
    }
  );
  CoInsuranceModel.associate = function (models) {
    // associations can be defined here
  };
  return CoInsuranceModel;
};
