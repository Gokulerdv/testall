module.exports = (sequelize, DataTypes) => {
  const PatientNotificationModel = sequelize.define(
    "PatientNotification",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      typeofnotify: {
        // manual, opendental, csv,
        type: DataTypes.STRING,
        unique: true
      },
      notifyinapp: {
        // [success, demographic, technical, notlinked, manual, opendental, csv]
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("notifyinapp");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("notifyinapp", JSON.stringify(value));
        }
      },
    //   isscheduled: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   ismanual: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   isimport: { type: DataTypes.BOOLEAN, defaultValue: false },
      isinapp: { type: DataTypes.BOOLEAN, defaultValue: false },
      isemail: { type: DataTypes.BOOLEAN, defaultValue: false },
      issms: { type: DataTypes.BOOLEAN, defaultValue: false }
    },
    {
      timestamps: true
    }
  );
  PatientNotificationModel.associate = function (models) {
    // associations can be defined here
  };
  return PatientNotificationModel;
};
