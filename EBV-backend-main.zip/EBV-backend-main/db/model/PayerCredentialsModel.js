module.exports = (sequelize, DataTypes) => {
  const PayerCredentialsModel = sequelize.define(
    "PayerCredential",
    {
      payer: {
        type: DataTypes.STRING
      },
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      website: {
        type: DataTypes.STRING
      },
      username: {
        type: DataTypes.STRING
      },
      password: {
        type: DataTypes.STRING
      },
      payerLogo: {
        type: DataTypes.TEXT("long")
      },
      adminId: {
          type: DataTypes.STRING
      }
    },
    {
      timestamps: true
    }
  );
  return PayerCredentialsModel;
};
