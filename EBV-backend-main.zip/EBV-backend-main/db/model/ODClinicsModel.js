module.exports = (sequelize, DataTypes) => {
  const ODClinicsModel = sequelize.define(
    "ODClinics",//tablename
    {
      ClinicNum: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
      },
      Description: DataTypes.STRING,
      State: DataTypes.STRING,
      Address: DataTypes.STRING,
      Address2: DataTypes.STRING,
      City: DataTypes.STRING,
      Zip: DataTypes.STRING,
      Phone: DataTypes.STRING,
      BillingAddress: DataTypes.STRING,
      Abbr: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODClinicsModel.associate = function (models) {
    // associations can be defined here
    //   ODClinicsModel.belongsTo(models.product);
  };
  return ODClinicsModel;
};
