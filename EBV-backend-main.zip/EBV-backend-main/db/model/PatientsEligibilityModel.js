module.exports = (sequelize, DataTypes) => {
  const PatientsEligibilityModel = sequelize.define(
    "PatientEligibility",
    {
      patientId: {
        type: DataTypes.STRING,
        allowNull: false
      },
      eligibilityId: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true
      },
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false
      },
      adminId: {
        type: DataTypes.STRING
      },
      uniqueId: {
        type: DataTypes.STRING
      },
      lastverified: {
        type: DataTypes.STRING
      },
      verificationType: {
        type: DataTypes.STRING
      },
      coInsurance: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("coInsurance");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("coInsurance", JSON.stringify(value));
        }
      },
      payer: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("payer");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("payer", JSON.stringify(value));
        }
      },
      subscriber: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("subscriber");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("subscriber", JSON.stringify(value));
        }
      },
      patient: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("patient");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("patient", JSON.stringify(value));
        }
      },
      planBenefits: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("planBenefits");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("planBenefits", JSON.stringify(value));
        }
      },
      deductible: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("deductible");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("deductible", JSON.stringify(value));
        }
      },
      limitationAndMaximum: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("limitationAndMaximum");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("limitationAndMaximum", JSON.stringify(value));
        }
      },
      notCovered: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("notCovered");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("notCovered", JSON.stringify(value));
        }
      },
      maximum: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("maximum");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("maximum", JSON.stringify(value));
        }
      },
      limitation: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("limitation");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("limitation", JSON.stringify(value));
        }
      },
      miscellaneous: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("miscellaneous");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("miscellaneous", JSON.stringify(value));
        }
      },
      notesAndRemarks: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("notesAndRemarks");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("notesAndRemarks", JSON.stringify(value));
        }
      },
      errors: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("errors");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("errors", JSON.stringify(value));
        }
      },
      activeCoverage: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("activeCoverage");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("activeCoverage", JSON.stringify(value));
        }
      }
    },
    {
      timestamps: true
    }
  );
  PatientsEligibilityModel.associate = function (models) {
    // associations can be defined here
  };
  return PatientsEligibilityModel;
};
