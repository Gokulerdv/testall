module.exports = (sequelize, DataTypes) => {
  const ScheduleSettingsModel = sequelize.define(
    "ScheduleSettings",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      adminId: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      GeneralSettingsAdminId:{
        type:DataTypes.STRING
      },
      scheduledaction: {
        type: DataTypes.STRING
      },
      timetorun: {
        type: DataTypes.STRING
      },
      numberofpatients: {
        type: DataTypes.INTEGER
      },
      statusflag: {
        type: DataTypes.STRING
      },
      weeklydays: {
        type: DataTypes.STRING // Mon-1, Tue-2, Wed-3, Thurs-4, Fri -5
      },
      isweekly: {
        type: DataTypes.BOOLEAN // whether it is weekly
      },
      ismonthly: {
        type: DataTypes.BOOLEAN // whether it is monthy
      },
      isdaily: {
        type: DataTypes.BOOLEAN // whether it is daily
      },
      everyweek: { type: DataTypes.STRING }, // Repeat for every week(twice the week)
      everymonth: { type: DataTypes.STRING }, // Repeat for Every Month (2 months once)
      oncountofdays: { type: DataTypes.STRING }, // On the day of 1st or 2nd
      oncountofweekdays: { type: DataTypes.STRING }, // On the Mon/Tue/Wed/Thurs/Fri
      oncountofweeks: { type: DataTypes.STRING } // On the weeks - first/second/third/fourth
    },
    {
      timestamps: true
    }
  );
  ScheduleSettingsModel.associate = function (models) {
    // associations can be defined here
    ScheduleSettingsModel.hasMany(models.Errorlogs, {
      foreignKey: 'scheduleId'
    })
  };
  return ScheduleSettingsModel;
};
