module.exports = (sequelize, DataTypes) => {
  const ODCarriersModel = sequelize.define(
    "ODCarriers",//tablename
    {
      CarrierNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      payersName: DataTypes.STRING,
      state: DataTypes.STRING,
      city: DataTypes.STRING,
      zipCode: DataTypes.STRING,
      address1: DataTypes.STRING,
      address2: DataTypes.STRING,
      payerIdCode: DataTypes.STRING,
      Phone: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODCarriersModel.associate = function (models) {
    // associations can be defined here
    //   ODCarriersModel.belongsTo(models.product);
  };
  return ODCarriersModel;
};
