module.exports = (sequelize, DataTypes) => {
  const ELimitationMaximumModel = sequelize.define(
    'ELimitationMaximum', {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement:true
    },
    patientId: {
      type: DataTypes.STRING,
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    code: {
      type: DataTypes.STRING,
    },
    serviceType: {
      type: DataTypes.STRING,
    },
    network: {
      type: DataTypes.STRING,
    },
    coverageLevel: {
      type: DataTypes.STRING,
    },
    planPeriod: {
      type: DataTypes.STRING,
    },
    amount: {
      type: DataTypes.STRING,
    },
    insuranceType: {
      type: DataTypes.STRING
    },
    statusflag: {
      type: DataTypes.STRING
    },
    benefitAge: {
      type: DataTypes.STRING
    },
    limitation: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("limitation");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("limitation", JSON.stringify(value));
      }
    },
    serviceDates: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue("serviceDates");
        return value ? JSON.parse(value) : null;
      },
      set(value) {
        this.setDataValue("serviceDates", JSON.stringify(value));
      }
    },
    planCoverageDescription: {
      type: DataTypes.STRING
    }, 
    auth: {
      type: DataTypes.STRING
    },
    message: {
      type: DataTypes.TEXT,
    }
  }, {
      timestamps: true
    }
  )
  ELimitationMaximumModel.associate = function (models) {
    // associations can be defined here
  };
  return ELimitationMaximumModel;
};
