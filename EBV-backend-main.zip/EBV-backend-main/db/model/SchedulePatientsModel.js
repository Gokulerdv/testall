module.exports = (sequelize, DataTypes) => {
  const SchedulePatientsModel = sequelize.define(
    "SchedulePatients",
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false
      },
      patientId: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true
      },
      uniqueId: {
        type: DataTypes.STRING
      },
      eligibilityId: {
        type: DataTypes.STRING
      },
      addedFrom: {
        type: DataTypes.STRING
      },
      adminId: {
        type: DataTypes.STRING
      },
      verificationType: {
        type: DataTypes.STRING
      },
      statusflag: {
        type: DataTypes.STRING
      },
      firstName: {
        type: DataTypes.STRING
      },
      lastName: {
        type: DataTypes.STRING
      },
      dateOfBirth: {
        type: DataTypes.DATE
      },
      memberId: {
        type: DataTypes.STRING
      },
      groupId: {
        type: DataTypes.STRING
      },
      relationship: {
        type: DataTypes.STRING
      },
      procedureCode: {
        type: DataTypes.STRING
      },
      procedureType: {
        type: DataTypes.STRING
      },
      provider: {
        type: DataTypes.STRING
      },
      providerFirstName: {
        type: DataTypes.STRING
      },
      providerLastName: {
        type: DataTypes.STRING
      },
      providerNpi: {
        type: DataTypes.STRING
      },
      providerTaxId: {
        type: DataTypes.STRING
      },
      insurancePayer: {
        type: DataTypes.STRING
      },
      payerIdCode: {
        type: DataTypes.STRING
      },
      subscriberFirstName: {
        type: DataTypes.STRING
      },
      subscriberLastName: {
        type: DataTypes.STRING
      },
      subscriberDateOfBirth: {
        type: DataTypes.DATE
      },
      subscriberAddress: {
        type: DataTypes.STRING
      },
      subscriberAddress1: {
        type: DataTypes.STRING
      },
      subscriberCity: {
        type: DataTypes.STRING
      },
      subscriberZip: {
        type: DataTypes.STRING
      },
      subscriberState: {
        type: DataTypes.STRING
      },
      dependentFirstName: {
        type: DataTypes.STRING
      },
      dependentLastName: {
        type: DataTypes.STRING
      },
      dependentDateOfBirth: {
        type: DataTypes.DATE
      },
      typeOfService: {
        type: DataTypes.STRING
      },
      practiceNameAndLoc: {
        type: DataTypes.STRING
      },
      appointmentType: {
        type: DataTypes.STRING
      },
      scheduleAppointment: {
        type: DataTypes.DATE
      },
      speciality: {
        type: DataTypes.STRING
      },
      isVerified: {
        type: DataTypes.BOOLEAN
      },
      isVerifiedManually: {
        type: DataTypes.BOOLEAN
      },
      lastVerified: {
        type: DataTypes.DATE
      },
      remainingBenefits: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("remainingBenefits");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("remainingBenefits", JSON.stringify(value));
        }
      },
      effectiveDateFrom: {
        type: DataTypes.DATE
      },
      effectiveEndDate: {
        type: DataTypes.DATE
      },
      insuranceDateOfBirth: {
        type: DataTypes.DATE
      },
      insuranceLastName: {
        type: DataTypes.STRING
      },
      insurancePhoneNumber: {
        type: DataTypes.STRING
      },
      EmpName: {
        type: DataTypes.STRING
      },
      EmployerNum: {
        type: DataTypes.STRING
      },
      planType: {
        type: DataTypes.STRING
      },
      email: {
        type: DataTypes.STRING
      },
      WirelessPhone: {
        type: DataTypes.STRING
      },
      Address: {
        type: DataTypes.STRING
      },
      Address2: {
        type: DataTypes.STRING
      },
      City: {
        type: DataTypes.STRING
      },
      Zip: {
        type: DataTypes.STRING
      },
      State: {
        type: DataTypes.STRING
      },
      gender: {
        type: DataTypes.STRING
      },
      appointmentRenderingProvider: {
        type: DataTypes.STRING
      },
      isScheduled: {
        type: DataTypes.BOOLEAN
      },
      insuranceName: {
        type: DataTypes.STRING
      },
      insurancePlan: {
        type: DataTypes.STRING
      },
      verificationError: {
        type: DataTypes.STRING
      },
      verificationErrCode: {
        type: DataTypes.STRING
      },
      verificationErrMessages: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("verificationErrMessages");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("verificationErrMessages", JSON.stringify(value));
        }
      },
      empenrollmentstatus: {
        type: DataTypes.STRING
      },
      employerId: {
        type: DataTypes.STRING
      },
      employeeId: {
        type: DataTypes.STRING
      },
      empnetworkstatus: {
        type: DataTypes.STRING
      },
      empemail: {
        type: DataTypes.STRING
      },
      empWirelessPhone: {
        type: DataTypes.STRING
      },
      empAddress: {
        type: DataTypes.STRING
      },
      empAddress2: {
        type: DataTypes.STRING
      },
      empCity: {
        type: DataTypes.STRING
      },
      empZip: {
        type: DataTypes.STRING
      },
      empState: {
        type: DataTypes.STRING
      },
      empWebSite: {
        type: DataTypes.STRING
      },
      medicaidId: {
        type: DataTypes.STRING
      },
      isexclude: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      isSuccess: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      istechnical: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      isdemographic: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      notlinked: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      medical:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      dental:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      others:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      primary:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      secondary:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      tertiary:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      }
    },
    {
      timestamps: true
    }
  );
  SchedulePatientsModel.associate = function (models) {
    // associations can be defined here
    // SchedulePatientsModel.hasMany(models.PatientEligibility,{
    //   foreignKey: "patientId"
    // });
    SchedulePatientsModel.hasMany(models.ECoInsurance, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EActiveCoverages, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EADAProcedure, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EBenefitHistory, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EDeductible, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.ELimitationMaximum, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EMiscellaneous, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.ENotCovered, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.ENotesAndRemark, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EPatient, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EPayer, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    SchedulePatientsModel.hasMany(models.EPlanBenfit, {
      foreignKey: "scheduledPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
  };

  return SchedulePatientsModel;
};
