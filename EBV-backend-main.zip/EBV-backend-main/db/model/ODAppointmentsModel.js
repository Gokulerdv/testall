module.exports = (sequelize, DataTypes) => {
  const ODAppointmentsModel = sequelize.define(
    "ODAppointments",
    {
      patientId: {
        type: DataTypes.STRING,
      },
      addedFrom: DataTypes.STRING,
      AptDateTime: DataTypes.TEXT("long"),
      AppointmentTypeNum: DataTypes.STRING,
      AptNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      ProvNum: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODAppointmentsModel.associate = function (models) {
    // associations can be defined here
    //   ODAppointmentsModel.belongsTo(models.product);
  };
  return ODAppointmentsModel;
};
