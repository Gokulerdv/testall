module.exports = (sequelize, DataTypes) => {
  const ODInsSubPlansModel = sequelize.define(
    "ODInsSub",//tablename
    {
      PlanNum: {
        type: DataTypes.STRING,
      },
      InsSubNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      Subscriber: {
        type: DataTypes.STRING
      },
      SubscriberID: DataTypes.STRING,
      BenefitNotes: {
        type: DataTypes.TEXT
      },
      ReleaseInfo: {
        type: DataTypes.TEXT
      }
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODInsSubPlansModel.associate = function (models) {
    // associations can be defined here
    //   ODInsSubPlansModel.belongsTo(models.product);
  };
  return ODInsSubPlansModel;
};
