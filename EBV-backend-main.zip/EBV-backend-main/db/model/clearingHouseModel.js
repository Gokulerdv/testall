module.exports = (sequelize, DataTypes) => {
    const ClearingHouseModel = sequelize.define(
      "ClearingHouse",
      {
        
       id:{
        type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
       },
       name:{
        type: DataTypes.STRING,
        },
      }

    )
return ClearingHouseModel;
}