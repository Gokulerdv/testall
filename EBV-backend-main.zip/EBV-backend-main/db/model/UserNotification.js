module.exports = (sequelize, DataTypes) => {
  const UserNotificationModel = sequelize.define(
    "UserNotification",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      typeofnotify: {
        // manual, opendental, csv, ispatientupdate, ispatientdelete
        type: DataTypes.STRING,
        unique: true
      },
      notifyinapp: {
        // [success, demographic, technical, notlinked, manual, opendental, csv]
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("notifyinapp");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("notifyinapp", JSON.stringify(value));
        }
      },
      fromDate: {
        // 2024-05-01
        type: DataTypes.DATE
      },
      toDate: {
        // 2024-05-31
        type: DataTypes.DATE
      },
      isinapp: { type: DataTypes.BOOLEAN, defaultValue: false },
      isemail: { type: DataTypes.BOOLEAN, defaultValue: false },
      issms: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   ismanual: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   isscheduled: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   isimport: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   ispatientupdate: { type: DataTypes.BOOLEAN, defaultValue: false },
    //   ispatientdelete: { type: DataTypes.BOOLEAN, defaultValue: false }
    },
    {
      timestamps: true
    }
  );
  UserNotificationModel.associate = function (models) {
    // associations can be defined here
  };
  return UserNotificationModel;
};
