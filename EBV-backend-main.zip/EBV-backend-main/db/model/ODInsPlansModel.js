module.exports = (sequelize, DataTypes) => {
  const ODInsPlansModel = sequelize.define(
    "ODInsPlans",//tablename
    {
      PlanNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      groupNumber: DataTypes.STRING,
      CarrierNum: DataTypes.STRING,
      EmployerNum: DataTypes.STRING,
      PlanType: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  
  );
  ODInsPlansModel.associate = function (models) {
    // associations can be defined here
    //   ODInsPlansModel.belongsTo(models.product);
  };
  return ODInsPlansModel;
};
