module.exports = (sequelize, DataTypes) => {
  const ODProcedureCodeModel = sequelize.define(
    "ODProcedureCode",//tablename
  
    {
      ProcCode: {
        type: DataTypes.STRING,
      },
      CodeNum: {
        type: DataTypes.STRING,
        primaryKey: true
      },
      description: DataTypes.STRING,
      AbbrDesc: DataTypes.STRING,
      ProcTime: DataTypes.STRING,
      procedureType: DataTypes.STRING,
      ProcTime: DataTypes.STRING,
      DateTStamp: DataTypes.DATE,
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  ODProcedureCodeModel.associate = function (models) {
    // associations can be defined here
    //   ODProcedureCodeModel.belongsTo(models.product);
  };
  return ODProcedureCodeModel;
};
