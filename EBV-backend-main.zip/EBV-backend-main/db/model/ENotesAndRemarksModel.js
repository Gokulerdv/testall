module.exports = (sequelize, DataTypes) => {
  const NotesAndRemarksModel = sequelize.define(
    'ENotesAndRemark', {
    patientId: {
      type: DataTypes.STRING,
    },
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      unique: true
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    data: {
      type: DataTypes.TEXT,
    },
    statusflag: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    }
  }, {
    timestamps: true
  }
  )
  NotesAndRemarksModel.associate = function (models) {
    // associations can be defined here
  };
  return NotesAndRemarksModel;
};
