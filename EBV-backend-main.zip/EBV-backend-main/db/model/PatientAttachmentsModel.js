module.exports = (sequelize, DataTypes) => {
  const PatientAttachmentsModel = sequelize.define(
    "PatientAttachments",
    {
      uniqueId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      patientId: DataTypes.STRING,
      fileName: DataTypes.STRING,
      base64File: DataTypes.TEXT('long'),
      description: DataTypes.STRING,
      isPatientCard: DataTypes.STRING
    },
    {
      // Sequelize options
      timestamps: true
    }
  );
  PatientAttachmentsModel.associate = function (models) {
    // associations can be defined here
    //   PatientAttachmentsModel.belongsTo(models.product);
  };
  return PatientAttachmentsModel;
};
