module.exports = (sequelize, DataTypes) => {
  const ManualPatientsModel = sequelize.define(
    "ManualPatients",
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false
      },
      patientId: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true
      },
      uniqueId: {
        type: DataTypes.STRING
      },
      eligibilityId: {
        type: DataTypes.STRING
      },
      addedFrom: {
        type: DataTypes.STRING
      },
      adminId: {
        type: DataTypes.STRING
      },
      verificationType: {
        type: DataTypes.STRING
      },
      statusflag: {
        type: DataTypes.CHAR
      },
      firstName: {
        type: DataTypes.STRING
      },
      lastName: {
        type: DataTypes.STRING
      },
      dateOfBirth: {
        type: DataTypes.DATE
      },
      memberId: {
        type: DataTypes.STRING
      },
      groupId: {
        type: DataTypes.STRING
      },
      relationship: {
        type: DataTypes.STRING
      },
      procedureCode: {
        type: DataTypes.STRING
      },
      procedureType: {
        type: DataTypes.STRING
      },
      provider: {
        type: DataTypes.STRING
      },
      providerFirstName: {
        type: DataTypes.STRING
      },
      providerLastName: {
        type: DataTypes.STRING
      },
      providerNpi: {
        type: DataTypes.STRING
      },
      providerTaxId: {
        type: DataTypes.STRING
      },
      insurancePayer: {
        type: DataTypes.STRING
      },
      payerIdCode: {
        type: DataTypes.STRING
      },
      subscriberFirstName: {
        type: DataTypes.STRING
      },
      subscriberLastName: {
        type: DataTypes.STRING
      },
      subscriberDateOfBirth: {
        type: DataTypes.DATE
      },
      subscriberAddress: {
        type: DataTypes.STRING
      },
      subscriberAddress1: {
        type: DataTypes.STRING
      },
      subscriberCity: {
        type: DataTypes.STRING
      },
      subscriberZip: {
        type: DataTypes.STRING
      },
      subscriberState: {
        type: DataTypes.STRING
      },
      dependentFirstName: {
        type: DataTypes.STRING
      },
      dependentLastName: {
        type: DataTypes.STRING
      },
      dependentDateOfBirth: {
        type: DataTypes.DATE
      },
      typeOfService: {
        type: DataTypes.STRING
      },
      practiceNameAndLoc: {
        type: DataTypes.STRING
      },
      appointmentType: {
        type: DataTypes.STRING
      },
      scheduleAppointment: {
        type: DataTypes.DATE
      },
      speciality: {
        type: DataTypes.STRING
      },
      isVerified: {
        type: DataTypes.BOOLEAN
      },
      isVerifiedManually: {
        type: DataTypes.BOOLEAN
      },
      lastVerified: {
        type: DataTypes.DATE
      },
      remainingBenefits: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("remainingBenefits");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("remainingBenefits", JSON.stringify(value));
        }
      },
      effectiveDateFrom: {
        type: DataTypes.DATE
      },
      effectiveEndDate: {
        type: DataTypes.DATE
      },
      insuranceDateOfBirth: {
        type: DataTypes.DATE
      },
      insuranceLastName: {
        type: DataTypes.STRING
      },
      insurancePhoneNumber: {
        type: DataTypes.STRING
      },
      EmpName: {
        type: DataTypes.STRING
      },
      EmployerNum: {
        type: DataTypes.STRING
      },
      planType: {
        type: DataTypes.STRING
      },
      email: {
        type: DataTypes.STRING
      },
      WirelessPhone: {
        type: DataTypes.STRING
      },
      Address: {
        type: DataTypes.STRING
      },
      Address2: {
        type: DataTypes.STRING
      },
      City: {
        type: DataTypes.STRING
      },
      Zip: {
        type: DataTypes.STRING
      },
      State: {
        type: DataTypes.STRING
      },
      gender: {
        type: DataTypes.STRING
      },
      appointmentRenderingProvider: {
        type: DataTypes.STRING
      },
      verificationError: {
        type: DataTypes.STRING
      },
      verificationErrCode: {
        type: DataTypes.STRING
      },
      verificationErrMessages: {
        type: DataTypes.TEXT,
        get() {
          const value = this.getDataValue("verificationErrMessages");
          return value ? JSON.parse(value) : null;
        },
        set(value) {
          this.setDataValue("verificationErrMessages", JSON.stringify(value));
        }
      },
      empenrollmentstatus: {
        type: DataTypes.STRING
      },
      employerId: {
        type: DataTypes.STRING
      },
      employeeId: {
        type: DataTypes.STRING
      },
      empnetworkstatus: {
        type: DataTypes.STRING
      },
      empemail: {
        type: DataTypes.STRING
      },
      empWirelessPhone: {
        type: DataTypes.STRING
      },
      empAddress: {
        type: DataTypes.STRING
      },
      empAddress2: {
        type: DataTypes.STRING
      },
      empCity: {
        type: DataTypes.STRING
      },
      empZip: {
        type: DataTypes.STRING
      },
      empState: {
        type: DataTypes.STRING
      },
      empWebSite: {
        type: DataTypes.STRING
      },
      medicaidId: {
        type: DataTypes.STRING
      },
      isexclude: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      isSuccess: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      istechnical: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      isdemographic: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      notlinked: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      medical:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      dental:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      others:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      primary:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      secondary:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      },
      tertiary:{
        type:DataTypes.BOOLEAN,
        defaultValue: false
      }
    },
    {
      timestamps: true
    }
  );
  ManualPatientsModel.associate = function (models) {
    // associations can be defined here
    // ManualPatientsModel.hasMany(models.PatientEligibility, {
    //   foreignKey: "patientId"
    // });
    ManualPatientsModel.hasMany(models.ECoInsurance, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EActiveCoverages, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EADAProcedure, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EBenefitHistory, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EDeductible, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.ELimitationMaximum, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EMiscellaneous, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.ENotCovered, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.ENotesAndRemark, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EPatient, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EPayer, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.EPlanBenfit, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.ESubscriber, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    ManualPatientsModel.hasMany(models.ESubscriber, {
      foreignKey: "manualPatientId",
      onDelete: "CASCADE",
      onUpdate: "CASCADE"
    });
    // ManualPatientsModel.hasMany(models.PatientEligibility, {
    //   foreignKey: "manualPatientId",
    //   onDelete: "CASCADE",
    //   onUpdate: "CASCADE"
    // });
  };
  return ManualPatientsModel;
};
