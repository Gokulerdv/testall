module.exports = (sequelize, DataTypes) => {
  const PayerModel = sequelize.define(
    'EPayer', {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    patientId: {
      type: DataTypes.STRING,
    },
    payerId: {
      type: DataTypes.STRING,
    },
    name: {
      type: DataTypes.STRING
    },
    statusflag: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    }
  }, {
    timestamps: true
  }
  )
  PayerModel.associate = function (models) {
    // associations can be defined here
  };
  return PayerModel;
};
