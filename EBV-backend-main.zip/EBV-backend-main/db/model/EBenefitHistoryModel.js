module.exports = (sequelize, DataTypes) => {
  const BenefitHistoryModel = sequelize.define(
    'EBenefitHistory', {
    patientId: {
      type: DataTypes.STRING,
    },
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement:true
    },
    eligibilityId: {
      type: DataTypes.STRING
    },
    serviceType: {
      type: DataTypes.STRING,
    },
    doses: {
      type: DataTypes.STRING,
    },
    provider: {
      type: DataTypes.STRING,
    },
  
    procedure: {
      type: DataTypes.STRING,
    },
    benefitsConsumed: {
      type: DataTypes.STRING,
    },
  
    message: {
      type: DataTypes.TEXT,
    },
    statusflag: {
      type: DataTypes.STRING
    },
    isManual: {
      type: DataTypes.BOOLEAN
    }
  }, {
    timestamps: true
  }
  )
  BenefitHistoryModel.associate = function (models) {
    // associations can be defined here
  };
  return BenefitHistoryModel;
};
