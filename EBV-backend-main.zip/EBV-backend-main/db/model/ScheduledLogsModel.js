module.exports = (sequelize, DataTypes) => {
  const ScheduledLogsModel = sequelize.define(
    "ScheduledLog",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      adminId: {
        type: DataTypes.STRING,
        allowNull: false
      },
      scheduledaction: {
        type: DataTypes.STRING,
        allowNull: false
      },
      timeToRun: {
        type: DataTypes.STRING,
        allowNull: false
      },
      noOfPatients: {
        type: DataTypes.INTEGER,
        allowNull: false
      },
      isWeekly: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      isMonthly: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      isDaily: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      timeOfLastRun: {
        type: DataTypes.DATE,
        allowNull: true
      }
    },
    {
      timestamps: true
    }
  );
  return ScheduledLogsModel;
};
