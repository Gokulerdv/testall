require("dotenv").config();

var express = require("express");
const sls = require("serverless-http");
var cors = require("cors");
var cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
var logger = require("morgan");
const multer = require("multer");
const { ConfidentialClientApplication } = require("@azure/msal-node");
const { fetch } = require("undici");

const { sequelize } = require("./db/model");
const {
  DocumentAnalysisClient,
  AzureKeyCredential,
} = require("@azure/ai-form-recognizer");
const swaggerUi = require("swagger-ui-express");
const swaggerDocument = require("./swagger-output.json");
const router = require("./app/routes/routes");

var app = express();

app.use(logger("dev"));
app.use(cors());
app.use(express.json({ limit: "15mb", extended: true }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use("/", router);

let port = process.env.PORT || 8585;
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    limit: "15mb",
    extended: true,
    parameterLimit: 50000,
  })
);
app.use(bodyParser.urlencoded({ extended: true }));

const storage = multer.memoryStorage();
const upload = multer({ storage });

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

sequelize
  .sync()
  .then(() => console.log("MSSQL DB Connection established"))
  .catch((err) => console.log(err, "error in database establishment"));

const clients = new Map();

const credential = new AzureKeyCredential(process.env.AZURE_KEY_CREDENTIAL);
const documentAnalysisClient = new DocumentAnalysisClient(
  process.env.AZURE_DOCUMENT_ANALYSIS_CLIENT_URL,
  credential
);

const powerBIConfig = {
    authenticationMode: process.env.POWER_BI_AUTHENTICATION_MODE,
    authorityUrl: process.env.POWER_BI_AUTHORITY_URL,
    clientId: process.env.POWER_BI_CLIENT_ID,
    clientSecret: process.env.POWER_BI_CLIENT_SECRET,
    powerBiApiUrl: process.env.POWER_BI_API_URL,
    scopeBase: process.env.POWER_BI_SCOPE_BASE,
    tenantId: process.env.POWER_BI_TENANT_ID,
  },
  // eslint-disable-next-line sort-vars
  clientCredentialRequest = {
    scopes: [powerBIConfig.scopeBase],
  },
  // eslint-disable-next-line sort-vars
  msalConfig = {
    auth: {
      authority: `${powerBIConfig.authorityUrl}${powerBIConfig.tenantId}`,
      clientId: powerBIConfig.clientId,
      clientSecret: powerBIConfig.clientSecret,
    },
  },
  // eslint-disable-next-line sort-vars
  msalInstance = new ConfidentialClientApplication(msalConfig);

app.get("/power-bi/access-token/:workspaceId/:reportId", async (req, res) => {
  try {
    const workspaceId = req.params.workspaceId;
    const reportId = req.params.reportId;

    const token = await msalInstance.acquireTokenByClientCredential(
      clientCredentialRequest
    );

    if (!token) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    // eslint-disable-next-line one-var
    const reportInGroup = await fetch(
      `${powerBIConfig.powerBiApiUrl}/v1.0/myorg/groups/${workspaceId}/reports/${reportId}`,
      {
        headers: {
          Authorization: `Bearer ${token.accessToken}`,
          "Content-Type": "application/json",
        },
        method: "GET",
      }
    );

    if (!reportInGroup.ok)
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    // eslint-disable-next-line one-var
    const reportInGroupData = await reportInGroup.json(),
      // eslint-disable-next-line sort-vars
      generateToken = await fetch(
        `${powerBIConfig.powerBiApiUrl}/v1.0/myorg/GenerateToken`,
        {
          body: JSON.stringify({
            datasets: [{ id: reportInGroupData.datasetId }],
            reports: [
              {
                allowEdit: false,
                id: reportId,
              },
            ],
            targetWorkspaces: [
              {
                id: workspaceId,
              },
            ],
          }),
          headers: {
            Authorization: `Bearer ${token.accessToken}`,
            "Content-Type": "application/json",
          },
          method: "POST",
        }
      ),
      // eslint-disable-next-line sort-vars
      generateTokenData = await generateToken.json();

    const result = {
      accessToken: generateTokenData.token,
      embedUrl: [
        {
          embedUrl: reportInGroupData.embedUrl,
          reportId: reportInGroupData.id,
          reportName: reportInGroupData.name,
        },
      ],
      expiry: generateTokenData.expiration,
    };

    return res.status(200).json(result);
  } catch (error) {
    console.error(error);
  }
});

app.post("/ocr", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const poller = await documentAnalysisClient.beginAnalyzeDocument(
      "prebuilt-document",
      req.file.buffer
    );
    const { keyValuePairs } = await poller.pollUntilDone();

    const name_keys = [
      "subscriber name",
      "member name",
      "policyowner",
      "primary enrollee",
      "enrollee name",
      "subscriber:",
      "name of beneficiary",
      "member",
      "cardholder's name",
      "subscriber",
      "policyowner:",
    ];
    const member_id_keys = [
      "id",
      "id ",
      "policy number",
      "identification number",
      "entrolle id",
      "membership #",
      "member i.d.",
      "medicare claim number",
      "member id",
      "id#",
      "identification Number",
      "identification Number:",
      "Identification Number",
      "cabon numbe",
      "policy number:",
      "id:",
      "membership #:",
    ];
    const group_id_keys = [
      "grp",
      "plan id",
      "group number",
      "group",
      "group #",
      "plan number",
      "plan",
      "group code",
      "group numbe",
      "Group Number",
      "group number:",
      "orova number",
      "grp",
      "plan id:",
      "group:",
      "group #:",
    ];
    const dob_keys = [
      "DOB:",
      "dob",
      "dob:",
      "DOB",
      "Date Of Birth",
      "DATE OF BIRTH",
      "date of birth",
      "date of birth:",
      "Date Of Birth:",
    ];
    const gender_id_keys = ["Sex", "SEX", "sex"];

    const extractedData = keyValuePairs.map((item) => {
      let key_text = item.key.content.toLowerCase();

      // Add the condition to modify key_text here
      key_text = key_text.replace(" :", "");
      key_text = key_text.replace("\n", " ").trim(":");

      if (name_keys.includes(key_text)) {
        key_text = "Name";
      } else if (member_id_keys.includes(key_text)) {
        key_text = "memberId";
      } else if (group_id_keys.includes(key_text)) {
        key_text = "groupId";
      } else if (gender_id_keys.includes(key_text)) {
        key_text = "gender";
      } else if (dob_keys.includes(key_text)) {
        key_text = "dateOfBirth";
      }

      return {
        Key: key_text,
        Value: item.value?.content,
      };
    });
    console.log(extractedData);
    return res.status(200).json(extractedData);
  } catch (error) {
    console.log({ error });
    return res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/events", async (req, res) => {
  try {
    const clientId = req.query.clientId;
    const postData = req.body;

    const client = clients.get(clientId);

    if (!client) {
      throw new Error("Client not found");
    }

    console.log(`$client:${clientId} sending ${JSON.stringify(postData)}`);
    client.write(`data: ${JSON.stringify(postData)}\n\n`);

    client.end();
    clients.delete(clientId);

    return res
      .status(200)
      .send({ message: `Data successfully sent to client:${clientId}` });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/events", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  const clientId = req.query.clientId;
  clients.set(clientId, res);
  console.log(`$client:${clientId} added and listening for server events!`);

  req.on("close", () => {
    console.log(`$client:${clientId} disconnected!`);

    clients.delete(clientId);
    res.end();
  });
});

app.listen(port);
console.log("Server listening to Port", port);

module.exports = app;
module.exports.handler = sls(app);
