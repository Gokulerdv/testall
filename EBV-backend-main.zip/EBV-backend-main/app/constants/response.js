const successResponse = (message, data) => {
  return {
    status: true,
    message: message,
    data: data,
  };
};
const failedResponse = (message, data) => {
  return {
    status: false,
    message: message,
    data: data || {},
  };
};

module.exports = { successResponse, failedResponse };
