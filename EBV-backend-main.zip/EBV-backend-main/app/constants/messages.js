const messages = {
  common: {
    success: "Request processed successfully!",
    failed: "Request failed",
    downtime:
      "Sorry, Our servers are under maintenance, Please try after some time!",
    added: "Item added successfully",
    fetched: "Requested items fetched successfully",
    updated: "Item updated successfully",
    deleted: "Item deleted successfully",
    uploadSuccess: "Uploaded successfully",
    noItems: "No items found",
    noItemsInTable: (tableName) => "No items found in " + tableName,
  },
  account: {
    added: "Account added successfully",
  },
  login: {
    missingCredentials: "Please provide valid email and password!",
    noAccountFound: "No account found!",
    invalidCredentials: "Invalid login credentials",
    successful: "Successfully logged in.",
  },
  patient: {
    added: "Patient added successfully",
    addedAndVerified: "Patient added and verified successfully",
  },
  dentalXchange: {
    addedAndVerified: "Patient added and verified.",
    verifiedAndAdded: "Patient verified and added to eligibilities.",
    failedVerification: "Failed to verify patient.",
  },
  fileUpload: {
    success: "Successfully uploaded",
    failed: "Failed to uploaded file",
    noFile: "No files are found, please add files to upload!",
  },
};

module.exports = messages;
