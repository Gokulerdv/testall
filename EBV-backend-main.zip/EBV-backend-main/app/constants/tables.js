const tableNames = {
  userMaster: "UserMaster",
  patientMaster: "PatientMaster",
  patientMaster2: "PatientsMaster",
  settingsMaster: "SettingsMaster",
  eligibilityMaster: "EligibilityMaster",
  manualVerification: "ManualPatientMaster",
  scheduledVerification: "ScheduledPatientMaster",
  childTables: {
    PatientAttachments: "PatientAttachments",
    PatientsEligibilities: "PatientsEligibilities",
  },
};

module.exports = tableNames;
