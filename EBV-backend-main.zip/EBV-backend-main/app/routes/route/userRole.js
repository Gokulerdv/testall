var express = require("express");
var router = express.Router();
var userRoleController = require("../../controller/userAndroles/roleController");

//post method
//this fn used for create practice table
//http://localhost:4001/api/userrole/create
router.post("/create", userRoleController.create);

// //post method
// //this fn used for create practice table
// //http://localhost:4001/api/userrole/getall
router.get("/getall", userRoleController.getAll);

// //post method
// //this fn used for create practice table
// //http://localhost:4001/api/userrole/get/
router.get("/get/:roleId", userRoleController.getRoleById);

router.get("/getroleproducts/:roleId", userRoleController.getroleProductsById);

// //post method
// //this fn used for create practice table
// //http://localhost:4001/api/userrole/update/
router.put("/update/:roleId", userRoleController.update);

// //post method
// //this fn used for create practice table
// //http://localhost:4001/api/userrole/delete/123
router.delete("/delete/:roleId", userRoleController.delete);

module.exports = router;
