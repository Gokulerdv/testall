const express = require("express");
const router = express.Router();
const userNotificationController = require("../../../app/controller/notifications/userNotification");
const auth = require("../../controller/authController");
// Create a user notification
// http://localhost:8585/usernotification/create
// router.post('/create',  userNotificationController.create);
// router.post('/create-all',  userNotificationController.createAll);

// Get all user notifications
// http://localhost:8585/usernotification/getAll
router.get("/getAll", auth, userNotificationController.getAll);

// Get user notification by ID
// http://localhost:8585/usernotification/getById/1
router.get("/get/:typeofnotify", auth, userNotificationController.getById);

// Update user notification
router.put("/update/:typeofnotify", auth, userNotificationController.update);

module.exports = router;
