const express = require("express");
const router = express.Router();
const providerController = require("../../controller/provider/providerController");
const auth = require("../../controller/authController");
//post method
//this fn user for register user
//http://localhost:8585/provider/create
router.post("/create", auth, providerController.create);

//post method
//this fn user for register user
//http://localhost:8585/provider/getAll
router.get("/getAll/:adminId", auth, providerController.getAll);

//get method
//this route for get module by ID
//http://localhost:8585/provider/get/1
router.get("/get/:uniqueId", auth, providerController.getbyId);

//put method
//this route for get module by ID
//http://localhost:8585/provider/update/1
router.put("/update/:uniqueId", auth, providerController.updatebyId);

//delete method
//this route for get module by ID
//http://localhost:8585/provider/delete/1
router.delete("/delete/:uniqueId", auth, providerController.deletebyId);

//get method
//this route for get module by ID
//http://localhost:8585/provider/search
router.get("/search", auth, providerController.searchProvider);

module.exports = router;
