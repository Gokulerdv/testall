var express = require("express");
var router = express.Router();
var practice = require("../../controller/userAndroles/practiceController");


//http://localhost:4001/api/practice/get/123
router.get("/get/:practiceId", practice.getPracticeById);

router.get('/getAll',practice.getAllPractice)

module.exports = router;