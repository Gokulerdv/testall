const express = require("express");
const router = express.Router();
const patientController = require("../../controller/reports/newPatient");
const auth = require("../../controller/authController");
// Create a new patient
router.post("/create", auth, patientController.create);

// Get all patients
router.get("/getAll", auth, patientController.getAll);

// Get a patient by ID
router.get("/getById/:patientId", auth, patientController.getById);

// Update a patient
router.put("/update/:patientId", auth, patientController.update);

// Delete a patient
router.delete("/delete/:patientId", auth, patientController.delete);

module.exports = router;
