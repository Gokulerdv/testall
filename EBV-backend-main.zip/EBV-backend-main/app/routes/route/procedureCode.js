const express = require("express");
const router = express.Router();
const procedureCodeController = require("../../controller/settings/procedureCodeController");
const auth = require("../../controller/authController");

//post method
//this fn user for register user
//http://localhost:8585/procedurecodes/fetch
router.post("/fetch", auth, procedureCodeController.manualCreateProcedureCodes);

//post method
//this fn user for register user
//http://localhost:8585/procedurecode/getAll
router.get("/getAll", auth, procedureCodeController.getAllProcedureCodes);

//get method
//this route for get module by ID
//http://localhost:8585/procedurecode/get/1
// router.get("/get/:uniqueId", procedureCodeController.getbyId);

// //put method
// //this route for get module by ID
// //http://localhost:8585/procedurecode/update/1
// router.put("/update/:uniqueId", procedureCodeController.updatebyId);

// //delete method
// //this route for get module by ID
// //http://localhost:8585/procedurecode/delete/1
// router.delete("/delete/:uniqueId", procedureCodeController.deletebyId);

//get method
//this route for get module by ID
//http://localhost:8585/procedurecode/search
router.get("/types", auth, procedureCodeController.getAllProcedureTypes);

module.exports = router;
