const express = require("express");
const router = express.Router();
const transactionController = require("../../controller/reports/transaction");
const auth = require("../../controller/authController");
// Create a new transaction
router.post("/create", auth, transactionController.create);

// Get all transactions
router.get("/getAll", auth, transactionController.getAll);

// Get a transaction by ID
router.get("/getById/:transactionId", auth, transactionController.getById);

// Update a transaction
router.put("/update/:transactionId", auth, transactionController.update);

// Delete a transaction
router.delete("/delete/:transactionId", auth, transactionController.delete);

module.exports = router;
