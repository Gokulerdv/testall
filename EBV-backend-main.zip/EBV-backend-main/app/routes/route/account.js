const express = require("express");
const router = express.Router();
const accountController = require("../../controller/accounts/accountController");

// account login
router.post("/login", accountController.loginUser)

router.post("/refresh", accountController.refreshAccessToken)
router.post("/verify-token", accountController.verifyAccessToken)

module.exports = router;
