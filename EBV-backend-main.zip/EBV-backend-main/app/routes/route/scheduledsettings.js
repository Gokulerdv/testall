const express = require("express");
const router = express.Router();
const scheduledSettingsController = require("../../controller/settings/scheduledSettingsController");
const auth = require("../../controller/authController");

//post method
//this fn user for register user
//http://localhost:8585/scheduledSettings/create
router.post("/create", auth, scheduledSettingsController.create);

//post method
//this fn user for register user
//http://localhost:8585/scheduledSettings/getAll
router.get("/getAll/:adminId", auth, scheduledSettingsController.getAll);

//get method
//this route for get module by ID
//http://localhost:8585/scheduledSettings/get/1
router.get("/get/:id", auth, scheduledSettingsController.getbyId);

//put method
//this route for get module by ID
//http://localhost:8585/scheduledSettings/update/1
router.put("/update/:id", auth, scheduledSettingsController.updatebyId);

//delete method
//this route for get module by ID
//http://localhost:8585/scheduledSettings/delete/1
router.delete("/delete/:id", auth, scheduledSettingsController.deletebyId);

// for testing purposes
// router.get("/autoverify",  scheduledSettingsController.verifyAutomatically);

module.exports = router;
