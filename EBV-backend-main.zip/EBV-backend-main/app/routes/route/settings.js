const express = require("express");
const router = express.Router();
const settingController = require("../../controller/settings/Settings");
const credentialController = require("../../controller/settings/PayerCredentialController");
const { check } = require("express-validator");
const auth = require("../../controller/authController");

//post method
//http://localhost:8585/settings/createpayer
router.post("/createpayer", auth, settingController.createPayers);

router.post("/manual-createpayer", auth, settingController.manualCreatePayers);

// get method
// http://localhost:8585/settings/getall
router.get("/getall", auth, settingController.getAllPayers);

//get method
//this route for get module by ID
//http://localhost:8585/settings/get/1
router.get("/get/:id", auth, settingController.getPayerbyId);

//put method
//this route for module update
//http://localhost:8585/settings/update/1
router.put("/update/:id", auth, settingController.updatePayerbyId);

//delete method
//this route for module update
//http://localhost:8585/settings/delete/1
router.delete("/delete/:id", auth, settingController.deletePayerbyId);

//get method
//this route for module update
//http://localhost:8585/settings/search
router.get("/search", auth, settingController.searchPayerId);

//post method
//http://localhost:8585/settings/createcredential
router.post(
  "/createcredential",
  check("password", "Password should contain max 12 characters").isLength({
    max: 8,
  }),
  auth,
  credentialController.createCredential
);

//get method
//http://localhost:8585/settings/credentialgetall
router.get("/credentialgetall", auth, credentialController.credentialGetall);

//get method
//this route for get module by ID
//http://localhost:8585/settings/credentialget/1
router.get("/credentialget/:id", auth, credentialController.credentialGetbyId);

//put method
//this route for get module by ID
//http://localhost:8585/settings/credentialupdate/1
router.put(
  "/credentialupdate/:id",
  auth,
  credentialController.credentialUpdatebyId
);

//delete method
//this route for get module by ID
//http://localhost:8585/settings/credentialdelete/1
router.delete(
  "/credentialdelete/:id",
  auth,
  credentialController.credentialDeletebyId
);

router.get("/searchmyins", auth, credentialController.searchMyIns);

module.exports = router;
