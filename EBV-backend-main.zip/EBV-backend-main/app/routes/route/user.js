var express = require("express");
var router = express.Router();
var useraccount = require("../../controller/userAndroles/userController");

// //post method
// // //this fn used for create practice table
// // //http://localhost:4001/api/useraccount/create
router.post("/create", useraccount.create);

// //get method
// //this fn used for create practice table
// //http://localhost:4001/api/useraccount/getall
router.get("/getall", useraccount.getAll);

// // //get method
// // //this fn used for create practice table
// //http://localhost:4001/api/useraccount/get/
router.get("/get/:user_id", useraccount.getUserById);

// // // //get method
// // // //this route for get user by ID
// // // //http://localhost:4000/api/useraccount/locations/userid
router.get("/locations/:userId", useraccount.getLocationById);

// // // //get method
// // // //this route for get user by ID
// // // //http://localhost:4000/api/useraccount/getbylocation
router.get("/getbylocation", useraccount.getUserByLocation);

// //put method
//this fn used for create practice table
//http://localhost:4001/api/useraccount/update/123
router.put("/update/:user_id", useraccount.update);
//  router.patch("/updateActive/:user_id", useraccount.updateActive)

//delete method
//this fn used for create practice table
// http://localhost:4001/api/useraccount/delete/123
router.delete("/delete/:user_id", useraccount.delete);


module.exports = router;
