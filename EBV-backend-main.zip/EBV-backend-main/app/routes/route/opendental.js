const express = require("express");
const router = express.Router();
const opendentalController = require("../../controller/opendental/opendentalController");
const auth = require("../../controller/authController");

// get all patient
router.get("/patient/all", auth, opendentalController.getAllPatients);
router.get(
  "/appointment/all",
  auth,
  opendentalController.getAllPatientAppoinments
);
router.get(
  "/appointmenttypes/all",
  auth,
  opendentalController.getAllAppoinmentsType
);
router.get("/clinics/all", auth, opendentalController.getAllClinics);

router.get("/patplans/all", auth, opendentalController.getAllPatPlans);
router.get("/inssubs/all", auth, opendentalController.getAllInsSubs);
router.get(
  "/procedurecode/all",
  auth,
  opendentalController.getAllProcedureCodes
);
router.get(
  "/familymodules/all",
  auth,
  opendentalController.getFamilyModulesByPatientId
);
router.get("/providers/all", auth, opendentalController.getAllProviders);
router.get("/carriers/all", auth, opendentalController.getAllCarriers);
router.get("/insplans/all", auth, opendentalController.getAllInsplans);
router.get(
  "/procedurelogs/all",
  auth,
  opendentalController.getAllProcedureLogs
);

//Staging table operations
router.get(
  "/procedurecode/getAll",
  auth,
  opendentalController.getAllODProcedureCodes
);
router.get(
  "/procedurecode/getTypes",
  auth,
  opendentalController.getAllODProcedureTypes
);
router.get("/provider/getAll", auth, opendentalController.getAllODProviders);

module.exports = router;
