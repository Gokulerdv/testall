const express = require("express");
const router = express.Router();
const scheduledLogs = require('../../controller/settings/scheduledLogsController')
const auth = require('../../controller/authController')

//http://localhost:8585/scheduledLogs/getScheduledLogs/:adminId
router.get("/getScheduledLogs/:adminId", auth,  scheduledLogs.getScheduleByadminID);

// will be removed later scheduledLogs.createlogs
router.post("/create", auth, scheduledLogs.createlogs)

module.exports = router;