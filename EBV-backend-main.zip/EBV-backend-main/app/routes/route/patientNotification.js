const express = require("express");
const router = express.Router();
const patientNotificationController = require("../../../app/controller/notifications/patientNotification");
const auth = require("../../controller/authController");

// Create a patient notification
// http://localhost:8585/patientnotification/create
// router.post('/create',  patientNotificationController.create);

// Get all patient notifications
// http://localhost:8585/patientnotification/getAll
router.get("/getAll", auth, patientNotificationController.getAll);

// Get patient notification by ID
// http://localhost:8585/patientnotification/get/:type
router.get("/get/:typeofnotify", auth, patientNotificationController.getById);

// Update patient notification
// http://localhost:8585/patientnotification/update
router.put("/update/:typeofnotify", auth, patientNotificationController.update);

// Delete patient notification
// router.delete('/delete/:typeofnotify',  patientNotificationController.delete);

module.exports = router;
