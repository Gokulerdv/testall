const express = require("express");
const router = express.Router();
const eligibilityController = require("../../controller/eligibility/eligibilityController");
const auth = require("../../controller/authController");

const multer = require("multer");
// const cron = require("node-cron");
// cron.schedule("* * * * *", () => {
//   console.log("Running in every second");
// });

// Set up multer storage
const storage = multer.memoryStorage(); // Store files in memory as buffers
const upload = multer({ storage: storage });

// add eligibility
router.post("/create", auth, eligibilityController.addEligibility);
router.get(
  "/getEligibility/:patientId",
  auth,
  eligibilityController.getEligibilityByPatient
);
router.put("/update/:patientId", auth, eligibilityController.editEligibility);

router.post("/createcoins", auth, eligibilityController.createcoinsurance);
router.get("/getallcoins/:patientId", auth, eligibilityController.getAllcoins);
router.get("/getcoinsbyid/:id", auth, eligibilityController.getcoinsbyId);
router.put("/updatecoinsbyid/:id", auth, eligibilityController.updatecoinsbyId);
router.delete(
  "/deletecoinbyid/:id",
  auth,
  eligibilityController.deletecoinbyId
);
router.get("/getAllcoinsfilter", auth, eligibilityController.getAllcoinsfilter);

router.post("/createDeductible", auth, eligibilityController.createdeductible);
router.get(
  "/getAllDeductible/:patientId",
  auth,
  eligibilityController.getAlldeductible
);
router.get(
  "/getDeductibleById/:id",
  auth,
  eligibilityController.getdeductiblebyId
);
router.put(
  "/updateDeductibleById/:id",
  auth,
  eligibilityController.updatedeductiblebyId
);
router.delete(
  "/deleteDeductibleById/:id",
  auth,
  eligibilityController.deletedeductiblebyId
);
router.get(
  "/getAllDeductiblefilter",
  auth,
  eligibilityController.getAllDeductiblefilter
);

router.post(
  "/createActiveCoverage",
  auth,
  eligibilityController.createactivecoverage
);
router.get(
  "/getAllActiveCoverage/:patientId",
  auth,
  eligibilityController.getAllActiveCoverage
);
router.get(
  "/getActiveCoverageById/:id",
  auth,
  eligibilityController.getActiveCoveragebyId
);
router.put(
  "/updateActiveCoverageById/:id",
  auth,
  eligibilityController.updateActiveCoveragebyId
);
router.delete(
  "/deleteActiveCoverageById/:id",
  auth,
  eligibilityController.deleteActiveCoveragebyId
);
router.get(
  "/getAllActiveCoveragefilter",
  auth,
  eligibilityController.getAllActiveCoveragefilter
);

router.post("/createLimitation", auth, eligibilityController.createlimitation);
router.get(
  "/getAllLimitation/:patientId",
  auth,
  eligibilityController.getAlllimitation
);
router.get(
  "/getLimitationById/:id",
  auth,
  eligibilityController.getlimitationbyId
);
router.put(
  "/updateLimitationById/:id",
  auth,
  eligibilityController.updatelimitationbyId
);
router.delete(
  "/deleteLimitationById/:id",
  auth,
  eligibilityController.deletelimitationbyId
);
router.get(
  "/getAllLimitationfilter",
  auth,
  eligibilityController.getAllLimitationfilter
);

router.post(
  "/createAdaProcedure",
  auth,
  eligibilityController.createadaprocedure
);
router.get(
  "/getAllAdaProcedure/:patientId",
  auth,
  eligibilityController.getAlladaprocedure
);
router.get(
  "/getAdaProcedureById/:id",
  auth,
  eligibilityController.getadaprocedurebyId
);
router.put(
  "/updateAdaProcedureById/:id",
  auth,
  eligibilityController.updateadaprocedurebyId
);
router.delete(
  "/deleteAdaProcedureById/:id",
  auth,
  eligibilityController.deleteadaprocedurebyId
);
router.get(
  "/getAlladaprocedurefilter",
  auth,
  eligibilityController.getAlladaprocedurefilter
);

router.post("/createNotCovered", auth, eligibilityController.createnotcovered);
router.get(
  "/getAllNotCovered/:patientId",
  auth,
  eligibilityController.getAllNotCovered
);
router.get(
  "/getNotCoveredById/:id",
  auth,
  eligibilityController.getNotCoveredbyId
);
router.put(
  "/updateNotCoveredById/:id",
  auth,
  eligibilityController.updateNotCoveredbyId
);
router.delete(
  "/deleteNotCoveredById/:id",
  auth,
  eligibilityController.deleteNotCoveredbyId
);
router.get(
  "/getAllNotCoveredfilter",
  auth,
  eligibilityController.getAllNotCoveredfilter
);

router.post(
  "/createBenefitHistory",
  auth,
  eligibilityController.createbenefithistory
);
router.get(
  "/getAllBenefitHistory/:patientId",
  auth,
  eligibilityController.getAllBenefitHistory
);
router.get(
  "/getBenefitHistoryById/:id",
  auth,
  eligibilityController.getBenefitHistorybyId
);
router.put(
  "/updateBenefitHistoryById/:id",
  auth,
  eligibilityController.updateBenefitHistorybyId
);
router.delete(
  "/deleteBenefitHistoryById/:id",
  auth,
  eligibilityController.deleteBenefitHistorybyId
);

router.get(
  "/dxcSubscriber/:id",
  auth,
  eligibilityController.getSubscriberByPatientId
);

router.put(
  "/dxcupdateSubscriber/:id",
  auth,
  eligibilityController.updateSubscriberByPatientId
);
router.get("/dxcPayer/:id", auth, eligibilityController.getPayerByPatientId);
router.get(
  "/dxcPatient/:id",
  auth,
  eligibilityController.getPatientByPatientId
);
router.put(
  "/dxcPatient/:id",
  auth,
  eligibilityController.updatePatientByPatientId
);

router.get(
  "/miscellaneous/:patientId",
  auth,
  eligibilityController.getAllMiscellaneous
);

router.get(
  "/miscellaneous/getbyid/:id",
  auth,
  eligibilityController.getMiscellaneousById
);

router.delete(
  "/miscellaneous/:id",
  auth,
  eligibilityController.deleteMiscellaneous
);
router.put(
  "/miscellaneous/:id",
  auth,
  eligibilityController.updateMiscellaneous
);

router.post("/miscellaneous", auth, eligibilityController.createmiscellaneous);

router.get(
  "/notesandremarks/:patientId",
  auth,
  eligibilityController.getNotesAndRemarksByPatientId
);

router.post(
  "/notesandremarks",
  auth,
  eligibilityController.createnotesandremarks
);

router.delete(
  "/notesandremarks/:id",
  auth,
  eligibilityController.deleteNotesAndRemarks
);
router.put(
  "/notesandremarks/:id",
  auth,
  eligibilityController.updateNotesAndRemarks
);

// PDF Generation
router.post("/getreport", auth, eligibilityController.getreport);

router.get("/gethistory", auth, eligibilityController.getPastBenefitHistory);

// router.get("/getallpatientpdf",auth, eligibilityController.getAllPatientPdf);

module.exports = router;
