const express = require("express");
const router = express.Router();
const patientsController = require("../../controller/patients/patientsController");
const auth = require("../../controller/authController");

// const multer = require("multer");
// const cron = require("node-cron");
// cron.schedule("* * * * *", () => {
//   console.log("Running in every second");
// });

// Set up multer storage
// const storage = multer.memoryStorage(); // Store files in memory as buffers
// const upload = multer({ storage: storage });

//check eligibility
router.post(
  "/check-eligibility",
  auth,
  patientsController.checkPatientEligibility
);

// add patient
router.post("/", auth, patientsController.addPatient);
// Need to check this
router.get("/getcoins/:id", auth, patientsController.getCoinsurance);

//get patient by Patient ID
router.get("/getpatient", auth, patientsController.getPatientById);

router.post("/add", auth, patientsController.addScheduledPatient);

router.post("/update", auth, patientsController.updatePatient);

router.delete("/delete", auth, patientsController.deletePatients);

router.post(
  "/schedulepatient/create",
  auth,
  patientsController.createSchedulePatients
);

router.get("/familymodules/all", auth, patientsController.getallFamilyModules);

router.put("/exclude/:uniqueId", auth, patientsController.exclude);

router.post("/verifypatient", auth, patientsController.verifyNow);

router.get("/getallpatients", auth, patientsController.getallPatientsData);

router.post("/csv/upload", auth, patientsController.importPatientsFromCSV);

router.post(
  "/attachments/:patientId",
  auth,
  patientsController.addPatientAttachments
);

router.get(
  "/attachments/:patientId",
  auth,
  patientsController.getAllPatientAttachments
);

router.delete(
  "/attachments/:attachmentId",
  auth,
  patientsController.deletePatientAttachments
);

router.get("/downloadsamplecsv", auth, patientsController.getfile);

router.post("/bulkverify", auth, patientsController.bulkVerify);
router.post("/bulkexclude", auth, patientsController.bulkexclude);
router.post("/bulkpdf", auth, patientsController.bulkpdfdownload);
router.post("/bulkverifyall", auth, patientsController.bulkVerifyAll);
module.exports = router;
