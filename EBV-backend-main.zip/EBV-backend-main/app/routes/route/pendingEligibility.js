const express = require("express");
const router = express.Router();
const pendingEligibilityController = require("../../controller/reports/pendingEligibility");
const auth = require("../../controller/authController");

// Route to create a new pending eligibility entry
router.post("/create", auth, pendingEligibilityController.create);

// Route to get all pending eligibility entries
router.get("/getAll", auth, pendingEligibilityController.getAll);

// Route to get a pending eligibility entry by ID
router.get("/getById/:id", auth, pendingEligibilityController.getById);

// Route to update a pending eligibility entry by ID
router.put("/update/:id", auth, pendingEligibilityController.update);

// Route to delete a pending eligibility entry by ID
router.delete("/delete/:id", auth, pendingEligibilityController.delete);

//Route to get all manual and schedule entries
router.post(
  "/getdetailsbycriteria",
  auth,
  pendingEligibilityController.getPatientsByCriteria
);
router.get("/getallpatients", auth, pendingEligibilityController.getPatients);

module.exports = router;
