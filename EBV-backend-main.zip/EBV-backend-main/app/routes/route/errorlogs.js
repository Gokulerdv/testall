const express = require("express");
const router = express.Router();
const errorlogsController = require("../../controller/settings/errorlogscontroller");
const auth = require("../../controller/authController");

//post method
//this fn user for register user
//http://localhost:8585/errorlogs/create
router.post("/create", auth, errorlogsController.create);

//get method
//this fn user for register user
//http://localhost:8585/errorlogs/getAll
router.get("/getAll", auth, errorlogsController.getAll);

//get method
//this fn user for register user
//http://localhost:8585/errorlogs/get/1
router.get("/get/:adminId", auth, errorlogsController.getbyId);

//put method
//this fn user for register user
//http://localhost:8585/errorlogs/update/1
router.put("/update/:adminId", auth, errorlogsController.updatebyId);

//delete method
//this fn user for register user
//http://localhost:8585/errorlogs/delete/1
router.delete("/delete/:adminId", auth, errorlogsController.deletebyId);

module.exports = router;
