const express = require("express");
const router = express.Router();
const generalSettingController = require("../../controller/settings/generalSettingsController");
const auth = require("../../controller/authController");

//post method
//this fn user for register user
//http://localhost:8585/generalsettings/create
router.post("/create", auth, generalSettingController.create);

//post method
//this fn user for register user
//http://localhost:8585/generalsettings/getAll
router.get("/getAll", auth, generalSettingController.getAll);

//get method
//this route for get module by ID
//http://localhost:8585/generalsettings/get/1
router.get("/get/:adminId", auth, generalSettingController.getbyId);

//put method
//this route for get module by ID
//http://localhost:8585/generalsettings/update/1
router.put("/update/:adminId", auth, generalSettingController.updatebyId);

//delete method
//this route for get module by ID
//http://localhost:8585/generalsettings/delete/1
router.delete("/delete/:adminId", auth, generalSettingController.deletebyId);

module.exports = router;
