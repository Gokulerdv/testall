const express = require("express");
const router = express.Router();

const notificationController = require("../../controller/settings/notificationController");
const auth = require("../../controller/authController");

// //post method
// //this fn user for register user
// //http://localhost:8585/notification/create
// router.post("/create",  notificationController.create);

//get method
//this fn user for register user
//http://localhost:8585/notification/getAll
router.get("/getAll", auth, notificationController.getall);

// //get method
// //this fn user for register user
// //http://localhost:8585/notification/get
// router.get("/get/:id",  notificationController.getbyid);

// //put method
// //this fn user for register user
// //http://localhost:8585/notification/update
router.put("/update/:id", auth, notificationController.updatebyid);

// //delete method
// //this fn user for register user
// //http://localhost:8585/notification/delete
// router.delete("/delete/:id",  notificationController.deletebyid);

module.exports = router;
