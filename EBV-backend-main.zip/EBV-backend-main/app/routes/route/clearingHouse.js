const express = require("express");
const router = express.Router();

const clearinghouseController = require("../../controller/settings/clearinghouseController");
const auth = require("../../controller/authController");

//post method
//this fn user for register user
//http://localhost:8585/clearingHouse/create
router.post("/create", auth, clearinghouseController.create);

//get method
//this fn user for register user
//http://localhost:8585/clearingHouse/getAll
router.get("/getAll", auth, clearinghouseController.getall);
//get method
//this fn user for register user
//http://localhost:8585/clearingHouse/get/1
router.get("/get/:id", auth, clearinghouseController.getbyid);

//put method
//this fn user for register user
//http://localhost:8585/clearingHouse/update/1
router.put("/update/:id", auth, clearinghouseController.updatebyid);

//delete method
//this fn user for register user
//http://localhost:8585/clearingHouse/delete/1
router.delete("/delete/:id", auth, clearinghouseController.deletebyid);

module.exports = router;
