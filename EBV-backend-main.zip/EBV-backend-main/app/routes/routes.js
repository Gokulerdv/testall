const express = require("express");
const router = express.Router();

let patientRoutes = require("./route/patients");

// let patientsRoutes = require('../routes/route')
let openDentalRouter = require("./route/opendental");
let eligibilityRouter = require("./route/eligibility");
let accountRouter = require("./route/account");
let settingRouter = require("./route/settings");
let generalsettingsRouter = require("./route/generalsettings");
let scheduledsettingsRouter = require("./route/scheduledsettings");
let providerRouter = require("./route/provider");
let errorlogsRouter = require("./route/errorlogs");
let indexRouter = require("./route/index");
let scheduledLogRouter = require("./route/scheduledLog");
let userNotification = require("./route/userNotification");
let patientNotifications = require("./route/patientNotification");
let pendingEligibility = require("./route/pendingEligibility");
let newPatient = require("../../app/routes/route/newPatient");
let transaction = require("../../app/routes/route/transaction");
let notificationRouter = require("./route/notification");
let clearinghouseRouter = require("./route/clearingHouse");
let procedureCodesRouter = require("./route/procedureCode");
let useraccount = require('./route/user')
let userRole = require('./route/userRole')
let practice = require('./route/practice')

router.use("/", indexRouter);
router.use("/opendental", openDentalRouter);
router.use("/account", accountRouter);
router.use("/settings", settingRouter);
router.use("/eligibility", eligibilityRouter);
router.use("/patients", patientRoutes);
router.use("/generalSettings", generalsettingsRouter);
router.use("/scheduledSettings", scheduledsettingsRouter);
router.use("/provider", providerRouter);
router.use("/Errorlogs", errorlogsRouter);
router.use("/scheduledLogs", scheduledLogRouter);
router.use("/usernotification", userNotification);
router.use("/patientnotification", patientNotifications);
router.use("/pendingeligibility", pendingEligibility);
router.use("/newpatient", newPatient);
router.use("/transaction", transaction);
router.use("/notification", notificationRouter);
router.use("/clearinghouse", clearinghouseRouter);
router.use("/procedurecodes", procedureCodesRouter);
router.use("/useraccount", useraccount);
router.use("/userrole", userRole);
router.use("/practice", practice);

module.exports = router;
