module.exports = [
  {
    code: "D0120",
    procedureType: "Diagnostic",
    description: "periodic oral evaluation - established patient"
  },
  {
    code: "D0140",
    procedureType: "Diagnostic",
    description: "limited oral evaluation - problem focused"
  },
  {
    code: "D0145",
    procedureType: "Diagnostic",
    description:
      "oral evaluation for a patient under three years of age and counseling with primary caregiver"
  },
  {
    code: "D0150",
    procedureType: "Diagnostic",
    description: "comprehensive oral evaluation - new or established patient"
  },
  {
    code: "D0160",
    procedureType: "Diagnostic",
    description:
      "detailed and extensive oral evaluation - problem focused, by report"
  },
  {
    code: "D0170",
    procedureType: "Diagnostic",
    description:
      "re-evaluation - limited, problem focused (established patient; not post-operative visit)"
  },
  {
    code: "D0171",
    procedureType: "Diagnostic",
    description: "re-evaluation - post-operative office visit"
  },
  {
    code: "D0180",
    procedureType: "Diagnostic",
    description:
      "comprehensive periodontal evaluation - new or established patient"
  },
  {
    code: "D0190",
    procedureType: "Diagnostic",
    description: "screening of a patient"
  },
  {
    code: "D0191",
    procedureType: "Diagnostic",
    description: "assessment of a patient"
  },
  {
    code: "D0210",
    procedureType: "Diagnostic",
    description: "intraoral - comprehensive series of radiographic images"
  },
  {
    code: "D0220",
    procedureType: "Diagnostic",
    description: "intraoral - periapical first radiographic image"
  },
  {
    code: "D0230",
    procedureType: "Diagnostic",
    description: "intraoral � periapical each additional radiographic image"
  },
  {
    code: "D0240",
    procedureType: "Diagnostic",
    description: "intraoral � occlusal radiographic image"
  },
  {
    code: "D0250",
    procedureType: "Diagnostic",
    description:
      "extra-oral � 2D projection radiographic image created using a stationary radiation source, and detector"
  },
  {
    code: "D0251",
    procedureType: "Diagnostic",
    description: "extra-oral posterior dental radiographic image"
  },
  {
    code: "D0270",
    procedureType: "Diagnostic",
    description: "bitewing - single radiographic image"
  },
  {
    code: "D0272",
    procedureType: "Diagnostic",
    description: "bitewings - two radiographic images"
  },
  {
    code: "D0273",
    procedureType: "Diagnostic",
    description: "bitewings - three radiographic images"
  },
  {
    code: "D0274",
    procedureType: "Diagnostic",
    description: "bitewings - four radiographic images"
  },
  {
    code: "D0277",
    procedureType: "Diagnostic",
    description: "vertical bitewings - 7 to 8 radiographic images"
  },
  {
    code: "D0310",
    procedureType: "Diagnostic",
    description: "sialography"
  },
  {
    code: "D0320",
    procedureType: "Diagnostic",
    description: "temporomandibular joint arthrogram, including injection"
  },
  {
    code: "D0321",
    procedureType: "Diagnostic",
    description: "other temporomandibular joint radiographic images, by report"
  },
  {
    code: "D0322",
    procedureType: "Diagnostic",
    description: "tomographic survey"
  },
  {
    code: "D0330",
    procedureType: "Diagnostic",
    description: "panoramic radiographic image"
  },
  {
    code: "D0340",
    procedureType: "Diagnostic",
    description:
      "2D cephalometric radiographic image - acquisition, measurement and analysis"
  },
  {
    code: "D0350",
    procedureType: "Diagnostic",
    description:
      "2D oral/facial photographic image obtained intra-orally or extra-orally"
  },
  {
    code: "D0364",
    procedureType: "Diagnostic",
    description:
      "cone beam CT capture and interpretation with limited field of view - less than one whole jaw"
  },
  {
    code: "D0365",
    procedureType: "Diagnostic",
    description:
      "cone beam CT capture and interpretation with field of view of one full dental arch - mandible"
  },
  {
    code: "D0366",
    procedureType: "Diagnostic",
    description:
      "cone beam CT capture and interpretation with field of view of one full dental arch - maxilla, with or without cranium"
  },
  {
    code: "D0367",
    procedureType: "Diagnostic",
    description:
      "cone beam CT capture and interpretation with field of view of both jaws; with or without cranium"
  },
  {
    code: "D0368",
    procedureType: "Diagnostic",
    description:
      "cone beam CT capture and interpretation for TMJ series including two or more exposures"
  },
  {
    code: "D0369",
    procedureType: "Diagnostic",
    description: "maxillofacial MRI capture and interpretation"
  },
  {
    code: "D0370",
    procedureType: "Diagnostic",
    description: "maxillofacial ultrasound capture and interpretation"
  },
  {
    code: "D0371",
    procedureType: "Diagnostic",
    description: "sialoendoscopy capture and interpretation"
  },
  {
    code: "D0372",
    procedureType: "Diagnostic",
    description:
      "intraoral tomosynthesis � comprehensive series of radiographic images"
  },
  {
    code: "D0373",
    procedureType: "Diagnostic",
    description: "intraoral tomosynthesis � bitewing radiographic image"
  },
  {
    code: "D0374",
    procedureType: "Diagnostic",
    description: "intraoral tomosynthesis � periapical radiographic image"
  },
  {
    code: "D0380",
    procedureType: "Diagnostic",
    description:
      "cone beam CT image capture with limited field of viewless than one whole jaw"
  },
  {
    code: "D0381",
    procedureType: "Diagnostic",
    description:
      "cone beam CT image capture with field of view of one full dental arch - mandible"
  },
  {
    code: "D0382",
    procedureType: "Diagnostic",
    description:
      "cone beam CT image capture with field of view of one full dental arch - maxilla, with or without cranium"
  },
  {
    code: "D0383",
    procedureType: "Diagnostic",
    description:
      "cone beam CT image capture with field of view of both jaws, with or without cranium"
  },
  {
    code: "D0384",
    procedureType: "Diagnostic",
    description:
      "cone beam CT image capture for TMJ series including two or more exposures"
  },
  {
    code: "D0385",
    procedureType: "Diagnostic",
    description: "maxillofacial MRI image capture"
  },
  {
    code: "D0386",
    procedureType: "Diagnostic",
    description: "maxillofacial ultrasound image capture"
  },
  {
    code: "D0387",
    procedureType: "Diagnostic",
    description:
      "intraoral tomosynthesis � comprehensive series of radiographic images � image capture only"
  },
  {
    code: "D0388",
    procedureType: "Diagnostic",
    description:
      "intraoral tomosynthesis � bitewing radiographic image � image capture only"
  },
  {
    code: "D0389",
    procedureType: "Diagnostic",
    description:
      "intraoral tomosynthesis � periapical radiographic image � image capture only"
  },
  {
    code: "D0391",
    procedureType: "Diagnostic",
    description:
      "interpretation of diagnostic image by a practitioner not associated with capture of the image, including report"
  },
  {
    code: "D0393",
    procedureType: "Diagnostic",
    description:
      "virtual treatment simulation using 3D image volume or surface scan"
  },
  {
    code: "D0394",
    procedureType: "Diagnostic",
    description:
      "digital subtraction of two or more images or image volumes of the same modality"
  },
  {
    code: "D0395",
    procedureType: "Diagnostic",
    description:
      "fusion of two or more 3D image volumes of one or more modalities"
  },
  {
    code: "D0411",
    procedureType: "Diagnostic",
    description: "HbA1c in-office point of service testing"
  },
  {
    code: "D0412",
    procedureType: "Diagnostic",
    description: "blood glucose level test - in-office using a glucose meter"
  },
  {
    code: "D0414",
    procedureType: "Diagnostic",
    description:
      "laboratory processing of microbial specimen to include culture and sensitivity studies, preparation and transmission of written report"
  },
  {
    code: "D0415",
    procedureType: "Diagnostic",
    description: "collection of microorganisms for culture and sensitivity"
  },
  {
    code: "D0416",
    procedureType: "Diagnostic",
    description: "viral culture"
  },
  {
    code: "D0417",
    procedureType: "Diagnostic",
    description:
      "collection and preparation of saliva sample for laboratory diagnostic testing"
  },
  {
    code: "D0418",
    procedureType: "Diagnostic",
    description: "analysis of saliva sample"
  },
  {
    code: "D0419",
    procedureType: "Diagnostic",
    description: "assessment of salivary flow by measurement"
  },
  {
    code: "D0422",
    procedureType: "Diagnostic",
    description:
      "collection and preparation of genetic sample material for laboratory analysis and report"
  },
  {
    code: "D0423",
    procedureType: "Diagnostic",
    description:
      "genetic test for susceptibility to diseases - specimen analysis"
  },
  {
    code: "D0425",
    procedureType: "Diagnostic",
    description: "caries susceptibility tests"
  },
  {
    code: "D0431",
    procedureType: "Diagnostic",
    description:
      "adjunctive pre-diagnostic test that aids in detection of mucosal abnormalities including premalignant and malignant lesions, not to include cytology or biopsy procedures"
  },
  {
    code: "D0460",
    procedureType: "Diagnostic",
    description: "pulp vitality tests"
  },
  {
    code: "D0470",
    procedureType: "Diagnostic",
    description: "diagnostic casts"
  },
  {
    code: "D0472",
    procedureType: "Diagnostic",
    description:
      "accession of tissue, gross examination, preparation and transmission of written report"
  },
  {
    code: "D0473",
    procedureType: "Diagnostic",
    description:
      "accession of tissue, gross and microscopic examination, preparation and transmission of written report"
  },
  {
    code: "D0474",
    procedureType: "Diagnostic",
    description:
      "accession of tissue, gross and microscopic examination, including assessment of surgical margins for presence of disease, preparation and transmission of written report"
  },
  {
    code: "D0475",
    procedureType: "Diagnostic",
    description: "decalcification procedure"
  },
  {
    code: "D0476",
    procedureType: "Diagnostic",
    description: "special stains for microorganisms"
  },
  {
    code: "D0477",
    procedureType: "Diagnostic",
    description: "special stains, not for microorganisms"
  },
  {
    code: "D0478",
    procedureType: "Diagnostic",
    description: "immunohistochemical stains"
  },
  {
    code: "D0479",
    procedureType: "Diagnostic",
    description: "tissue in-situ hybridization, including interpretation"
  },
  {
    code: "D0480",
    procedureType: "Diagnostic",
    description:
      "accession of exfoliative cytologic smears, microscopic examination, preparation and transmission of written report"
  },
  {
    code: "D0481",
    procedureType: "Diagnostic",
    description: "electron microscopy"
  },
  {
    code: "D0482",
    procedureType: "Diagnostic",
    description: "direct immunofluorescence"
  },
  {
    code: "D0483",
    procedureType: "Diagnostic",
    description: "indirect immunofluorescence"
  },
  {
    code: "D0484",
    procedureType: "Diagnostic",
    description: "consultation on slides prepared elsewhere"
  },
  {
    code: "D0485",
    procedureType: "Diagnostic",
    description:
      "consultation, including preparation of slides from biopsy material supplied by referring source"
  },
  {
    code: "D0486",
    procedureType: "Diagnostic",
    description:
      "laboratory accession of transepithelial cytologic sample, macroscopic examination, preparation and transmission of written report"
  },
  {
    code: "D0502",
    procedureType: "Diagnostic",
    description: "other oral pathology procedures, by report"
  },
  {
    code: "D0600",
    procedureType: "Diagnostic",
    description:
      "non-ionizing diagnostic procedure capable of quantifying, monitoring, and recording changes in structure of enamel, dentin, and cementum"
  },
  {
    code: "D0601",
    procedureType: "Diagnostic",
    description:
      "caries risk assessment and documentation, with a finding of low risk"
  },
  {
    code: "D0602",
    procedureType: "Diagnostic",
    description:
      "caries risk assessment and documentation, with a finding of moderate risk"
  },
  {
    code: "D0603",
    procedureType: "Diagnostic",
    description:
      "caries risk assessment and documentation, with a finding of high risk"
  },
  {
    code: "D0604",
    procedureType: "Diagnostic",
    description:
      "antigen testing for a public health related pathogen, including coronavirus"
  },
  {
    code: "D0605",
    procedureType: "Diagnostic",
    description:
      "antibody testing for a public health related pathogen, including coronavirus"
  },
  {
    code: "D0606",
    procedureType: "Diagnostic",
    description:
      "molecular testing for a public health related pathogen, including coronavirus"
  },
  {
    code: "D0701",
    procedureType: "Diagnostic",
    description: "panoramic radiographic image � image capture only"
  },
  {
    code: "D0702",
    procedureType: "Diagnostic",
    description: "2-D cephalometric radiographic image � image capture only"
  },
  {
    code: "D0703",
    procedureType: "Diagnostic",
    description:
      "2-D oral/facial photographic image obtained intra-orally or extra-orally � image capture only"
  },
  {
    code: "D0705",
    procedureType: "Diagnostic",
    description:
      "extra-oral posterior dental radiographic image � image capture only"
  },
  {
    code: "D0706",
    procedureType: "Diagnostic",
    description: "intraoral � occlusal radiographic image � image capture only"
  },
  {
    code: "D0707",
    procedureType: "Diagnostic",
    description:
      "intraoral � periapical radiographic image � image capture only"
  },
  {
    code: "D0708",
    procedureType: "Diagnostic",
    description: "intraoral � bitewing radiographic image � image capture only"
  },
  {
    code: "D0709",
    procedureType: "Diagnostic",
    description:
      "intraoral � comprehensive series of radiographic images � image capture only"
  },
  {
    code: "D0801",
    procedureType: "Diagnostic",
    description: "3D dental surface scan � direct"
  },
  {
    code: "D0802",
    procedureType: "Diagnostic",
    description: "3D dental surface scan � indirect"
  },
  {
    code: "D0803",
    procedureType: "Diagnostic",
    description: "3D facial surface scan � direct,"
  },
  {
    code: "D0804",
    procedureType: "Diagnostic",
    description: "3D facial surface scan � indirect"
  },
  {
    code: "D0999",
    procedureType: "Diagnostic",
    description: "unspecified diagnostic procedure, by report"
  },
  {
    code: "D1110",
    procedureType: "Preventive",
    description: "prophylaxis � adult"
  },
  {
    code: "D1120",
    procedureType: "Preventive",
    description: "prophylaxis � child"
  },
  {
    code: "D1206",
    procedureType: "Preventive",
    description: "topical application of fluoride varnish"
  },
  {
    code: "D1208",
    procedureType: "Preventive",
    description: "topical application of fluoride - excluding varnish"
  },
  {
    code: "D1310",
    procedureType: "Preventive",
    description: "nutritional counseling for control of dental disease"
  },
  {
    code: "D1320",
    procedureType: "Preventive",
    description:
      "tobacco counseling for the control and prevention of oral disease"
  },
  {
    code: "D1321",
    procedureType: "Preventive",
    description:
      "counseling for the control and prevention of adverse oral, behavioral, and systemic health effects associated with high-risk substance use"
  },
  {
    code: "D1330",
    procedureType: "Preventive",
    description: "oral hygiene instructions"
  },
  {
    code: "D1351",
    procedureType: "Preventive",
    description: "sealant - per tooth"
  },
  {
    code: "D1352",
    procedureType: "Preventive",
    description:
      "preventive resin restoration in a moderate to high caries risk patient - permanent tooth"
  },
  {
    code: "D1353",
    procedureType: "Preventive",
    description: "sealant repair - per tooth"
  },
  {
    code: "D1354",
    procedureType: "Preventive",
    description: "application of caries arresting medicament - per tooth"
  },
  {
    code: "D1355",
    procedureType: "Preventive",
    description: "caries preventive medicament application � per tooth"
  },
  {
    code: "D1510",
    procedureType: "Preventive",
    description: "space maintainer - fixed, unilateral - per quadrant"
  },
  {
    code: "D1516",
    procedureType: "Preventive",
    description: "space maintainer - fixed - bilateral, maxillary"
  },
  {
    code: "D1517",
    procedureType: "Preventive",
    description: "space maintainer - fixed - bilateral, mandibular"
  },
  {
    code: "D1520",
    procedureType: "Preventive",
    description: "space maintainer - removable, unilateral - per quadrant"
  },
  {
    code: "D1526",
    procedureType: "Preventive",
    description: "space maintainer - removable - bilateral, maxillary"
  },
  {
    code: "D1527",
    procedureType: "Preventive",
    description: "space maintainer - removable - bilateral, mandibular"
  },
  {
    code: "D1551",
    procedureType: "Preventive",
    description: "re-cement or re-bond bilateral space maintainer - maxillary"
  },
  {
    code: "D1552",
    procedureType: "Preventive",
    description: "re-cement or re-bond bilateral space maintainer - mandibular"
  },
  {
    code: "D1553",
    procedureType: "Preventive",
    description:
      "re-cement or re-bond unilateral space maintainer - per quadrant"
  },
  {
    code: "D1556",
    procedureType: "Preventive",
    description: "removal of fixed unilateral space maintainer - per quadrant"
  },
  {
    code: "D1557",
    procedureType: "Preventive",
    description: "removal of fixed bilateral space maintainer � maxillary"
  },
  {
    code: "D1558",
    procedureType: "Preventive",
    description: "removal of fixed bilateral space maintainer � mandibular"
  },
  {
    code: "D1575",
    procedureType: "Preventive",
    description:
      "distal shoe space maintainer - fixed, unilateral - per quadrant"
  },
  {
    code: "D1701",
    procedureType: "Preventive",
    description: "Pfizer-BioNTech Covid-19 vaccine administration - first dose"
  },
  {
    code: "D1702",
    procedureType: "Preventive",
    description: "Pfizer-BioNTech Covid-19 vaccine administration - second dose"
  },
  {
    code: "D1703",
    procedureType: "Preventive",
    description: "Moderna Covid-19 vaccine administration - first dose"
  },
  {
    code: "D1704",
    procedureType: "Preventive",
    description: "Moderna Covid-19 vaccine administration - second dose"
  },
  {
    code: "D1705",
    procedureType: "Preventive",
    description: "AstraZeneca Covid-19 vaccine administration - first dose"
  },
  {
    code: "D1706",
    procedureType: "Preventive",
    description: "AstraZeneca Covid-19 vaccine administration - second dose"
  },
  {
    code: "D1707",
    procedureType: "Preventive",
    description: "Janssen Covid-19 vaccine administration"
  },
  {
    code: "D1781",
    procedureType: "Preventive",
    description: "vaccine administration � human papillomavirus � Dose 1"
  },
  {
    code: "D1782",
    procedureType: "Preventive",
    description: "vaccine administration � human papillomavirus � Dose 2"
  },
  {
    code: "D1783",
    procedureType: "Preventive",
    description: "vaccine administration � human papillomavirus � Dose 3"
  },
  {
    code: "D1999",
    procedureType: "Preventive",
    description: "unspecified preventive procedure, by report"
  },
  {
    code: "D2140",
    procedureType: "Restorative",
    description: "amalgam - one surface, primary of permanent"
  },
  {
    code: "D2150",
    procedureType: "Restorative",
    description: "amalgam - two surfaces, primary or permanent"
  },
  {
    code: "D2160",
    procedureType: "Restorative",
    description: "amalgam - three surfaces, primary or permanent"
  },
  {
    code: "D2161",
    procedureType: "Restorative",
    description: "amalgam - four or more surfaces, primary or permanent"
  },
  {
    code: "D2330",
    procedureType: "Restorative",
    description: "resin-based composite - one surface, anterior"
  },
  {
    code: "D2331",
    procedureType: "Restorative",
    description: "resin-based composite - two surfaces, anterior"
  },
  {
    code: "D2332",
    procedureType: "Restorative",
    description: "resin-based composite - three surfaces, anterior"
  },
  {
    code: "D2335",
    procedureType: "Restorative",
    description:
      "resin-based composite - four or more surfaces or involving incisal angle (anterior)"
  },
  {
    code: "D2390",
    procedureType: "Restorative",
    description: "resin-based composite crown, anterior"
  },
  {
    code: "D2391",
    procedureType: "Restorative",
    description: "resin-based composite - one surface, posterior"
  },
  {
    code: "D2392",
    procedureType: "Restorative",
    description: "resin-based composite - two surfaces, posterior"
  },
  {
    code: "D2393",
    procedureType: "Restorative",
    description: "resin-based composite - three surfaces, posterior"
  },
  {
    code: "D2394",
    procedureType: "Restorative",
    description: "resin-based composite - four or more surfaces, posterior"
  },
  {
    code: "D2410",
    procedureType: "Restorative",
    description: "gold foil - one surface"
  },
  {
    code: "D2420",
    procedureType: "Restorative",
    description: "gold foil - two surfaces"
  },
  {
    code: "D2430",
    procedureType: "Restorative",
    description: "gold foil - three surfaces"
  },
  {
    code: "D2510",
    procedureType: "Restorative",
    description: "inlay - metallic - one surface"
  },
  {
    code: "D2520",
    procedureType: "Restorative",
    description: "inlay - metallic - two surfaces"
  },
  {
    code: "D2530",
    procedureType: "Restorative",
    description: "inlay - metallic - three or more surfaces"
  },
  {
    code: "D2542",
    procedureType: "Restorative",
    description: "onlay - metallic - two surfaces"
  },
  {
    code: "D2543",
    procedureType: "Restorative",
    description: "onlay - metallic - three surfaces"
  },
  {
    code: "D2544",
    procedureType: "Restorative",
    description: "onlay - metallic - four or more surfaces"
  },
  {
    code: "D2610",
    procedureType: "Restorative",
    description: "inlay - porcelain/ceramic - one surface"
  },
  {
    code: "D2620",
    procedureType: "Restorative",
    description: "inlay - porcelain/ceramic - two surfaces"
  },
  {
    code: "D2630",
    procedureType: "Restorative",
    description: "inlay - porcelain/ceramic - three or more surfaces"
  },
  {
    code: "D2642",
    procedureType: "Restorative",
    description: "onlay - porcelain/ceramic - two surfaces"
  },
  {
    code: "D2643",
    procedureType: "Restorative",
    description: "onlay - porcelain/ceramic - three surfaces"
  },
  {
    code: "D2644",
    procedureType: "Restorative",
    description: "onlay - porcelain/ceramic - four or more surfaces"
  },
  {
    code: "D2650",
    procedureType: "Restorative",
    description: "inlay - resin-based composite - one surface"
  },
  {
    code: "D2651",
    procedureType: "Restorative",
    description: "inlay - resin-based composite - two surfaces"
  },
  {
    code: "D2652",
    procedureType: "Restorative",
    description: "inlay - resin-based composite - three of more surfaces"
  },
  {
    code: "D2662",
    procedureType: "Restorative",
    description: "onlay - resin-based composite - two surfaces"
  },
  {
    code: "D2663",
    procedureType: "Restorative",
    description: "onlay - resin-based composite - three surfaces"
  },
  {
    code: "D2664",
    procedureType: "Restorative",
    description: "onlay - resin-based composite - four or more surfaces"
  },
  {
    code: "D2710",
    procedureType: "Restorative",
    description: "crown - resin-based composite (indirect)"
  },
  {
    code: "D2712",
    procedureType: "Restorative",
    description: "crown - 3/4 resin-based composite (indirect)"
  },
  {
    code: "D2720",
    procedureType: "Restorative",
    description: "crown - resin with high noble metal"
  },
  {
    code: "D2721",
    procedureType: "Restorative",
    description: "crown - resin with predominantly base metal"
  },
  {
    code: "D2722",
    procedureType: "Restorative",
    description: "crown - resin with noble metal"
  },
  {
    code: "D2740",
    procedureType: "Restorative",
    description: "crown - porcelain/ceramic"
  },
  {
    code: "D2750",
    procedureType: "Restorative",
    description: "crown - porcelain fused to high noble metal"
  },
  {
    code: "D2751",
    procedureType: "Restorative",
    description: "crown - porcelain fused to predominantly base metal"
  },
  {
    code: "D2752",
    procedureType: "Restorative",
    description: "crown - porcelain fused to noble metal"
  },
  {
    code: "D2753",
    procedureType: "Restorative",
    description: "crown - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D2780",
    procedureType: "Restorative",
    description: "crown - 3/4 cast high noble metal"
  },
  {
    code: "D2781",
    procedureType: "Restorative",
    description: "crown - 3/4 cast predominantly base metal"
  },
  {
    code: "D2782",
    procedureType: "Restorative",
    description: "crown - 3/4 cast noble metal"
  },
  {
    code: "D2783",
    procedureType: "Restorative",
    description: "crown - 3/4 porcelain/ceramic"
  },
  {
    code: "D2790",
    procedureType: "Restorative",
    description: "crown - full cast high noble metal"
  },
  {
    code: "D2791",
    procedureType: "Restorative",
    description: "crown - full cast predominantly base metal"
  },
  {
    code: "D2792",
    procedureType: "Restorative",
    description: "crown - full cast noble metal"
  },
  {
    code: "D2794",
    procedureType: "Restorative",
    description: "crown - titanium and titanium alloys"
  },
  {
    code: "D2799",
    procedureType: "Restorative",
    description:
      "interim crown- further treatment or completion of diagnosis necessary prior to final impression"
  },
  {
    code: "D2910",
    procedureType: "Restorative",
    description:
      "re-cement or re-bond inlay, onlay, veneer or partial coverage restoration"
  },
  {
    code: "D2915",
    procedureType: "Restorative",
    description:
      "re-cement or re-bond indirectly fabricated or prefabricated post and core"
  },
  {
    code: "D2920",
    procedureType: "Restorative",
    description: "re-cement or re-bond crown"
  },
  {
    code: "D2921",
    procedureType: "Restorative",
    description: "reattachment of tooth fragment, incisal edge or cusp"
  },
  {
    code: "D2928",
    procedureType: "Restorative",
    description: "prefabricated porcelain/ceramic crown � permanent tooth"
  },
  {
    code: "D2929",
    procedureType: "Restorative",
    description: "prefabricated porcelain/ceramic crown - primary tooth"
  },
  {
    code: "D2930",
    procedureType: "Restorative",
    description: "prefabricated stainless steel crown - primary tooth"
  },
  {
    code: "D2931",
    procedureType: "Restorative",
    description: "prefabricated stainless steel crown - permanent tooth"
  },
  {
    code: "D2932",
    procedureType: "Restorative",
    description: "prefabricated resin crown"
  },
  {
    code: "D2933",
    procedureType: "Restorative",
    description: "prefabricated stainless steel crown with resin window"
  },
  {
    code: "D2934",
    procedureType: "Restorative",
    description:
      "prefabricated esthetic coated stainless steel crown - primary tooth"
  },
  {
    code: "D2940",
    procedureType: "Restorative",
    description: "protective restoration"
  },
  {
    code: "D2941",
    procedureType: "Restorative",
    description: "interim therapeutic restoration - primary dentition"
  },
  {
    code: "D2949",
    procedureType: "Restorative",
    description: "restorative foundation for an indirect restoration"
  },
  {
    code: "D2950",
    procedureType: "Restorative",
    description: "core buildup, including any pins when required"
  },
  {
    code: "D2951",
    procedureType: "Restorative",
    description: "pin retention - per tooth, in addition to restoration"
  },
  {
    code: "D2952",
    procedureType: "Restorative",
    description: "post and core in addition to crown, indirectly fabricated"
  },
  {
    code: "D2953",
    procedureType: "Restorative",
    description: "each additional indirectly fabricated post - same tooth"
  },
  {
    code: "D2954",
    procedureType: "Restorative",
    description: "prefabricated post and core in addition to crown"
  },
  {
    code: "D2955",
    procedureType: "Restorative",
    description: "post removal"
  },
  {
    code: "D2957",
    procedureType: "Restorative",
    description: "each additional prefabricated post - same tooth"
  },
  {
    code: "D2960",
    procedureType: "Restorative",
    description: "labial veneer (resin laminate) � chairside direct"
  },
  {
    code: "D2961",
    procedureType: "Restorative",
    description: "labial veneer (resin laminate) � laboratory indirect"
  },
  {
    code: "D2962",
    procedureType: "Restorative",
    description: "labial veneer (porcelain laminate) � laboratory indirect"
  },
  {
    code: "D2971",
    procedureType: "Restorative",
    description:
      "additional procedures to customize a crown to fit under an existing partial denture framework"
  },
  {
    code: "D2975",
    procedureType: "Restorative",
    description: "coping"
  },
  {
    code: "D2980",
    procedureType: "Restorative",
    description: "crown repair necessitated by restorative material failure"
  },
  {
    code: "D2981",
    procedureType: "Restorative",
    description: "inlay repair necessitated by restorative material failure"
  },
  {
    code: "D2982",
    procedureType: "Restorative",
    description: "onlay repair necessitated by restorative material failure"
  },
  {
    code: "D2983",
    procedureType: "Restorative",
    description: "veneer repair necessitated by restorative material failure"
  },
  {
    code: "D2990",
    procedureType: "Restorative",
    description: "resin infiltration of incipient smooth surface lesions"
  },
  {
    code: "D2999",
    procedureType: "Restorative",
    description: "unspecified restorative procedure, by report"
  },
  {
    code: "D3110",
    procedureType: "Endodontics",
    description: "pulp cap - direct (excluding final restoration)"
  },
  {
    code: "D3120",
    procedureType: "Endodontics",
    description: "pulp cap - indirect (excluding final restoration)"
  },
  {
    code: "D3220",
    procedureType: "Endodontics",
    description:
      "therapeutic pulpotomy (excluding final restoration) - removal of pulp coronal to the dentinocemental junction and application of medicament"
  },
  {
    code: "D3221",
    procedureType: "Endodontics",
    description: "pulpal debridement, primary and permanent teeth"
  },
  {
    code: "D3222",
    procedureType: "Endodontics",
    description:
      "partial pulpotomy for apexogenesis - permanent tooth with incomplete root development"
  },
  {
    code: "D3230",
    procedureType: "Endodontics",
    description:
      "pulpal therapy (restorbable filling) - anterior, primary tooth (excluding final restoration)"
  },
  {
    code: "D3240",
    procedureType: "Endodontics",
    description:
      "pulpal therapy (restorbable filling) - posterior, primary tooth (excluding final restoration)"
  },
  {
    code: "D3310",
    procedureType: "Endodontics",
    description:
      "endodontic therapy, anterior tooth (excluding final restoration)"
  },
  {
    code: "D3320",
    procedureType: "Endodontics",
    description:
      "endodontic therapy, premolar tooth (excluding final restoration)"
  },
  {
    code: "D3330",
    procedureType: "Endodontics",
    description: "endodontic therapy, molar tooth (excluding final restoration)"
  },
  {
    code: "D3331",
    procedureType: "Endodontics",
    description: "treatment of root canal obstruction; non-surgical access"
  },
  {
    code: "D3332",
    procedureType: "Endodontics",
    description:
      "incomplete endodontic therapy; inoperable, unrestorable or fractured tooth"
  },
  {
    code: "D3333",
    procedureType: "Endodontics",
    description: "internal root repair of perforation defects"
  },
  {
    code: "D3346",
    procedureType: "Endodontics",
    description: "retreatment of previous root canal therapy - anterior"
  },
  {
    code: "D3347",
    procedureType: "Endodontics",
    description: "retreatment of previous root canal therapy - premolar"
  },
  {
    code: "D3348",
    procedureType: "Endodontics",
    description: "retreatment of previous root canal therapy - molar"
  },
  {
    code: "D3351",
    procedureType: "Endodontics",
    description:
      "apexification/recalcification - initial visit (apical closure/calcific repair of perforations, root resorption, etc.)"
  },
  {
    code: "D3352",
    procedureType: "Endodontics",
    description:
      "apexification/recalcification - interim medication replacement"
  },
  {
    code: "D3353",
    procedureType: "Endodontics",
    description:
      "apexification/ recalcification - final visit (includes completed root canal therapy - apical closure/calcific repair of perforations, root resorption, etc.)"
  },
  {
    code: "D3355",
    procedureType: "Endodontics",
    description: "pulpal regeneration - initial visit"
  },
  {
    code: "D3356",
    procedureType: "Endodontics",
    description: "pulpal regeneration - interim medication replacement"
  },
  {
    code: "D3357",
    procedureType: "Endodontics",
    description: "pulpal regeneration - completion of treatment"
  },
  {
    code: "D3410",
    procedureType: "Endodontics",
    description: "apicoectomy - anterior"
  },
  {
    code: "D3421",
    procedureType: "Endodontics",
    description: "apicoectomy - premolar (first root)"
  },
  {
    code: "D3425",
    procedureType: "Endodontics",
    description: "apicoectomy - molar (first root)"
  },
  {
    code: "D3426",
    procedureType: "Endodontics",
    description: "apicoectomy (each additional root)"
  },
  {
    code: "D3428",
    procedureType: "Endodontics",
    description:
      "bone graft in conjunction with periradicular surgery - per tooth, single site"
  },
  {
    code: "D3429",
    procedureType: "Endodontics",
    description:
      "bone graft in conjunction with periradicular surgery - each additional contiguous tooth in the same surgical site"
  },
  {
    code: "D3430",
    procedureType: "Endodontics",
    description: "retrograde filling - per root"
  },
  {
    code: "D3431",
    procedureType: "Endodontics",
    description:
      "biologic materials to aid in soft and osseous tissue regeneration in conjunction with periradicular surgery"
  },
  {
    code: "D3432",
    procedureType: "Endodontics",
    description:
      "guided tissue regeneration, resorbable barrier, per site, in conjunction with periradicular surgery"
  },
  {
    code: "D3450",
    procedureType: "Endodontics",
    description: "root amputation - per root"
  },
  {
    code: "D3460",
    procedureType: "Endodontics",
    description: "endodontic endosseous implant"
  },
  {
    code: "D3470",
    procedureType: "Endodontics",
    description: "intentional re-implantation (including necessary splinting)"
  },
  {
    code: "D3471",
    procedureType: "Endodontics",
    description: "surgical repair of root resorption - anterior"
  },
  {
    code: "D3472",
    procedureType: "Endodontics",
    description: "surgical repair of root resorption � premolar"
  },
  {
    code: "D3473",
    procedureType: "Endodontics",
    description: "surgical repair of root resorption � molar"
  },
  {
    code: "D3501",
    procedureType: "Endodontics",
    description:
      "surgical exposure of root surface without apicoectomy or repair of root resorption � anterior"
  },
  {
    code: "D3502",
    procedureType: "Endodontics",
    description:
      "surgical exposure of root surface without apicoectomy or repair of root resorption � premolar"
  },
  {
    code: "D3503",
    procedureType: "Endodontics",
    description:
      "surgical exposure of root surface without apicoectomy or repair of root resorption � molar"
  },
  {
    code: "D3910",
    procedureType: "Endodontics",
    description: "surgical procedure for isolation of tooth with rubber dam"
  },
  {
    code: "D3911",
    procedureType: "Endodontics",
    description: "intraorifice barrier"
  },
  {
    code: "D3920",
    procedureType: "Endodontics",
    description:
      "hemisection (including any root removal), not including root canal therapy"
  },
  {
    code: "D3921",
    procedureType: "Endodontics",
    description: "decoronation or submergence of an erupted tooth"
  },
  {
    code: "D3950",
    procedureType: "Endodontics",
    description: "canal preparation and fitting of preformed dowel or post"
  },
  {
    code: "D3999",
    procedureType: "Endodontics",
    description: "unspecified endodontic procedure, by report"
  },
  {
    code: "D4210",
    procedureType: "Periodontics",
    description:
      "gingivectomy or gingivoplasty - four or more contiguous teeth or tooth bounded spaces per quadrant"
  },
  {
    code: "D4211",
    procedureType: "Periodontics",
    description:
      "gingivectomy or gingivoplasty - one to three contiguous teeth or tooth bounded spaces per quadrant"
  },
  {
    code: "D4212",
    procedureType: "Periodontics",
    description:
      "gingivectomy or gingivoplasty to allow access for restorative procedure, per tooth"
  },
  {
    code: "D4322",
    procedureType: "Periodontics",
    description: "splint - intra-coronal; natural teeth or prosthetic crowns"
  },
  {
    code: "D4323",
    procedureType: "Periodontics",
    description: "splint - extra-coronal; natural teeth or prosthetic crowns"
  },
  {
    code: "D4230",
    procedureType: "Periodontics",
    description:
      "anatomical crown exposure - four or more contiguous teeth or bounded spaces per quadrant"
  },
  {
    code: "D4231",
    procedureType: "Periodontics",
    description:
      "anatomical crown exposure - one to three teeth or bounded spaces per quadrant"
  },
  {
    code: "D4240",
    procedureType: "Periodontics",
    description:
      "gingival flap procedure, including root planing - four or more contiguous teeth or tooth bounded spaces per quadrant"
  },
  {
    code: "D4241",
    procedureType: "Periodontics",
    description:
      "gingival flap procedure, including root planing - one to three contiguous teeth or tooth bounded spaces per quadrant"
  },
  {
    code: "D4245",
    procedureType: "Periodontics",
    description: "apically positioned flap"
  },
  {
    code: "D4249",
    procedureType: "Periodontics",
    description: "clinical crown lengthening - hard tissue"
  },
  {
    code: "D4260",
    procedureType: "Periodontics",
    description:
      "osseous surgery (including elevation of a full thickness flap and closure) - four or more contiguous teeth or tooth bounded spaces per quadrant"
  },
  {
    code: "D4261",
    procedureType: "Periodontics",
    description:
      "osseous surgery (including elevation of a full thickness flap and closure) - one to three contiguous teeth or tooth bounded spaces per quadrant"
  },
  {
    code: "D4263",
    procedureType: "Periodontics",
    description:
      "bone replacement graft - retained natural tooth - first site in quadrant"
  },
  {
    code: "D4264",
    procedureType: "Periodontics",
    description:
      "bone replacement graft - retained natural tooth - each additional site in quadrant"
  },
  {
    code: "D4265",
    procedureType: "Periodontics",
    description:
      "biologic materials to aid in soft and osseous tissue regeneration, per site"
  },
  {
    code: "D4266",
    procedureType: "Periodontics",
    description:
      "guided tissue regeneration, natural teeth - resorbable barrier, per site"
  },
  {
    code: "D4267",
    procedureType: "Periodontics",
    description:
      "guided tissue regeneration, natural teeth - non-resorbable barrier, per site (includes membrane removal)"
  },
  {
    code: "D4268",
    procedureType: "Periodontics",
    description: "surgical revision procedure, per tooth"
  },
  {
    code: "D4270",
    procedureType: "Periodontics",
    description: "pedicle soft tissue graft procedure"
  },
  {
    code: "D4273",
    procedureType: "Periodontics",
    description:
      "autogenous connective tissue graft procedure (including donor and recipient surgical sites) first tooth, implant or edentulous tooth position in graft"
  },
  {
    code: "D4274",
    procedureType: "Periodontics",
    description:
      "mesial/distal wedge procedure, single tooth (when not performed in conjunction with surgical procedures in the same anatomical area)"
  },
  {
    code: "D4275",
    procedureType: "Periodontics",
    description:
      "non-autogenous connective tissue graft (including recipient site and donor material) first tooth, implant, or edentulous tooth position in graft"
  },
  {
    code: "D4276",
    procedureType: "Periodontics",
    description: "combined connective tissue and pedicle graft, per tooth"
  },
  {
    code: "D4277",
    procedureType: "Periodontics",
    description:
      "free soft tissue graft procedure (including recipient and donor surgical sites) first tooth, implant, or edentulous tooth position in graft"
  },
  {
    code: "D4278",
    procedureType: "Periodontics",
    description:
      "free soft tissue graft procedure (including recipient and donor surgical sites) each additional contiguous tooth, implant, or edentulous tooth position in same graft site"
  },
  {
    code: "D4283",
    procedureType: "Periodontics",
    description:
      "autogenous connective tissue graft procedure (including donor and recipient surgical sites) - each additional contiguous tooth, implant or edentulous tooth position in same graft site"
  },
  {
    code: "D4285",
    procedureType: "Periodontics",
    description:
      "non-autogenous connective tissue graft procedure (including recipient surgical site and donor material) � each additional contiguous tooth, implant or edentulous tooth position in same graft site"
  },
  {
    code: "D4286",
    procedureType: "Periodontics",
    description: "removal of non-resorbable barrier"
  },
  {
    code: "D4341",
    procedureType: "Periodontics",
    description:
      "periodontal scaling and root planing - four or more teeth per quadrant"
  },
  {
    code: "D4342",
    procedureType: "Periodontics",
    description:
      "periodontal scaling and root planing - one to three teeth per quadrant"
  },
  {
    code: "D4346",
    procedureType: "Periodontics",
    description:
      "scaling in presence of generalized moderate or severe gingival inflammation - full mouth, after oral evaluation"
  },
  {
    code: "D4355",
    procedureType: "Periodontics",
    description:
      "full mouth debridement to enable comprehensive periodontal evaluation and diagnosis on a subsequent visit"
  },
  {
    code: "D4381",
    procedureType: "Periodontics",
    description:
      "localized delivery of antimicrobial agents via a controlled release vehicle into diseased crevicular tissue, per tooth"
  },
  {
    code: "D4910",
    procedureType: "Periodontics",
    description: "periodontal maintenance"
  },
  {
    code: "D4920",
    procedureType: "Periodontics",
    description:
      "unscheduled dressing change (by someone other than treating dentist or their staff)"
  },
  {
    code: "D4921",
    procedureType: "Periodontics",
    description: "gingival irrigation with a medicinal agent - per quadrant"
  },
  {
    code: "D4999",
    procedureType: "Periodontics",
    description: "unspecified periodontal procedure, by report"
  },
  {
    code: "D5110",
    procedureType: "Prosthodontics",
    description: "complete denture - maxillary"
  },
  {
    code: "D5120",
    procedureType: "Prosthodontics",
    description: "complete denture - mandibular"
  },
  {
    code: "D5130",
    procedureType: "Prosthodontics",
    description: "immediate denture - maxillary"
  },
  {
    code: "D5140",
    procedureType: "Prosthodontics",
    description: "immediate denture - mandibular"
  },
  {
    code: "D5211",
    procedureType: "Prosthodontics",
    description:
      "maxillary partial denture - resin base (including retentive/clasping materials, rests, and teeth)"
  },
  {
    code: "D5212",
    procedureType: "Prosthodontics",
    description:
      "mandibular partial denture - resin base (including retentive/clasping materials, rests, and teeth)"
  },
  {
    code: "D5213",
    procedureType: "Prosthodontics",
    description:
      "maxillary partial denture - cast metal framework with resin denture bases (including retentive/clasping materials, rests and teeth)"
  },
  {
    code: "D5214",
    procedureType: "Prosthodontics",
    description:
      "mandibular partial denture - cast metal framework with resin denture bases (including retentive/clasping materials, rests and teeth)"
  },
  {
    code: "D5221",
    procedureType: "Prosthodontics",
    description:
      "immediate maxillary partial denture - resin base (including retentive/clasping materials, rests and teeth)"
  },
  {
    code: "D5222",
    procedureType: "Prosthodontics",
    description:
      "immediate mandibular partial denture - resin base (including retentive/clasping materials, rests and teeth)"
  },
  {
    code: "D5223",
    procedureType: "Prosthodontics",
    description:
      "immediate maxillary partial denture - cast metal framework with resin denture bases (including retentive/clasping materials, rests and teeth)"
  },
  {
    code: "D5224",
    procedureType: "Prosthodontics",
    description:
      "immediate mandibular partial denture - cast metal framework with resin denture bases (including retentive/clasping materials, rests and teeth)"
  },
  {
    code: "D5225",
    procedureType: "Prosthodontics",
    description:
      "maxillary partial denture - flexible base (including any clasps, retentive/clasping materials, rests, and teeth)"
  },
  {
    code: "D5226",
    procedureType: "Prosthodontics",
    description:
      "mandibular partial denture � flexible base (including any clasps, retentive/clasping materials, rests, and teeth)"
  },
  {
    code: "D5227",
    procedureType: "Prosthodontics",
    description:
      "immediate maxillary partial denture - flexible base (including any clasps, rests and teeth)"
  },
  {
    code: "D5228",
    procedureType: "Prosthodontics",
    description:
      "immediate mandibular partial denture - flexible base (including any clasps, rests and teeth)"
  },
  {
    code: "D5282",
    procedureType: "Prosthodontics",
    description:
      "removable unilateral partial denture � one piece cast metal (including clasps retentive/clasping materials, rests, and teeth), maxillary"
  },
  {
    code: "D5283",
    procedureType: "Prosthodontics",
    description:
      "removable unilateral partial denture � one piece cast metal (including clasps retentive/clasping materials, rests, and teeth), mandibular"
  },
  {
    code: "D5284",
    procedureType: "Prosthodontics",
    description:
      "removable unilateral partial denture � one piece flexible base (including clasps retentive/clasping materials, rests, and teeth) � per quadrant"
  },
  {
    code: "D5286",
    procedureType: "Prosthodontics",
    description:
      "removable unilateral partial denture � one piece resin (including retentive/clasping materials, rests, and teeth) � per quadrant"
  },
  {
    code: "D5410",
    procedureType: "Prosthodontics",
    description: "adjust complete denture - maxillary"
  },
  {
    code: "D5411",
    procedureType: "Prosthodontics",
    description: "adjust complete denture - mandibular"
  },
  {
    code: "D5421",
    procedureType: "Prosthodontics",
    description: "adjust partial denture - maxillary"
  },
  {
    code: "D5422",
    procedureType: "Prosthodontics",
    description: "adjust partial denture - mandibular"
  },
  {
    code: "D5511",
    procedureType: "Prosthodontics",
    description: "repair broken complete denture base, mandibular"
  },
  {
    code: "D5512",
    procedureType: "Prosthodontics",
    description: "repair broken complete denture base, maxillary"
  },
  {
    code: "D5520",
    procedureType: "Prosthodontics",
    description:
      "replace missing or broken teeth - complete denture (each tooth)"
  },
  {
    code: "D5611",
    procedureType: "Prosthodontics",
    description: "repair resin partial denture base, mandibular"
  },
  {
    code: "D5612",
    procedureType: "Prosthodontics",
    description: "repair resin partial denture base, maxillary"
  },
  {
    code: "D5621",
    procedureType: "Prosthodontics",
    description: "repair cast partial framework, mandibular"
  },
  {
    code: "D5622",
    procedureType: "Prosthodontics",
    description: "repair cast partial framework, maxillary"
  },
  {
    code: "D5630",
    procedureType: "Prosthodontics",
    description:
      "repair or replace broken retentive/clasping materials - per tooth"
  },
  {
    code: "D5640",
    procedureType: "Prosthodontics",
    description: "replace broken teeth - per tooth"
  },
  {
    code: "D5650",
    procedureType: "Prosthodontics",
    description: "add tooth to existing partial denture"
  },
  {
    code: "D5660",
    procedureType: "Prosthodontics",
    description: "add clasp to existing partial denture - per tooth"
  },
  {
    code: "D5670",
    procedureType: "Prosthodontics",
    description:
      "replace all teeth and acrylic on cast metal framework (maxillary)"
  },
  {
    code: "D5671",
    procedureType: "Prosthodontics",
    description:
      "replace all teeth and acrylic on cast metal framework (mandibular)"
  },
  {
    code: "D5710",
    procedureType: "Prosthodontics",
    description: "rebase complete maxillary denture"
  },
  {
    code: "D5711",
    procedureType: "Prosthodontics",
    description: "rebase complete mandibular denture"
  },
  {
    code: "D5720",
    procedureType: "Prosthodontics",
    description: "rebase maxillary partial denture"
  },
  {
    code: "D5721",
    procedureType: "Prosthodontics",
    description: "rebase mandibular partial denture"
  },
  {
    code: "D5725",
    procedureType: "Prosthodontics",
    description: "rebase hybrid prosthesis"
  },
  {
    code: "D5730",
    procedureType: "Prosthodontics",
    description: "reline complete maxillary denture (chairside direct)"
  },
  {
    code: "D5731",
    procedureType: "Prosthodontics",
    description: "reline complete mandibular denture (direct)"
  },
  {
    code: "D5740",
    procedureType: "Prosthodontics",
    description: "reline maxillary partial denture (chairside direct)"
  },
  {
    code: "D5741",
    procedureType: "Prosthodontics",
    description: "reline mandibular partial denture (chairside direct)"
  },
  {
    code: "D5750",
    procedureType: "Prosthodontics",
    description: "reline complete maxillary denture (laboratory indirect)"
  },
  {
    code: "D5751",
    procedureType: "Prosthodontics",
    description: "reline complete mandibular denture (laboratory indirect)"
  },
  {
    code: "D5760",
    procedureType: "Prosthodontics",
    description: "reline maxillary partial denture (laboratory indirect)"
  },
  {
    code: "D5761",
    procedureType: "Prosthodontics",
    description: "reline mandibular partial denture (laboratory indirect)"
  },
  {
    code: "D5765",
    procedureType: "Prosthodontics",
    description:
      "soft liner for complete or partial removable denture - indirect"
  },
  {
    code: "D5810",
    procedureType: "Prosthodontics",
    description: "interim complete denture (maxillary)"
  },
  {
    code: "D5811",
    procedureType: "Prosthodontics",
    description: "interim complete denture (mandibular)"
  },
  {
    code: "D5820",
    procedureType: "Prosthodontics",
    description:
      "interim partial denture (maxillary) (including retentive/clasping materials, rests, and teeth), maxillary"
  },
  {
    code: "D5821",
    procedureType: "Prosthodontics",
    description:
      "interim partial denture (mandibular) (including retentive/clasping materials, rests, and teeth), mandibular"
  },
  {
    code: "D5850",
    procedureType: "Prosthodontics",
    description: "tissue conditioning, maxillary"
  },
  {
    code: "D5851",
    procedureType: "Prosthodontics",
    description: "tissue conditioning, mandibular"
  },
  {
    code: "D5862",
    procedureType: "Prosthodontics",
    description: "precision attachment, by report"
  },
  {
    code: "D5863",
    procedureType: "Prosthodontics",
    description: "overdenture - complete maxillary"
  },
  {
    code: "D5864",
    procedureType: "Prosthodontics",
    description: "overdenture - partial maxillary"
  },
  {
    code: "D5865",
    procedureType: "Prosthodontics",
    description: "overdenture - complete mandibular"
  },
  {
    code: "D5866",
    procedureType: "Prosthodontics",
    description: "overdenture - partial mandibular"
  },
  {
    code: "D5867",
    procedureType: "Prosthodontics",
    description:
      "replacement of replaceable part of semi-precision or precision attachment, per attachment"
  },
  {
    code: "D5875",
    procedureType: "Prosthodontics",
    description:
      "modification of removable prosthesis following implant surgery"
  },
  {
    code: "D5876",
    procedureType: "Prosthodontics",
    description: "add metal substructure to acrylic full denture (per arch)"
  },
  {
    code: "D5899",
    procedureType: "Prosthodontics",
    description: "unspecified removable prosthodontic procedure, by report"
  },
  {
    code: "D5911",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "facial moulage (sectional)"
  },
  {
    code: "D5912",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "facial moulage (complete)"
  },
  {
    code: "D5913",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "nasal prosthesis"
  },
  {
    code: "D5914",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "auricular prosthesis"
  },
  {
    code: "D5915",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "orbital prosthesis"
  },
  {
    code: "D5916",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "ocular prosthesis"
  },
  {
    code: "D5919",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "facial prosthesis"
  },
  {
    code: "D5922",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "nasal septal prosthesis"
  },
  {
    code: "D5923",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "ocular prosthesis, interim"
  },
  {
    code: "D5924",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "cranial prosthesis"
  },
  {
    code: "D5925",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "facial augmentation implant prosthesis"
  },
  {
    code: "D5926",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "nasal prosthesis, replacement"
  },
  {
    code: "D5927",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "auricular prosthesis, replacement"
  },
  {
    code: "D5928",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "orbital prosthesis, replacement"
  },
  {
    code: "D5929",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "facial prosthesis, replacement"
  },
  {
    code: "D5931",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "obturator prosthesis, surgical"
  },
  {
    code: "D5932",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "obturator prosthesis, definitive"
  },
  {
    code: "D5933",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "obturator prosthesis, modification"
  },
  {
    code: "D5934",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "mandibular resection prosthesis with guide flange"
  },
  {
    code: "D5935",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "mandibular resection prosthesis without guide flange"
  },
  {
    code: "D5936",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "obturator prosthesis, interim"
  },
  {
    code: "D5937",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "trismus appliance (not for TMD treatment)"
  },
  {
    code: "D5951",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "feeding aid"
  },
  {
    code: "D5952",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "speech aid prosthesis, pediatric"
  },
  {
    code: "D5953",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "speech aid prosthesis, adult"
  },
  {
    code: "D5954",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "palatal augmentation prosthesis"
  },
  {
    code: "D5955",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "palatal lift prosthesis, definitive"
  },
  {
    code: "D5958",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "palatal lift prosthesis, interim"
  },
  {
    code: "D5959",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "palatal lift prosthesis, modification"
  },
  {
    code: "D5960",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "speech aid prosthesis, modification"
  },
  {
    code: "D5982",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "surgical stent"
  },
  {
    code: "D5983",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "radiation carrier"
  },
  {
    code: "D5984",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "radiation shield"
  },
  {
    code: "D5985",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "radiation cone locator"
  },
  {
    code: "D5986",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "fluoride gel carrier"
  },
  {
    code: "D5987",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "commissure splint"
  },
  {
    code: "D5988",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "surgical splint"
  },
  {
    code: "D5991",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "vesiculobullous disease medicament carrier"
  },
  {
    code: "D5992",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "adjust maxillofacial prosthetic appliance, by report"
  },
  {
    code: "D5993",
    procedureType: "Maxillofacial\n  Prosthetics",
    description:
      "maintenance and cleaning of a maxillofacial prosthesis (extra-or intra-oral) other than required adjustments, by report"
  },
  {
    code: "D5995",
    procedureType: "Periodontics",
    description:
      "periodontal medicament carrier with peripheral seal � laboratory processed � maxillary"
  },
  {
    code: "D5996",
    procedureType: "Periodontics",
    description:
      "periodontal medicament carrier with peripheral seal � laboratory processed � mandibular"
  },
  {
    code: "D5999",
    procedureType: "Maxillofacial\n  Prosthetics",
    description: "unspecified maxillofacial prosthesis, by report"
  },
  {
    code: "D6010",
    procedureType: "Implant \n Services",
    description: "surgical placement of implant body: endosteal implant"
  },
  {
    code: "D6011",
    procedureType: "Implant \n Services",
    description:
      "surgical access to an implant body (second stage implant surgery)"
  },
  {
    code: "D6012",
    procedureType: "Implant \n Services",
    description:
      "surgical placement of interim implant body for transitional prosthesis: endosteal implant"
  },
  {
    code: "D6013",
    procedureType: "Implant \n Services",
    description: "surgical placement of mini implant"
  },
  {
    code: "D6040",
    procedureType: "Implant \n Services",
    description: "surgical placement: eposteal implant"
  },
  {
    code: "D6050",
    procedureType: "Implant \n Services",
    description: "surgical placement: transosteal implant"
  },
  {
    code: "D6051",
    procedureType: "Implant \n Services",
    description: "interim implant abutment placement"
  },
  {
    code: "D6055",
    procedureType: "Implant \n Services",
    description: "connecting bar - implant supported or abutment supported"
  },
  {
    code: "D6056",
    procedureType: "Implant \n Services",
    description: "prefabricated abutment - includes modification and placement"
  },
  {
    code: "D6057",
    procedureType: "Implant \n Services",
    description: "custom fabricated abutment - includes placement"
  },
  {
    code: "D6058",
    procedureType: "Implant \n Services",
    description: "abutment supported porcelain / ceramic crown"
  },
  {
    code: "D6059",
    procedureType: "Implant \n Services",
    description:
      "abutment supported porcelain fused to metal crown (high noble metal)"
  },
  {
    code: "D6060",
    procedureType: "Implant \n Services",
    description:
      "abutment supported porcelain fused to metal crown (predominantly base metal)"
  },
  {
    code: "D6061",
    procedureType: "Implant \n Services",
    description:
      "abutment supported porcelain fused to metal crown (noble metal)"
  },
  {
    code: "D6062",
    procedureType: "Implant \n Services",
    description: "abutment supported cast metal crown (high noble metal)"
  },
  {
    code: "D6063",
    procedureType: "Implant \n Services",
    description:
      "abutment supported cast metal crown (predominantly base metal)"
  },
  {
    code: "D6064",
    procedureType: "Implant \n Services",
    description: "abutment supported cast metal crown (noble metal)"
  },
  {
    code: "D6065",
    procedureType: "Implant \n Services",
    description: "implant supported porcelain / ceramic crown"
  },
  {
    code: "D6066",
    procedureType: "Implant \n Services",
    description:
      "implant supported crown - porcelain fused to high noble alloys"
  },
  {
    code: "D6067",
    procedureType: "Implant \n Services",
    description: "implant supported crown - high noble alloys"
  },
  {
    code: "D6068",
    procedureType: "Implant \n Services",
    description: "abutment supported retainer for porcelain/ceramic FPD"
  },
  {
    code: "D6069",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer for porcelain fused to metal FPD (high noble metal)"
  },
  {
    code: "D6070",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer for porcelain fused to metal FPD (predominantly base metal)"
  },
  {
    code: "D6071",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer for porcelain fused to metal FPD (noble metal)"
  },
  {
    code: "D6072",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer for cast metal FPD (high noble metal)"
  },
  {
    code: "D6073",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer for cast metal FPD (predominantly base metal)"
  },
  {
    code: "D6074",
    procedureType: "Implant \n Services",
    description: "abutment supported retainer for cast metal FPD (noble metal)"
  },
  {
    code: "D6075",
    procedureType: "Implant \n Services",
    description: "implant supported retainer for ceramic FPD"
  },
  {
    code: "D6076",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer for FPD - porcelain fused to high noble alloys"
  },
  {
    code: "D6077",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer for cast metal FPD - high noble alloys"
  },
  {
    code: "D6080",
    procedureType: "Implant \n Services",
    description:
      "implant maintenance procedures when prostheses are removed and reinserted, including cleansing of prostheses and abutments"
  },
  {
    code: "D6081",
    procedureType: "Implant \n Services",
    description:
      "scaling and debridement in the presence of inflammation or mucositis of a single implant, including cleaning of the implant surfaces, without flap entry and closure"
  },
  {
    code: "D6082",
    procedureType: "Implant \n Services",
    description:
      "implant supported crown - porcelain fused to predominantly base alloys"
  },
  {
    code: "D6083",
    procedureType: "Implant \n Services",
    description: "implant supported crown - porcelain fused to noble alloys"
  },
  {
    code: "D6084",
    procedureType: "Implant \n Services",
    description:
      "implant supported crown - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D6085",
    procedureType: "Implant \n Services",
    description: "interim implant crown"
  },
  {
    code: "D6086",
    procedureType: "Implant \n Services",
    description: "implant supported crown - predominantly base alloys"
  },
  {
    code: "D6087",
    procedureType: "Implant \n Services",
    description: "implant supported crown - noble alloys"
  },
  {
    code: "D6088",
    procedureType: "Implant \n Services",
    description: "implant supported crown - titanium and titanium alloys"
  },
  {
    code: "D6090",
    procedureType: "Implant \n Services",
    description: "repair implant supported prosthesis, by report"
  },
  {
    code: "D6091",
    procedureType: "Implant \n Services",
    description:
      "replacement of replaceable part of semi-precision or precision attachment of implant/abutment supported prosthesis, per attachment"
  },
  {
    code: "D6092",
    procedureType: "Implant \n Services",
    description: "re-cement or re-bond implant/abutment supported crown"
  },
  {
    code: "D6093",
    procedureType: "Implant \n Services",
    description:
      "re-cement or re-bond implant/abutment supported fixed partial denture"
  },
  {
    code: "D6094",
    procedureType: "Implant \n Services",
    description: "abutment supported crown - titanium and titanium alloys"
  },
  {
    code: "D6095",
    procedureType: "Implant \n Services",
    description: "repair implant abutment, by report"
  },
  {
    code: "D6096",
    procedureType: "Implant \n Services",
    description: "remove broken implant retaining screw"
  },
  {
    code: "D6097",
    procedureType: "Implant \n Services",
    description:
      "abutment supported crown - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D6098",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer � porcelain fused to predominantly base alloys"
  },
  {
    code: "D6099",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer for FPD - porcelain fused to noble alloys"
  },
  {
    code: "D6100",
    procedureType: "Implant \n Services",
    description: "surgical removal of implant body"
  },
  {
    code: "D6101",
    procedureType: "Implant \n Services",
    description:
      "debridement of a peri-implant defect or defects surrounding a single implant, and surface cleaning of the exposed implant surfaces, including flap entry and closure"
  },
  {
    code: "D6102",
    procedureType: "Implant \n Services",
    description:
      "debridement and osseous contouring of a peri-implant defect or defects surrounding a single implant and includes surface cleaning of the exposed implant surfaces, including flap entry and closure"
  },
  {
    code: "D6103",
    procedureType: "Implant \n Services",
    description:
      "bone graft for repair of peri-implant defect - does not include flap entry and closure"
  },
  {
    code: "D6104",
    procedureType: "Implant \n Services",
    description: "bone graft at time of implant placement"
  },
  {
    code: "D6105",
    procedureType: "Implant \n Services",
    description:
      "removal of implant body not requiring bone removal or flap elevation"
  },
  {
    code: "D6106",
    procedureType: "Implant \n Services",
    description: "guided tissue regeneration � resorbable barrier, per implant"
  },
  {
    code: "D6107",
    procedureType: "Implant \n Services",
    description:
      "guided tissue regeneration � non-resorbable barrier, per implant"
  },
  {
    code: "D6110",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported removable denture for edentulous arch - maxillary"
  },
  {
    code: "D6111",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported removable denture for edentulous arch - mandibular"
  },
  {
    code: "D6112",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported removable denture for partially edentulous arch - maxillary"
  },
  {
    code: "D6113",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported removable denture for partially edentulous arch - mandibular"
  },
  {
    code: "D6114",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported fixed denture for edentulous arch - maxillary"
  },
  {
    code: "D6115",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported fixed denture for edentulous arch - mandibular"
  },
  {
    code: "D6116",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported fixed denture for partially edentulous arch - maxillary"
  },
  {
    code: "D6117",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported fixed denture for partially edentulous arch - mandibular"
  },
  {
    code: "D6118",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported interim fixed denture for edentulous arch - mandibular"
  },
  {
    code: "D6119",
    procedureType: "Implant \n Services",
    description:
      "implant / abutment supported interim fixed denture for edentulous arch - maxillary"
  },
  {
    code: "D6120",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D6121",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer for metal FPD - predominantly base alloys"
  },
  {
    code: "D6122",
    procedureType: "Implant \n Services",
    description: "implant supported retainer for metal FPD - noble alloys"
  },
  {
    code: "D6123",
    procedureType: "Implant \n Services",
    description:
      "implant supported retainer for metal FPD - titanium and titanium alloys"
  },
  {
    code: "D6190",
    procedureType: "Implant \n Services",
    description: "radiographic/surgical implant index, by report"
  },
  {
    code: "D6191",
    procedureType: "Implant \n Services",
    description: "semi-precision abutment � placement"
  },
  {
    code: "D6192",
    procedureType: "Implant \n Services",
    description: "semi-precision attachment � placement"
  },
  {
    code: "D6194",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer crown for FPD - titanium and titanium alloys"
  },
  {
    code: "D6195",
    procedureType: "Implant \n Services",
    description:
      "abutment supported retainer - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D6197",
    procedureType: "Implant \n Services",
    description:
      "replacement of restorative material used to close an access opening of a screw-retained implant supported prosthesis, per implant"
  },
  {
    code: "D6198",
    procedureType: "Implant \n Services",
    description: "remove interim implant component"
  },
  {
    code: "D6199",
    procedureType: "Implant \n Services",
    description: "unspecified implant procedure, by report"
  },
  {
    code: "D6205",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - indirect resin based composite"
  },
  {
    code: "D6210",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - cast high noble metal"
  },
  {
    code: "D6211",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - cast predominantly base metal"
  },
  {
    code: "D6212",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - cast noble metal"
  },
  {
    code: "D6214",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - titanium and titanium alloys"
  },
  {
    code: "D6240",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - porcelain fused to high noble metal"
  },
  {
    code: "D6241",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - porcelain fused to predominantly base metal"
  },
  {
    code: "D6242",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - porcelain fused to noble metal"
  },
  {
    code: "D6243",
    procedureType: "Implant \n Services",
    description: "pontic - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D6245",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - porcelain/ceramic"
  },
  {
    code: "D6250",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - resin with high noble metal"
  },
  {
    code: "D6251",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - resin with predominantly base metal"
  },
  {
    code: "D6252",
    procedureType: "Prosthodontics\n Fixed",
    description: "pontic - resin with noble metal"
  },
  {
    code: "D6253",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "interim pontic - further treatment or completion of diagnosis necessary prior to final impression"
  },
  {
    code: "D6545",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer - cast metal for resin bonded fixed prosthesis"
  },
  {
    code: "D6548",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "retainer - porcelain/ceramic for resin bonded fixed prosthesis"
  },
  {
    code: "D6549",
    procedureType: "Prosthodontics\n Fixed",
    description: "resin retainer - for resin bonded fixed prosthesis"
  },
  {
    code: "D6600",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - porcelain/ceramic, two surfaces"
  },
  {
    code: "D6601",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - porcelain/ceramic, three or more surfaces"
  },
  {
    code: "D6602",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - cast high noble metal, two surfaces"
  },
  {
    code: "D6603",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "retainer inlay - cast high noble metal, three or more surfaces"
  },
  {
    code: "D6604",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - cast predominantly base metal, two surfaces"
  },
  {
    code: "D6605",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "retainer inlay - cast predominantly base metal, three or more surfaces"
  },
  {
    code: "D6606",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - cast noble metal, two surfaces"
  },
  {
    code: "D6607",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - cast noble metal, three or more surfaces"
  },
  {
    code: "D6608",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - porcelain/ceramic, two surfaces"
  },
  {
    code: "D6609",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - porcelain/ceramic, three or more surfaces"
  },
  {
    code: "D6610",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - cast high noble metal, two surfaces"
  },
  {
    code: "D6611",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "retainer onlay - cast high noble metal, three or more surfaces"
  },
  {
    code: "D6612",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - cast predominantly base metal, two surfaces"
  },
  {
    code: "D6613",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "retainer onlay - cast predominantly base metal, three or more surfaces"
  },
  {
    code: "D6614",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - cast noble metal, two surfaces"
  },
  {
    code: "D6615",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - cast noble metal, three or more surfaces"
  },
  {
    code: "D6624",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer inlay - titanium"
  },
  {
    code: "D6634",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer onlay - titanium"
  },
  {
    code: "D6710",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - indirect resin based composite"
  },
  {
    code: "D6720",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - resin with high noble metal"
  },
  {
    code: "D6721",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - resin with predominantly base metal"
  },
  {
    code: "D6722",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - resin with noble metal"
  },
  {
    code: "D6740",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - porcelain/ceramic"
  },
  {
    code: "D6750",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - porcelain fused to high noble metal"
  },
  {
    code: "D6751",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - porcelain fused to predominantly base metal"
  },
  {
    code: "D6752",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - porcelain fused to noble metal"
  },
  {
    code: "D6753",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "retainer crown - porcelain fused to titanium and titanium alloys"
  },
  {
    code: "D6780",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - 3/4 cast high noble metal"
  },
  {
    code: "D6781",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - 3/4 cast predominantly base metal"
  },
  {
    code: "D6782",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - 3/4 cast noble metal"
  },
  {
    code: "D6783",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - 3/4 porcelain/ceramic"
  },
  {
    code: "D6784",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown 3/4 - titanium and titanium alloys"
  },
  {
    code: "D6790",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - full cast high noble metal"
  },
  {
    code: "D6791",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - full cast predominantly base metal"
  },
  {
    code: "D6792",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - full cast noble metal"
  },
  {
    code: "D6793",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "interim retainer crown - further treatment or completion of diagnosis necessary prior to final impression"
  },
  {
    code: "D6794",
    procedureType: "Prosthodontics\n Fixed",
    description: "retainer crown - titanium and titanium alloys"
  },
  {
    code: "D6920",
    procedureType: "Prosthodontics\n Fixed",
    description: "connector bar"
  },
  {
    code: "D6930",
    procedureType: "Prosthodontics\n Fixed",
    description: "re-cement or re-bond fixed partial denture"
  },
  {
    code: "D6940",
    procedureType: "Prosthodontics\n Fixed",
    description: "stress breaker"
  },
  {
    code: "D6950",
    procedureType: "Prosthodontics\n Fixed",
    description: "precision attachment"
  },
  {
    code: "D6980",
    procedureType: "Prosthodontics\n Fixed",
    description:
      "fixed partial denture repair necessitated by restorative material failure"
  },
  {
    code: "D6985",
    procedureType: "Prosthodontics\n Fixed",
    description: "pediatric partial denture, fixed"
  },
  {
    code: "D6999",
    procedureType: "Prosthodontics\n Fixed",
    description: "unspecified fixed prosthodontic procedure, by report"
  },
  {
    code: "D7111",
    procedureType: "OMS",
    description: "extraction, coronal remnants - primary tooth"
  },
  {
    code: "D7140",
    procedureType: "OMS",
    description:
      "extraction, erupted tooth or exposed root (elevation and/or forceps removal)"
  },
  {
    code: "D7210",
    procedureType: "OMS",
    description:
      "extraction, erupted tooth requiring removal of bone and/or sectioning of tooth, and including elevation of mucoperiosteal flap if indicated"
  },
  {
    code: "D7220",
    procedureType: "OMS",
    description: "removal of impacted tooth - soft tissue"
  },
  {
    code: "D7230",
    procedureType: "OMS",
    description: "removal of impacted tooth - partially bony"
  },
  {
    code: "D7240",
    procedureType: "OMS",
    description: "removal of impacted tooth - completely bony"
  },
  {
    code: "D7241",
    procedureType: "OMS",
    description:
      "removal of impacted tooth - completely bony, with unusual surgical complications"
  },
  {
    code: "D7250",
    procedureType: "OMS",
    description: "removal of residual tooth roots (cutting procedure)"
  },
  {
    code: "D7251",
    procedureType: "OMS",
    description:
      "coronectomy - intentional partial tooth removal, impacted teeth only"
  },
  {
    code: "D7260",
    procedureType: "OMS",
    description: "oroantral fistula closure"
  },
  {
    code: "D7261",
    procedureType: "OMS",
    description: "primary closure of a sinus perforation"
  },
  {
    code: "D7270",
    procedureType: "OMS",
    description:
      "tooth re-implantation and/or stabilization of accidentally evulsed or displaced tooth"
  },
  {
    code: "D7272",
    procedureType: "OMS",
    description:
      "tooth transplantation (includes re-implantation from one site to another and splinting and/or stabilization)"
  },
  {
    code: "D7280",
    procedureType: "OMS",
    description: "exposure of an unerupted tooth"
  },
  {
    code: "D7282",
    procedureType: "OMS",
    description:
      "mobilization of erupted or malpositioned tooth to aid eruption"
  },
  {
    code: "D7283",
    procedureType: "OMS",
    description: "placement of device to facilitate eruption of impacted tooth"
  },
  {
    code: "D7285",
    procedureType: "OMS",
    description: "incisional biopsy of oral tissue - hard (bone, tooth)"
  },
  {
    code: "D7286",
    procedureType: "OMS",
    description: "incisional biopsy of oral tissue - soft"
  },
  {
    code: "D7287",
    procedureType: "OMS",
    description: "exfoliative cytological sample collection"
  },
  {
    code: "D7288",
    procedureType: "OMS",
    description: "brush biopsy - transepithelial sample collection"
  },
  {
    code: "D7290",
    procedureType: "OMS",
    description: "surgical repositioning of teeth"
  },
  {
    code: "D7291",
    procedureType: "OMS",
    description: "transeptal fiberotomy/supra crestal fiberotomy, by report"
  },
  {
    code: "D7292",
    procedureType: "OMS",
    description:
      "placement of temporary anchorage device [screw retained plate] requiring flap"
  },
  {
    code: "D7293",
    procedureType: "OMS",
    description: "placement of temporary anchorage device requiring flap"
  },
  {
    code: "D7294",
    procedureType: "OMS",
    description: "placement of temporary anchorage device without flap"
  },
  {
    code: "D7295",
    procedureType: "OMS",
    description: "harvest of bone for use in autogenous grafting procedure"
  },
  {
    code: "D7296",
    procedureType: "OMS",
    description:
      "corticotomy - one to three teeth or tooth spaces, per quadrant"
  },
  {
    code: "D7297",
    procedureType: "OMS",
    description:
      "corticotomy - four or more teeth or tooth spaces, per quadrant"
  },
  {
    code: "D7310",
    procedureType: "OMS",
    description:
      "alveoloplasty in conjunction with extractions - four or more teeth or tooth spaces, per quadrant"
  },
  {
    code: "D7311",
    procedureType: "OMS",
    description:
      "alveoloplasty in conjunction with extractions - one to three teeth or tooth spaces, per quadrant"
  },
  {
    code: "D7320",
    procedureType: "OMS",
    description:
      "alveoloplasty not in conjunction with extractions - four or more teeth or tooth spaces, per quadrant"
  },
  {
    code: "D7321",
    procedureType: "OMS",
    description:
      "alveoloplasty not in conjunction with extractions - one to three teeth or tooth spaces, per quadrant"
  },
  {
    code: "D7298",
    procedureType: "OMS",
    description:
      "removal of temporary anchorage device [screw retained plate], requiring flap"
  },
  {
    code: "D7299",
    procedureType: "OMS",
    description: "removal of temporary anchorage device, requiring flap"
  },
  {
    code: "D7300",
    procedureType: "OMS",
    description: "removal of temporary anchorage device without flap"
  },
  {
    code: "D7340",
    procedureType: "OMS",
    description:
      "vestibuloplasty - ridge extension (secondary epithelialization)"
  },
  {
    code: "D7350",
    procedureType: "OMS",
    description:
      "vestibuloplasty - ridge extension (including soft tissue grafts, muscle reattachment, revision of soft tissue attachment and management of hypertrophied and hyperplastic tissue)"
  },
  {
    code: "D7410",
    procedureType: "OMS",
    description: "excision of benign lesion up to 1.25 cm"
  },
  {
    code: "D7411",
    procedureType: "OMS",
    description: "excision of benign lesion greater than 1.25 cm"
  },
  {
    code: "D7412",
    procedureType: "OMS",
    description: "excision of benign lesion, complicated"
  },
  {
    code: "D7413",
    procedureType: "OMS",
    description: "excision of malignant lesion up to 1.25 cm"
  },
  {
    code: "D7414",
    procedureType: "OMS",
    description: "excision of malignant lesion greater than 1.25 cm"
  },
  {
    code: "D7415",
    procedureType: "OMS",
    description: "excision of malignant lesion, complicated"
  },
  {
    code: "D7440",
    procedureType: "OMS",
    description: "excision of malignant tumor - lesion diameter up to 1.25 cm"
  },
  {
    code: "D7441",
    procedureType: "OMS",
    description:
      "excision of malignant tumor - lesion diameter greater than 1.25 cm"
  },
  {
    code: "D7450",
    procedureType: "OMS",
    description:
      "removal of benign odontogenic cyst or tumor - lesion diameter up to 1.25 cm"
  },
  {
    code: "D7451",
    procedureType: "OMS",
    description:
      "removal of benign odontogenic cyst or tumor - lesion diameter greater than 1.25 cm"
  },
  {
    code: "D7460",
    procedureType: "OMS",
    description:
      "removal of benign nonodontogenic cyst or tumor - lesion diameter greater than 1.25 cm"
  },
  {
    code: "D7461",
    procedureType: "OMS",
    description:
      "removal of benign nonodontogenic cyst or tumor - lesion diameter greater than 1.25 cm"
  },
  {
    code: "D7465",
    procedureType: "OMS",
    description:
      "destruction of lesion(s) by physical or chemical method, by report"
  },
  {
    code: "D7471",
    procedureType: "OMS",
    description: "removal of lateral exostosis (maxilla or mandible)"
  },
  {
    code: "D7472",
    procedureType: "OMS",
    description: "removal of torus palatinus"
  },
  {
    code: "D7473",
    procedureType: "OMS",
    description: "removal of torus mandibularis"
  },
  {
    code: "D7485",
    procedureType: "OMS",
    description: "reduction of osseous tuberosity"
  },
  {
    code: "D7490",
    procedureType: "OMS",
    description: "radical resection of maxilla or mandible"
  },
  {
    code: "D7509",
    procedureType: "OMS",
    description: "marsupialization of odontogenic cyst"
  },
  {
    code: "D7510",
    procedureType: "OMS",
    description: "incision and drainage of abscess - intraoral soft tissue"
  },
  {
    code: "D7511",
    procedureType: "OMS",
    description:
      "incision and drainage of abscess - intraoral soft tissue - complicated (includes drainage of multiple fascial spaces)"
  },
  {
    code: "D7520",
    procedureType: "OMS",
    description: "incision and drainage of abscess - extraoral soft tissue"
  },
  {
    code: "D7521",
    procedureType: "OMS",
    description:
      "incision and drainage of abscess - extraoral soft tissue - complicated (includes drainage of multiple fascial spaces)"
  },
  {
    code: "D7530",
    procedureType: "OMS",
    description:
      "removal of foreign body from mucosa, skin, or subcutaneous alveolar tissue"
  },
  {
    code: "D7540",
    procedureType: "OMS",
    description:
      "removal of reaction producing foreign bodies, musculoskeletal system"
  },
  {
    code: "D7550",
    procedureType: "OMS",
    description:
      "partial ostectomy/sequestrectomy for removal of non-vital bone"
  },
  {
    code: "D7560",
    procedureType: "OMS",
    description:
      "maxillary sinusotomy for removal of tooth fragment or foreign body"
  },
  {
    code: "D7610",
    procedureType: "OMS",
    description: "maxilla - open reduction (teeth immobilized, if present)"
  },
  {
    code: "D7620",
    procedureType: "OMS",
    description: "maxilla - closed reduction (teeth immobilized, if present)"
  },
  {
    code: "D7630",
    procedureType: "OMS",
    description: "mandible - open reduction (teeth immobilized, if present)"
  },
  {
    code: "D7640",
    procedureType: "OMS",
    description: "mandible - closed reduction (teeth immobilized, if present)"
  },
  {
    code: "D7650",
    procedureType: "OMS",
    description: "malar and/or zygomatic arch - open reduction"
  },
  {
    code: "D7660",
    procedureType: "OMS",
    description: "malar and/or zygomatic arch - closed reduction"
  },
  {
    code: "D7670",
    procedureType: "OMS",
    description:
      "alveolus - closed reduction, may include stabilization of teeth"
  },
  {
    code: "D7671",
    procedureType: "OMS",
    description: "alveolus - open reduction, may include stabilization of teeth"
  },
  {
    code: "D7680",
    procedureType: "OMS",
    description:
      "facial bones - complicated reduction with fixation and multiple surgical approaches"
  },
  {
    code: "D7710",
    procedureType: "OMS",
    description: "maxilla - open reduction"
  },
  {
    code: "D7720",
    procedureType: "OMS",
    description: "maxilla - closed reduction"
  },
  {
    code: "D7730",
    procedureType: "OMS",
    description: "mandible - open reduction"
  },
  {
    code: "D7740",
    procedureType: "OMS",
    description: "mandible - closed reduction"
  },
  {
    code: "D7750",
    procedureType: "OMS",
    description: "malar and/or zygomatic arch - open reduction"
  },
  {
    code: "D7760",
    procedureType: "OMS",
    description: "malar and/or zygomatic arch - closed reduction"
  },
  {
    code: "D7770",
    procedureType: "OMS",
    description: "alveolus - open reduction stabilization of teeth"
  },
  {
    code: "D7771",
    procedureType: "OMS",
    description: "alveolus, closed reduction stabilization of teeth"
  },
  {
    code: "D7780",
    procedureType: "OMS",
    description:
      "facial bones - complicated reduction with fixation and multiple approaches"
  },
  {
    code: "D7810",
    procedureType: "OMS",
    description: "open reduction of dislocation"
  },
  {
    code: "D7820",
    procedureType: "OMS",
    description: "closed reduction of dislocation"
  },
  {
    code: "D7830",
    procedureType: "OMS",
    description: "manipulation under anesthesia"
  },
  {
    code: "D7840",
    procedureType: "OMS",
    description: "condylectomy"
  },
  {
    code: "D7850",
    procedureType: "OMS",
    description: "surgical discectomy, with/without implant"
  },
  {
    code: "D7852",
    procedureType: "OMS",
    description: "disc repair"
  },
  {
    code: "D7854",
    procedureType: "OMS",
    description: "synovectomy"
  },
  {
    code: "D7856",
    procedureType: "OMS",
    description: "myotomy"
  },
  {
    code: "D7858",
    procedureType: "OMS",
    description: "joint reconstruction"
  },
  {
    code: "D7860",
    procedureType: "OMS",
    description: "arthrotomy"
  },
  {
    code: "D7865",
    procedureType: "OMS",
    description: "arthroplasty"
  },
  {
    code: "D7870",
    procedureType: "OMS",
    description: "arthrocentesis"
  },
  {
    code: "D7871",
    procedureType: "OMS",
    description: "non-arthroscopic lysis and lavage"
  },
  {
    code: "D7872",
    procedureType: "OMS",
    description: "arthroscopy - diagnosis, with or without biopsy"
  },
  {
    code: "D7873",
    procedureType: "OMS",
    description: "arthroscopy: lavage and lysis of adhesions"
  },
  {
    code: "D7874",
    procedureType: "OMS",
    description: "arthroscopy: disc repositioning and stabilization"
  },
  {
    code: "D7875",
    procedureType: "OMS",
    description: "arthroscopy: synovectomy"
  },
  {
    code: "D7876",
    procedureType: "OMS",
    description: "arthroscopy: discectomy"
  },
  {
    code: "D7877",
    procedureType: "OMS",
    description: "arthroscopy: debridement"
  },
  {
    code: "D7880",
    procedureType: "OMS",
    description: "occlusal orthotic device, by report"
  },
  {
    code: "D7881",
    procedureType: "OMS",
    description: "occlusal orthotic device adjustment"
  },
  {
    code: "D7899",
    procedureType: "OMS",
    description: "unspecified TMD therapy, by report"
  },
  {
    code: "D7910",
    procedureType: "OMS",
    description: "suture of recent small wounds up to 5 cm"
  },
  {
    code: "D7911",
    procedureType: "OMS",
    description: "complicated suture - up to 5 cm"
  },
  {
    code: "D7912",
    procedureType: "OMS",
    description: "complicated suture - greater than 5 cm"
  },
  {
    code: "D7920",
    procedureType: "OMS",
    description:
      "skin graft (identify defect covered, location and type of graft)"
  },
  {
    code: "D7921",
    procedureType: "OMS",
    description:
      "collection and application of autologous blood concentrate product (PRF)"
  },
  {
    code: "D7922",
    procedureType: "OMS",
    description:
      "placement of intra-socket biological dressing to aid in hemostasis or clot stabilization, per site"
  },
  {
    code: "D7940",
    procedureType: "OMS",
    description: "osteoplasty - for orthognathic deformities"
  },
  {
    code: "D7941",
    procedureType: "OMS",
    description: "osteotomy - mandibular rami"
  },
  {
    code: "D7943",
    procedureType: "OMS",
    description:
      "osteotomy - mandibular rami with bone graft; includes obtaining the graft"
  },
  {
    code: "D7944",
    procedureType: "OMS",
    description: "osteotomy - segmented or subapical"
  },
  {
    code: "D7945",
    procedureType: "OMS",
    description: "osteotomy - body of mandible"
  },
  {
    code: "D7946",
    procedureType: "OMS",
    description: "LeFort I (maxilla - total)"
  },
  {
    code: "D7947",
    procedureType: "OMS",
    description: "LeFort I (maxilla - segmented)"
  },
  {
    code: "D7948",
    procedureType: "OMS",
    description:
      "LeFort II or LeFort III (osteoplasty of facial bones for midface hypoplasia or retrusion) - without bone graft"
  },
  {
    code: "D7949",
    procedureType: "OMS",
    description: "LeFort II or LeFort III - with bone graft"
  },
  {
    code: "D7950",
    procedureType: "OMS",
    description:
      "osseous, osteoperiosteal, or cartilage graft of the mandible or maxilla - autogenous or nonautogenous, by report"
  },
  {
    code: "D7951",
    procedureType: "OMS",
    description:
      "sinus augmentation with bone or bone substitutes via a lateral open approach"
  },
  {
    code: "D7952",
    procedureType: "OMS",
    description: "sinus augmentation via a vertical approach"
  },
  {
    code: "D7953",
    procedureType: "OMS",
    description: "bone replacement graft for ridge preservation - per site"
  },
  {
    code: "D7955",
    procedureType: "OMS",
    description: "repair of maxillofacial soft and/or hard tissue defect"
  },
  {
    code: "D7956",
    procedureType: "OMS",
    description:
      "guided tissue regeneration, edentulous area � resorbable barrier, per site"
  },
  {
    code: "D7957",
    procedureType: "OMS",
    description:
      "guided tissue regeneration, edentulous area � non-resorbable barrier, per site"
  },
  {
    code: "D7961",
    procedureType: "OMS",
    description: "buccal / labial frenectomy (frenulectomy)"
  },
  {
    code: "D7962",
    procedureType: "OMS",
    description: "lingual frenectomy (frenulectomy)"
  },
  {
    code: "D7963",
    procedureType: "OMS",
    description: "frenuloplasty"
  },
  {
    code: "D7970",
    procedureType: "OMS",
    description: "excision of hyperplastic tissue - per arch"
  },
  {
    code: "D7971",
    procedureType: "OMS",
    description: "excision of pericoronal gingiva"
  },
  {
    code: "D7972",
    procedureType: "OMS",
    description: "surgical reduction of fibrous tuberosity"
  },
  {
    code: "D7979",
    procedureType: "OMS",
    description: "non-surgical sialolithotomy"
  },
  {
    code: "D7980",
    procedureType: "OMS",
    description: "surgical sialolithotomy"
  },
  {
    code: "D7981",
    procedureType: "OMS",
    description: "excision of salivary gland, by report"
  },
  {
    code: "D7982",
    procedureType: "OMS",
    description: "sialodochoplasty"
  },
  {
    code: "D7983",
    procedureType: "OMS",
    description: "closure of salivary fistula"
  },
  {
    code: "D7990",
    procedureType: "OMS",
    description: "emergency tracheotomy"
  },
  {
    code: "D7991",
    procedureType: "OMS",
    description: "coronoidectomy"
  },
  {
    code: "D7993",
    procedureType: "OMS",
    description: "surgical placement of craniofacial implant � extra oral"
  },
  {
    code: "D7994",
    procedureType: "OMS",
    description: "surgical placement: zygomatic implant"
  },
  {
    code: "D7995",
    procedureType: "OMS",
    description: "synthetic graft - mandible or facial bones, by report"
  },
  {
    code: "D7996",
    procedureType: "OMS",
    description:
      "implant - mandible for augmentation purposes (excluding alveolar ridge), by report"
  },
  {
    code: "D7997",
    procedureType: "OMS",
    description:
      "appliance removal (not by dentist who placed appliance), includes removal of archbar"
  },
  {
    code: "D7998",
    procedureType: "OMS",
    description:
      "intraoral placement of a fixation device not in conjunction with a fracture"
  },
  {
    code: "D7999",
    procedureType: "OMS",
    description: "unspecified oral surgery procedure, by report"
  },
  {
    code: "D8010",
    procedureType: "Orthodontics",
    description: "limited orthodontic treatment of the primary dentition"
  },
  {
    code: "D8020",
    procedureType: "Orthodontics",
    description: "limited orthodontic treatment of the transitional dentition"
  },
  {
    code: "D8030",
    procedureType: "Orthodontics",
    description: "limited orthodontic treatment of the adolescent dentition"
  },
  {
    code: "D8040",
    procedureType: "Orthodontics",
    description: "limited orthodontic treatment of the adult dentition"
  },
  {
    code: "D8070",
    procedureType: "Orthodontics",
    description:
      "comprehensive orthodontic treatment of the transitional dentition"
  },
  {
    code: "D8080",
    procedureType: "Orthodontics",
    description:
      "comprehensive orthodontic treatment of the adolescent dentition"
  },
  {
    code: "D8090",
    procedureType: "Orthodontics",
    description: "comprehensive orthodontic treatment of the adult dentition"
  },
  {
    code: "D8210",
    procedureType: "Orthodontics",
    description: "removable appliance therapy"
  },
  {
    code: "D8220",
    procedureType: "Orthodontics",
    description: "fixed appliance therapy"
  },
  {
    code: "D8660",
    procedureType: "Orthodontics",
    description:
      "pre-orthodontic treatment examination to monitor growth and development"
  },
  {
    code: "D8670",
    procedureType: "Orthodontics",
    description: "periodic orthodontic treatment visit"
  },
  {
    code: "D8680",
    procedureType: "Orthodontics",
    description:
      "orthodontic retention (removal of appliances, construction and placement of retainer(s))"
  },
  {
    code: "D8681",
    procedureType: "Orthodontics",
    description: "removable orthodontic retainer adjustment"
  },
  {
    code: "D8695",
    procedureType: "Orthodontics",
    description:
      "removal of fixed orthodontic appliances for reasons other than completion of treatment"
  },
  {
    code: "D8696",
    procedureType: "Orthodontics",
    description: "repair of orthodontic appliance - maxillary"
  },
  {
    code: "D8697",
    procedureType: "Orthodontics",
    description: "repair of orthodontic appliance - mandibular"
  },
  {
    code: "D8698",
    procedureType: "Orthodontics",
    description: "re-cement or re-bond fixed retainer - maxillary"
  },
  {
    code: "D8699",
    procedureType: "Orthodontics",
    description: "re-cement or re-bond fixed retainer - mandibular"
  },
  {
    code: "D8701",
    procedureType: "Orthodontics",
    description: "repair of fixed retainer, includes reattachment - maxillary"
  },
  {
    code: "D8702",
    procedureType: "Orthodontics",
    description: "repair of fixed retainer, includes reattachment - mandibular"
  },
  {
    code: "D8703",
    procedureType: "Orthodontics",
    description: "replacement of lost or broken retainer - maxillary"
  },
  {
    code: "D8704",
    procedureType: "Orthodontics",
    description: "replacement of lost or broken retainer - mandibular"
  },
  {
    code: "D8999",
    procedureType: "Orthodontics",
    description: "unspecified orthodontic procedure, by report"
  },
  {
    code: "D9110",
    procedureType: "Adjunctive \n General Services",
    description: "palliative treatment of dental pain - per visit"
  },
  {
    code: "D9120",
    procedureType: "Adjunctive \n General Services",
    description: "fixed partial denture sectioning"
  },
  {
    code: "D9130",
    procedureType: "Adjunctive \n General Services",
    description:
      "temporomandibular joint dysfunction - non-invasive physical therapies"
  },
  {
    code: "D9210",
    procedureType: "Adjunctive \n General Services",
    description:
      "local anesthesia not in conjunction with operative or surgical procedures"
  },
  {
    code: "D9211",
    procedureType: "Adjunctive \n General Services",
    description: "regional block anesthesia"
  },
  {
    code: "D9212",
    procedureType: "Adjunctive \n General Services",
    description: "trigeminal division block anesthesia"
  },
  {
    code: "D9215",
    procedureType: "Adjunctive \n General Services",
    description:
      "local anesthesia in conjunction with operative or surgical procedures"
  },
  {
    code: "D9219",
    procedureType: "Adjunctive \n General Services",
    description:
      "evaluation for moderate sedation, deep sedation or general anesthesia"
  },
  {
    code: "D9222",
    procedureType: "Adjunctive \n General Services",
    description: "deep sedation/general anesthesia - first 15 minutes"
  },
  {
    code: "D9223",
    procedureType: "Adjunctive \n General Services",
    description:
      "deep sedation/general anesthesia - each subsequent 15 minute increment"
  },
  {
    code: "D9230",
    procedureType: "Adjunctive \n General Services",
    description: "inhalation of nitrous oxide/analgesia, anxiolysis"
  },
  {
    code: "D9239",
    procedureType: "Adjunctive \n General Services",
    description:
      "intravenous moderate (conscious) sedation/analgesia - first 15 minutes"
  },
  {
    code: "D9243",
    procedureType: "Adjunctive \n General Services",
    description:
      "intravenous moderate (conscious) sedation/analgesia - each subsequent 15 minute increment"
  },
  {
    code: "D9248",
    procedureType: "Adjunctive \n General Services",
    description: "non-intravenous conscious sedation"
  },
  {
    code: "D9310",
    procedureType: "Adjunctive \n General Services",
    description:
      "consultation - diagnostic service provided by dentist or physician other than requesting dentist or physician"
  },
  {
    code: "D9311",
    procedureType: "Adjunctive \n General Services",
    description: "consultation with a medical health care professional"
  },
  {
    code: "D9410",
    procedureType: "Adjunctive \n General Services",
    description: "house/extended care facility call"
  },
  {
    code: "D9420",
    procedureType: "Adjunctive \n General Services",
    description: "hospital or ambulatory surgical center call"
  },
  {
    code: "D9430",
    procedureType: "Adjunctive \n General Services",
    description:
      "office visit for observation (during regularly scheduled hours) - no other services performed"
  },
  {
    code: "D9440",
    procedureType: "Adjunctive \n General Services",
    description: "office visit - after regularly scheduled hours"
  },
  {
    code: "D9450",
    procedureType: "Adjunctive \n General Services",
    description:
      "case presentation, subsequent to detailed and extensive treatment planning"
  },
  {
    code: "D9610",
    procedureType: "Adjunctive \n General Services",
    description: "therapeutic parenteral drug, single administration"
  },
  {
    code: "D9612",
    procedureType: "Adjunctive \n General Services",
    description:
      "therapeutic parenteral drugs, two or more administrations, different medications"
  },
  {
    code: "D9613",
    procedureType: "Adjunctive \n General Services",
    description:
      "infiltration of sustained release therapeutic drug - per quadrant"
  },
  {
    code: "D9630",
    procedureType: "Adjunctive \n General Services",
    description: "drugs or medicaments dispensed in the office for home use"
  },
  {
    code: "D9910",
    procedureType: "Adjunctive \n General Services",
    description: "application of desensitizing medicament"
  },
  {
    code: "D9911",
    procedureType: "Adjunctive \n General Services",
    description:
      "application of desensitizing resin for cervical and/or root surface, per tooth"
  },
  {
    code: "D9912",
    procedureType: "Adjunctive \n General Services",
    description: "pre-visit patient screening"
  },
  {
    code: "D9920",
    procedureType: "Adjunctive \n General Services",
    description: "behaviour management, by report"
  },
  {
    code: "D9930",
    procedureType: "Adjunctive \n General Services",
    description:
      "treatment of complications (post-surgical) - unusual circumstances, by report"
  },
  {
    code: "D9932",
    procedureType: "Adjunctive \n General Services",
    description:
      "cleaning and inspection of removable complete denture, maxillary"
  },
  {
    code: "D9933",
    procedureType: "Adjunctive \n General Services",
    description:
      "cleaning and inspection of removable complete denture, mandibular"
  },
  {
    code: "D9934",
    procedureType: "Adjunctive \n General Services",
    description:
      "cleaning and inspection of removable partial denture, maxillary"
  },
  {
    code: "D9935",
    procedureType: "Adjunctive \n General Services",
    description:
      "cleaning and inspection of removable partial denture, mandibular"
  },
  {
    code: "D9941",
    procedureType: "Adjunctive \n General Services",
    description: "fabrication of athletic mouthguard"
  },
  {
    code: "D9942",
    procedureType: "Adjunctive \n General Services",
    description: "repair and/or reline of occlusal guard"
  },
  {
    code: "D9943",
    procedureType: "Adjunctive \n General Services",
    description: "occlusal guard adjustment"
  },
  {
    code: "D9944",
    procedureType: "Adjunctive \n General Services",
    description: "occlusal guard - hard appliance, full arch"
  },
  {
    code: "D9945",
    procedureType: "Adjunctive \n General Services",
    description: "occlusal guard - soft appliance, full arch"
  },
  {
    code: "D9946",
    procedureType: "Adjunctive \n General Services",
    description: "occlusal guard - hard appliance,partial arch"
  },
  {
    code: "D9947",
    procedureType: "Adjunctive \n General Services",
    description: "custom sleep apnea appliance fabrication and placement"
  },
  {
    code: "D9948",
    procedureType: "Adjunctive \n General Services",
    description: "adjustment of custom sleep apnea appliance"
  },
  {
    code: "D9949",
    procedureType: "Adjunctive \n General Services",
    description: "repair of custom sleep apnea appliance"
  },
  {
    code: "D9950",
    procedureType: "Adjunctive \n General Services",
    description: "occlusion analysis - mounted case"
  },
  {
    code: "D9951",
    procedureType: "Adjunctive \n General Services",
    description: "occlusal adjustment - limited"
  },
  {
    code: "D9952",
    procedureType: "Adjunctive \n General Services",
    description: "occlusal adjustment - complete"
  },
  {
    code: "D9953",
    procedureType: "Adjunctive \n General Services",
    description: "reline custom sleep apnea appliance (indirect)"
  },
  {
    code: "D9961",
    procedureType: "Adjunctive \n General Services",
    description: "duplicate/copy patient's records"
  },
  {
    code: "D9970",
    procedureType: "Adjunctive \n General Services",
    description: "enamel microabrasion"
  },
  {
    code: "D9971",
    procedureType: "Adjunctive \n General Services",
    description:
      "odontoplasty 1-2 teeth; includes removal of enamel projections� per tooth"
  },
  {
    code: "D9972",
    procedureType: "Adjunctive \n General Services",
    description: "external bleaching - per arch - performed in office"
  },
  {
    code: "D9973",
    procedureType: "Adjunctive \n General Services",
    description: "external bleaching - per tooth"
  },
  {
    code: "D9974",
    procedureType: "Adjunctive \n General Services",
    description: "internal bleaching - per tooth"
  },
  {
    code: "D9975",
    procedureType: "Adjunctive \n General Services",
    description:
      "external bleaching for home application, per arch; includes materials and fabrication of custom trays"
  },
  {
    code: "D9985",
    procedureType: "Adjunctive \n General Services",
    description: "sales tax"
  },
  {
    code: "D9986",
    procedureType: "Adjunctive \n General Services",
    description: "missed appointment"
  },
  {
    code: "D9987",
    procedureType: "Adjunctive \n General Services",
    description: "cancelled appointment"
  },
  {
    code: "D9990",
    procedureType: "Adjunctive \n General Services",
    description: "certified translation or sign-language services - per visit"
  },
  {
    code: "D9991",
    procedureType: "Adjunctive \n General Services",
    description:
      "dental case management - addressing appointment compliance barriers"
  },
  {
    code: "D9992",
    procedureType: "Adjunctive \n General Services",
    description: "dental case management - care coordination"
  },
  {
    code: "D9993",
    procedureType: "Adjunctive \n General Services",
    description: "dental case management - motivational interviewing"
  },
  {
    code: "D9994",
    procedureType: "Adjunctive \n General Services",
    description:
      "dental case management - patient education to improve oral health literacy"
  },
  {
    code: "D9995",
    procedureType: "Adjunctive \n General Services",
    description: "teledentistry - synchronous; real-time encounter"
  },
  {
    code: "D9996",
    procedureType: "Adjunctive \n General Services",
    description:
      "teledentistry - asynchronous; information stored and forwarded for subsequent review"
  },
  {
    code: "D9997",
    procedureType: "Adjunctive \n General Services",
    description:
      "dental case management - patients with special health care needs"
  },
  {
    code: "D9999",
    procedureType: "Adjunctive \n General Services",
    description: "unspecified adjunctive procedure, by report"
  }
];
