const { isEmpty } = require("lodash");
const models = require("../../../db/model");
const { v4: uuidv4 } = require("uuid");
const { Op } = require("sequelize");
const Sequelize = require("sequelize");

//create data
module.exports.create = async function (req, res) {
  // #swagger.tags = ['Provider']
  const uniqueId = uuidv4();
  try {
    let {
      doctorName,
      ssn,
      npiId,
      taxId,
      deaNumber,
      practiceName,
      providerType,
      location,
      adminId,
      status
    } = req.body;

    const [npiExists, taxExists] = await Promise.all([
      models.Provider.findOne({ where: { npiId }, raw: true }),
      models.Provider.findOne({ where: { taxId }, raw: true })
    ]);

    if (npiExists || taxExists) {
      let errors = [];
      if (npiExists) errors.push("NPI ID");
      if (taxExists) errors.push("Tax ID");
      const errorMsg = errors.join(" and ") + " should be unique.";

      return res.status(400).send({
        message: errorMsg
      });
    } else {
      const newData = await models.Provider.create({
        doctorName: doctorName,
        ssn: ssn,
        npiId: npiId,
        taxId: taxId,
        deaNumber: deaNumber,
        practiceName: practiceName,
        providerType: providerType,
        location: location,
        adminId: adminId,
        uniqueId: uniqueId,
        status: status
      });

      res.status(200).send({
        data: newData,
        message: "Data updated successfully"
      });
    }
  } catch (e) {
    console.log(e);
    let errorMsg = "Error occurred while saving data";
    res.status(400).send({
      message: errorMsg,
      error: e
    });
  }
};

//get all details
module.exports.getAll = async (req, res) => {
  // #swagger.tags = ['Provider']
  const { adminId } = req.params;
  try {
    const data = await models.Provider.findAll({
      where: {
        adminId
      }
    });
    res.status(200).json({
      data: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Data fetch failed"
    });
  }
};

//get by uniqueId
module.exports.getbyId = async (req, res) => {
  // #swagger.tags = ['Provider']
  const { uniqueId } = req.params;
  try {
    const data = await models.Provider.findOne({
      where: { uniqueId }
    });

    res.status(200).send({
      deta: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "payer fetch failed"
    });
  }
};

//Update by uniqueId
module.exports.updatebyId = async (req, res) => {
  // #swagger.tags = ['Provider']
  const { uniqueId } = req.params;
  const {
    doctorName,
    ssn,
    npiId,
    taxId,
    deaNumber,
    practiceName,
    providerType,
    location,
    status
  } = req.body;

  const updatedata = {};
  if (!isEmpty(doctorName)) updatedata.doctorName = doctorName;
  if (!isEmpty(ssn)) updatedata.ssn = ssn;
  if (!isEmpty(npiId)) updatedata.npiId = npiId; 
  if (!isEmpty(taxId)) updatedata.taxId = taxId;
  if (!isEmpty(deaNumber)) updatedata.deaNumber = deaNumber;
  if (!isEmpty(practiceName)) updatedata.practiceName = practiceName;
  if (!isEmpty(providerType)) updatedata.providerType = providerType;
  if (!isEmpty(location)) updatedata.location = location;
   updatedata.status = status; 

  try {
    if (!uniqueId) {
      return res.status(400).send({
        message: "Unique ID must be provided."
      });
    }

    // Ensure npiId or taxId is not undefined if you are using them in findOne conditions
    if (updatedata.npiId || updatedata.taxId) {
      const conflicts = await Promise.all([
        updatedata.npiId ? models.Provider.findOne({
          where: { npiId, uniqueId: { [Sequelize.Op.ne]: uniqueId } },
          raw: true
        }) : null,
        updatedata.taxId ? models.Provider.findOne({
          where: { taxId, uniqueId: { [Sequelize.Op.ne]: uniqueId } },
          raw: true
        }) : null
      ]);

      const [npiExists, taxExists] = conflicts;
      if (npiExists || taxExists) {
        let errors = [];
        if (npiExists) errors.push("NPI ID");
        if (taxExists) errors.push("Tax ID");
        const errorMsg = errors.join(" and ") + " should be unique.";
        return res.status(400).send({ message: errorMsg });
      }
    }

    const response = await models.Provider.update(updatedata, { where: { uniqueId } });
    if (response[0] > 0) {
      res.status(200).send({
        message: "Provider data updated successfully."
      });
    } else {
      res.status(400).send({ message: "No changes detected or update failed." });
    }
  } catch (error) {
    console.error("Update failed with error: ", error);
    res.status(500).send({
      message: "Data update failed due to an internal error.",
      error: error
    });
  }
};


//delete by uniqueId
module.exports.deletebyId = async (req, res) => {
  // #swagger.tags = ['Provider']
  const { uniqueId } = req.params;
  try {
    const result = await models.Provider.destroy({
      where: {
        uniqueId
      }
    });
    if (result === 0) {
      return res.status(404).json({
        message: "data not found for deletion"
      });
    }
    res.status(200).json({
      data: [{ deleted_id: uniqueId }],
      message: "Provider details deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Provider details deleted failed"
    });
  }
};

//Search filter

module.exports.searchProvider = async (req, res) => {
  // #swagger.tags = ['Provider']
  const { searchString } = req.body;

  if (!searchString) {
    return res.status(400).json({ message: "Search string is required" });
  }

  const searchCriteria = {
    [Op.or]: [
      { doctorName: { [Op.like]: "%" + searchString + "%" } },
      { ssn: { [Op.like]: "%" + searchString + "%" } },
      { npiId: { [Op.like]: "%" + searchString + "%" } },
      { taxId: { [Op.like]: "%" + searchString + "%" } },
      { deaNumber: { [Op.like]: "%" + searchString + "%" } },
      { practiceName: { [Op.like]: "%" + searchString + "%" } },
      { providerType: { [Op.like]: "%" + searchString + "%" } },
      { location: { [Op.like]: "%" + searchString + "%" } },
      { adminId: { [Op.like]: "%" + searchString + "%" } },
      { status: { [Op.like]: "%" + searchString + "%" } }
    ]
  };

  try {
    const result = await models.Provider.findAll({
      where: searchCriteria
    });
    res.status(200).json({
      data: result,
      message: "Search results retrieved successfully"
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      // Use 500 for server errors
      error: "An error occurred while processing your request."
    });
  }
};
