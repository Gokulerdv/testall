// const AWS = require("aws-sdk");
const axios = require("axios");
const async = require("async");
const moment = require("moment");

const models = require("../../../db/model");
const OpenDentalApiPath = process.env.OPEN_DENTAL_URL;
const OpenDentalAuthorization = process.env.OPEN_DENTAL_AUTHORIZATION;

// AWS.config.update({ region: "ap-south-1" });
const dateStamp = moment().subtract(7, "d").format("YYYY-MM-DD HH:mm:ss");

module.exports.getAllPatients = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/patients/Simple`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    // function to get all patients
    const addPatient = async (newPatient, callback) => {
      const newData = {};
      newData.lastName = `${newPatient?.LName}`;
      newData.firstName = `${newPatient?.FName}`;
      newData.Preferred = `${newPatient?.Preferred}`;
      newData.PatStatus = `${newPatient?.PatStatus}`;
      newData.Gender = `${newPatient?.Gender}`;
      newData.Position = `${newPatient?.Position}`;
      newData.dateOfBirth = `${newPatient?.Birthdate}`;
      newData.SSN = `${newPatient?.SSN}`;
      newData.Address = `${newPatient?.Address}`;
      newData.Address2 = `${newPatient?.Address2}`;
      newData.City = `${newPatient?.City}`;
      newData.State = `${newPatient?.State}`;
      newData.Zip = `${newPatient?.Zip}`;
      newData.HmPhone = `${newPatient?.HmPhone}`;
      newData.WkPhone = `${newPatient?.WkPhone}`;
      newData.WirelessPhone = `${newPatient?.WirelessPhone}`;
      newData.email = `${newPatient?.Email}`;
      newData.PriProv = `${newPatient?.PriProv}`;
      newData.priProvAbbr = `${newPatient?.priProvAbbr}`;
      newData.secProvAbbr = `${newPatient?.secProvAbbr}`;
      newData.BillingType = `${newPatient?.BillingType}`;
      newData.ChartNumber = `${newPatient?.ChartNumber}`;
      newData.ClinicNum = `${newPatient.ClinicNum}`;
      newData.statusflag = "A";
      newData.patientId = `${newPatient?.PatNum}`;
      newData.isScheduled = true;
      newData.PatCreatedAt = `${newPatient.DateTStamp}`;

      try {
        const existingPatient = await models.ODPatients.findByPk(
          `${newPatient.PatNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(newData);
          callback();
        } else {
          // Create new patient
          await models.ODPatients.create({
            patientId: `${newPatient.PatNum}`,
            ...newData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addPatient(data, callback);
      },
      async () => {
        const allPatients = await models.ODPatients.findAll({ raw: true });
        res.status(200).send({
          data: allPatients,
          message: `Patient Details uploaded successfully`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODPatients = getODPatients;
async function getODPatients(req, res) {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/patients/Simple`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    // function to get all patients
    const addPatient = async (newPatient, callback) => {
      const newData = {};
      newData.lastName = `${newPatient?.LName}`;
      newData.firstName = `${newPatient?.FName}`;
      newData.Preferred = `${newPatient?.Preferred}`;
      newData.PatStatus = `${newPatient?.PatStatus}`;
      newData.Gender = `${newPatient?.Gender}`;
      newData.Position = `${newPatient?.Position}`;
      newData.dateOfBirth = `${newPatient?.Birthdate}`;
      newData.SSN = `${newPatient?.SSN}`;
      newData.Address = `${newPatient?.Address}`;
      newData.Address2 = `${newPatient?.Address2}`;
      newData.City = `${newPatient?.City}`;
      newData.State = `${newPatient?.State}`;
      newData.Zip = `${newPatient?.Zip}`;
      newData.HmPhone = `${newPatient?.HmPhone}`;
      newData.WkPhone = `${newPatient?.WkPhone}`;
      newData.WirelessPhone = `${newPatient?.WirelessPhone}`;
      newData.email = `${newPatient?.Email}`;
      newData.PriProv = `${newPatient?.PriProv}`;
      newData.priProvAbbr = `${newPatient?.priProvAbbr}`;
      newData.secProvAbbr = `${newPatient?.secProvAbbr}`;
      newData.BillingType = `${newPatient?.BillingType}`;
      newData.ChartNumber = `${newPatient?.ChartNumber}`;
      newData.ClinicNum = `${newPatient.ClinicNum}`;
      newData.statusflag = "A";
      newData.patientId = `${newPatient?.PatNum}`;
      newData.isScheduled = true;
      newData.PatCreatedAt = `${newPatient.DateTStamp}`;

      try {
        const existingPatient = await models.ODPatients.findByPk(
          `${newPatient.PatNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(newData);
          callback();
        } else {
          // Create new patient
          await models.ODPatients.create({
            patientId: `${newPatient.PatNum}`,
            ...newData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addPatient(data, callback);
      },
      async () => {
        console.log("Fetched all OD Patient Records");
      }
    );
  } catch (error) {
    console.log(error);
    // res.status(400).send(error);
  }
}

module.exports.getODPatientAppoinments = getODPatientAppoinments;
async function getODPatientAppoinments(req, res) {
  const dateFormated = moment().subtract(7, "d").format("YYYY-MM-DD");
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/appointments?dateStart=${dateFormated}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    // ==== (function to add appointments)
    const addAppointments = async (data, callback) => {
      const appointmentData = {};
      appointmentData.addedFrom = "OpenDental";
      appointmentData.AptDateTime = `${data?.AptDateTime}`;
      appointmentData.AppointmentTypeNum = `${data?.AppointmentTypeNum}`;
      appointmentData.patientId = `${data?.PatNum}`;
      appointmentData.ProvNum = `${data?.ProvNum}`;

      try {
        const existingPatient = await models.ODAppointments.findByPk(
          `${data.AptNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(appointmentData);
          callback();
        } else {
          // Create new patient
          await models.ODAppointments.create({
            AptNum: `${data.AptNum}`,
            ...appointmentData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addAppointments(data, callback);
      },
      async () => {
        console.log("Fetched all Appointments");
      }
    );
  } catch (error) {
    console.log(error, "getODAppointment error");
  }
}

module.exports.getAllPatientAppoinments = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/appointments?DateTStamp=${dateStamp}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    // ==== (function to add appointments)
    const addAppointments = async (data, callback) => {
      const appointmentData = {};
      appointmentData.addedFrom = "OpenDental";
      appointmentData.AptDateTime = `${data?.AptDateTime}`;
      appointmentData.AppointmentTypeNum = `${data?.AppointmentTypeNum}`;
      appointmentData.patientId = `${data?.PatNum}`;
      appointmentData.ProvNum = `${data?.ProvNum}`;

      try {
        const existingPatient = await models.ODAppointments.findByPk(
          `${data.AptNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(appointmentData);
          callback();
        } else {
          // Create new patient
          await models.ODAppointments.create({
            AptNum: `${data.AptNum}`,
            ...appointmentData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addAppointments(data, callback);
      },
      async () => {
        const appointments = await models.ODAppointments.findAll({ raw: true });
        res.status(200).send({
          data: appointments,
          message: `Appointment Data has been stored`,
        });
      }
    );
  } catch (error) {
    console.log(error, "Open dental error");
    res.status(400).send(error);
  }
};

module.exports.getODAppoinmentsType = getODAppoinmentsType;
async function getODAppoinmentsType(req, res) {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/appointmenttypes`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addAppointmentTypes = async (data, callback) => {
      const appointmentTypeData = {};
      appointmentTypeData.AppointmentTypeName = data.AppointmentTypeName;
      appointmentTypeData.appointmentTypeColor = `${data?.appointmentTypeColor}`;
      appointmentTypeData.RequiredProcCodesNeeded = `${data?.RequiredProcCodesNeeded}`;

      try {
        const existingPatient = await models.ODAppointmentTypes.findByPk(
          `${data.AppointmentTypeNum}`
        );

        if (existingPatient) {
          // Update existing appointment type
          await existingPatient.update(appointmentTypeData);
          callback();
        } else {
          // Create new appointment type
          await models.ODAppointmentTypes.create({
            AppointmentTypeNum: data.AppointmentTypeNum,
            ...appointmentTypeData,
          });
          callback();
        }
      } catch (error) {
        console.log(error, "<-----------------------191");
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addAppointmentTypes(data, callback);
      },
      async () => {
        console.log(`Appointment Type data has beed fetched`);
      }
    );
  } catch (error) {
    console.log(error, "<-------------------------------211");
  }
}

module.exports.getAllAppoinmentsType = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/appointmenttypes`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addAppointmentTypes = async (data, callback) => {
      const appointmentTypeData = {};
      appointmentTypeData.AppointmentTypeName = data.AppointmentTypeName;
      appointmentTypeData.appointmentTypeColor = `${data?.appointmentTypeColor}`;
      appointmentTypeData.RequiredProcCodesNeeded = `${data?.RequiredProcCodesNeeded}`;

      try {
        const existingPatient = await models.ODAppointmentTypes.findByPk(
          `${data.AppointmentTypeNum}`
        );

        if (existingPatient) {
          // Update existing appointment type
          await existingPatient.update(appointmentTypeData);
          callback();
        } else {
          // Create new appointment type
          await models.ODAppointmentTypes.create({
            AppointmentTypeNum: data.AppointmentTypeNum,
            ...appointmentTypeData,
          });
          callback();
        }
      } catch (error) {
        console.log(error, "<-----------------------191");
        res
          .status(400)
          .send({ error: error, msg: "Appointmenttypes db error" });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addAppointmentTypes(data, callback);
      },
      async () => {
        const appointmentTypes = await models.ODAppointmentTypes.findAll({
          raw: true,
        });
        res.status(200).send({
          data: appointmentTypes,
          message: `Appointment Type data has beed fetched`,
        });
      }
    );
  } catch (error) {
    console.log(error, "<-------------------------------211");
    res.status(400).send({ error: error, msg: "Error on open dental api" });
  }
};
module.exports.getODClinics = getODClinics;
async function getODClinics() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/clinics`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });
    const addClinics = async (data, callback) => {
      const clinicsdData = {};
      clinicsdData.Description = `${data?.Description}`;
      clinicsdData.State = `${data?.State}`;
      clinicsdData.Address = `${data?.Address}`;
      clinicsdData.Address2 = `${data?.Address2}`;
      clinicsdData.City = `${data?.City}`;
      clinicsdData.Zip = `${data?.Zip}`;
      clinicsdData.Phone = `${data?.Phone}`;
      clinicsdData.BillingAddress = `${data?.BillingAddress}`;
      clinicsdData.Abbr = `${data?.Abbr}`;

      try {
        const exsitingClinics = await models.ODClinics.findByPk(
          `${data?.ClinicNum}`
        );

        if (exsitingClinics) {
          await exsitingClinics.update(clinicsdData);
          callback();
        } else {
          await models.ODClinics.create({
            ClinicNum: data.ClinicNum,
            ...clinicsdData,
          });
          callback();
        }
      } catch (error) {
        console.log("==========>", error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addClinics(data, callback);
      },
      async () => {
        console.log(`Clinics data has beed fetched`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllClinics = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/clinics`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });
    const addClinics = async (data, callback) => {
      const clinicsdData = {};
      clinicsdData.Description = `${data?.Description}`;
      clinicsdData.State = `${data?.State}`;
      clinicsdData.Address = `${data?.Address}`;
      clinicsdData.Address2 = `${data?.Address2}`;
      clinicsdData.City = `${data?.City}`;
      clinicsdData.Zip = `${data?.Zip}`;
      clinicsdData.Phone = `${data?.Phone}`;
      clinicsdData.BillingAddress = `${data?.BillingAddress}`;
      clinicsdData.Abbr = `${data?.Abbr}`;

      try {
        const exsitingClinics = await models.ODClinics.findByPk(
          `${data?.ClinicNum}`
        );

        if (exsitingClinics) {
          await exsitingClinics.update(clinicsdData);
          callback();
        } else {
          await models.ODClinics.create({
            ClinicNum: data.ClinicNum,
            ...clinicsdData,
          });
          callback();
        }
      } catch (error) {
        console.log("==========>", error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addClinics(data, callback);
      },
      async () => {
        const clincs = await models.ODClinics.findAll({ raw: true });
        res.status(200).send({
          data: clincs,
          message: `Clinics data has beed fetched`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODPatPlans = getODPatPlans;
async function getODPatPlans() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/patplans`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addPatplans = async (data, callback) => {
      const patPlanData = {};
      patPlanData.patientId = data.PatNum;
      patPlanData.PatID = `${data?.PatID}`;
      patPlanData.InsSubNum = `${data?.InsSubNum}`;
      patPlanData.Relationship = `${data?.Relationship}`;
      patPlanData.PatNum = `${data?.PatNum}`;

      try {
        const existingPatient = await models.ODPatPlans.findByPk(
          data.PatPlanNum
        );

        if (existingPatient) {
          // Update existing appointment type
          await existingPatient.update(patPlanData);
          callback();
        } else {
          // Create new appointment type
          await models.ODPatPlans.create({
            PatPlanNum: data.PatPlanNum,
            ...patPlanData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addPatplans(data, callback);
      },
      async () => {
        console.log(`Patplans data are fetched and added`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllPatPlans = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/patplans`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addPatplans = async (data, callback) => {
      const patPlanData = {};
      patPlanData.patientId = data.PatNum;
      patPlanData.PatID = `${data?.PatID}`;
      patPlanData.InsSubNum = `${data?.InsSubNum}`;
      patPlanData.Relationship = `${data?.Relationship}`;
      patPlanData.PatNum = `${data?.PatNum}`;

      try {
        const existingPatient = await models.ODPatPlans.findByPk(
          data.PatPlanNum
        );

        if (existingPatient) {
          // Update existing appointment type
          await existingPatient.update(patPlanData);
          callback();
        } else {
          // Create new appointment type
          await models.ODPatPlans.create({
            PatPlanNum: data.PatPlanNum,
            ...patPlanData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addPatplans(data, callback);
      },
      async () => {
        const patPlans = await models.ODPatPlans.findAll({ raw: true });
        res.status(200).send({
          data: patPlans,
          message: `Patplans data are fetched and added`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODInsSubs = getODInsSubs;
async function getODInsSubs() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/inssubs`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addInsSubs = async (data, callback) => {
      const insSubsData = {};
      insSubsData.PlanNum = data?.PlanNum;
      insSubsData.Subscriber = `${data?.Subscriber}`;
      insSubsData.SubscriberID = `${data?.SubscriberID}`;
      insSubsData.BenefitNotes = `${data?.BenefitNotes}`;
      insSubsData.ReleaseInfo = `${data?.ReleaseInfo}`;

      try {
        const existingPatient = await models.ODInsSub.findByPk(data.InsSubNum);

        if (existingPatient) {
          // Update existing insSubsData
          await existingPatient.update(insSubsData);
          callback();
        } else {
          // Create new insSubsData
          await models.ODInsSub.create({
            InsSubNum: data.InsSubNum,
            ...insSubsData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addInsSubs(data, callback);
      },
      async () => {
        console.log(`Inssubs data are fetched and updated`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllInsSubs = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/inssubs`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addInsSubs = async (data, callback) => {
      const insSubsData = {};
      insSubsData.PlanNum = data?.PlanNum;
      insSubsData.Subscriber = `${data?.Subscriber}`;
      insSubsData.SubscriberID = `${data?.SubscriberID}`;
      insSubsData.BenefitNotes = `${data?.BenefitNotes}`;
      insSubsData.ReleaseInfo = `${data?.ReleaseInfo}`;

      try {
        const existingPatient = await models.ODInsSub.findByPk(data.InsSubNum);

        if (existingPatient) {
          // Update existing insSubsData
          await existingPatient.update(insSubsData);
          callback();
        } else {
          // Create new insSubsData
          await models.ODInsSub.create({
            InsSubNum: data.InsSubNum,
            ...insSubsData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addInsSubs(data, callback);
      },
      async () => {
        const insSubData = await models.ODInsSub.findAll({ raw: true });
        res.status(200).send({
          data: insSubData,
          message: `Inssubs data are fetched and updated`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODProcedureCodes = getODProcedureCodes;
async function getODProcedureCodes() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/procedurecodes`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });
    var count = 0;
    const addProcedure = async (data, callback) => {
      const procedureCodeData = {};
      procedureCodeData.procedureType = `${data?.procCat}`;
      procedureCodeData.AbbrDesc = `${data?.AbbrDesc}`;
      procedureCodeData.description = `${data?.Descript}`;
      procedureCodeData.ProcTime = `${data?.ProcTime}`;
      procedureCodeData.ProcCode = `${data?.ProcCode}`;
      procedureCodeData.CodeNum = `${data?.CodeNum}`;
      procedureCodeData.DateTStamp = `${data?.DateTStamp}`;
      procedureCodeData.CodeNum = `${data?.CodeNum}`;

      try {
        const existingProcedure = await models.ODProcedureCode.findByPk(
          `${data?.CodeNum}`
        );

        if (existingProcedure) {
          // Update existing procedure code
          await existingProcedure.update(procedureCodeData);
          count = count + 1;
          callback();
        } else {
          // Create new insSubsData
          await models.ODProcedureCode.create({
            ProcCode: data.ProcCode,
            ...procedureCodeData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };
    async.eachSeries(
      response.data,
      (data, callback) => {
        addProcedure(data, callback);
      },
      async () => {
        console.log(`ProcedureCode data has been added/updated to ebv table`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllProcedureCodes = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/procedurecodes`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });
    var count = 0;
    const addProcedure = async (data, callback) => {
      const procedureCodeData = {};
      procedureCodeData.procedureType = `${data?.procCat}`;
      procedureCodeData.AbbrDesc = `${data?.AbbrDesc}`;
      procedureCodeData.description = `${data?.Descript}`;
      procedureCodeData.ProcTime = `${data?.ProcTime}`;
      procedureCodeData.ProcCode = `${data?.ProcCode}`;
      procedureCodeData.CodeNum = `${data?.CodeNum}`;
      procedureCodeData.DateTStamp = `${data?.DateTStamp}`;
      procedureCodeData.CodeNum = `${data?.CodeNum}`;

      try {
        const existingProcedure = await models.ODProcedureCode.findByPk(
          `${data?.CodeNum}`
        );

        if (existingProcedure) {
          // Update existing procedure code
          await existingProcedure.update(procedureCodeData);
          count = count + 1;
          callback();
        } else {
          // Create new insSubsData
          await models.ODProcedureCode.create({
            ProcCode: data.ProcCode,
            ...procedureCodeData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };
    async.eachSeries(
      response.data,
      (data, callback) => {
        addProcedure(data, callback);
      },
      async () => {
        const procedureCodeData = await models.ODProcedureCode.findAll({
          raw: true,
        });
        res.status(200).send({
          data: procedureCodeData,
          message: `ProcedureCode data has been added/updated to ebv table`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODFamilyModulesByPatientId = getODFamilyModulesByPatientId;
async function getODFamilyModulesByPatientId() {
  const addFamMod = async (data, callback) => {
    try {
      const res = await axios.get(
        `${OpenDentalApiPath}/familymodules/${data?.PatNum}/Insurance`,
        {
          headers: {
            Authorization: OpenDentalAuthorization,
          },
        }
      );
      const familydata = res.data[0];

      // add data to family modules
      const familyModuleData = {};
      if (familydata) {
        // familyModuleData.patientId = `${familydata?.PatNum}`;
        familyModuleData.InsSubNum = `${familydata?.InsSubNum}`;
        familyModuleData.Subscriber = `${familydata?.Subscriber}`;
        familyModuleData.subscriberName = `${familydata?.subscriber}`;
        familyModuleData.SubscriberID = `${familydata?.SubscriberID}`;
        familyModuleData.Relationship = `${familydata?.Relationship}`;
        familyModuleData.CarrierNum = `${familydata?.CarrierNum}`;
        familyModuleData.CarrierName = `${familydata?.CarrierName}`;
        familyModuleData.PlanNum = `${familydata?.PlanNum}`;
        familyModuleData.GroupName = `${familydata?.GroupName}`;
        familyModuleData.GroupNum = `${familydata?.GroupNum}`;
        familyModuleData.planType = `${familydata?.planType}`;
        familyModuleData.EmployerNum = `${familydata?.EmployerNum}`;
        familyModuleData.employer = `${familydata?.employer}`;
        familyModuleData.PatPlanNum = `${familydata?.PatPlanNum}`;
        familyModuleData.CopayFeeSched = `${familydata?.CopayFeeSched}`;
        familyModuleData.Ordinal = `${familydata.Ordinal}`;
        familyModuleData.Ordinaltype = `${familydata.ordinal}`;

        // update famil modules model
        try {
          const existingFamilyModule = await models.ODFamilyModules.findByPk(
            `${familydata?.PatNum}`
          );

          if (existingFamilyModule) {
            // Update existing family
            await existingFamilyModule.update(familyModuleData);
            callback();
          } else {
            // Create new insSubsData
            await models.ODFamilyModules.create({
              patientId: familydata?.PatNum,
              ...familyModuleData,
            });
            callback();
          }
        } catch (error) {
          console.log(error);
        }
      } else {
        //("No family modules skip");
        callback();
      }

      //************ end */
    } catch (error) {
      console.log(error);
    }
  };
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/patients/Simple?DateTStamp=${dateStamp}&PatStatus=Patient`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    async.eachSeries(
      response.data,
      (data, callback) => {
        addFamMod(data, callback);
      },
      async () => {
        console.log(`data has been added/updated to ebv table`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}

module.exports.getFamilyModulesByPatientId = async function (req, res) {
  // #swagger.tags = ['Opendental']

  const addFamMod = async (data, callback) => {
    try {
      const res = await axios.get(
        `${OpenDentalApiPath}/familymodules/${data?.PatNum}/Insurance`,
        {
          headers: {
            Authorization: OpenDentalAuthorization,
          },
        }
      );
      const familydata = res.data[0];

      // add data to family modules
      const familyModuleData = {};
      if (familydata) {
        // familyModuleData.patientId = `${familydata?.PatNum}`;
        familyModuleData.InsSubNum = `${familydata?.InsSubNum}`;
        familyModuleData.Subscriber = `${familydata?.Subscriber}`;
        familyModuleData.subscriberName = `${familydata?.subscriber}`;
        familyModuleData.SubscriberID = `${familydata?.SubscriberID}`;
        familyModuleData.Relationship = `${familydata?.Relationship}`;
        familyModuleData.CarrierNum = `${familydata?.CarrierNum}`;
        familyModuleData.CarrierName = `${familydata?.CarrierName}`;
        familyModuleData.PlanNum = `${familydata?.PlanNum}`;
        familyModuleData.GroupName = `${familydata?.GroupName}`;
        familyModuleData.GroupNum = `${familydata?.GroupNum}`;
        familyModuleData.planType = `${familydata?.planType}`;
        familyModuleData.EmployerNum = `${familydata?.EmployerNum}`;
        familyModuleData.employer = `${familydata?.employer}`;
        familyModuleData.PatPlanNum = `${familydata?.PatPlanNum}`;
        familyModuleData.CopayFeeSched = `${familydata?.CopayFeeSched}`;
        familyModuleData.Ordinal = `${familydata.Ordinal}`;
        familyModuleData.Ordinaltype = `${familydata.ordinal}`;

        // update famil modules model
        try {
          const existingFamilyModule = await models.ODFamilyModules.findByPk(
            `${familydata?.PatNum}`
          );

          if (existingFamilyModule) {
            // Update existing family
            await existingFamilyModule.update(familyModuleData);
            callback();
          } else {
            // Create new insSubsData
            await models.ODFamilyModules.create({
              patientId: familydata?.PatNum,
              ...familyModuleData,
            });
            callback();
          }
        } catch (error) {
          console.log(error);
          res.status(400).send({ error: error });
        }
      } else {
        //("No family modules skip");
        callback();
      }

      //************ end */
    } catch (error) {
      console.log(error);
      res
        .status(400)
        .send({ error: error, message: "Open dental family module api error" });
    }
  };
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/patients/Simple?DateTStamp=${dateStamp}&PatStatus=Patient`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    async.eachSeries(
      response.data,
      (data, callback) => {
        addFamMod(data, callback);
      },
      async () => {
        const data = await models.ODFamilyModules.findAll({ raw: true });
        res.status(200).send({
          data: data,
          message: `data has been added/updated to ebv table`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODProviders = getODProviders;
async function getODProviders() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/providers`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });
    var count = 0;
    const addproviders = async (data, callback) => {
      const providersData = {};
      providersData.ProvNum = `${data?.ProvNum}`;
      providersData.lastName = `${data?.LName}`;
      providersData.firstName = `${data?.FName}`;
      providersData.SSN = `${data?.SSN}`;
      providersData.StateLicense = `${data?.StateLicense}`;
      providersData.PreferredName = `${data?.PreferredName}`;
      providersData.Specialty = `${data?.Specialty}`;
      providersData.NationalProvID = `${data?.NationalProvID}`;

      try {
        const existingProviders = await models.ODProvider.findByPk(
          `${data?.ProvNum}`
        );

        if (existingProviders) {
          // Update existing insSubsData
          await existingProviders.update(providersData);
          count = count + 1;
          callback();
        } else {
          // Create new insSubsData
          await models.ODProvider.create({
            provNum: `${data?.ProvNum}`,
            ...providersData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addproviders(data, callback);
      },
      async () => {
        console.log(`Provider data has been added/updated to ebv table`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllProviders = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/providers`, {
      headers: {
        Authorization: OpenDentalAuthorization
      }
    });
    var count = 0;
    const addproviders = async (data, callback) => {
      const providersData = {};
      providersData.ProvNum = `${data?.ProvNum}`;
      providersData.lastName = `${data?.LName}`;
      providersData.firstName = `${data?.FName}`;
      providersData.SSN = `${data?.SSN}`;
      providersData.StateLicense = `${data?.StateLicense}`;
      providersData.PreferredName = `${data?.PreferredName}`;
      providersData.Specialty = `${data?.Specialty}`;
      providersData.NationalProvID = `${data?.NationalProvID}`;

      try {
        const existingProviders = await models.ODProvider.findByPk(
          `${data?.ProvNum}`
        );

        if (existingProviders) {
          // Update existing insSubsData
          await existingProviders.update(providersData);
          count = count + 1;
          callback();
        } else {
          // Create new insSubsData
          await models.ODProvider.create({
            provNum: `${data?.ProvNum}`,
            ...providersData
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addproviders(data, callback);
      },
      async () => {
        const data = await models.ODProvider.findAll({ raw: true });
        res.status(200).send({
          data: data,
          message: `Provider data has been added/updated to ebv table`
        });
      }
    );

    // res.status(200).send({
    //   data: [],
    //   message: `Provider data has been added/updated to ebv table`,
    // });
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODCarriers = getODCarriers;
async function getODCarriers() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/carriers`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    var count = 0;
    const addCarriers = async (data, callback) => {
      const carrierData = {};
      carrierData.payersName = `${data?.CarrierName}`;
      carrierData.state = `${data?.State}`;
      carrierData.city = `${data?.city}`;
      carrierData.zipCode = `${data?.Zip}`;
      carrierData.address1 = `${data?.Address}`;
      carrierData.address2 = `${data?.Address2}`;
      carrierData.payerIdCode = `${data?.ElectID}`;
      carrierData.Phone = `${data?.Phone}`;

      try {
        const existingCarriers = await models.ODCarriers.findByPk(
          `${data?.CarrierNum}`
        );

        if (existingCarriers) {
          // Update existing insSubsData
          await existingCarriers.update(carrierData);
          count = count + 1;
          callback();
        } else {
          // Create new insSubsData
          await models.ODCarriers.create({
            CarrierNum: `${data?.CarrierNum}`,
            ...carrierData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addCarriers(data, callback);
      },
      async () => {
        console.log(`${count} data has been added/updated to ebv table`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllCarriers = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/carriers`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    var count = 0;
    const addCarriers = async (data, callback) => {
      const carrierData = {};
      carrierData.payersName = `${data?.CarrierName}`;
      carrierData.state = `${data?.State}`;
      carrierData.city = `${data?.city}`;
      carrierData.zipCode = `${data?.Zip}`;
      carrierData.address1 = `${data?.Address}`;
      carrierData.address2 = `${data?.Address2}`;
      carrierData.payerIdCode = `${data?.ElectID}`;
      carrierData.Phone = `${data?.Phone}`;

      try {
        const existingCarriers = await models.ODCarriers.findByPk(
          `${data?.CarrierNum}`
        );

        if (existingCarriers) {
          // Update existing insSubsData
          await existingCarriers.update(carrierData);
          count = count + 1;
          callback();
        } else {
          // Create new insSubsData
          await models.ODCarriers.create({
            CarrierNum: `${data?.CarrierNum}`,
            ...carrierData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addCarriers(data, callback);
      },
      async () => {
        const data = await models.ODCarriers.findAll({ raw: true });
        res.status(200).send({
          data: data,
          message: `${count} data has been added/updated to ebv table`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getODInsplans = getODInsplans;
async function getODInsplans() {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/insplans`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addInsPlans = async (data, callback) => {
      const insPlanData = {};
      insPlanData.groupNumber = `${data?.GroupNum}`;
      insPlanData.CarrierNum = `${data?.CarrierNum}`;
      insPlanData.EmployerNum = `${data?.EmployerNum}`;
      insPlanData.PlanType = `${data?.PlanType}`;

      try {
        const existingPatient = await models.ODInsPlans.findByPk(
          `${data.PlanNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(insPlanData);
          callback();
        } else {
          // Create new patient
          await models.ODInsPlans.create({
            PlanNum: `${data.PlanNum}`,
            ...insPlanData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addInsPlans(data, callback);
      },
      async () => {
        console.log(`Insplans data are fetched and updated`);
      }
    );
  } catch (error) {
    console.log(error);
  }
}
module.exports.getAllInsplans = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(`${OpenDentalApiPath}/insplans`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    const addInsPlans = async (data, callback) => {
      const insPlanData = {};
      insPlanData.groupNumber = `${data?.GroupNum}`;
      insPlanData.CarrierNum = `${data?.CarrierNum}`;
      insPlanData.EmployerNum = `${data?.EmployerNum}`;
      insPlanData.PlanType = `${data?.PlanType}`;

      try {
        const existingPatient = await models.ODInsPlans.findByPk(
          `${data.PlanNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(insPlanData);
          callback();
        } else {
          // Create new patient
          await models.ODInsPlans.create({
            PlanNum: `${data.PlanNum}`,
            ...insPlanData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
        res.status(400).send({ error: error });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addInsPlans(data, callback);
      },
      async () => {
        const data = await models.ODInsPlans.findAll({ raw: true });
        res.status(200).send({
          data: data,
          message: `Insplans data are fetched and updated`,
        });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
  }
};

module.exports.getDefinitions = async (req, res) => {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/definitions`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });
    return response.data;
  } catch (e) {
    console.log(e);
    res.status(400).send(e);
  }
};

module.exports.getODProcedureLogs = getODProcedureLogs;
async function getODProcedureLogs() {
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/procedurelogs?DateTStamp=${dateStamp}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    const addProcedureLogs = async (data, callback) => {
      const procedureLogs = {};
      procedureLogs.ProcNum = `${data.ProcNum}`;
      procedureLogs.PatNum = `${data?.PatNum}`;
      procedureLogs.AptNum = `${data?.AptNum}`;
      procedureLogs.ProvNum = `${data?.ProvNum}`;
      procedureLogs.procCode = `${data?.procCode}`;

      try {
        const existingPLogs = await models.ODProcedureLog.findByPk(
          `${data.ProcNum}`
        );

        if (existingPLogs) {
          // Update existing appointment type
          await existingPLogs.update(procedureLogs);
          callback();
        } else {
          // Create new appointment type
          await models.ODProcedureLog.create({
            ProcNum: data.ProcNum,
            ...procedureLogs,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addProcedureLogs(data, callback);
      },
      async () => {
        console.log(`ProcedureLogs data has beed fetched`);
      }
    );
  } catch (e) {}
}
module.exports.getAllProcedureLogs = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/procedurelogs?DateTStamp=${dateStamp}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    const addProcedureLogs = async (data, callback) => {
      const procedureLogs = {};
      procedureLogs.ProcNum = `${data.ProcNum}`;
      procedureLogs.PatNum = `${data?.PatNum}`;
      procedureLogs.AptNum = `${data?.AptNum}`;
      procedureLogs.ProvNum = `${data?.ProvNum}`;
      procedureLogs.procCode = `${data?.procCode}`;

      try {
        const existingPLogs = await models.ODProcedureLog.findByPk(
          `${data.ProcNum}`
        );

        if (existingPLogs) {
          // Update existing appointment type
          await existingPLogs.update(procedureLogs);
          callback();
        } else {
          // Create new appointment type
          await models.ODProcedureLog.create({
            ProcNum: data.ProcNum,
            ...procedureLogs,
          });
          callback();
        }
      } catch (error) {
        res.status(400).send({ error: error, msg: "ProcedureLogs db error" });
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addProcedureLogs(data, callback);
      },
      async () => {
        const data = await models.ODProcedureLog.findAll({ raw: true });
        res.status(200).send({
          data: data,
          message: `ProcedureLogs data has beed fetched`,
        });
      }
    );
  } catch (e) {
    console.log(e);
    res.status(400).send({ error: e, msg: "ProcedureLogs Opendental error" });
  }
};

module.exports.getAllODProcedureCodes = async function (req, res) {
  // #swagger.tags = ['Opendental']
  const { procedureType } = req.query;
  const params = {};
  if (procedureType) {
    params["procedureType"] = procedureType;
  }

  try {
    const procedureCodes = await models.ODProcedureCode.findAll({
      where: params,
      raw: true,
    });

    res.status(200).json({
      data: procedureCodes,
      message: "Procedure Code details fetched successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Procedure Code fetch failed",
    });
  }
};

module.exports.getAllODProcedureTypes = async (req, res) => {
  // #swagger.tags = ['Opendental']
  try {
    const procedureCodes = await models.ODProcedureCode.findAll({
      attributes: [
        [
          models.Sequelize.fn(
            "DISTINCT",
            models.Sequelize.col("procedureType")
          ),
          "procedureType",
        ],
      ],
      raw: true,
    });

    const procedureTypes = procedureCodes.map((code) => code.procedureType);

    res.status(200).json({
      data: procedureTypes,
      message: "Procedure Types details fetched successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Procedure Types fetch failed",
    });
  }
};

module.exports.getAllODProviders = async function (req, res) {
  // #swagger.tags = ['Opendental']
  try {
    const providers = await models.ODProvider.findAll();

    res.status(200).json({
      data: providers,
      message: "Opendental provider details fetched successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Opendental provider fetch failed",
    });
  }
};
