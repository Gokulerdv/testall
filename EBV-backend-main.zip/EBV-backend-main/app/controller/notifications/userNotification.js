const models = require("../../../db/model");

const defaultSettings = [
  {
    typeofnotify: "opendental",
    notifyinapp: ["success", "demographic", "technical", "notlinked"],
    fromDate: null,
    toDate: null,
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "ispatientdelete",
    notifyinapp: ["csv", "manual", "opendental"],
    fromDate: null,
    toDate: null,
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "ispatientupdate",
    notifyinapp: ["csv", "manual", "opendental"],
    fromDate: null,
    toDate: null,
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "csv",
    notifyinapp: ["success", "demographic", "technical", "notlinked"],
    fromDate: null,
    toDate: null,
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "manual",
    notifyinapp: ["success", "demographic", "technical", "notlinked"],
    fromDate: null,
    toDate: null,
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "isbulkverify",
    notifyinapp: ["success", "demographic", "technical", "notlinked", "opendental", "manual", "csv"],
    fromDate: null,
    toDate: null,
    isinapp: false,
    isemail: false,
    issms: false
  }
];

const validateArray = (inputArray, validValues) => {
  return inputArray.every((value) => validValues.includes(value));
};

module.exports.createAll = async function (req, res) {
  // #swagger.tags = ['User Notification']

  try {
    await models.UserNotification.bulkCreate(defaultSettings);

    res.status(200).send({
      message: "Default User notification created successfully"
    });
  } catch (error) {
    console.error({ error });
    res
      .status(500)
      .send({ error: error, message: "User notification creation failed" });
  }
};

module.exports.getAll = async function (req, res) {
  // #swagger.tags = ['User Notification']
  try {
    const userNotifications = await models.UserNotification.findAll();

    if (userNotifications.length === 0) {
      await models.UserNotification.bulkCreate(defaultSettings);

      const userNotifications = await models.UserNotification.findAll();
      res.status(200).json({
        data: userNotifications,
        message: "All User Notifications fetched successfully"
      });
    } else {
      res.status(200).json({
        data: userNotifications,
        message: "All User Notifications fetched successfully"
      });
    }
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ error: error, message: "User Notification retrieval failed" });
  }
};

module.exports.getById = async function (req, res) {
  // #swagger.tags = ['User Notification']
  const { typeofnotify } = req.params;
  try {
    const response = await models.UserNotification.findOne({
      where: { typeofnotify }
    });
    res.status(200).send({
      data: response,
      message: "User Notification details fetched successfully"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({
      error: error,
      message: "User Notification details fetch failed"
    });
  }
};

module.exports.update = async function (req, res) {
  // #swagger.tags = ['User Notification']
  const { typeofnotify } = req.params;
  const { notifyinapp, fromDate, toDate, isinapp, isemail, issms } = req.body;

  let iserror = false;

  for (const item of defaultSettings) {
    if (notifyinapp !== undefined && typeofnotify === item.typeofnotify) {
      const isValid =
        Array.isArray(notifyinapp) &&
        (notifyinapp.length === 0 || validateArray(notifyinapp, item.notifyinapp));

      if (!isValid) {
        return res.status(400).send({
          message: `notifyinapp should contain only defined values for ${item.typeofnotify}`,
          error: { notifyinappAllowedValues: item.notifyinapp }
        });
      }
    }
  }

  const updateNotification = {};
  if (Array.isArray(notifyinapp)) updateNotification.notifyinapp = notifyinapp;
  if (fromDate) updateNotification.fromDate = fromDate;
  if (toDate) updateNotification.toDate = toDate;
  if (isinapp !== undefined) updateNotification.isinapp = isinapp;
  if (isemail !== undefined) updateNotification.isemail = isemail;
  if (issms !== undefined) updateNotification.issms = issms;

  try {
    if (!iserror) {
      await models.UserNotification.update(updateNotification, {
        where: { typeofnotify }
      });
      const result = await models.UserNotification.findOne({
        where: { typeofnotify }
      });
      return res.status(200).send({
        data: result,
        message: "User Notification details updated"
      });
    }
  } catch (error) {
    console.error({ error });
    return res.status(400).send({ error, message: "User Notification update failed" });
  }
};


module.exports.delete = async function (req, res) {
  // #swagger.tags = ['User Notification']
  const { notification_id } = req.params;
  try {
    await models.UserNotification.destroy({
      where: { id: notification_id }
    });
    res.status(200).json({
      data: [{ deleted_Notification: notification_id }],
      message: "User Notification deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ error: error, message: "User Notification deletion failed" });
  }
};
