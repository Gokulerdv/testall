const models = require("../../../db/model");

const defaultPatientNotification = [
  {
    typeofnotify: "opendental",
    notifyinapp: ["success", "demographic", "technical", "notlinked"],
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "csv",
    notifyinapp: ["success", "demographic", "technical", "notlinked"],
    isinapp: false,
    isemail: false,
    issms: false
  },
  {
    typeofnotify: "manual",
    notifyinapp: ["success", "demographic", "technical", "notlinked"],
    isinapp: false,
    isemail: false,
    issms: false
  }
];

const validateArray = (inputArray, validValues) => {
  return inputArray.every((value) => validValues.includes(value));
};

module.exports.getAll = async function (req, res) {
  // #swagger.tags = ['Patient Notification']
  try {
    const patientNotifications = await models.PatientNotification.findAll();

    if (patientNotifications.length === 0) {
      await models.PatientNotification.bulkCreate(defaultPatientNotification);

      const patientNotifications = await models.PatientNotification.findAll();
      res.status(200).json({
        data: patientNotifications,
        message: "All User Notifications fetched successfully"
      });
    } else {
      res.status(200).json({
        data: patientNotifications,
        message: "All User Notifications fetched successfully"
      });
    }
  } catch (error) {
    console.error(error);
    res
      .status(400)
      .json({ error: error, message: "Patient Notification retrieval failed" });
  }
};

module.exports.getById = async function (req, res) {
  // #swagger.tags = ['Patient Notification']
  const { typeofnotify } = req.params;
  try {
    const response = await models.PatientNotification.findOne({
      where: { typeofnotify }
    });
    res.status(200).json({
      data: response,
      message: "Patient Notification details fetched successfully"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).json({
      error: error,
      message: "Patient Notification details fetch failed"
    });
  }
};

module.exports.update = async function (req, res) {
  // #swagger.tags = ['Patient Notification']
  const { typeofnotify } = req.params;
  const { notifyinapp, isinapp, isemail, issms } = req.body;

  let iserror = false;
  defaultPatientNotification.forEach((item) => {
    if (notifyinapp && typeofnotify === item.typeofnotify) {
      const isValid =
        notifyinapp &&
        notifyinapp.length > 0 &&
        validateArray(notifyinapp, item.notifyinapp);

      if (!isValid) {
        iserror = true;
        res.status(400).send({
          message: `notifyinapp should contain only defined values for ${item.typeofnotify}`,
          error: { notifyinappAllowedValues: item.notifyinapp }
        });
      }
    }
  });

  const updateNotification = {};

  if (notifyinapp && notifyinapp.length > 0)
    updateNotification.notifyinapp = notifyinapp;
  updateNotification.isinapp = isinapp;
  updateNotification.isemail = isemail;
  updateNotification.issms = issms;

  try {
    if (!iserror) {
      await models.PatientNotification.update(updateNotification, {
        where: { typeofnotify: typeofnotify }
      });
      const result = await models.PatientNotification.findOne({
        where: {
          typeofnotify
        }
      });
      res.status(200).send({
        data: result,
        message: "Patient Notification details updated"
      });
    }
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .json({ error: error, message: "Patient Notification update failed" });
  }
};

// module.exports.delete = async function (req, res) {
//   // #swagger.tags = ['Patient Notification']
//   const { notification_id } = req.params;
//   try {
//     await models.PatientNotification.destroy({
//       where: { id: notification_id }
//     });
//     res.status(200).json({
//       data: [{ deleted_Notification: notification_id }],
//       message: "Patient Notification deleted successfully"
//     });
//   } catch (error) {
//     console.log(error);
//     res
//       .status(500)
//       .json({ error: error, message: "Patient Notification deletion failed" });
//   }
// };
