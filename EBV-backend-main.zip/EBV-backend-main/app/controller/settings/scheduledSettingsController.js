const models = require("../../../db/model");
const { isEmpty } = require("lodash");
const { Op } = require("sequelize");
const async = require("async");
const moment = require("moment");
const axios = require("axios");
const cron = require("node-cron");
const scheduledLogs = require("./scheduledLogsController");
const errorLogs = require("./errorlogscontroller");
const {
  verifyPatientNow,
  fetchOpendentalData,
} = require("../patients/patientsController");
const OpenDentalApiPath = process.env.OPEN_DENTAL_URL;
const OpenDentalAuthorization = process.env.OPEN_DENTAL_AUTHORIZATION;
const cronJobs = {};
let patids = [];

const {
  getODPatients,
  getODPatientAppoinments,
  getODProcedureLogs,
  getODInsplans,
  getODCarriers,
  getODProviders,
  getODFamilyModulesByPatientId,
  getODProcedureCodes,
  getODInsSubs,
  getODPatPlans,
  getODClinics,
  getODAppoinmentsType,
} = require("../opendental/opendentalController");
const { asyncDisposeSymbol } = require("puppeteer");
//create data
module.exports.create = async function (req, res) {
  // #swagger.tags = ['Scheduled Settings']
  try {
    let {
      scheduledaction,
      timetorun,
      numberofpatients,
      statusflag,
      adminId,
      weeklydays, // Mon-1, Tue-2, Wed-3, Thurs-4, Fri -5
      isweekly, // whether it is weekly
      isdaily, // whether it is daily
      ismonthly, // whether it is monthy
      everyweek, // Repeat for every week(twice the week)
      everymonth, // Repeat for Every Month (2 months once)
      oncountofdays, // On the day of 1st or 2nd
      oncountofweekdays, // On the Mon/Tue/Wed/Thurs/Fri
      oncountofweeks, // On the weeks - first/second/third/fourth
    } = req.body;

    models.ScheduleSettings.create({
      scheduledaction: scheduledaction,
      timetorun: timetorun,
      numberofpatients: numberofpatients,
      statusflag: statusflag,
      adminId: adminId,
      weeklydays: weeklydays, // Mon-1, Tue-2, Wed-3, Thurs-4, Fri -5
      isweekly: isweekly, // whether it is weekly
      isdaily: isdaily, // whether it is daily
      ismonthly: ismonthly, // whether it is monthy
      everyweek: everyweek, // Repeat for every week(twice the week)
      everymonth: everymonth, // Repeat for Every Month (2 months once)
      oncountofdays: oncountofdays, // On the day of 1st or 2nd
      oncountofweekday: oncountofweekdays, // On the Mon/Tue/Wed/Thurs/Fri
      oncountofweeks: oncountofweeks, // On the weeks - first/second/third/fourth
    })
      .then((newData) => {
        scheduleSettingsCron(newData?.dataValues, req, res);
        res.status(200).send({
          data: newData,
          message: "Data updated successfully",
        });
      })
      .catch((error) => console.error("Error:", error));
  } catch (e) {
    console.log(e);
    res.status(400).send({
      message: "Error occurred while saving data",
      error: e,
    });
  }
};

//get all details
module.exports.getAll = async (req, res) => {
  // #swagger.tags = ['Scheduled Settings']
  const { adminId } = req.params;
  try {
    const data = await models.ScheduleSettings.findAll({
      where: {
        adminId,
      },
    });
    res.status(200).json({
      data: data,
      message: "Data fetched successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Data fetch failed",
    });
  }
};

//get by id
module.exports.getbyId = async (req, res) => {
  // #swagger.tags = ['Scheduled Settings']
  const { id } = req.params;
  try {
    if (id === "null") {
      res.status(400).json({
        message: "Id should not be null",
      });
    } else {
      const data = await models.ScheduleSettings.findOne({
        where: { id },
      });
      res.status(200).send({
        deta: data,
        message: "Data fetched successfully",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "scheduled settings fetch failed",
    });
  }
};

//Update by id
module.exports.updatebyId = async (req, res) => {
  // #swagger.tags = ['Scheduled Settings']
  const { id } = req.params;
  const {
    scheduledaction,
    timetorun,
    numberofpatients,
    statusflag,
    weeklydays,
    isweekly,
    isdaily,
    ismonthly,
    everyweek,
    everymonth,
    oncountofdays,
    oncountofweekdays,
    oncountofweeks,
    adminId,
  } = req.body;
  if (cronJobs[id]) {
    // Stop the existing job
    cronJobs[id].stop();
  }
  const updatedata = {};
  if (!isEmpty(scheduledaction)) updatedata.scheduledaction = scheduledaction;
  if (!isEmpty(timetorun)) updatedata.timetorun = timetorun;
  if (!isEmpty(numberofpatients))
    updatedata.numberofpatients = numberofpatients;
  if (!isEmpty(statusflag)) updatedata.statusflag = statusflag;
  if (!isEmpty(weeklydays)) updatedata.weeklydays = weeklydays;
  updatedata.isdaily = isdaily;
  updatedata.isweekly = isweekly;
  updatedata.ismonthly = ismonthly;
  if (!isEmpty(everyweek)) updatedata.everyweek = everyweek;
  if (!isEmpty(everymonth)) updatedata.everymonth = everymonth;
  if (!isEmpty(oncountofweekdays))
    updatedata.oncountofweekdays = oncountofweekdays;
  if (!isEmpty(oncountofweeks)) updatedata.oncountofweeks = oncountofweeks;
  if (!isEmpty(oncountofdays)) updatedata.oncountofdays = oncountofdays;
  if (!isEmpty(adminId)) updatedata.adminId = adminId;

  try {
    const response = await models.ScheduleSettings.update(updatedata, {
      where: {
        id,
      },
    });
    if (response[0] === 1) {
      const data = await models.ScheduleSettings.findOne({
        where: {
          id,
        },
      });
      scheduleSettingsCron(data, req, res);
      res.status(200).send({
        data: data,
        message: "data updated successfully",
      });
    } else {
      res.status(400).send({ message: "data update failed" });
    }
  } catch (error) {
    console.log({ error });
    res.status(400).send({ error: error, message: "data  update failed" });
  }
};

//delete by id
module.exports.deletebyId = async (req, res) => {
  // #swagger.tags = ['Scheduled Settings']
  const { id } = req.params;
  if (cronJobs[id]) {
    // Stop the existing job
    cronJobs[id].stop();
  }
  try {
    const result = await models.ScheduleSettings.destroy({
      where: {
        id,
      },
    });
    if (result === 0) {
      return res.status(404).json({
        message: "data not found for deletion",
      });
    }
    res.status(200).json({
      data: [{ deleted_id: id }],
      message: "Scheduled Settings details deleted successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Scheduled Settings details deleted failed",
    });
  }
};

async function verifyAutomatically(req, res, schedule, generalsettings) {
  try {
    const uniqueIds = [];
    if (generalsettings?.isverifyautomatically) {
      let verifiedinpast = moment()
        .subtract(generalsettings?.verifiedinpast, "days")
        .toDate();

      async.parallel(
        {
          standard: function (callback) {
            let verifyschedulestandard = moment()
              .add(generalsettings?.verifyschedulestandard, "days")
              .toDate();
            let benefitsummaryStandard = moment()
              .subtract(generalsettings?.benefitsummarystandard, "days")
              .toDate();
            models.SchedulePatients.findAll({
              where: {
                medicaidId: null,
                scheduleAppointment: {
                  [Op.gt]: moment().startOf("day").toDate(),
                  [Op.lte]: verifyschedulestandard,
                },
                [Op.and]: [
                  {
                    scheduleAppointment: {
                      [Op.gt]: benefitsummaryStandard,
                    },
                  },
                  {
                    [Op.or]: [
                      {
                        lastVerified: {
                          [Op.lt]: verifiedinpast,
                        },
                      },
                      { lastVerified: null },
                    ]
                  },
                ],
                [Op.or]: [
                  {
                    lastVerified: {
                      [Op.lt]: verifiedinpast,
                    },
                  },
                  { lastVerified: null },
                ],
              },
              raw: true,
              order: [["createdAt", "DESC"]],
              limit: schedule?.numberofpatients,
            })
              .then((results) => callback(null, results))
              .catch((error) => callback(error));
          },
          medicaidId: function (callback) {
            let verifyschedulemedicaid = moment()
              .add(generalsettings?.verifyschedulemedicaid, "days")
              .toDate();
            let benefitsummarymedicaid = moment()
              .subtract(generalsettings?.benefitsummarymedicaid, "days")
              .toDate();
            models.SchedulePatients.findAll({
              where: {
                medicaidId: {
                  [Op.ne]: null,
                },
                scheduleAppointment: {
                  [Op.gt]: moment().startOf("day").toDate(),
                  [Op.lte]: verifyschedulemedicaid,
                },
                [Op.and]: [
                  {
                    scheduleAppointment: {
                      [Op.gt]: benefitsummarymedicaid,
                    },
                  },
                  {
                    [Op.or]: [
                      {
                        lastVerified: {
                          [Op.lt]: verifiedinpast,
                        },
                      },
                      { lastVerified: null },
                    ]
                  },
                ],
                [Op.or]: [
                  {
                    lastVerified: {
                      [Op.lt]: verifiedinpast,
                    },
                  },
                  { lastVerified: null },
                ],
              },
              raw: true,
              order: [["createdAt", "DESC"]],
              limit: schedule?.numberofpatients,
            })
              .then((results) => {
                callback(null, results)
              })
              .catch((error) => callback(error));
          },
          csvstandard: function (callback) {
            let verifyschedulestandard = moment()
              .add(generalsettings?.verifyschedulestandard, "days")
              .toDate();
            let benefitsummaryStandard = moment()
              .subtract(generalsettings?.benefitsummarystandard, "days")
              .toDate();
            models.ManualPatients.findAll({
              where: {
                addedFrom: "csv",
                medicaidId: null,
                scheduleAppointment: {
                  [Op.gt]: moment().startOf("day").toDate(),
                  [Op.lte]: verifyschedulestandard,
                },
                [Op.and]: [
                  {
                    scheduleAppointment: {
                      [Op.gt]: benefitsummaryStandard,
                    },
                  },
                  {
                    [Op.or]: [
                      {
                        lastVerified: {
                          [Op.lt]: verifiedinpast,
                        },
                      },
                      { lastVerified: null },
                    ]
                  }
                ],
                [Op.or]: [
                  {
                    lastVerified: {
                      [Op.lt]: verifiedinpast,
                    },
                  },
                  { lastVerified: null },
                ],
              },
              raw: true,
              order: [["createdAt", "DESC"]],
              limit: schedule?.numberofpatients,
            })
              .then((results) => callback(null, results))
              .catch((error) => callback(error));
          },
          csvmedicaidId: function (callback) {
            let verifyschedulemedicaid = moment()
              .add(generalsettings?.verifyschedulemedicaid, "days")
              .toDate();
            let benefitsummarymedicaid = moment()
              .subtract(generalsettings?.benefitsummarymedicaid, "days")
              .toDate();
            models.SchedulePatients.findAll({
              where: {
                addedFrom: "csv",
                medicaidId: {
                  [Op.ne]: null,
                },
                scheduleAppointment: {
                  [Op.gt]: moment().startOf("day").toDate(),
                  [Op.lte]: verifyschedulemedicaid,
                },
                [Op.and]: [
                  {
                    scheduleAppointment: {
                      [Op.gt]: benefitsummarymedicaid,
                    },
                  },
                  {
                    [Op.or]: [
                      {
                        lastVerified: {
                          [Op.lt]: verifiedinpast,
                        },
                      },
                      { lastVerified: null },
                    ]
                  },
                ],
                [Op.or]: [
                  {
                    lastVerified: {
                      [Op.lt]: verifiedinpast,
                    },
                  },
                  { lastVerified: null },
                ],
              },
              raw: true,
              order: [["createdAt", "DESC"]],
              limit: schedule?.numberofpatients,
            })
              .then((results) => callback(null, results))
              .catch((error) => callback(error));
          },
        },
        (err, results) => {
          const finalresults = [
            ...results.standard,
            ...results.medicaidId,
            ...results.csvstandard,
            ...results.csvmedicaidId,
          ];
          if (err) {
            res.status(400).send({
              err: err,
              message: "CRON failed to initiate",
            });
          }
          for (let i of finalresults) {
            if (uniqueIds.indexOf(i.uniqueId) === -1) {
              uniqueIds.push({
                uniqueId: i.uniqueId,
                isScheduled: i.isScheduled,
              });
            }
          }
          console.log(uniqueIds, "<---400");
          if (uniqueIds?.length > 0) {
            async.eachSeries(
              uniqueIds,
              (ids, callback) => {
                verifyPatientNow(ids, true, schedule?.adminId, callback);
              },
              (err, data) => {
                // logging to have success and failure
                if (err) {
                  errorLogs.create(schedule, err);
                }
                // notification trigger when verify automatically gets completed - (Scheduled Verification - PMS)
                // pull batch time and batch count (i.e) patient count
              }
            );
          }
        }
      );
    }
  } catch (e) {
    console.log(e);
    errorLogs.create(schedule, e);
  }
}

// module.exports.verifyAutomatically = async function (req, res) {
//   try {
//     // verifyAutomatically(req, res, schedule);
//     verifyAutomatically(req, res);
//   } catch (e) {
//     console.log(e);
//   }
// };

const scheduleSettingsCron = async (schedule, req, res) => {
  const generalsettings = await models.GeneralSettings.findOne({
    where: { adminId: schedule?.adminId },
    raw: true,
  });
  cronJobs[schedule.id] = cron.schedule(triggerCron(schedule), () => {
    updateappointments(req, res, generalsettings, patids).then(() => {
      getODData(req, res, schedule, patids);
    })
  }, {
    scheduled: true
  });
  cronJobs[schedule.id].start();
  scheduledLogs.create(schedule);
};

const triggerCron = (schedule) => {
  let cronTime = "";
  let scheduleData = schedule;

  let hours = moment(scheduleData?.timetorun, "h:mm A").hours() || 0;
  let minutes = moment(scheduleData?.timetorun, "h:mm A").minutes() || 0;

  /* reference for CRON*/
  // * * * * *
  // | | | | |
  // | | | | day of week
  // | | | month
  // | | day of month
  // | hour
  // minute

  if (scheduleData?.isweekly) {
    let value = null;
    if (scheduleData?.everyweek > 1 && scheduleData?.everyweek <= 4) {
      value = "*" + "/" + 7 * scheduleData?.everyweek;
      cronTime = `${minutes} ${hours} * * ${value}`;
    } else {
      if (!scheduleData?.everyweek) {
        cronTime = `${minutes} ${hours} * * ${scheduleData?.weeklydays}`;
      }
    }
  } else if (!scheduleData?.isweekly && scheduleData?.weeklydays?.length > 0) {
    cronTime = `${minutes} ${hours} * * ${scheduleData?.weeklydays}`;
  } else if (scheduleData?.isdaily) {
    cronTime = `${minutes} ${hours} * * *`;
  } else {
    if (scheduleData?.ismonthly) {
      cronTime = `${minutes} ${hours} ${scheduleData?.oncountofdays} * *`;
    }
  }
  console.log(
    `Cron Started on Hour: ${hours}, ${minutes} and freuquencyrun: ${cronTime}`
  );
  return cronTime;
};

const getODData = async (req, res, schedule, patids) => {
  try {
    const generalsettings = await models.GeneralSettings.findOne({
      where: { adminId: schedule?.adminId },
      raw: true,
    });
    Promise.all([
      await getODPatients(),
      await getODPatientAppoinments(),
      await getODProcedureLogs(),
      await getODInsplans(),
      await getODCarriers(),
      await getODProviders(),
      await getODFamilyModulesByPatientId(),
      await getODProcedureCodes(),
      await getODInsSubs(),
      await getODPatPlans(),
      await getODClinics(),
      await getODAppoinmentsType(),
    ]).then(() => {
      const days = generalsettings?.verifyschedulestandard > generalsettings?.verifyschedulemedicaid ? generalsettings?.verifyschedulestandard : generalsettings?.verifyschedulemedicaid;
      fetchOpendentalData(
        req,
        res,
        days,
        patids
      ).then(() => {
        verifyAutomatically(req, res, schedule, generalsettings);
      });
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      error: e,
      message: "Open Dental data fetch failed",
    });
  }
};

async function updateappointments(req, res, generalsettings, patids) {
  try {
    let daystoconsider = 0;
    if (generalsettings?.verifyschedulestandard > generalsettings?.verifyschedulemedicaid) daystoconsider = generalsettings?.verifyschedulestandard;
    else daystoconsider = generalsettings?.verifyschedulemedicaid
    const dateFormated = moment().add(daystoconsider, "d").format("YYYY-MM-DD");
    const response = await axios.get(
      `${OpenDentalApiPath}/appointments?dateStart=${moment().format("YYYY-MM-DD")}&dateEnd=${dateFormated}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );
    const addAppointments = async (data, callback) => {
      patids.push(data.PatNum)
      const appointmentData = {};
      appointmentData.addedFrom = "OpenDental";
      appointmentData.AptDateTime = `${data?.AptDateTime}`;
      appointmentData.AppointmentTypeNum = `${data?.AppointmentTypeNum}`;
      appointmentData.patientId = `${data?.PatNum}`;
      appointmentData.ProvNum = `${data?.ProvNum}`;

      try {
        const existingPatient = await models.ODAppointments.findByPk(
          `${data.AptNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(appointmentData);
          callback();
        } else {
          // Create new patient
          await models.ODAppointments.create({
            AptNum: `${data.AptNum}`,
            ...appointmentData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addAppointments(data, callback);
        updatePatients(data.PatNum)
      },
      async () => {
        console.log("Fetched Patient Appointments");
      }
    );
  } catch (e) {
    console.log(e);
  }
}

const updatePatients = async (patientNum) => {
  try {
    const response = await axios.get(`${OpenDentalApiPath}/patients/${patientNum}`, {
      headers: {
        Authorization: OpenDentalAuthorization,
      },
    });

    // function to get all patients
    const addPatient = async (newPatient) => {
      const newData = {};
      newData.lastName = `${newPatient?.LName}`;
      newData.firstName = `${newPatient?.FName}`;
      newData.Preferred = `${newPatient?.Preferred}`;
      newData.PatStatus = `${newPatient?.PatStatus}`;
      newData.Gender = `${newPatient?.Gender}`;
      newData.Position = `${newPatient?.Position}`;
      newData.dateOfBirth = `${newPatient?.Birthdate}`;
      newData.SSN = `${newPatient?.SSN}`;
      newData.Address = `${newPatient?.Address}`;
      newData.Address2 = `${newPatient?.Address2}`;
      newData.City = `${newPatient?.City}`;
      newData.State = `${newPatient?.State}`;
      newData.Zip = `${newPatient?.Zip}`;
      newData.HmPhone = `${newPatient?.HmPhone}`;
      newData.WkPhone = `${newPatient?.WkPhone}`;
      newData.WirelessPhone = `${newPatient?.WirelessPhone}`;
      newData.email = `${newPatient?.Email}`;
      newData.PriProv = `${newPatient?.PriProv}`;
      newData.priProvAbbr = `${newPatient?.priProvAbbr}`;
      newData.secProvAbbr = `${newPatient?.secProvAbbr}`;
      newData.BillingType = `${newPatient?.BillingType}`;
      newData.ChartNumber = `${newPatient?.ChartNumber}`;
      newData.ClinicNum = `${newPatient.ClinicNum}`;
      newData.statusflag = "A";
      newData.patientId = `${newPatient?.PatNum}`;
      newData.isScheduled = true;
      newData.PatCreatedAt = `${newPatient.DateTStamp}`;

      try {
        const existingPatient = await models.ODPatients.findByPk(
          `${newPatient.PatNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(newData);
        } else {
          // Create new patient
          await models.ODPatients.create({
            patientId: `${newPatient.PatNum}`,
            ...newData,
          });
        }
      } catch (error) {
        console.log(error);
      }
    };
    addPatient(response.data);
  } catch (e) {
    console.log("-------addpatient error", e);
  }
}
