const models = require("../../../db/model");
const CryptoJS = require("crypto-js");
const { isEmpty } = require("lodash");
const { Op } = require("sequelize");

//create credential
module.exports.createCredential = async (req, res) => {
  // #swagger.tags = ['Payer Credentials']
  try {
    let { payer, website, username, password, adminId, payerLogo } = req.body;

    // Make sure password is a string
    if (typeof password !== "string") {
      throw new Error("Password must be a string");
    }

    // Encrypt the password
    var encryptedPassword = CryptoJS.AES.encrypt(
      password,
      "secret-key"
    ).toString();

    const newPayer = await models.PayerCredential.create({
      payer: payer,
      website: website,
      username: username,
      password: encryptedPassword,
      adminId: adminId,
      payerLogo: payerLogo,
    });

    res.status(200).send({
      data: [newPayer],
      message: "Payer data saved successfully",
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      message: "Error occurred while saving Payer data",
    });
  }
};
//get all credential
module.exports.credentialGetall = async (req, res) => {
  // #swagger.tags = ['Payer Credentials']
  try {
    const payers = await models.PayerCredential.findAll();

    // Decrypt passwords for each record
    const decryptedPayers = payers.map((payer) => {
      const decryptedPassword = CryptoJS.AES.decrypt(
        payer.password,
        "secret-key"
      ).toString(CryptoJS.enc.Utf8);
      return {
        id: payer.id,
        payer: payer.payer,
        website: payer.website,
        username: payer.username,
        password: decryptedPassword,
        adminId: payer.adminId,
        payerLogo: payer.payerLogo,
      };
    });

    res.status(200).json({
      data: decryptedPayers,
      message: "Payer details fetched successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Payer fetch failed",
    });
  }
};

//get credential by id
module.exports.credentialGetbyId = async (req, res) => {
  // #swagger.tags = ['Payer Credentials']
  const { id } = req.params;
  try {
    const payer = await models.PayerCredential.findOne({
      where: { id },
    });

    const decryptedPassword = CryptoJS.AES.decrypt(
      payer.password,
      "secret-key"
    ).toString(CryptoJS.enc.Utf8);
    const decryptedPayer = {
      id: payer.id,
      payer: payer.payer,
      website: payer.website,
      username: payer.username,
      password: decryptedPassword,
      adminId: payer.adminId,
      payerLogo: payer.payerLogo,
    };

    res.status(200).send({
      deta: decryptedPayer,
      message: "Payer details fetched by id",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "payer fetch failed",
    });
  }
};

// credentail updation
module.exports.credentialUpdatebyId = async (req, res) => {
  // #swagger.tags = ['Payer Credentials']
  const id = req.params.id;
  const { payer, website, username, password, adminId, payerLogo } = req.body;

  try {
    // Encrypt the password if it's provided
    let encryptedPassword = null;
    if (!isEmpty(password)) {
      encryptedPassword = CryptoJS.AES.encrypt(
        password,
        "secret-key"
      ).toString();
    }

    // Find the existing record
    const existingPayer = await models.PayerCredential.findOne({
      where: { id },
    });

    // If no record found, return 404
    if (!existingPayer) {
      return res.status(404).json({
        message: "Payer not found",
      });
    }

    // Update the existing record with new data
    if (!isEmpty(payer)) existingPayer.payer = payer;
    if (!isEmpty(website)) existingPayer.website = website;
    if (!isEmpty(username)) existingPayer.username = username;
    if (!isEmpty(encryptedPassword)) existingPayer.password = encryptedPassword;
    if (!isEmpty(adminId)) existingPayer.adminId = adminId;

    if (payerLogo !== undefined) {
      existingPayer.payerLogo = payerLogo;
    }

    // Save the updated record
    await existingPayer.save();

    res.status(200).json({
      data: existingPayer,
      message: "Payer details updated successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error.message,
      message: "Payer update failed",
    });
  }
};

// credential deletion
module.exports.credentialDeletebyId = async (req, res) => {
  // #swagger.tags = ['Payer Credentials']
  const id = req.params.id;
  try {
    const result = await models.PayerCredential.destroy({
      where: {
        id: id,
      },
    });
    if (result === 0) {
      return res.status(404).json({
        message: "Payer not found for deletion",
      });
    }
    res.status(200).json({
      data: [{ deleted_id: req.params.id }],
      message: "Payer details deleted successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Payer details deleted failed",
    });
  }
};

module.exports.searchMyIns = async (req, res) => {
  // #swagger.tags = ['Payer Credentials']

  const { searchString } = req.body;
  const { username } = req.body;

  const searchCriteria = { payer: { [Op.like]: "%" + searchString + "%" } };

  if (!searchString) {
    return res.status(400).json({ message: "Search string is required" });
  }
  if (req.body.username) {
    searchCriteria["username"] = { [Op.like]: "%" + username + "%" };
  }

  try {
    const result = await models.PayerCredential.findAll({
      where: searchCriteria,
    });
    res.status(200).json({
      data: result,
      message: "Search results retrieved successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Error occurred while searching",
    });
  }
};
