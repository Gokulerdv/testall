const models = require("../../../db/model");

//create data
module.exports.createNotification = async function (body) {
  try {
    let {
      ismanual,
      iscsv,
      isScheduled,
      isSuccess,
      istechnical,
      notlinked,
      demographic,
      message,
      adminId,
      patientId,
      patientName,
      isPatientUpdate,
      isPatientDelete
    } = body;

    const newData = await models.Notification.create({
      ismanual: ismanual,
      iscsv: iscsv,
      isScheduled: isScheduled,
      isSuccess: isSuccess,
      istechnical: istechnical,
      notlinked: notlinked,
      demographic: demographic,
      message: message,
      adminId: adminId,
      patientId: patientId,
      patientName: patientName,
      isPatientUpdate: isPatientUpdate,
      isPatientDelete: isPatientDelete,
      isRead: false
    });
    // res.status(200).send({
    //     data: newData,
    //     message: "Data created successfully"
    // });
  } catch (e) {
    console.log(e);
    // res.status(400).send({
    //     message: "Error occured while saving data",
    //     error: e
    // });
  }
};

//get all details

module.exports.getall = async (req, res) => {
  // #swagger.tags = ['Notification Schema']
  try {
    const data = await models.Notification.findAll();
    res.status(200).json({
      data: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Data fetch failed"
    });
  }
};

//get by id
module.exports.getbyid = async function (req, res) {
  // #swagger.tags = ['Notification Schema']
  const { id } = req.params;
  try {
    const data = await models.Notification.findOne({
      where: { id }
    });

    res.status(200).send({
      data: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Data fetch failed"
    });
  }
};

//updated by id

module.exports.updatebyid = async function (req, res) {
  // #swagger.tags = ['Notification Schema']

  const { id } = req.params;
  const { isRead } = req.body;
  const updateData = {};
  updateData.isRead = isRead;
  try {
    await models.Notification.update(updateData, {
      where: {
        id
      }
    });

    const data = await models.Notification.findOne({
      where: {
        id
      }
    });
    res.status(200).send({
      data: data,
      message: "data updated successfully"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({ error: error, message: "data  update failed" });
  }
};

//delete by id

module.exports.deletebyid = async function (req, res) {
  const { id } = req.params;
  try {
    const result = await models.Notification.destroy({
      where: { id }
    });
    if (result == 0) {
      return res.status(404).json({
        message: "Data not found for deletion"
      });
    }
    res.status(200).json({
      data: [{ deleted_id: id }],
      message: "data deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "data deleted failed"
    });
  }
};
