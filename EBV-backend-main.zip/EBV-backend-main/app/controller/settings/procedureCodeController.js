const models = require("../../../db/model");
const procedureCodeList = require("../../utils/procedureCodeMaster");
// const { Op } = require("sequelize");
// const { isEmpty } = require("lodash");

module.exports.manualCreateProcedureCodes = async (req, res) => {
  // #swagger.tags = ['Procedure Codes']
  try {
    procedureCodeList.forEach(async (data) => {
      if (data) {
        await models.ProcedureCode.create({
          procedureCode: data.code,
          description: data.description,
          procedureType: data.procedureType
        });
      }
    });
    res.status(200).send({
      message: "Procedure Code Data Saved Successfully"
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      error: e,
      message: "Procedure Code Data Not Saved"
    });
  }
};

//get all details
module.exports.getAllProcedureCodes = async (req, res) => {
  // #swagger.tags = ['Procedure Codes']
  const { procedureType } = req.query;

  const params = {};

  if (procedureType) {
    params["procedureType"] = procedureType;
  }

  try {
    const procedureCodes = await models.ProcedureCode.findAll({
      where: params,
      raw: true
    });

    res.status(200).json({
      data: procedureCodes,
      message: "Procedure Code details fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Procedure Code fetch failed"
    });
  }
};

module.exports.getAllProcedureTypes = async (req, res) => {
  // #swagger.tags = ['Procedure Codes']
  try {
    const procedureCodes = await models.ProcedureCode.findAll({
      attributes: [
        [
          models.Sequelize.fn("DISTINCT", models.Sequelize.col("procedureType")),
          "procedureType"
        ]
      ],
      raw: true
    });

    const procedureTypes = procedureCodes.map((code) => code.procedureType);

    res.status(200).json({
      data: procedureTypes,
      message: "Procedure Types details fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Procedure Types fetch failed"
    });
  }
};
