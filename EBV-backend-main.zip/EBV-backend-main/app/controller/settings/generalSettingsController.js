const { isEmpty } = require("lodash");
const models = require("../../../db/model");
const db = require("../../../db/model");

const defaultSettings = {
  isverifyautomatically: "false",
  verifyschedulestandard: "03",
  verifyschedulemedicaid: "03",
  benefitsummarystandard: "03",
  benefitsummarymedicaid: "03",
  excludeclone: "false",
  verifiedinpast: "03",
  warningdays: "03",
  userhistoryname: "Admin",
  ishistory: "false",
  verificationcodes: [],
};

//create data
module.exports.create = async function (req, res) {
  // #swagger.tags = ['General Settings']
  try {
    let {
      isverifyautomatically,
      verifyschedulestandard,
      verifyschedulemedicaid,
      benefitsummarystandard,
      benefitsummarymedicaid,
      excludeclone,
      verifiedinpast,
      warningdays,
      userhistoryname,
      ishistory,
      activedays,
      verificationcodes,
      adminId,
    } = req.body;

    const newData = await models.GeneralSettings.create({
      isverifyautomatically: isverifyautomatically,
      verifyschedulestandard: verifyschedulestandard,
      verifyschedulemedicaid: verifyschedulemedicaid,
      benefitsummarystandard: benefitsummarystandard,
      benefitsummarymedicaid: benefitsummarymedicaid,
      excludeclone: excludeclone,
      verifiedinpast: verifiedinpast,
      warningdays: warningdays,
      userhistoryname: userhistoryname,
      ishistory: ishistory,
      activedays: activedays,
      adminId: adminId,
      verificationcodes: verificationcodes,
    });

    res.status(200).send({
      data: newData,
      message: "Data created successfully",
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      message: "Error occurred while saving data",
      error: e.message, // Send error message instead of the entire error object
    });
  }
};

//get all details
module.exports.getAll = async (req, res) => {
  // #swagger.tags = ['General Settings']
  try {
    const data = await models.GeneralSettings.findAll();
    res.status(200).json({
      data: data,
      message: "Data fetched successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Data fetch failed",
    });
  }
};

//get by id
module.exports.getbyId = async (req, res) => {
  // #swagger.tags = ['General Settings']
  const { adminId } = req.params;
  try {
    const data = await models.GeneralSettings.findOne({
      where: { adminId },
    });
    if (data === null) {
      const response = await models.GeneralSettings.create({
        ...defaultSettings,
        adminId,
      });
      res.status(200).send({
        data: response,
        message: "Data fetched successfully",
      });
    } else {
      res.status(200).send({
        data: data,
        message: "Data fetched successfully",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "payer fetch failed",
    });
  }
};

// /Update by id
module.exports.updatebyId = async (req, res) => {
  // #swagger.tags = ['General Settings']
  const { adminId } = req.params;
  const {
    isverifyautomatically,
    verifyschedulestandard,
    verifyschedulemedicaid,
    benefitsummarystandard,
    benefitsummarymedicaid,
    excludeclone,
    verifiedinpast,
    warningdays,
    userhistoryname,
    ishistory,
    activedays,
    verificationcodes,
  } = req.body;

  const updatedata = {};

  updatedata.isverifyautomatically = isverifyautomatically;
  updatedata.excludeclone = excludeclone;

  if (!isEmpty(verifyschedulestandard))
    updatedata.verifyschedulestandard = verifyschedulestandard;
  if (!isEmpty(verifyschedulemedicaid))
    updatedata.verifyschedulemedicaid = verifyschedulemedicaid;
  if (!isEmpty(benefitsummarystandard))
    updatedata.benefitsummarystandard = benefitsummarystandard;
  if (!isEmpty(benefitsummarymedicaid))
    updatedata.benefitsummarymedicaid = benefitsummarymedicaid;
  if (!isEmpty(verifiedinpast)) updatedata.verifiedinpast = verifiedinpast;
  if (!isEmpty(warningdays)) updatedata.warningdays = warningdays;
  if (!isEmpty(userhistoryname)) updatedata.userhistoryname = userhistoryname;
  updatedata.ishistory = ishistory;
  if (!isEmpty(verificationcodes))
    updatedata.verificationcodes = verificationcodes;
  if (!isEmpty(activedays)) updatedata.activedays = activedays;

  let response;
  try {
    // check whether admin has settings
    await db.sequelize.transaction(async (t) => {
      const adminDetails = await models.GeneralSettings.findOne({
        where: {
          adminId,
        },
        transaction: t,
      });
      if (adminDetails) {
        //update exsiting details
        response = await models.GeneralSettings.update(updatedata, {
          where: {
            adminId,
          },
          transaction: t,
        });
      } else {
        //create
        response = await models.GeneralSettings.create(
          {
            ...updatedata,
            adminId,
          },
          {
            transaction: t,
          }
        );
      }
      if (response[0] === 1) {
        const updatedData = await models.GeneralSettings.findOne({
          where: {
            adminId,
          },
          transaction: t,
        });
        res.status(200).send({
          data: updatedData,
          message: "data updated successfully",
        });
      } else {
        res
          .status(200)
          .send({ data: response, message: "Data cretaed successfully" });
      }
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({ error: error, message: "data update failed" });
  }
};

//delete by id
module.exports.deletebyId = async (req, res) => {
  // #swagger.tags = ['General Settings']
  const { adminId } = req.params;
  try {
    const result = await models.GeneralSettings.destroy({
      where: {
        adminId,
      },
    });
    if (result === 0) {
      return res.status(404).json({
        message: "data not found for deletion",
      });
    }
    res.status(200).json({
      data: [{ deleted_id: adminId }],
      message: "Payer details deleted successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Payer details deleted failed",
    });
  }
};
