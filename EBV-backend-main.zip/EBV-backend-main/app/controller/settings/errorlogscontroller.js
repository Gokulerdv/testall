const models = require("../../../db/model");
const fs = require('fs')
//Create data
module.exports.create = async function (schedule, err) {
  // #swagger.tags = ['Error logs']
  try {
    fs.writeFileSync('./errorLogs.txt', err)
    const logFileContent = fs.readFileSync('./errorLogs.txt', 'base64')
    const stats = fs.statSync('./errorLogs.txt');
    const sizeInBytes = stats.size;

    const newData = await models.Errorlogs.create({
      adminId: schedule.adminId,
      date: schedule.createdAt,
      logfile: logFileContent,
      size: sizeInBytes,
      scheduleId:schedule.id
    });
    fs.unlinkSync('./errorLogs.txt');
  } catch (e) {
    console.log(e);
  }
};

//get all details 

module.exports.getAll = async (req, res) => {
  // #swagger.tags = ['Error logs']
  try {
    const data = await models.Errorlogs.findAll();
    res.status(200).json({
      data: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      mesage: "Data fetched failed"
    });
  }
};

//get by adminid

module.exports.getbyId = async (req, res) => {
  // #swagger.tags = ['Error logs']Errorlogs
  const { adminId } = req.params;
  try {
    const data = await models.Errorlogs.findOne({
      where: { adminId }
    });

    res.status(200).send({
      deta: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "payer fetch failed"
    });
  }
};

//update by adminid

module.exports.updatebyId = async (req, res) => {
  // #swagger.tags = ['Error logs']

  const { adminId } = req.params
  const { date, logfile, size } = req.body;

  const data = {
    date,
    logfile,
    size
  };
  try {
    const resp = await models.Errorlogs.update(data, {
      where: {
        adminId
      }
    });
    if (resp[0] === 1) {
      res.status(200).send({
        data: resp,
        message: "data updated successfully"
      });
    } else {
      res.status(404).send({ message: "data update failed" });
    }
  }
  catch (error) {
    console.log({ error });
    res.status(400).send({ error: error, message: "data  update failed" });
  }
};

//Delete by adminId
module.exports.deletebyId = async (req, res) => {
  // #swagger.tags = ['Error logs']
  const { adminId } = req.params
  try {
    const result = await models.Errorlogs.destroy({
      where: {
        adminId
      }
    });
    if (result === 0) {
      return res.status(404).json({
        message: "Data not found for deletion"
      });
    }
    res.status(200).json({
      data: [{ deleted_id: adminId }],
      message: "Data details deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Data details deleted failed"
    })
  }
};
