const models = require("../../../db/model")

//create data 
module.exports.create = async function (req, res) {
    // #swagger.tags = ['Clearing House']
    try {
        let {
            id,
            name
        } = req.body;
        const newData = await models.ClearingHouse.create({
            id: id,
            name: name
        });
        res.status(200).send({
            data: newData,
            message: "Data created successfully"
        });
    } catch (e) {
        console.log(e)
        res.status(400).send({
            message: "Error occured while saving data",
            error: e
        });
    }
};

//getall details 
module.exports.getall = async (req, res) => {
    // #swagger.tags = ['Clearing House']
    try {
        const data = await models.ClearingHouse.findAll();
        res.status(200).json({
            data: data,
            message: "Data fetched successfully"
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({
            error: error,
            message: "Data fetch failed"
        });
    }
};


//get by id
module.exports.getbyid = async function (req, res) {
    // #swagger.tags = ['Clearing House']
    const { id } = req.params;
    try {
        const data = await models.ClearingHouse.findOne({
            where: { id }
        });

        res.status(200).send({
            data: data,
            message: "Data fetched successfully"
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({
            error: error,
            message: "Data fetch failed"
        })
    }
};

//update by id
module.exports.updatebyid = async function (req, res) {
    // #swagger.tags = ['Clearing House']
    const { id } = req.params;
    const {
        name
    } = req.body;

    const updateData = {
        name
    }
    try {
        const response = await models.ClearingHouse.update(updateData, {
            where: {
                id
            }
        });
        res.status(200).send({
            data: response,
            message: "data updated successfully"
        });
    } catch (error) {
        console.log({ error });
        res.status(400).send({ error: error, message: "data  update failed" });
    }
};

//deleted by id

module.exports.deletebyid = async function (req, res) {
    const { id } = req.params;
    try {
        const result = await models.ClearingHouse.destroy({
            where: { id }
        });
        if (result == 0) {
            return res.status(404).json({
                message: "Data not found for deletion"
            });
        } res.status(200).json({
            data: [{ deleted_id: id }],
            message: "data deleted successfully"
        });
    } catch (error) {
        console.log(error);
        res.status(400).send({
            error: error,
            message: "data deleted failed"
        });
    }
};
