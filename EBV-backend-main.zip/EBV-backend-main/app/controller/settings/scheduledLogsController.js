const models = require("../../../db/model");

module.exports.create = async function (schedule) {
  try {
    const resp = await models.ScheduledLog.create({
      scheduledaction: schedule.scheduledaction,
      adminId: schedule.adminId,
      timeToRun: schedule.timetorun,
      noOfPatients: schedule.numberofpatients,
      isWeekly: schedule.isweekly,
      isMonthly: schedule.ismonthly,
      isDaily: schedule.isdaily,
      timeOfLastRun: Date.now()
    })
  } catch (e) {
    console.log(e);
  }
};
// No Needed - will be removed later
module.exports.createlogs = async function (req, res) {
  // #swagger.tags = ['Scheduled Logs']
  const {
    scheduledaction,
    adminId,
    timetorun,
    numberofpatients,
    isweekly,
    ismonthly,
    isdaily
  } = req.body;
  try {
    const resp = await models.ScheduledLog.create({
      scheduledaction: scheduledaction,
      adminId: adminId,
      timeToRun: timetorun,
      noOfPatients: numberofpatients,
      isWeekly: isweekly,
      isMonthly: ismonthly,
      isDaily: isdaily,
      timeOfLastRun: Date.now()
    });
    res.status(200).send({
      data: resp,
      message: "Scheduled Logs created successfully"
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      message: "Error occurred while saving data",
      error: e
    });
  }
};

module.exports.getScheduleByadminID = async function (req, res) {
  // #swagger.tags = ['Scheduled Logs']
  try {
    const { adminId } = req.params;
    const data = await models.ScheduledLog.findAll({
      where: { adminId: adminId }
    });
    res.status(200).json({
      data: data,
      message: "Data fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      mesage: "Data fetched failed"
    });
  }
};
