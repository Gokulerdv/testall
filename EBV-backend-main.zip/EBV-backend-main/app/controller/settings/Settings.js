const models = require("../../../db/model");
const payerList = require("../../utils/payerList");
const { Op } = require("sequelize");
const { isEmpty } = require("lodash");

module.exports.createPayers = async (req, res) => {
  // #swagger.tags = ['Payers']
  try {
    let { payerId, payerName, clearingHouse, payerLogo, adminId } = req.body;
    const newPayer = await models.InsurancePayer.create({
      payerId: payerId,
      payerName: payerName,
      clearingHouse: clearingHouse,
      payerLogo: payerLogo,
      adminId: adminId
    });
    const newPayerData = newPayer?.dataValues;
    res.status(200).send({
      data: [newPayerData],
      message: "Payer Data Saved Successfully"
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      error: e,
      message: "Payer Data Not Saved"
    });
  }
};

module.exports.manualCreatePayers = async (req, res) => {
  // #swagger.tags = ['Payers']
  try {
    payerList.forEach(async (data) => {
      if (data) {
        await models.InsurancePayer.create({
          payerName: data.payerName,
          payerId: data.payerId,
          clearingHouse: "dentalxchange",
          payerLogo: data.payerLogo
        });
      }
    });
    res.status(200).send({
      message: "Payer Data Saved Successfully"
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({
      error: e,
      message: "Payer Data Not Saved"
    });
  }
};

//get all details
module.exports.getAllPayers = async (req, res) => {
  // #swagger.tags = ['Payers']
  try {
    const payers = await models.InsurancePayer.findAll();

    res.status(200).json({
      data: payers,
      message: "Payer details fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Payer fetch failed"
    });
  }
};

//get details by id
module.exports.getPayerbyId = async (req, res) => {
  // #swagger.tags = ['Payers']
  const { id } = req.params;
  try {
    const resp = await models.InsurancePayer.findOne({
      where: { id }
    });
    res.status(200).send({
      data: resp,
      message: "Payer details fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      error: error,
      message: "Payer fetch failed"
    });
  }
};

//update payers details

module.exports.updatePayerbyId = async (req, res) => {
  // #swagger.tags = ['Payers']
  const { id } = req.params;
  const { payerId, payerName, clearingHouse, payerLogo, adminId } = req.body;
  const updatePayer = {};

  if (!isEmpty(payerId)) updatePayer.payerId = payerId;
  if (!isEmpty(payerName)) updatePayer.payerName = payerName;
  if (!isEmpty(clearingHouse)) updatePayer.clearingHouse = clearingHouse;
  if (!isEmpty(payerLogo)) updatePayer.payerLogo = payerLogo;
  if (!isEmpty(adminId)) updatePayer.adminId = adminId;

  try {
    const resp = await models.InsurancePayer.update(updatePayer, {
      where: {
        id: id
      }
    });

    res.status(200).json({
      data: resp,
      message: "Payer details updated successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Payer updation failed"
    });
  }
};

//delete payer by id

module.exports.deletePayerbyId = async (req, res) => {
  // #swagger.tags = ['Payers']
  const id = req.params.id;
  try {
    const result = await models.InsurancePayer.destroy({
      where: {
        id: id
      }
    });
    if (result === 0) {
      return res.status(404).json({
        message: "Payer not found for deletion "
      });
    }
    res.status(200).json({
      data: [{ deleted_id: req.params.id }],
      message: "Payer details deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Payer details deleted failed"
    });
  }
};

//search filter

module.exports.searchPayerId = async (req, res) => {
  // #swagger.tags = ['Payers']

  const { searchString } = req.body;
  const { clearingHouse } = req.body;

  const searchCriteria = {
    [Op.or]: [
      { payerId: { [Op.like]: "%" + searchString + "%" } },
      { payerName: { [Op.like]: "%" + searchString + "%" } }
    ]
  };

  if (!searchString) {
    return res.status(400).json({ message: "Search string is required" });
  }
  if (req.body.clearingHouse) searchCriteria["clearingHouse"] = clearingHouse;

  try {
    const result = await models.InsurancePayer.findAll({
      where: searchCriteria
    });
    res.status(200).json({
      data: result,
      message: "Search results retrieved successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Error occurred while searching"
    });
  }
};
