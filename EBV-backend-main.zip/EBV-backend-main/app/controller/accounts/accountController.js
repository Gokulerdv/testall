// const userPool = require("../../congnito");
// const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const AWS = require("aws-sdk");
const axios = require("axios");
// const qs = require("qs");
const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");

const cognito = new AWS.CognitoIdentityServiceProvider();

const GENYUS_IAM = process.env.GENYUS_IAM;

const client = jwksClient({
  jwksUri: process.env.COGNITO_TOKEN_SIGNING_KEY,
});

function getKey(header, callback) {
  client.getSigningKey(header.kid, function (err, key) {
    var signingKey = key?.rsaPublicKey;
    callback(null, signingKey);
  });
}

module.exports.createCongnitoUser = function (office_mail, isPracticeAdmin) {
  return new Promise((resolve, reject) => {
    const params = {
      UserPoolId: process.env.GENYUS_AWS_USER_POOL_ID,
      Username: office_mail,
      UserAttributes: [
        {
          Name: "email",
          Value: office_mail,
        },
        {
          Name: "email_verified",
          Value: "true",
        },
      ],
      //todo discuss with product team
      TemporaryPassword: "Admin@123",
      MessageAction: "SUPPRESS",
    };

    cognito.adminCreateUser(params, (err, data) => {
      if (err) {
        console.error(err);
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};


async function refreshAccessToken1(refreshToken) {
  try {
    const response = await axios.post(
      `${process.env.COGNITO_DOMAIN}/oauth2/token`,
      new URLSearchParams({
        grant_type: "refresh_token",
        client_id: process.env.GENYUS_AWS_CLIENT_ID,
        refresh_token: refreshToken,
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error refreshing access token:", error);
    throw error;
  }
}

module.exports.refreshAccessToken = async function (req, res) {
  // #swagger.tags = ['Users']
  const { refreshToken } = req.body;
  try {
    const tokens = await refreshAccessToken1(refreshToken);
    res.json(tokens);
  } catch (error) {
    console.error("Error ---->", error);
    res.status(500).send({
      msg: "Internal Server Error",
      error: error?.response?.data || error,
    });
  }
};


module.exports.loginUser = async function (req, res) {
  // #swagger.tags = ['Users']
  const { email, password } = req.body;
  try {
    const loginUrl = `${GENYUS_IAM}/api/auth/login`;

    const response = await axios.post(loginUrl, {
      email,
      password,
    });

    if (response.headers["content-type"].includes("application/json")) {
      res.status(200).send({
        data: response.data,
      });
    } else {
      console.error("Expected JSON response but received HTML", response.data);
      res.status(500).send({
        error: "Unexpected response format",
        message: "Login failed",
      });
    }
  } catch (error) {
    console.error({ error });

    if (error.response) {
      res.status(error.response.status).send({
        error: error.response.data,
        message: error.response.data.message || "Login failed",
      });
    } else if (error.request) {
      res.status(500).send({
        error: "No response received from authentication server",
        message: "Login failed",
      });
    } else {
      res.status(500).send({
        error: error.message,
        message: "Login failed",
      });
    }
  }
};

module.exports.verifyAccessToken = async function (req, res) {
  // #swagger.tags = ['Users']
  const { accessToken } = req.body;
  if (!accessToken) {
    return res
      .status(401)
      .send({ error: "No token provided or invalid token format." });
  }
  try {
    jwt.verify(
      accessToken,
      getKey,
      {
        algorithms: ["RS256"],
      },
      (err, decoded) => {
        if (err) {
          console.log("JWT error:", err);
          return res
            .status(401)
            .send({ error: "Unauthorized: Invalid token." });
        } else {
          req.user = decoded;
          return res
        .status(200)
        .send({ message:"Valid token" });
        }
      }
    );
  } catch (error) {
    console.error({ error });
    res.status(500).send({
      error: error.message,
      message: "Verification failed",
    });
  }
};
