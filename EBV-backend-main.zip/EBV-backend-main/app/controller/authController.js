const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");

const client = jwksClient({
  jwksUri: process.env.COGNITO_TOKEN_SIGNING_KEY,
});

function getKey(header, callback) {
  client.getSigningKey(header.kid, function (err, key) {
    var signingKey = key?.rsaPublicKey;
    callback(null, signingKey);
  });
}

const auth = (req, res, next) => {
  const { authorization } = req.headers;
  const dev = process.env.NODE_ENV;
  if (dev !== "development") {
    if (!authorization || !authorization.startsWith("Bearer ")) {
      return res
        .status(401)
        .send({ error: "No token provided or invalid token format." });
    }

    const token = authorization.split(" ")[1];

    jwt.verify(
      token,
      getKey,
      {
        algorithms: ["RS256"],
      },
      (err, decoded) => {
        if (err) {
          console.log("JWT error:", err);
          return res
            .status(401)
            .send({ error: "Unauthorized: Invalid token." });
        } else {
          req.user = decoded;
          next();
        }
      }
    );
  } else {
    next();
  }
};

module.exports = auth;
