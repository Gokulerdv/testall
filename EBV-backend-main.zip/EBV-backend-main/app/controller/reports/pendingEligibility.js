const models = require("../../../db/model");
const puppeteer = require("puppeteer");
const moment = require("moment");
const { Op } = require("sequelize");

// Create a new PendingEligibility entry
module.exports.create = async function (req, res) {
  // #swagger.tags = ['Pending Eligibility Report']
  try {
    const {
      filterName,
      fromDate,
      toDate,
      insuranceHierarchy,
      location,
      patients,
      provider,
      lastEligibility,
      insuranceStatus,
      daysGreaterThan,
      insuranceType,
      columns,
      payer,
      isFavorite,
      isSave
    } = req.body;
    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    //uncomment on commit/ deployment
    const browser = await puppeteer.launch({
      executablePath: "/usr/bin/google-chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox"]
    });
    const page = await browser.newPage();
    const tableHeaders =
      columns?.length > 0 &&
      columns
        .map(
          (item) =>
            item &&
            `
      <th>${item
        .replace(/([A-Z])/g, " $1")
        .trim()
        .replace(/^\w/, (c) => c.toUpperCase())}</th>
      `
        )
        .join("");
    const tableData =
      patientDetails?.length > 0 &&
      patientDetails
        .map((item, i) => {
          let str = "";
          const className = i % 2 === 0 ? "even-row" : "odd-row";
          for (const column of columns) {
            let columnValue = item[column];
            if (column === "patientName") {
              columnValue = `${item.firstName} ${item.lastName}`.trim();
            } else if (column === "subscriberName") {
              columnValue =
                `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
            } else if (column === "dependentName") {
              columnValue =
                `${item.dependentFirstName} ${item.dependentLastName}`.trim();
            } else if (column === "insuranceName") {
              columnValue = `<img src="${item.payerLogo}" />`;
            }
            if (column.includes("OfBirth")) {
              columnValue = new Date(columnValue)
                .toLocaleDateString("en-GB")
                .replace(/\//g, "/");
            }
            str += `<td><span class=${
              column === "patientName" || column === "patientId"
                ? "underlined"
                : ""
            }>${columnValue}</span></td>`;
          }
          return `<tr class="${className}">${str}</tr>`;
        })
        .join("");

    const content = `
<html>
<head>
</head>
<style>
h1,h2,h3,h4,h5,h6,p,li,ul{
  margin:0;
  padding:0;
}
body {
  font-family: 'Roboto', sans-serif;
  font-style: normal !important;
  margin: 0;
  padding:20px;
  box-sizing:border-box;
}
table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #dee2e6;
}
thead {
  display: table-header-group;
}
tr{
border-top: 1px solid #dee2e6;
}
td{
font-size:8px !important;
}
th, td {
  padding: 5px 5px;
  text-align: left;
}
img{
  width:50px;
}
th{
font-size:8px;
}
.d-flex{
  display: -webkit-flex;
  display: flex;
}
.jbw{
  -webkit-justify-content: space-between;
  justify-content: space-between;
}
.alc{
  -webkit-align-items: center;
  align-items: center;
}
.fw{
  flex-wrap:wrap;
  -webkit-flex-wrap: wrap;
}
.w-50{
  width: 50%;
}
.fs-12{
  font-size: 12px;
}
.fw-500{
  font-weight: 500;
}
.w-100{
  width: 100%;
}
li{
  list-style-type:none;
}
.labelColor{
  color:#9F9F9F;
}
.pendingList{
  width:75%;
}
.tal{
  text-align: left;
}
.mb-10{
  margin-bottom:10px;
}
.mb-30{
  margin-bottom:30px;
}
.flex-grow {
  flex-grow: 1; 
  flex-basis: 0;
}
.fs-14{
  font-size:14px;
}
.even-row {
  background: #fafafa;
}
.odd-row {
  background: #f5f5f5;
}
.underlined {
  text-decoration: underline;
  color: #8dbdca;
}

</style>
<body>
<div>
<div class="pendingList">
<div class="mb-30">
<ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
<li class="flex-grow ">Location</li>
<li class="flex-grow ">Provider</li>
<li class="flex-grow ">Payer</li>
<li class="flex-grow ">Insurance Status</li>
</ul>
<ul class="d-flex jbw fs-14 fw-500 w-100 tal ">
<li class="flex-grow ">${
      location?.length > 0 && location.map((item) => `<p>${item}</p>`).join("")
    }</li>
<li class="flex-grow ">${
      provider?.length > 0 && provider.map((item) => `<p>${item}</p>`).join("")
    }</li>
<li class="flex-grow ">${
      payer?.length > 0 && payer.map((item) => `<p>${item}</p>`).join("")
    }</li>
<li class="flex-grow ">${insuranceStatus}</li>
</ul>
</div>
<div class="mb-30">
<ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
<li class="flex-grow ">Insurance Type</li>
<li class="flex-grow ">Insurance Hiearchy</li>
<li class="flex-grow ">Patient</li>
<li class="flex-grow ">Days Since Last Eligibility</li>
</ul>
<ul class="d-flex jbw fs-14 fw-500 w-100">
<li class="flex-grow ">${insuranceType}</li>
<li class="flex-grow ">${
      insuranceHierarchy?.length > 0 &&
      insuranceHierarchy.map((item) => `<p>${item}</p>`).join("")
    }</li>
<li class="flex-grow ">01</li>
<li class="flex-grow ">Greater Than ${daysGreaterThan}Days</li>
</ul>
</div>
</div>
<table>
      <thead>
            <tr>
               ${tableHeaders} 

            </tr>
      </thead>
      <tbody>
      ${tableData}
      </tbody>
      </table>
</div>
</body>
</html>`;
    await page.setViewport({ width: 1920, height: 1080 });
    await page.setContent(content);

    const pdfBuffer = await page.pdf({
      format: "A4",
      margin: {
        top: "10px",
        right: "0px",
        bottom: "10px",
        left: "0px"
      },
      path: "output.pdf",
      printBackground: true
    });
    await browser.close();
    if (isSave) {
      const newPendingEligibility =
        await models.PendingEligibilityReports.create({
          filterName,
          fromDate,
          toDate,
          insuranceHierarchy,
          location,
          patients,
          provider,
          lastEligibility,
          insuranceStatus,
          daysGreaterThan,
          insuranceType,
          columns,
          payer,
          isFavorite,
          pdf: pdfBuffer
        });
      return res.status(200).json({
        message: "Pending eligibility PDF created successfully",
        data: {
          pendingEligibility: newPendingEligibility,
          patientDetails: patientDetails,
          pdf: pdfBuffer
        }
      });
    } else {
      return res.status(200).json({
        message: "Pending eligibility PDF created successfully",
        data: {
          pendingEligibility: req.body,
          patientDetails: patientDetails,
          pdf: pdfBuffer
        }
      });
    }
  } catch (e) {
    let errorMsg = "Error occurred while saving data";
    if (e.name === "SequelizeUniqueConstraintError") {
      errorMsg =
        "The filter name must be unique. A duplicate filter name was found.";
      return res.status(400).send({ message: errorMsg, error: e });
    } else
      return res.status(500).json({
        message: "Failed to create pending eligibility",
        error: e.message
      });
  }
};

// Get all PendingEligibility entries
module.exports.getAll = async function (req, res) {
  // #swagger.tags = ['Pending Eligibility Report']
  try {
    const allPendingEligibilities =
      await models.PendingEligibilityReports.findAll({
        attributes: {
          exclude: ["pdf"]
        }
      });
    res.status(200).json({ data: allPendingEligibilities });
  } catch (error) {
    console.error("Error getting all pending eligibilities:", error);
    res.status(500).json({
      message: "Failed to get all pending eligibilities",
      error: error.message
    });
  }
};

// Get a PendingEligibility entry by ID
module.exports.getById = async function (req, res) {
  // #swagger.tags = ['Pending Eligibility Report']
  const { id } = req.params;
  try {
    const pendingEligibility = await models.PendingEligibilityReports.findOne({
      where: { id: id }
    });
    const patients = pendingEligibility.patients;
    const location = pendingEligibility.location;
    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    if (!pendingEligibility) {
      return res.status(404).json({ message: "Pending eligibility not found" });
    }
    res
      .status(200)
      .json({
        pendingEligibility: pendingEligibility,
        patientDetails: patientDetails
      });
  } catch (error) {
    console.error("Error getting pending eligibility by ID:", error);
    res.status(500).json({
      message: "Failed to get pending eligibility",
      error: error.message
    });
  }
};

// Update a PendingEligibility entry by ID
module.exports.update = async function (req, res) {
  // #swagger.tags = ['Pending Eligibility Report']
  const { id } = req.params;
  const {
    filterName,
    fromDate,
    toDate,
    insuranceHierarchy,
    location,
    patients,
    provider,
    lastEligibility,
    insuranceStatus,
    daysGreaterThan,
    insuranceType,
    columns,
    payer,
    isFavorite
  } = req.body;
  try {
    if (
      Object.keys(req.body).length === 1 &&
      Object.keys(req.body)[0] === "isFavorite"
    ) {
      const [updatedCount] = await models.PendingEligibilityReports.update(
        req.body,
        {
          where: { id }
        }
      );
      if (updatedCount === 0) {
        return res
          .status(404)
          .json({ message: "Pending eligibility not found" });
      }
      const result = await models.PendingEligibilityReports.findOne({
        where: { id }
      });
      const value = await generatePdf(result);
      res.status(200).send({
        message: "Pending eligibility updated successfully",
        data: {
          'pendingEligibility':result,
          ...value
        }
      });
    } else {
      const value = await generatePdf(req.body);
      const updatePendingEligibility = {
        fromDate: fromDate,
        toDate: toDate,
        insuranceHierarchy: insuranceHierarchy,
        patients: patients,
        provider: provider,
        location: location,
        lastEligibility: lastEligibility,
        insuranceStatus: insuranceStatus,
        daysGreaterThan: daysGreaterThan,
        insuranceType: insuranceType,
        columns: columns,
        payer: payer,
        isFavorite: isFavorite,
        pdf: value.pdfBuffer
      };
      const [updatedCount] = await models.PendingEligibilityReports.update(
        updatePendingEligibility,
        {
          where: { id }
        }
      );
      if (updatedCount === 0) {
        return res
          .status(404)
          .json({ message: "Pending eligibility not found" });
      }

      const result = await models.PendingEligibilityReports.findOne({
        where: { id }
      });
      res.status(200).send({
        message: "Pending eligibility updated successfully",
        data: {
          'pendingEligibility':result,
          ...value
        }
      });
    }
  } catch (e) {
    // let errorMsg = "Error occurred while saving data";
    // if (e.name === "SequelizeUniqueConstraintError") {
    //   errorMsg = "The filter name must be unique. A duplicate filter name was found.";
    //   return res.status(400).send({ message: errorMsg, error: e });
    // }
    // else
    return res.status(500).json({
      message: "Failed to update pending eligibility",
      error: e.message
    });
  }
};

// Delete a PendingEligibility entry by ID
module.exports.delete = async function (req, res) {
  // #swagger.tags = ['Pending Eligibility Report']
  const { id } = req.params;
  try {
    const deletedCount = await models.PendingEligibilityReports.destroy({
      where: { id }
    });
    if (deletedCount === 0) {
      return res.status(404).json({ message: "Pending eligibility not found" });
    }
    res
      .status(200)
      .json({ message: "Pending eligibility deleted successfully" });
  } catch (error) {
    console.error("Error deleting pending eligibility:", error);
    res.status(500).json({
      message: "Failed to delete pending eligibility",
      error: error.message
    });
  }
};

//get patient details from manual and schedule patients

module.exports.getPatientsByCriteria = async (req, res) => {
  try {
    const attributesCommon = [
      ["practiceNameAndLoc", "location"],
      "provider",
      ["insurancePayer", "payer"],
      "firstName",
      "lastName",
      "patientId",
      "addedFrom"
    ];
    const {
      fromdate,
      todate,
      location,
      provider,
      payer,
      insurancestatus,
      insurancetype,
      patients
    } = req.body;
    const searchCriteria = {
      createdat: {
        [Op.gte]: moment(fromdate).toDate(),
        [Op.lt]: moment(todate).toDate()
      }
    };
    if (location) {
      searchCriteria["practiceNameAndLoc"] = {
        [Op.in]: location
      };
    }
    if (provider) {
      searchCriteria["provider"] = {
        [Op.in]: provider
      };
    }
    if (insurancestatus) {
      if (insurancestatus.includes("pendingeligibilty")) {
        searchCriteria["lastVerified"] = {
          [Op.ne]: null
        };
        searchCriteria["isVerified"] = false;
      } else {
        if (insurancestatus.includes("pendingverification")) {
          searchCriteria["lastVerified"] = {
            [Op.eq]: null
          };
          searchCriteria["isVerified"] = false;
        }
      }
    }
    if (insurancetype) {
      // medicaid, standard
      if (insurancetype.includes("medicaid")) {
        searchCriteria["medicaidId"] = {
          [Op.ne]: null
        };
      } else {
        if (insurancetype.includes("standard")) {
          searchCriteria["medicaidId"] = null;
        }
      }
    }
    if (payer && payer.length > 0) {
      searchCriteria["insurancePayer"] = {
        [Op.in]: payer
      };
    }
    if (patients && patients.length > 0) {
      let patientids = patients.map((patient) => patient.patientId);
      searchCriteria["patientId"] = {
        [Op.in]: patientids
      };
    }
    const attributesManual = [
      ...attributesCommon,
      [models.Sequelize.literal("0"), "isScheduled"]
    ];

    const attributesSchedule = [
      ...attributesCommon,
      [models.Sequelize.literal("1"), "isScheduled"]
    ];

    const manualPatients = await models.ManualPatients.findAll({
      where: searchCriteria,
      attributes: attributesManual,
      raw: true
    });

    const schedulePatients = await models.SchedulePatients.findAll({
      where: searchCriteria,
      attributes: attributesSchedule,
      raw: true
    });

    const combinedPatients = manualPatients.concat(schedulePatients);

    const result = {
      locations: [],
      providers: [],
      payers: [],
      patients: []
    };

    combinedPatients.forEach((data) => {
      if (data.location && !result.locations.includes(data.location)) {
        result.locations.push(data.location);
      }
      if (data.provider && !result.providers.includes(data.provider)) {
        result.providers.push(data.provider);
      }
      if (data.payer && !result.payers.includes(data.payer)) {
        result.payers.push(data.payer);
      }
      const patientKey = `${data.firstName}|${data.lastName}|${data.patientId}|${data.isScheduled}|${data.addedFrom}`;
      if (
        !result.patients.some(
          (patient) =>
            `${patient.firstName}|${patient.lastName}|${patient.patientId}|${patient.isScheduled}|${patient.addedFrom}` ===
            patientKey
        )
      ) {
        result.patients.push({
          firstName: data.firstName || "null",
          lastName: data.lastName || "null",
          patientId: data.patientId || "null",
          isScheduled: data.isScheduled,
          addedFrom: data.addedFrom || "null"
        });
      }
    });

    res.json(result);
  } catch (error) {
    console.error("Error fetching patient data:", error);
    res.status(500).send("Internal Server Error");
  }
};

module.exports.getPatients = async (req, res) => {
  try {
    const attributesCommon = [
      ["practiceNameAndLoc", "location"],
      "provider",
      ["insurancePayer", "payer"],
      "firstName",
      "lastName",
      "patientId",
      "addedFrom"
    ];

    const attributesManual = [
      ...attributesCommon,
      [models.Sequelize.literal("0"), "isScheduled"]
    ];

    const attributesSchedule = [
      ...attributesCommon,
      [models.Sequelize.literal("1"), "isScheduled"]
    ];

    const manualPatients = await models.ManualPatients.findAll({
      attributes: attributesManual,
      raw: true
    });

    const schedulePatients = await models.SchedulePatients.findAll({
      attributes: attributesSchedule,
      raw: true
    });

    const combinedPatients = manualPatients.concat(schedulePatients);

    const result = {
      locations: [],
      providers: [],
      payers: [],
      patients: []
    };

    combinedPatients.forEach((data) => {
      if (data.location && !result.locations.includes(data.location)) {
        result.locations.push(data.location);
      }
      if (data.provider && !result.providers.includes(data.provider)) {
        result.providers.push(data.provider);
      }
      if (data.payer && !result.payers.includes(data.payer)) {
        result.payers.push(data.payer);
      }
      const patientKey = `${data.firstName}|${data.lastName}|${data.patientId}|${data.isScheduled}|${data.addedFrom}`;
      if (
        !result.patients.some(
          (patient) =>
            `${patient.firstName}|${patient.lastName}|${patient.patientId}|${patient.isScheduled}|${patient.addedFrom}` ===
            patientKey
        )
      ) {
        result.patients.push({
          firstName: data.firstName || "null",
          lastName: data.lastName || "null",
          patientId: data.patientId || "null",
          isScheduled: data.isScheduled,
          addedFrom: data.addedFrom || "null"
        });
      }
    });

    res.json(result);
  } catch (error) {
    console.error("Error fetching patient data:", error);
    res.status(500).send("Internal Server Error");
  }
};

const generatePdf = async (req) => {
  const {
    filterName,
    fromDate,
    toDate,
    insuranceHierarchy,
    location,
    patients,
    provider,
    lastEligibility,
    insuranceStatus,
    daysGreaterThan,
    insuranceType,
    columns,
    payer,
    isFavorite,
    isSave
  } = req;
  try {
    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    //uncomment on commit/ deployment
    const browser = await puppeteer.launch({
      executablePath: "/usr/bin/google-chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox"]
    });
    const page = await browser.newPage();
    const tableHeaders =
      columns?.length > 0 &&
      columns
        .map(
          (item) =>
            item &&
            `
      <th>${item
        .replace(/([A-Z])/g, " $1")
        .trim()
        .replace(/^\w/, (c) => c.toUpperCase())}</th>
      `
        )
        .join("");
    const tableData =
      patientDetails?.length > 0 &&
      patientDetails
        .map((item, i) => {
          let str = "";
          const className = i % 2 === 0 ? "even-row" : "odd-row";
          for (const column of columns) {
            let columnValue = item[column];
            if (column === "patientName") {
              columnValue = `${item.firstName} ${item.lastName}`.trim();
            } else if (column === "subscriberName") {
              columnValue =
                `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
            } else if (column === "dependentName") {
              columnValue =
                `${item.dependentFirstName} ${item.dependentLastName}`.trim();
            } else if (column === "insuranceName") {
              columnValue = `<img src="${item.payerLogo}" />`;
            }
            if (column.includes("OfBirth")) {
              columnValue = new Date(columnValue)
                .toLocaleDateString("en-GB")
                .replace(/\//g, "/");
            }
            str += `<td><span class=${
              column === "patientName" || column === "patientId"
                ? "underlined"
                : ""
            }>${columnValue}</span></td>`;
          }
          return `<tr class="${className}">${str}</tr>`;
        })
        .join("");

    const content = `
  <html>
  <head>
  </head>
  <style>
  h1,h2,h3,h4,h5,h6,p,li,ul{
  margin:0;
  padding:0;
  }
  body {
  font-family: 'Roboto', sans-serif;
  font-style: normal !important;
  margin: 0;
  padding:20px;
  box-sizing:border-box;
  }
  table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #dee2e6;
  }
  thead {
  display: table-header-group;
  }
  tr{
  border-top: 1px solid #dee2e6;
  }
  td{
  font-size:8px !important;
  }
  th, td {
  padding: 5px 5px;
  text-align: left;
  }
  img{
  width:50px;
  }
  th{
  font-size:8px;
  }
  .d-flex{
  display: -webkit-flex;
  display: flex;
  }
  .jbw{
  -webkit-justify-content: space-between;
  justify-content: space-between;
  }
  .alc{
  -webkit-align-items: center;
  align-items: center;
  }
  .fw{
  flex-wrap:wrap;
  -webkit-flex-wrap: wrap;
  }
  .w-50{
  width: 50%;
  }
  .fs-12{
  font-size: 12px;
  }
  .fw-500{
  font-weight: 500;
  }
  .w-100{
  width: 100%;
  }
  li{
  list-style-type:none;
  }
  .labelColor{
  color:#9F9F9F;
  }
  .pendingList{
  width:75%;
  }
  .tal{
  text-align: left;
  }
  .mb-10{
  margin-bottom:10px;
  }
  .mb-30{
  margin-bottom:30px;
  }
  .flex-grow {
  flex-grow: 1; 
  flex-basis: 0;
  }
  .fs-14{
  font-size:14px;
  }
  .even-row {
  background: #fafafa;
  }
  .odd-row {
  background: #f5f5f5;
  }
  .underlined {
  text-decoration: underline;
  color: #8dbdca;
  }
  
  </style>
  <body>
  <div>
  <div class="pendingList">
  <div class="mb-30">
  <ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
  <li class="flex-grow ">Location</li>
  <li class="flex-grow ">Provider</li>
  <li class="flex-grow ">Payer</li>
  <li class="flex-grow ">Insurance Status</li>
  </ul>
  <ul class="d-flex jbw fs-14 fw-500 w-100 tal ">
  <li class="flex-grow ">${
    location?.length > 0 && location.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${
    provider?.length > 0 && provider.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${
    payer?.length > 0 && payer.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${insuranceStatus}</li>
  </ul>
  </div>
  <div class="mb-30">
  <ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
  <li class="flex-grow ">Insurance Type</li>
  <li class="flex-grow ">Insurance Hiearchy</li>
  <li class="flex-grow ">Patient</li>
  <li class="flex-grow ">Days Since Last Eligibility</li>
  </ul>
  <ul class="d-flex jbw fs-14 fw-500 w-100">
  <li class="flex-grow ">${insuranceType}</li>
  <li class="flex-grow ">${
    insuranceHierarchy?.length > 0 &&
    insuranceHierarchy.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">01</li>
  <li class="flex-grow ">Greater Than ${daysGreaterThan}Days</li>
  </ul>
  </div>
  </div>
  <table>
      <thead>
            <tr>
               ${tableHeaders} 
  
            </tr>
      </thead>
      <tbody>
      ${tableData}
      </tbody>
      </table>
  </div>
  </body>
  </html>`;
    await page.setViewport({ width: 1920, height: 1080 });
    await page.setContent(content);

    const pdfBuffer = await page.pdf({
      format: "A4",
      margin: {
        top: "10px",
        right: "0px",
        bottom: "10px",
        left: "0px"
      },
      path: "output.pdf",
      printBackground: true
    });
    await browser.close();
    return {
      pdfBuffer,
      patientDetails
    };
  } catch (error) {
    console.log(error);
  }
};
