const models = require("../../../db/model"); 
const puppeteer = require("puppeteer");
const Sequelize = require("sequelize");
// Create a new patient
module.exports.create = async function (req, res) {
  // #swagger.tags = ['New Patient Report']
  const {
    filterName,
    appointmentDate,
    fromDate,
    toDate,
    location,
    provider,
    patientType,
    patients,
    columns,
    isFavorite,
    isSave
  } = req.body;
  try {
    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: {
              patientId: patient.patientId,
              speciality: {
                [Sequelize.Op.in]: patientType
              }
            },
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: {
              patientId: patient.patientId,
              speciality: {
                [Sequelize.Op.in]: patientType
              }
            },
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: {
            practiceNameAndLoc: loc,
            speciality: {
              [Sequelize.Op.in]: patientType
            }
          },
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: {
            practiceNameAndLoc: loc,
            speciality: {
              [Sequelize.Op.in]: patientType
            }
          },
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      })
      patient.payerLogo = payerlogo.payerLogo
    }
    //uncomment on commit/ deployment
    const browser = await puppeteer.launch({
      executablePath: "/usr/bin/google-chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox"]
    });
    const page = await browser.newPage();
    const tableHeaders =
      columns?.length > 0 &&
      columns
        .map(
          (item) => item && `
        <th>${item
              .replace(/([A-Z])/g, " $1")
              .trim()
              .replace(/^\w/, (c) => c.toUpperCase())}</th>
        `
        )
        .join("");
    const tableData =
      patientDetails?.length > 0 &&
      patientDetails.map((item, i) => {
        let str = "";
        const className = (i % 2 === 0 ? "even-row" : "odd-row");
        for (const column of columns) {
          let columnValue = item[column];
          if (column === "patientName") {
            columnValue = `${item.firstName} ${item.lastName}`.trim();
          } else if (column === "subscriberName") {
            columnValue = `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
          } else if (column === "dependentName") {
            columnValue = `${item.dependentFirstName} ${item.dependentLastName}`.trim();
          } else if (column === "insuranceName") {
            columnValue = `<img src="${item.payerLogo}" />`
          }
          if (column.includes('OfBirth')) {
            columnValue = new Date(columnValue).toLocaleDateString("en-GB").replace(/\//g, "/");
          }
          str += `<td><span class=${(column === "patientName" || column === "patientId") ? "underlined" : ""}>${columnValue}</span></td>`;
        }
        return `<tr class="${className}">${str}</tr>`;
      }).join("");

    const content = `
  <html>
  <head>
  </head>
  <style>
  h1,h2,h3,h4,h5,h6,p,li,ul{
    margin:0;
    padding:0;
  }
  body {
    font-family: 'Roboto', sans-serif;
    font-style: normal !important;
    margin: 0;
    padding:20px;
    box-sizing:border-box;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    border: 1px solid #dee2e6;
  }
  thead {
    display: table-header-group;
  }
  tr{
  border-top: 1px solid #dee2e6;
  }
  td{
    font-size:8px !important;
    }
    th, td {
      padding: 5px 5px;
      text-align: left;
    }
    img{
      width:50px;
    }
    th{
    font-size:8px;
    }
  .d-flex{
    display: -webkit-flex;
    display: flex;
  }
  .jbw{
    -webkit-justify-content: space-between;
    justify-content: space-between;
  }
  .alc{
    -webkit-align-items: center;
    align-items: center;
  }
  .fw{
    flex-wrap:wrap;
    -webkit-flex-wrap: wrap;
  }
  .w-50{
    width: 50%;
  }
  .fs-12{
    font-size: 12px;
  }
  .fw-500{
    font-weight: 500;
  }
  .w-100{
    width: 100%;
  }
  li{
    list-style-type:none;
  }
  .labelColor{
    color:#9F9F9F;
  }
  .pendingList{
    width:75%;
  }
  .tal{
    text-align: left;
  }
  .mb-10{
    margin-bottom:10px;
  }
  .mb-30{
    margin-bottom:30px;
  }
  .flex-grow {
    flex-grow: 1; 
    flex-basis: 0;
  }
  .fs-14{
    font-size:14px;
  } 
  .even-row {
    background: #fafafa;
  }
  .odd-row {
    background: #f5f5f5;
  }
  .underlined {
    text-decoration: underline;
    color: #8dbdca;
  }
  </style>
  <body>
  <div>
  <div class="pendingList">
  <div class="mb-30">
  <ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
  <li class="flex-grow ">Location</li>
  <li class="flex-grow ">Provider</li>
  <li class="flex-grow ">Patient Type</li>
  <li class="flex-grow ">Patient</li>
  </ul>
  <ul class="d-flex jbw fs-14 fw-500 w-100 tal ">
  <li class="flex-grow ">${location?.length > 0 && location.map((item) => `<p>${item}</p>`).join("")
      }</li>
  <li class="flex-grow ">${provider?.length > 0 && provider.map((item) => `<p>${item}</p>`).join("")
      }</li>
  <li class="flex-grow ">${patientType}</li>
  <li class="flex-grow ">10</li>
  </ul>
  </div>
  </div>
  <table>
        <thead>
              <tr>
                 ${tableHeaders} 
              </tr>
        </thead>
        <tbody>
        ${tableData}
        </tbody>
        </table>
  </div>
  </body>
  </html>`;
    await page.setContent(content);

    const pdfBuffer = await page.pdf({
      format: "A4",
      margin: {
        top: "10px",
        right: "0px",
        bottom: "10px",
        left: "0px"
      },
      path: "output.pdf",
      printBackground: true
    });
    await browser.close();
    if (isSave) {
      const newPatientData = {
        filtername: filterName,
        appointmentDate: appointmentDate,
        fromDate: fromDate,
        toDate: toDate,
        location: location,
        provider: provider,
        patientType: patientType,
        patients: patients,
        columns: columns,
        isFavorite: isFavorite,
        pdf: pdfBuffer
      };
      const newpatient = await models.NewPatientReports.create(newPatientData);
      return res.status(200).json({
        message: "New patient PDF created  successfully",
        data: {
          newPatient: newpatient,
          patientDetails: patientDetails,
          pdf: pdfBuffer
        }
      });
    } else {
      return res.status(200).json({
        message: "New patient PDF created  successfully",
        data: {
          newPatient: req.body,
          patientDetails: patientDetails,
          pdf: pdfBuffer
        }
      });
    }
  } catch (e) {
    let errorMsg = "Error occurred while saving data";
    if (e.name === "SequelizeUniqueConstraintError") {
      errorMsg =
        "The filter name must be unique. A duplicate filter name was found.";
      return res.status(400).send({ message: errorMsg, error: e });
    } else
      res.status(500).json({
        message: "Error creating patient",
        error: e.message
      });
  }
};

// Get all Patient
module.exports.getAll = async function (req, res) {
  // #swagger.tags = ['New Patient Report']
  try {
    const allPatient = await models.NewPatientReports.findAll({
      attributes: {
        exclude: ['pdf']
      }
    });
    res.status(200).send({
      data: allPatient,
      message: "All Patient reports fetched successfully"
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error getting all Patient reports",
      error: error.message
    });
  }
};

// Get an Patient by ID
module.exports.getById = async function (req, res) {
  // #swagger.tags = ['New Patient Report']
  const { patientId } = req.params;
  try {
    const patient = await models.NewPatientReports.findByPk(patientId);
    const patients  =patient.patients
    const location  =patient.location
    const patientType  =patient.patientType
    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: {
              patientId: patient.patientId,
              speciality: {
                [Sequelize.Op.in]: patientType
              }
            },
            raw:true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: {
              patientId: patient.patientId,
              speciality: {
                [Sequelize.Op.in]: patientType
              }
            },
            raw:true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: {
            practiceNameAndLoc: loc,
            speciality: {
              [Sequelize.Op.in]: patientType
            }
          },
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: {
            practiceNameAndLoc: loc,
            speciality: {
              [Sequelize.Op.in]: patientType
            }
          },
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      })
      patient.payerLogo = payerlogo?.payerLogo? payerlogo.payerLogo : null
    }
    if (!patient) {
      res.status(404).json({ message: "patient not found" });
      return;
    }
    res.status(200).json({
        newPatient:patient,
        patientDetails:patientDetails
      }
    );
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error getting patient by ID",
      error: error.message
    });
  }
};

module.exports.update = async function (req, res) {
  // #swagger.tags = ['New Patient Report']
  // Find the patient by ID
  const patientId = req.params.patientId;

  const {
    filtername,
    appointmentDate,
    fromDate,
    toDate,
    location,
    provider,
    patientType,
    patient,
    columns,
    isFavorite
  } = req.body;
  try {
    if(Object.keys(req.body).length === 1 && Object.keys(req.body)[0] === 'isFavorite'){
      const [updatedCount] = await models.NewPatientReports.update(req.body,{
        where:{id:patientId}
      })
      if (updatedCount === 0) {
        return res.status(404).json({ message: "Pending eligibility not found" });
      }
      const result = await models.NewPatientReports.findOne({
        where: {id:  patientId }
      });
      const value = await generatePdf(result)
      res.status(200).send({
        message: "Pending eligibility updated successfully",
        data: {
          'newPatient':result,
          ...value
        }
      });
    }else{
    const value = await generatePdf(req.body)
    const updatedPatientData = {
      appointmentDate: appointmentDate,
      fromDate: fromDate,
      toDate: toDate,
      location: location,
      provider: provider,
      patientType: patientType,
      patient: patient,
      columns: columns,
      isFavorite: isFavorite,
      pdf:value.pdfBuffer
    };
    const patientToUpdate = await models.NewPatientReports.findByPk(patientId);
    if (!patientToUpdate) {
      return res.status(404).send({ message: "Patient not found" });
    }

    // Update the patient data
    await patientToUpdate.update(updatedPatientData);
    const result = await models.NewPatientReports.findByPk(patientId);
    res.status(200).send({
      data: {
        'newPatient':result,
        ...value
      },
      message: "Patient updated successfully"
    });
  }
  } catch (e) {
    // let errorMsg = "Error occurred while saving data";
    // if (e.name === "SequelizeUniqueConstraintError") {
    //   errorMsg = "The filter name must be unique. A duplicate filter name was found.";
    //   return res.status(400).send({ message: errorMsg, error: e });
    // }
    // else
    res.status(500).json({
      message: "Error updating patient",
      error: e.message
    });
  }
};

// Delete an patient
module.exports.delete = async function (req, res) {
  // #swagger.tags = ['New Patient Report']
  const { patientId } = req.params;
  try {
    const patient = await models.NewPatientReports.findByPk(patientId);
    if (!patient) {
      res.status(404).json({ message: "patient not found" });
      return;
    }
    await patient.destroy();
    res.status(200).json({
      message: "patient deleted successfully"
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error deleting patient",
      error: error.message
    });
  }
};


const generatePdf = async(req)=>{

    const {
      filterName,
      appointmentDate,
      fromDate,
      toDate,
      location,
      provider,
      patientType,
      patients,
      columns,
      isFavorite,
      isSave
    } = req;
    try {
      let patientDetails = [];
      if (patients.length > 0) {
        for (let patient of patients) {
          if (patient.isSchedule) {
            const patientdata = await models.SchedulePatients.findOne({
              where: {
                patientId: patient.patientId,
                speciality: {
                  [Sequelize.Op.in]: patientType
                }
              },
            });
            if (patientdata) {
              patientDetails = [...patientDetails, patientdata];
            }
          } else {
            const patientdata = await models.ManualPatients.findOne({
              where: {
                patientId: patient.patientId,
                speciality: {
                  [Sequelize.Op.in]: patientType
                }
              },
            });
            if (patientdata) {
              patientDetails = [...patientDetails, patientdata];
            }
          }
        }
      } else {
        for (const loc of location) {
          const scepatientdata = await models.SchedulePatients.findAll({
            where: {
              practiceNameAndLoc: loc,
              speciality: {
                [Sequelize.Op.in]: patientType
              }
            },
          });
          const manpatientdata = await models.ManualPatients.findAll({
            where: {
              practiceNameAndLoc: loc,
              speciality: {
                [Sequelize.Op.in]: patientType
              }
            },
          });
          if (manpatientdata.length > 0 || scepatientdata.length > 0) {
            patientDetails = [
              ...patientDetails,
              ...manpatientdata,
              ...scepatientdata
            ];
          }
        }
      }
      for (let patient of patientDetails) {
        const payerlogo = await models.InsurancePayer.findOne({
          where: { payerId: patient.payerIdCode }
        })
        patient.payerLogo = payerlogo.payerLogo
      }
      //uncomment on commit/ deployment
      const browser = await puppeteer.launch({
        executablePath: "/usr/bin/google-chrome",
        args: ["--no-sandbox", "--disable-setuid-sandbox"]
      });
      const page = await browser.newPage();
      const tableHeaders =
        columns?.length > 0 &&
        columns
          .map(
            (item) => item && `
          <th>${item
                .replace(/([A-Z])/g, " $1")
                .trim()
                .replace(/^\w/, (c) => c.toUpperCase())}</th>
          `
          )
          .join("");
      const tableData =
        patientDetails?.length > 0 &&
        patientDetails.map((item, i) => {
          let str = "";
          const className = (i % 2 === 0 ? "even-row" : "odd-row");
          for (const column of columns) {
            let columnValue = item[column];
            if (column === "patientName") {
              columnValue = `${item.firstName} ${item.lastName}`.trim();
            } else if (column === "subscriberName") {
              columnValue = `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
            } else if (column === "dependentName") {
              columnValue = `${item.dependentFirstName} ${item.dependentLastName}`.trim();
            } else if (column === "insuranceName") {
              columnValue = `<img src="${item.payerLogo}" />`
            }
            if (column.includes('OfBirth')) {
              columnValue = new Date(columnValue).toLocaleDateString("en-GB").replace(/\//g, "/");
            }
            str += `<td><span class=${(column === "patientName" || column === "patientId") ? "underlined" : ""}>${columnValue}</span></td>`;
          }
          return `<tr class="${className}">${str}</tr>`;
        }).join("");
  
      const content = `
    <html>
    <head>
    </head>
    <style>
    h1,h2,h3,h4,h5,h6,p,li,ul{
      margin:0;
      padding:0;
    }
    body {
      font-family: 'Roboto', sans-serif;
      font-style: normal !important;
      margin: 0;
      padding:20px;
      box-sizing:border-box;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      border: 1px solid #dee2e6;
    }
    thead {
      display: table-header-group;
    }
    tr{
    border-top: 1px solid #dee2e6;
    }
    td{
      font-size:8px !important;
      }
      th, td {
        padding: 5px 5px;
        text-align: left;
      }
      img{
        width:50px;
      }
      th{
      font-size:8px;
      }
    .d-flex{
      display: -webkit-flex;
      display: flex;
    }
    .jbw{
      -webkit-justify-content: space-between;
      justify-content: space-between;
    }
    .alc{
      -webkit-align-items: center;
      align-items: center;
    }
    .fw{
      flex-wrap:wrap;
      -webkit-flex-wrap: wrap;
    }
    .w-50{
      width: 50%;
    }
    .fs-12{
      font-size: 12px;
    }
    .fw-500{
      font-weight: 500;
    }
    .w-100{
      width: 100%;
    }
    li{
      list-style-type:none;
    }
    .labelColor{
      color:#9F9F9F;
    }
    .pendingList{
      width:75%;
    }
    .tal{
      text-align: left;
    }
    .mb-10{
      margin-bottom:10px;
    }
    .mb-30{
      margin-bottom:30px;
    }
    .flex-grow {
      flex-grow: 1; 
      flex-basis: 0;
    }
    .fs-14{
      font-size:14px;
    } 
    .even-row {
      background: #fafafa;
    }
    .odd-row {
      background: #f5f5f5;
    }
    .underlined {
      text-decoration: underline;
      color: #8dbdca;
    }
    </style>
    <body>
    <div>
    <div class="pendingList">
    <div class="mb-30">
    <ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
    <li class="flex-grow ">Location</li>
    <li class="flex-grow ">Provider</li>
    <li class="flex-grow ">Patient Type</li>
    <li class="flex-grow ">Patient</li>
    </ul>
    <ul class="d-flex jbw fs-14 fw-500 w-100 tal ">
    <li class="flex-grow ">${location?.length > 0 && location.map((item) => `<p>${item}</p>`).join("")
        }</li>
    <li class="flex-grow ">${provider?.length > 0 && provider.map((item) => `<p>${item}</p>`).join("")
        }</li>
    <li class="flex-grow ">${patientType}</li>
    <li class="flex-grow ">10</li>
    </ul>
    </div>
    </div>
    <table>
          <thead>
                <tr>
                   ${tableHeaders} 
                </tr>
          </thead>
          <tbody>
          ${tableData}
          </tbody>
          </table>
    </div>
    </body>
    </html>`;
      await page.setContent(content);
  
      const pdfBuffer = await page.pdf({
        format: "A4",
        margin: {
          top: "10px",
          right: "0px",
          bottom: "10px",
          left: "0px"
        },
        path: "output.pdf",
        printBackground: true
      });
      await browser.close();
      return{
        pdfBuffer,
        patientDetails
      }
  }catch(error){
  console.log(error)
}
}
