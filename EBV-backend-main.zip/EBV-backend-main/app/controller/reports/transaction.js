const models = require("../../../db/model"); 
const puppeteer = require("puppeteer");
// Create a new transaction
module.exports.create = async function (req, res) {
  // #swagger.tags = ['Transaction Report']
  try {
    const {
      filterName,
      fromDate,
      toDate,
      benefitsTypes,
      location,
      patientType,
      provider,
      appStatus,
      patients,
      isFavorite,
      isSave
    } = req.body;

    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: { patientId: patient.patientId }
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: { patientId: patient.patientId }
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: { practiceNameAndLoc: loc }
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: { practiceNameAndLoc: loc }
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    //uncomment on commit/ deployment
    const browser = await puppeteer.launch({
      executablePath: "/usr/bin/google-chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox"]
    });
    const page = await browser.newPage();
    const columns = [
      "patientId",
      "patientName",
      "dateOfBirth",
      "memberId",
      "groupId",
      "relationship",
      "procedureCode",
      "provider",
      "subscriberName",
      "dependentName",
      "typeOfService",
      "practiceNameAndLoc",
      "appointmentType",
      "insurancePlan",
      "insuranceName"
    ];

    const tableHeaders =
      columns?.length > 0 &&
      columns
        .map(
          (item) =>
            item &&
            `
        <th>${item
          .replace(/([A-Z])/g, " $1")
          .trim()
          .replace(/^\w/, (c) => c.toUpperCase())}</th>
        `
        )
        .join("");
    const tableData =
      patientDetails?.length > 0 &&
      patientDetails
        .map((item, i) => {
          let str = "";
          const className = i % 2 === 0 ? "even-row" : "odd-row";
          for (const column of columns) {
            let columnValue = item[column] || "";
            if (column === "patientName") {
              columnValue = `${item.firstName} ${item.lastName}`.trim();
            } else if (column === "subscriberName") {
              columnValue =
                `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
            } else if (column === "dependentName") {
              columnValue =
                `${item.dependentFirstName} ${item.dependentLastName}`.trim();
            } else if (column === "insuranceName") {
              columnValue = `<img src="${item.payerLogo}" />`;
            }
            if (column.includes("OfBirth")) {
              columnValue = new Date(columnValue)
                .toLocaleDateString("en-GB")
                .replace(/\//g, "/");
            }
            str += `<td class=${
              column === "patientName" || column === "patientId"
                ? "underlined"
                : ""
            }>${columnValue}</td>`;
          }
          return `<tr class="${className}">${str}</tr>`;
        })
        .join("");

    const content = `
  <html>
  <head>
  </head>
  <style>
  h1,h2,h3,h4,h5,h6,p,li,ul{
    margin:0;
    padding:0;

  }
  body {
    font-family: 'Roboto', sans-serif;
    font-style: normal !important;
    margin: 0;
    padding:10px;
    box-sizing:border-box;

  }
  table {
    width: 100%;
    border-collapse: collapse;
    border: 1px solid #dee2e6;
  }
  thead {
    display: table-header-group;
  }
  tr{
  border-top: 1px solid #dee2e6;
  }
  td{
  font-size:8px !important;
  }
  img{
    width:50px;
  }
  th, td {
    padding: 5px 5px;
    text-align: left;
  }
  th{
  font-size:8px;
  }
  .d-flex{
    display: -webkit-flex;
    display: flex;
  }
  .jbw{
    -webkit-justify-content: space-between;
    justify-content: space-between;
  }
  .alc{
    -webkit-align-items: center;
    align-items: center;
  }
  .fw{
    flex-wrap:wrap;
    -webkit-flex-wrap: wrap;
  }
  .w-50{
    width: 50%;
  }
  .fs-12{
    font-size: 12px;
  }
  .fw-500{
    font-weight: 500;
  }
  .w-100{
    width: 100%;
  }
  li{
    list-style-type:none;
  }
  .labelColor{
    color:#9F9F9F;
  }
  .pendingList{
    width:75%;
  }
  .tal{
    text-align: left;
  }
  .mb-10{
    margin-bottom:10px;
  }
  .mb-30{
    margin-bottom:30px;
  }
  .flex-grow {
    flex-grow: 1; 
    flex-basis: 0;
  }
  .fs-14{
    font-size:14px;
  } 
  .even-row {
    background: #fafafa;
  }
  .odd-row {
    background: #f5f5f5;
  }
  .underlined {
    text-decoration: underline;
    color: #8dbdca;
  }
  </style>
  <body>
  <div>
  <div class="pendingList">
  <div class="mb-30">
  <ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
  <li class="flex-grow ">Location</li>
  <li class="flex-grow ">Provider</li>
  <li class="flex-grow ">Benefits Types</li>
  <li class="flex-grow ">Patient Type</li>
  </ul>
  <ul class="d-flex jbw fs-14 fw-500 w-100 tal ">
  <li class="flex-grow ">${
    location?.length > 0 && location.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${
    provider?.length > 0 && provider.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${
    benefitsTypes?.length > 0 &&
    benefitsTypes.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${patientType}</li>
  </ul>
  </div>
  </div>
  <table class="table-striped">
        <thead>
              <tr>
                 ${tableHeaders} 
              </tr>
        </thead>
        <tbody>
        ${tableData}
        </tbody>
        </table>
  </div>
  </body>
  </html>`;
    await page.setContent(content);
    // const { width, height } = await page.evaluate(() => {
    //   // Measure the width and height of the content on the page
    //   const content = document.body;
    //   const rect = content.getBoundingClientRect();
    //   return { width: rect.width, height: rect.height };
    // });

    // // Set the viewport width and height to fit the content dimensions
    // await page.setViewport({ width: Math.ceil(width), height: Math.ceil(height) });
    const pdfBuffer = await page.pdf({
      path: "output.pdf",
      printBackground: true
    });
    await browser.close();

    if (isSave) {
      const newTransaction = await models.TransactionReports.create({
        filterName,
        fromDate,
        toDate,
        benefitsTypes,
        location,
        patientType,
        provider,
        appStatus,
        patients,
        isFavorite,
        pdf: pdfBuffer
      });
      return res.status(200).json({
        message: "Transaction PDF created successfully",
        data: {
          transcation: newTransaction,
          patientDetails: patientDetails,
          pdf: pdfBuffer
        }
      });
    } else {
      return res.status(200).json({
        message: "Transaction PDF created successfully",
        data: {
          transcation: req.body,
          patientDetails: patientDetails,
          pdf: pdfBuffer
        }
      });
    }
  } catch (e) {
    let errorMsg = "Error occurred while saving data";
    if (e.name === "SequelizeUniqueConstraintError") {
      errorMsg =
        "The filter name must be unique. A duplicate filter name was found.";
      return res.status(400).send({ message: errorMsg, error: e });
    } else
      return res.status(500).json({
        message: "Error creating transaction",
        error: e.message
      });
  }
};

// Get all transactions
module.exports.getAll = async function (req, res) {
  // #swagger.tags = ['Transaction Report']
  try {
    const allTransactions = await models.TransactionReports.findAll({
      attributes: {
        exclude: ["pdf"]
      }
    });

    res.status(200).json({
      data: allTransactions,
      message: "All transactions fetched successfully"
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error getting all transactions",
      error: error.message
    });
  }
};

// Get a transaction by ID
module.exports.getById = async function (req, res) {
  // #swagger.tags = ['Transaction Report']
  const { transactionId } = req.params;
  try {
    const transaction = await models.TransactionReports.findOne({
      where: {
        id: transactionId
      }
    });
    const patients = transaction.patients;
    const location = transaction.location;
    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: { patientId: patient.patientId },
            raw: true
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: { practiceNameAndLoc: loc },
          raw: true
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode },
        raw: true
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    if (!transaction) {
      res.status(404).json({ message: "Transaction not found" });
      return;
    }
    res.status(200).json({
        transaction: transaction,
        patientDetails: patientDetails
      });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error getting transaction by ID",
      error: error.message
    });
  }
};

// Update a transaction
module.exports.update = async function (req, res) {
  // #swagger.tags = ['Transaction Report']
  const { transactionId } = req.params;
  const {
    filterName,
    fromDate,
    toDate,
    benefitsTypes,
    location,
    patientType,
    provider,
    appStatus,
    patient,
    isFavorite
  } = req.body;

  try {
    if (
      Object.keys(req.body).length === 1 &&
      Object.keys(req.body)[0] === "isFavorite"
    ) {
      const [updatedCount] = await models.TransactionReports.update(req.body, {
        where: { id: transactionId }
      });
      if (updatedCount === 0) {
        return res
          .status(404)
          .json({ message: "Pending eligibility not found" });
      }
      const result = await models.TransactionReports.findOne({
        where: { id: transactionId }
      });
      const value = await generatePdf(result);
      res.status(200).send({
        message: "Pending eligibility updated successfully",
        data: {
          'transaction':result,
          ...value
        }
      });
    } else {
      const updateData = {};
      updateData.fromDate = fromDate;
      updateData.toDate = toDate;
      updateData.benefitsTypes = benefitsTypes;
      updateData.location = location;
      updateData.patientType = patientType;
      updateData.provider = provider;
      updateData.appStatus = appStatus;
      updateData.patient = patient;
      updateData.isFavorite = isFavorite;
      const transactionUpdate = await models.TransactionReports.findByPk(
        transactionId
      );
      if (!transactionUpdate) {
        return res.status(404).send({ message: "Patient not found" });
      }
      const value = await generatePdf(req.body);

      updateData.pdf = value.pdfBuffer;

      const updatedTransaction = await models.TransactionReports.update(
        updateData,
        {
          where: { id: transactionId }
        }
      );
      if (updatedTransaction) {
        const result = await models.TransactionReports.findOne({
          where: { id: transactionId }
        });

        res.status(200).json({
          data: {
            'transaction':result,
            ...value
          },
          message: "Transaction updated successfully"
        });
      } else {
        res.status(404).json({ message: "Transaction not found" });
      }
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error updating transaction",
      error: error.message
    });
  }
};

// Delete a transaction
module.exports.delete = async function (req, res) {
  // #swagger.tags = ['Transaction Report']
  const { transactionId } = req.params;
  try {
    const deletedCount = await models.TransactionReports.destroy({
      where: { id: transactionId }
    });
    if (deletedCount === 1) {
      res.status(200).json({ message: "Transaction deleted successfully" });
    } else {
      res.status(404).json({ message: "Transaction not found" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error deleting transaction",
      error: error.message
    });
  }
};

const generatePdf = async (req) => {
  try {
    const {
      filterName,
      fromDate,
      toDate,
      benefitsTypes,
      location,
      patientType,
      provider,
      appStatus,
      patients,
      isFavorite,
      isSave
    } = req;

    let patientDetails = [];
    if (patients.length > 0) {
      for (let patient of patients) {
        if (patient.isSchedule) {
          const patientdata = await models.SchedulePatients.findOne({
            where: { patientId: patient.patientId }
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        } else {
          const patientdata = await models.ManualPatients.findOne({
            where: { patientId: patient.patientId }
          });
          if (patientdata) {
            patientDetails = [...patientDetails, patientdata];
          }
        }
      }
    } else {
      for (const loc of location) {
        const scepatientdata = await models.SchedulePatients.findAll({
          where: { practiceNameAndLoc: loc }
        });
        const manpatientdata = await models.ManualPatients.findAll({
          where: { practiceNameAndLoc: loc }
        });
        if (manpatientdata.length > 0 || scepatientdata.length > 0) {
          patientDetails = [
            ...patientDetails,
            ...manpatientdata,
            ...scepatientdata
          ];
        }
      }
    }
    for (let patient of patientDetails) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode }
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    //uncomment on commit/ deployment
    const browser = await puppeteer.launch({
      executablePath: "/usr/bin/google-chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox"]
    });
    const page = await browser.newPage();
    const columns = [
      "patientId",
      "patientName",
      "dateOfBirth",
      "memberId",
      "groupId",
      "relationship",
      "procedureCode",
      "provider",
      "subscriberName",
      "dependentName",
      "typeOfService",
      "practiceNameAndLoc",
      "appointmentType",
      "insurancePlan",
      "insuranceName"
    ];

    const tableHeaders =
      columns?.length > 0 &&
      columns
        .map(
          (item) =>
            item &&
            `
        <th>${item
          .replace(/([A-Z])/g, " $1")
          .trim()
          .replace(/^\w/, (c) => c.toUpperCase())}</th>
        `
        )
        .join("");
    const tableData =
      patientDetails?.length > 0 &&
      patientDetails
        .map((item, i) => {
          let str = "";
          const className = i % 2 === 0 ? "even-row" : "odd-row";
          for (const column of columns) {
            let columnValue = item[column] || "";
            if (column === "patientName") {
              columnValue = `${item.firstName} ${item.lastName}`.trim();
            } else if (column === "subscriberName") {
              columnValue =
                `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
            } else if (column === "dependentName") {
              columnValue =
                `${item.dependentFirstName} ${item.dependentLastName}`.trim();
            } else if (column === "insuranceName") {
              columnValue = `<img src="${item.payerLogo}" />`;
            }
            if (column.includes("OfBirth")) {
              columnValue = new Date(columnValue)
                .toLocaleDateString("en-GB")
                .replace(/\//g, "/");
            }
            str += `<td class=${
              column === "patientName" || column === "patientId"
                ? "underlined"
                : ""
            }>${columnValue}</td>`;
          }
          return `<tr class="${className}">${str}</tr>`;
        })
        .join("");

    const content = `
  <html>
  <head>
  </head>
  <style>
  h1,h2,h3,h4,h5,h6,p,li,ul{
    margin:0;
    padding:0;

  }
  body {
    font-family: 'Roboto', sans-serif;
    font-style: normal !important;
    margin: 0;
    padding:10px;
    box-sizing:border-box;

  }
  table {
    width: 100%;
    border-collapse: collapse;
    border: 1px solid #dee2e6;
  }
  thead {
    display: table-header-group;
  }
  tr{
  border-top: 1px solid #dee2e6;
  }
  td{
  font-size:8px !important;
  }
  img{
    width:50px;
  }
  th, td {
    padding: 5px 5px;
    text-align: left;
  }
  th{
  font-size:8px;
  }
  .d-flex{
    display: -webkit-flex;
    display: flex;
  }
  .jbw{
    -webkit-justify-content: space-between;
    justify-content: space-between;
  }
  .alc{
    -webkit-align-items: center;
    align-items: center;
  }
  .fw{
    flex-wrap:wrap;
    -webkit-flex-wrap: wrap;
  }
  .w-50{
    width: 50%;
  }
  .fs-12{
    font-size: 12px;
  }
  .fw-500{
    font-weight: 500;
  }
  .w-100{
    width: 100%;
  }
  li{
    list-style-type:none;
  }
  .labelColor{
    color:#9F9F9F;
  }
  .pendingList{
    width:75%;
  }
  .tal{
    text-align: left;
  }
  .mb-10{
    margin-bottom:10px;
  }
  .mb-30{
    margin-bottom:30px;
  }
  .flex-grow {
    flex-grow: 1; 
    flex-basis: 0;
  }
  .fs-14{
    font-size:14px;
  } 
  .even-row {
    background: #fafafa;
  }
  .odd-row {
    background: #f5f5f5;
  }
  .underlined {
    text-decoration: underline;
    color: #8dbdca;
  }
  </style>
  <body>
  <div>
  <div class="pendingList">
  <div class="mb-30">
  <ul class="d-flex jbw labelColor fs-12 fw-500 w-100 mb-10">
  <li class="flex-grow ">Location</li>
  <li class="flex-grow ">Provider</li>
  <li class="flex-grow ">Benefits Types</li>
  <li class="flex-grow ">Patient Type</li>
  </ul>
  <ul class="d-flex jbw fs-14 fw-500 w-100 tal ">
  <li class="flex-grow ">${
    location?.length > 0 && location.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${
    provider?.length > 0 && provider.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${
    benefitsTypes?.length > 0 &&
    benefitsTypes.map((item) => `<p>${item}</p>`).join("")
  }</li>
  <li class="flex-grow ">${patientType}</li>
  </ul>
  </div>
  </div>
  <table class="table-striped">
        <thead>
              <tr>
                 ${tableHeaders} 
              </tr>
        </thead>
        <tbody>
        ${tableData}
        </tbody>
        </table>
  </div>
  </body>
  </html>`;
    await page.setContent(content);
    const pdfBuffer = await page.pdf({
      path: "output.pdf",
      printBackground: true
    });
    await browser.close();
    return {
      pdfBuffer,
      patientDetails
    };
  } catch (error) {
    console.log(error);
  }
};
