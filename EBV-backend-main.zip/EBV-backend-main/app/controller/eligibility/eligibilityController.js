const { v4: uuidv4 } = require("uuid");
const db = require("../../../db/model");
const models = require("../../../db/model");
const Sequelize = require("sequelize");
const path = require("path");
const fs = require("fs");
const imagePath = path.join(__dirname, "logo.png");
const image = fs.readFileSync(imagePath, "base64");
const imageDataUri = `data:image/png;base64,${image}`;
const async = require("async");
const puppeteer = require("puppeteer");
const { Op } = require("sequelize");
const { logaudit } = require("../patients/patientsController");

async function removeEmptyValues(obj, response) {
  if (obj && response && response.length > 0) {
    Object.keys(obj).forEach((key) => {
      for (let i = 0; i <= response.length; i++) {
        let results = response[i];
        if (
          results &&
          results[key] &&
          (results[key] !== null || results[key] !== undefined)
        ) {
          obj[key] = true;
          break;
        } else {
          continue;
        }
      }
    });
    return response, obj;
  }
}
module.exports.addEligibility = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  try {
    const {
      patientId,
      coInsurance,
      payer,
      subscriber,
      patient,
      planBenefits,
      deductible,
      limitationAndMaximum,
      notCovered,
      miscellaneous,
      notesAndRemarks,
      activeCoverage
    } = req.body;

    const newEligibility = {};

    newEligibility.patientId = patientId;
    newEligibility.uniqueId = uuidv4();
    newEligibility.verificationType = "Manual";
    newEligibility.lastverified = `${new Date()}`;
    if (coInsurance !== undefined && coInsurance.length > 0) {
      for (let insurance of coInsurance) {
        if (insurance.code) {
          await models.EADAProcedure.create({
            patientId: newEligibility.patientId,
            id: uuidv4(),
            auth: insurance.auth,
            network: insurance.network,
            coverageLevel: insurance.coverageLevel,
            percent: insurance.percent,
            message: insurance.message,
            insuranceType: insurance.insuranceType,
            code: insurance.code,
            planCoverageDescription: insurance.planCoverageDescription,
            statusflag: "A"
          });
        } else {
          await models.ECoInsurance.create({
            patientId: newEligibility.patientId,
            serviceType: insurance.serviceType,
            network: insurance.network,
            coverageLevel: insurance.coverageLevel,
            percent: insurance.percent,
            insuranceType: insurance.insuranceType,
            planCoverageDescription: insurance.planCoverageDescription,
            amount: insurance.amount,
            id: uuidv4(),
            statusflag: "A"
          });
        }
      }
    }
    if (payer !== undefined) {
      await models.EPayer.create({
        payerId: payer.id,
        patientId: newEligibility.patientId,
        name: payer.name,
        id: uuidv4(),
        statusflag: "A"
      });
    }

    if (deductible !== undefined && deductible.length > 0) {
      for (let value of deductible) {
        await models.EDeductible.create({
          id: uuidv4(),
          patientId: newEligibility.patientId,
          serviceType: value.serviceType,
          network: value.network,
          coverageLevel: value.coverageLevel,
          planPeriod: value.planPeriod,
          amount: value.amount,
          insuranceType: value.insuranceType,
          planCoverageDescription: value.planCoverageDescription || null,
          statusflag: "A"
        });
      }
    }

    if (limitationAndMaximum !== undefined && limitationAndMaximum.length > 0) {
      for (let limitation of limitationAndMaximum) {
        await models.ELimitationMaximum.create({
          id: uuidv4(),
          patientId: newEligibility.patientId,
          serviceType: limitation.serviceType,
          network: limitation.network,
          coverageLevel: limitation.coverageLevel,
          planPeriod: limitation.planPeriod,
          amount: limitation.amount,
          insuranceType: limitation.insuranceType,
          limitation: limitation.limitation || null,
          serviceDates: limitation.serviceDates || null,
          planCoverageDescription: limitation.planCoverageDescription,
          benefitAge: limitation.benefitAge,
          statusflag: "A"
        });
      }
    }
    if (notCovered !== undefined && notCovered.length > 0) {
      for (let value of notCovered) {
        await models.ENotCovered.create({
          patientId: newEligibility.patientId,
          id: uuidv4(),
          serviceType: value.serviceType,
          network: value.network,
          coverageLevel: value.coverageLevel,
          planPeriod: value.planPeriod || null,
          amount: value.amount || null,
          code: value.code || null,
          statusflag: "A"
        });
      }
    }
    if (activeCoverage !== undefined && activeCoverage.length > 0) {
      for (let value of activeCoverage) {
        await models.EActiveCoverages.create({
          patientId: newEligibility.patientId,
          id: uuidv4(),
          serviceType: value.serviceType,
          planCoverageDescription: value.planCoverageDescription,
          message: value.message,
          insuranceType: value.insuranceType,
          network: value.network || null,
          coverageLevel: value.coverageLevel || null,
          waitingPeriod: value.waitingPeriod || null,
          code: value.code || null,
          statusflag: "A"
        });
      }
    }
    if (subscriber !== undefined && subscriber.length > 0) {
      for (let value of subscriber) {
        await models.ESubscriber.create({
          id: uuidv4(),
          patientId: newEligibility.patientId,
          firstName: value.firstName,
          lastName: value.lastName,
          dateOfBirth: value.dateOfBirth,
          gender: value.gender,
          address: value.address,
          plan: value.plan,
          statusflag: "A"
        });
      }
    } else {
      if (subscriber !== undefined) {
        await models.ESubscriber.create({
          id: uuidv4(),
          patientId: newEligibility.patientId,
          firstName: subscriber.firstName,
          lastName: subscriber.lastName,
          dateOfBirth: subscriber.dateOfBirth,
          gender: subscriber.gender,
          address: subscriber.address,
          plan: subscriber.plan,
          statusflag: "A"
        });
      }
    }
    if (patient !== undefined) {
      // for (let value of notesAndRemarks) {
      await models.EPatient.create({
        id: uuidv4(),
        patientId: newEligibility.patientId,
        firstName: patient.firstName,
        lastName: patient.lastName,
        dateOfBirth: patient.dateOfBirth,
        gender: patient.gender,
        address: patient.address,
        plan: patient.plan,
        statusflag: "A"
      });
      // }
    }
    if (planBenefits !== undefined) {
      // for (let value of notesAndRemarks) {
      await models.EPlanBenfit.create({
        data: planBenefits,
        patientId: newEligibility.patientId,
        id: uuidv4(),
        statusflag: "A"
      });
    }
    if (miscellaneous !== undefined && miscellaneous.length > 0) {
      for (let value of miscellaneous) {
        await models.EMiscellaneous.create({
          question: value.question,
          patientId: newEligibility.patientId,
          answer: value.answer,
          id: uuidv4(),
          statusflag: "A"
        });
      }
    }
    if (notesAndRemarks !== undefined && notesAndRemarks.length > 0) {
      for (let value of notesAndRemarks) {
        await models.ENotesAndRemark.create({
          data: value.data,
          patientId: newEligibility.patientId,
          id: uuidv4(),
          statusflag: "A"
        });
      }
    }
    const response = await Models.PatientEligibility.create(newEligibility);
    const newEligibilityData = response?.dataValues;
    res.status(200).send({
      data: newEligibilityData,
      message: "patient eligibility details added"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "patient eligibility creation failed" });
  }
};

// Create Co-Insurance
module.exports.createcoinsurance = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const params = {
    patientId: req.body.patientId || null,
    serviceType: req.body.serviceType || null,
    network: req.body.network || null,
    coverageLevel: req.body.coverageLevel || null,
    percent: req.body.percent || null,
    insuranceType: req.body.insuranceType || null,
    code: req.body.code || null,
    planPeriod: req.body.planPeriod || null,
    planCoverageDescription: req.body.planCoverageDescription || null,
    amount: req.body.amount || null,
    message: req.body.message || null,
    type: req.body.type || null,
    statusflag: "A"
  };

  try {
    const response = await models.ECoInsurance.create(params);
    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;

    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Co-Insurance Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Co-Insurance Created but patient update failed"
          });
        });
    } else {

      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Co-Insurance Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Co-Insurance Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res.status(400).send({
      data: error,
      message: "Co-Insurance Creation Failed"
    });
  }
};

// Get Co-Insurance
module.exports.getAllcoins = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    let obj = {
      serviceType: false,
      network: false,
      coverageLevel: false,
      percent: false,
      insuranceType: false,
      code: false,
      planPeriod: false,
      planCoverageDescription: false,
      amount: false,
      type: false
    };
    let response = await models.ECoInsurance.findAll({
      where: { patientId: patientId },
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Co-Insurance details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Co-Insurance details fetch failed" });
  }
};

// Get Co-Insurance
module.exports.getAllcoinsfilter = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, network, code, eligibilityId } = req.query;
  let multiCode = code?.split(",");

  const params = {
    patientId: patientId
  };

  if (eligibilityId) {
    params["eligibilityId"] = eligibilityId;
  }

  if (code) {
    if (Array.isArray(multiCode)) {
      params["code"] = {
        [Sequelize.Op.in]: multiCode
      };
    } else {
      params["code"] = code;
    }
  }

  if (network) {
    if (Array.isArray(network)) {
      params["network"] = {
        [Sequelize.Op.in]: network
      };
    } else {
      params["network"] = network;
    }
  }

  try {
    let obj = {
      serviceType: false,
      network: false,
      coverageLevel: false,
      percent: false,
      insuranceType: false,
      code: false,
      planPeriod: false,
      planCoverageDescription: false,
      amount: false,
      type: false
    };
    let response = await models.ECoInsurance.findAll({
      where: params,
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Co-Insurance details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Co-Insurance details fetch failed" });
  }
};

module.exports.getcoinsbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    const response = await models.ECoInsurance.findOne({ where: { id: id } });
    res.status(200).send({
      data: response,
      message: "Co-Insurance data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Co-Insurance details fetch failed" });
  }
};

module.exports.updatecoinsbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateCoins = req.body;
  try {
    const response = await models.ECoInsurance.update(updateCoins, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Co-Insurance data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Co-Insurance details update failed" });
  }
};

module.exports.deletecoinbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.ECoInsurance.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Co-Insurance data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Co-Insurance details delete failed" });
  }
};

// Create Active Coverage
module.exports.createactivecoverage = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const params = {
    patientId: req.body.patientId || null,
    serviceType: req.body.serviceType || null,
    planCoverageDescription: req.body.planCoverageDescription || null,
    code: req.body.code || null,
    effectiveDateFrom: req.body.effectiveDateFrom || null,
    planPeriod: req.body.planPeriod || null,
    percent: req.body.percent || null,
    waitingPeriodApplies: req.body.waitingPeriodApplies || null,
    auth: req.body.auth || null,
    message: req.body.message || null,
    insuranceType: req.body.insuranceType || null,
    // No records
    waitingPeriod: req.body.waitingPeriod || null,
    coverageLevel: req.body.coverageLevel || null,
    network: req.body.network || null,
    //
    statusflag: "A"
  };

  try {
    const response = await models.EActiveCoverages.create(params);
    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;
    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Active Coverage Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Active Coverage Created but patient update failed"
          });
        });
    } else {
      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Active Coverage Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Active Coverage Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res.status(400).send({
      data: error,
      message: "Active Coverage Creation Failed"
    });
  }
};

// Get Active Coverage
module.exports.getAllActiveCoverage = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  const params = {
    patientId: patientId,
    serviceType: {
      [Sequelize.Op.ne]: null
    }
  };
  try {
    //
    let obj = {
      planCoverageDescription: false,
      effectiveDateFrom: false,
      planPeriod: false,
      percent: false,
      waitingPeriodApplies: false,
      auth: false,
      message: false,
      insuranceType: false,
      code: false,
      waitingPeriod: false,
      coverageLevel: false
    };
    let responseData = [];
    Promise.all([
      models.EActiveCoverages.findAll({ where: params }),
      models.EADAProcedure.findAll({ where: params }),
      models.ECoInsurance.findAll({ where: params }),
      models.EDeductible.findAll({ where: params }),
      models.ELimitationMaximum.findAll({ where: params }),
      models.ENotCovered.findAll({ where: params })
    ])
      .then(
        async ([
          table1Data,
          table2Data,
          table3Data,
          table4Data,
          table5Data,
          table6Data
        ]) => {
          const response = [
            ...table1Data,
            ...table2Data,
            ...table3Data,
            ...table4Data,
            ...table5Data,
            ...table6Data
          ];
          await removeEmptyValues(obj, response);
          obj = Object.assign(obj, {
            serviceType: true,
            code: true,
            network: true
          });
          let arrangedData = groupBy(response, "serviceType");
          if (arrangedData && Object.keys(arrangedData).length > 0) {
            for (let i in arrangedData) {
              let dataCheck = {
                type: i,
                activeCoverage: arrangedData[i]
              };
              responseData.push(dataCheck);
            }
          }
          res.status(200).send({
            obj,
            data: responseData,
            message: "Active Coverage details fetched"
          });
        }
      )
      .catch((err) => {
        console.error("Error occurred:", err);
      });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Active Coverage details fetch failed" });
  }
};

module.exports.getActiveCoveragebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    let responseData = [];
    const response = await models.EActiveCoverages.findOne({
      where: { id: id }
    });
    if (
      response &&
      response.dataValues &&
      Object.keys(response.dataValues).length > 0
    ) {
      let dataCheck = {
        type: response.dataValues.serviceType,
        activeCoverage: response.dataValues
      };
      responseData.push(dataCheck);
    }
    res.status(200).send({
      data: responseData,
      message: "Active Coverage data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Active Coverage details fetch failed" });
  }
};

module.exports.updateActiveCoveragebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateCoins = req.body;
  try {
    const response = await models.EActiveCoverages.update(updateCoins, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Active Coverage data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Active Coverage details update failed" });
  }
};

module.exports.deleteActiveCoveragebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.EActiveCoverages.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Active Coverage data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Active Coverage details delete failed" });
  }
};

module.exports.getAllActiveCoveragefilter = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, network, code, eligibilityId } = req.query;
  const params = {
    patientId: patientId,
    serviceType: {
      [Sequelize.Op.ne]: null
    }
  };
  if (eligibilityId) {
    params["eligibilityId"] = eligibilityId;
  }
  let multiCode = code?.split(",");
  if (code) {
    if (Array.isArray(multiCode)) {
      params["code"] = {
        [Sequelize.Op.in]: multiCode
      };
    } else {
      params["code"] = code;
    }
  }
  if (network) {
    if (Array.isArray(network)) {
      params["network"] = {
        [Sequelize.Op.in]: network
      };
    } else {
      params["network"] = network;
    }
  }

  try {
    let obj = {
      planCoverageDescription: false,
      effectiveDateFrom: false,
      planPeriod: false,
      percent: false,
      waitingPeriodApplies: false,
      auth: false,
      message: false,
      insuranceType: false,
      code: false,
      waitingPeriod: false,
      coverageLevel: false
    };
    let responseData = [];
    Promise.all([
      models.EActiveCoverages.findAll({ where: params }),
      models.EADAProcedure.findAll({ where: params }),
      models.ECoInsurance.findAll({ where: params }),
      models.EDeductible.findAll({ where: params }),
      models.ELimitationMaximum.findAll({ where: params }),
      models.ENotCovered.findAll({ where: params })
    ])
      .then(
        async ([
          table1Data,
          table2Data,
          table3Data,
          table4Data,
          table5Data,
          table6Data
        ]) => {
          const response = [
            ...table1Data,
            ...table2Data,
            ...table3Data,
            ...table4Data,
            ...table5Data,
            ...table6Data
          ];
          await removeEmptyValues(obj, response);
          obj = Object.assign(obj, {
            serviceType: true,
            code: true,
            network: true
          });
          let arrangedData = groupBy(response, "serviceType");
          if (arrangedData && Object.keys(arrangedData).length > 0) {
            for (let i in arrangedData) {
              let dataCheck = {
                type: i,
                activeCoverage: arrangedData[i]
              };
              responseData.push(dataCheck);
            }
          }
          res.status(200).send({
            obj,
            data: responseData,
            message: "Active Coverage details fetched"
          });
        }
      )
      .catch((err) => {
        console.error("Error occurred:", err);
      });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Active Coverage details fetch failed" });
  }
};

function groupBy(objectArray, property) {
  return objectArray.reduce(function (acc, obj) {
    var key = obj[property];
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(obj);
    return acc;
  }, {});
}

module.exports.createdeductible = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const params = {
    patientId: req.body.patientId || null,
    serviceType: req.body.serviceType || null,
    code: req.body.code || null,
    network: req.body.network || null,
    coverageLevel: req.body.coverageLevel || null,
    planPeriod: req.body.planPeriod || null,
    amount: req.body.amount || null,
    planCoverageDescription: req.body.planCoverageDescription || null,
    insuranceType: req.body.insuranceType || null,
    message: req.body.message || null,
    statusflag: "A"
  };

  try {
    const response = await models.EDeductible.create(params);

    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;
    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Deductibles Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Deductibles Created but patient update failed"
          });
        });
    } else {
      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Deductibles Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Deductibles Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res.status(400).send({
      data: error,
      message: "Deductible Creation Failed"
    });
  }
};

// Get Deductible
module.exports.getAlldeductible = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    let obj = {
      serviceType: false,
      code: false,
      network: false,
      coverageLevel: false,
      planPeriod: false,
      amount: false,
      planCoverageDescription: false,
      insuranceType: false,
      message: false
    };
    let response = await models.EDeductible.findAll({
      where: { patientId: patientId },
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Deductible details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Deductible details fetch failed" });
  }
};

module.exports.getdeductiblebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    const response = await models.EDeductible.findOne({ where: { id: id } });
    res.status(200).send({
      data: response,
      message: "Deductible data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Deductible details fetch failed" });
  }
};

module.exports.updatedeductiblebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateCoins = req.body;
  try {
    const response = await models.EDeductible.update(updateCoins, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Deductible data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Deductible details update failed" });
  }
};

module.exports.deletedeductiblebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.EDeductible.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Deductible data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Deductible details delete failed" });
  }
};

//

module.exports.getAllDeductiblefilter = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, network, code, eligibilityId } = req.query;
  let multiCode = code?.split(",");

  let obj = {
    serviceType: false,
    code: false,
    network: false,
    coverageLevel: false,
    planPeriod: false,
    amount: false,
    message: false,
    planCoverageDescription: false
  };

  const params = {
    patientId: patientId
  };

  if (eligibilityId) {
    params["eligibilityId"] = eligibilityId;
  }

  if (code) {
    if (Array.isArray(multiCode)) {
      params["code"] = {
        [Sequelize.Op.in]: multiCode
      };
    } else {
      params["code"] = code;
    }
  }

  if (network) {
    if (Array.isArray(network)) {
      params["network"] = {
        [Sequelize.Op.in]: network
      };
    } else {
      params["network"] = network;
    }
  }

  try {
    let response = await models.EDeductible.findAll({
      where: params,
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Deductible details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Deductible details fetch failed" });
  }
};

// Create Ada Procedure
module.exports.createadaprocedure = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const params = {
    patientId: req.body.patientId || null,
    serviceType: req.body.serviceType || null,
    code: req.body.code || null,
    network: req.body.network || null,
    coverageLevel: req.body.coverageLevel || null,
    percent: req.body.percent || null,
    auth: req.body.auth || null,
    limitation: req.body.limitation || null,
    ageLimit: req.body.ageLimit || null,
    message: req.body.message || null,
    insuranceType: req.body.insuranceType || null,
    statusflag: "A",
    frequency: req.body.frequency || null,
    description: req.body.description || null
  };

  try {
    const response = await models.EADAProcedure.create(params);

    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;
    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Procedure Code Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Procedure Code Created but patient update failed"
          });
        });
    } else {
      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Procedure Code Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Procedure Code Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res.status(400).send({
      error: error,
      message: "Procedure Code Creation failed"
    });
  }
};

// Get Ada Procedure
module.exports.getAlladaprocedure = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    let obj = {
      coverageLevel: false,
      percent: false,
      auth: false,
      limitation: false,
      ageLimit: false,
      message: false,
      insuranceType: false,
      description: false
    };

    let response = await models.EADAProcedure.findAll({
      where: { patientId: patientId },
      raw: true
    });
    await removeEmptyValues(obj, response);
    obj = Object.assign(obj, { serviceType: true, code: true, network: true });
    res.status(200).send({
      obj,
      data: response,
      message: "Ada Procedure details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Ada Procedure details fetch failed" });
  }
};

module.exports.getadaprocedurebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    const response = await models.EADAProcedure.findOne({ where: { id: id } });
    res.status(200).send({
      data: response,
      message: "Ada Procedure data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Ada Procedure details fetch failed" });
  }
};

module.exports.updateadaprocedurebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateAdaProcedure = req.body;
  try {
    const response = await models.EADAProcedure.update(updateAdaProcedure, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Ada Procedure data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Ada Procedure details update failed" });
  }
};

module.exports.deleteadaprocedurebyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.EADAProcedure.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Ada Procedure data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Ada Procedure details delete failed" });
  }
};

module.exports.getAlladaprocedurefilter = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  try {
    const { patientId, network, code, eligibilityId } = req.query;
    let multiCode = code?.split(",");
    const params = {
      patientId: patientId,
      code: {
        [Sequelize.Op.ne]: null
      }
    };
    if (eligibilityId) {
      params["eligibilityId"] = eligibilityId;
    }

    // let procedurecodes = await models.ODProcedureCode.findAll({
    //   raw: true
    // });
    let obj = {
      coverageLevel: false,
      percent: false,
      auth: false,
      limitation: false,
      ageLimit: false,
      message: false,
      insuranceType: false,
      description: false
    };
    if (code) {
      if (Array.isArray(multiCode)) {
        params["code"] = {
          [Sequelize.Op.in]: multiCode
        };
      } else {
        params["code"] = code;
      }
    }
    if (network) {
      if (Array.isArray(network)) {
        params["network"] = {
          [Sequelize.Op.in]: network
        };
      } else {
        params["network"] = network;
      }
    }

    Promise.all([
      models.EActiveCoverages.findAll({ where: params, raw: true }),
      models.EADAProcedure.findAll({ where: params, raw: true }),
      models.ECoInsurance.findAll({ where: params, raw: true }),
      models.EDeductible.findAll({ where: params, raw: true }),
      models.ELimitationMaximum.findAll({ where: params, raw: true }),
      models.ENotCovered.findAll({ where: params, raw: true })
    ])
      .then(
        async ([
          table1Data,
          table2Data,
          table3Data,
          table4Data,
          table5Data,
          table6Data
        ]) => {
          const response = [
            ...table1Data,
            ...table2Data,
            ...table3Data,
            ...table4Data,
            ...table5Data,
            ...table6Data
          ];
          // if (response?.length > 0 && procedurecodes?.length > 0) {
          //   for (let i of response) {
          //     for (let j of procedurecodes) {
          //       console.log("cjeck")
          //       if (i?.code?.toString() === j?.ProcCode?.toString()) {
          //         i.description = j.description;
          //         break;
          //       }
          //     }
          //   }
          // }
          // for (let i of response) {
          //   if (res?.code) {
          //     models.ODProcedureCode.findOne({
          //       where: { ProcCode: res.code }
          //     }).then((value) => {
          //       res.description = value?.dataValues?.description || null;
          //     })
          //   }
          // }
          async.eachSeries(
            response,
            async (res) => {
              if (res?.code) {
                let value = await models.ODProcedureCode.findOne({
                  where: { ProcCode: res.code }
                });
                res.description = value.dataValues.description || null;
              }
            },
            async () => {
              await removeEmptyValues(obj, response);
              res.status(200).send({
                obj,
                data: response,
                message: "Ada Procedure data Fetched"
              });
            }
          );
        }
      )
      .catch((err) => {
        console.error("Error occurred:", err);
      });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Ada Procedure details fetch failed" });
  }
};

module.exports.createlimitation = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const params = {
    patientId: req.body.patientId || null,
    serviceType: req.body.serviceType || null,
    code: req.body.code || null,
    network: req.body.network || null,
    coverageLevel: req.body.coverageLevel || null,
    planPeriod: req.body.planPeriod || null,
    amount: req.body.amount || null,
    auth: req.body.auth || null,
    message: req.body.message || null,
    limitation: req.body.limitation || null,
    planCoverageDescription: req.body.planCoverageDescription,
    benefitAge: req.body.benefitAge,
    statusflag: "A"
  };
  if (req.body.serviceDates) {
    params["serviceDates"] = JSON.parse(
      `["Last Visit: ${req.body.serviceDates}"]`
    );
  } else params["serviceDates"] = null;

  try {
    const response = await models.ELimitationMaximum.create(params);

    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;
    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Limitations Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Limitations Created but patient update failed"
          });
        });
    } else {
      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );

      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Limitations Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Limitations Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res.status(400).send({
      data: error,
      message: "Limitation Creation failed"
    });
  }
};

// Get Limitation
module.exports.getAlllimitation = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    let obj = {
      serviceType: false,
      code: false,
      network: false,
      coverageLevel: false,
      planPeriod: false,
      amount: false,
      insuranceType: false,
      auth: false,
      limitation: false,
      serviceDates: false,
      planCoverageDescription: false,
      benefitAge: false,
      message: false
    };
    let response = await models.ELimitationMaximum.findAll({
      where: { patientId: patientId },
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Limitation details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Limitation details fetch failed" });
  }
};

module.exports.getlimitationbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    const response = await models.ELimitationMaximum.findOne({
      where: { id: id }
    });
    res.status(200).send({
      data: response,
      message: "Limitation data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Limitation details fetch failed" });
  }
};

module.exports.updatelimitationbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateLimitation = req.body;
  try {
    if (updateLimitation?.serviceDates) {
      updateLimitation.serviceDates = JSON.parse(
        `["Last Visit: ${updateLimitation.serviceDates}"]`
      );
    } else updateLimitation.serviceDates = null;
    const response = await models.ELimitationMaximum.update(updateLimitation, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Limitation data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Limitation details update failed" });
  }
};

module.exports.deletelimitationbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.ELimitationMaximum.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Limitation data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Limitation details delete failed" });
  }
};

module.exports.getAllLimitationfilter = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, network, code, eligibilityId } = req.query;
  let multiCode = code?.split(",");
  const params = {
    patientId: patientId
  };
  if (eligibilityId) {
    params["eligibilityId"] = eligibilityId;
  }
  let obj = {
    serviceType: false,
    code: false,
    network: false,
    coverageLevel: false,
    planPeriod: false,
    amount: false,
    insuranceType: false,
    auth: false,
    limitation: false,
    serviceDates: false,
    planCoverageDescription: false,
    benefitAge: false,
    message: false
  };
  if (code) {
    if (Array.isArray(multiCode)) {
      params["code"] = {
        [Sequelize.Op.in]: multiCode
      };
    } else {
      params["code"] = code;
    }
  }
  if (network) {
    if (Array.isArray(network)) {
      params["network"] = {
        [Sequelize.Op.in]: network
      };
    } else {
      params["network"] = network;
    }
  }

  try {
    let response = await models.ELimitationMaximum.findAll({
      where: params,
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Limitation fetched"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({ error: error, message: "Limitation fetch failed" });
  }
};

// Create Not Covered
module.exports.createnotcovered = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const params = {
    patientId: req.body.patientId || null,
    serviceType: req.body.serviceType || null,
    network: req.body.network || null,
    coverageLevel: req.body.coverageLevel || null,
    message: req.body.message || null,
    planPeriod: req.body.planPeriod || null,
    amount: req.body.amount || null,
    code: req.body.code || null,
    statusflag: "A"
  };

  try {
    const response = await models.ENotCovered.create(params);

    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;
    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Not Covered Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Not Covered Created but patient update failed"
          });
        });
    } else {
      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );

      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Not Covered Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Not Covered Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res.status(400).send({
      data: error,
      message: "Not Covered Creation failed"
    });
  }
};

// Get Not Covered
module.exports.getAllNotCovered = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    let obj = {
      serviceType: false,
      network: false,
      coverageLevel: false,
      message: false,
      planPeriod: false,
      amount: false,
      code: false
    };
    let response = await models.ENotCovered.findAll({
      where: { patientId: patientId },
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Not Covered details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Not Covered details fetch failed" });
  }
};

module.exports.getNotCoveredbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    const response = await models.ENotCovered.findOne({ where: { id: id } });
    res.status(200).send({
      data: response,
      message: "Not Covered data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Not Covered details fetch failed" });
  }
};

module.exports.updateNotCoveredbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateCoins = req.body;
  try {
    const response = await models.ENotCovered.update(updateCoins, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Not Covered data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Not Covered details update failed" });
  }
};

module.exports.deleteNotCoveredbyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.ENotCovered.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Not Covered data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Not Covered details delete failed" });
  }
};

module.exports.getAllNotCoveredfilter = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, network, code, eligibilityId } = req.query;
  let multiCode = code?.split(",");
  const params = {
    patientId: patientId
  };
  let obj = {
    serviceType: false,
    network: false,
    coverageLevel: false,
    message: false,
    insuranceType: false,
    planPeriod: false,
    amount: false,
    code: false
  };
  if (eligibilityId) {
    params["eligibilityId"] = eligibilityId;
  }
  if (code) {
    if (Array.isArray(multiCode)) {
      params["code"] = {
        [Sequelize.Op.in]: multiCode
      };
    } else {
      params["code"] = code;
    }
  }
  if (network) {
    if (Array.isArray(network)) {
      params["network"] = {
        [Sequelize.Op.in]: network
      };
    } else {
      params["network"] = network;
    }
  }
  try {
    let response = await models.ENotCovered.findAll({
      where: params,
      raw: true
    });
    await removeEmptyValues(obj, response);
    res.status(200).send({
      obj,
      data: response,
      message: "Not Covered Details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Not Covered Details fetch failed" });
  }
};

// Create Benefit History
module.exports.createbenefithistory = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  try {
    const params = {
      patientId: req.body.patientId || null,
      serviceType: req.body.serviceType || null,
      doses: req.body.doses || null,
      provider: req.body.provider || null,
      procedure: req.body.procedure || null,
      benefitsConsumed: req.body.benefitsConsumed || null,
      message: req.body.message || null,
      effectiveEndDate: req.body.effectiveEndDate || null,
      statusflag: "A"
    };
    const response = await models.EBenefitHistory.create(params);

    const updatePatientData = {};
    updatePatientData.isVerified = true;
    updatePatientData.isVerifiedManually = true;
    if (req.body.isScheduled) {
      const patientDetails = await models.SchedulePatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })
      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Benefit History Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Benefit History Created but patient update failed"
          });
        });
    } else {
      const patientDetails = await models.ManualPatients.findOne({
        where: {
          patientId: req.body.patientId
        },
        attributes: ["patientId", "addedFrom", "scheduleAppointment", "adminId", "createdAt"],
        raw: true
      })

      await logaudit(
        "Manually Verified",
        patientDetails.patientId,
        patientDetails.addedFrom,
        patientDetails.addedFrom,
        patientDetails.scheduleAppointment,
        new Date(),
        new Date(),
        new Date(),
        patientDetails.adminId || "18",
        patientDetails.createdAt
      );

      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: req.body.patientId
        }
      })
        .then(() => {
          res.status(200).send({
            data: response,
            message: "Benefit History Created and Patient updated Succesfully "
          });
        })
        .catch((error) => {
          res.status(400).send({
            error: error,
            message: "Benefit History Created but patient update failed"
          });
        });
    }
  } catch (error) {
    res
      .status(400)
      .send({ error: error, message: "Benefit History Creation failed" });
  }
};

// Get Benefit History
module.exports.getAllBenefitHistory = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    let response = await models.EBenefitHistory.findAll({
      where: { patientId: patientId },
      raw: true
    });
    await removeEmptyValues(response);
    res.status(200).send({
      data: response,
      message: "Benefit History details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Benefit History details fetch failed" });
  }
};

module.exports.getBenefitHistorybyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    const response = await models.EBenefitHistory.findOne({
      where: { id: id }
    });
    res.status(200).send({
      data: response,
      message: "Benefit History data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Benefit History details fetch failed" });
  }
};

module.exports.updateBenefitHistorybyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateCoins = req.body;
  try {
    const response = await models.EBenefitHistory.update(updateCoins, {
      where: { id: id }
    });
    res.status(200).send({
      message: "Benefit History data Updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Benefit History details update failed" });
  }
};

module.exports.deleteBenefitHistorybyId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    await models.EBenefitHistory.destroy({ where: { id: id } });
    res.status(200).send({
      message: "Benefit History data Deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Benefit History details delete failed" });
  }
};

// Get Subscriber by Patient Id
module.exports.getSubscriberByPatientId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id: patientId } = req.params;
  try {
    const response = await models.ESubscriber.findOne({
      where: { patientId: patientId }
    });
    res.status(200).send({
      data: response,
      message: "Subscriber data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Subscriber details fetch failed" });
  }
};

module.exports.updateSubscriberByPatientId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  const updateSubs = req.body;
  try {
    const response = await models.ESubscriber.update(updateSubs, {
      where: { id: id }
    });
    res.status(200).send({
      data: response,
      message: "Subscriber data updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Subscriber details update failed" });
  }
};

// Get Patient by Patient Id
module.exports.getPatientByPatientId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id: patientId } = req.params;
  try {
    const response = await models.EPatient.findOne({
      where: { patientId: patientId }
    });
    res.status(200).send({
      data: response,
      message: "Patient data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Patient details fetch failed" });
  }
};

module.exports.updatePatientByPatientId = async (req, res) => {
  try {
    const { id } = req.params;
    const updatePatients = req.body;
    let response = await models.EPatient.update(updatePatients, {
      where: { id: id }
    });
    res.status(200).send({
      data: response,
      message: "Patient details updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Patient details fetch failed" });
  }
};

// Get Payer by Patient Id
module.exports.getPayerByPatientId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id: patientId } = req.params;
  try {
    const response = await models.EPayer.findOne({
      where: { patientId: patientId }
    });
    res.status(200).send({
      data: response,
      message: "Payer data fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Payer details fetch failed" });
  }
};

// Create Notes and Remarks
module.exports.createnotesandremarks = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, data, isScheduled, eligibilityId } = req.body;
  let notesAndRemarksData = {};
  notesAndRemarksData.patientId = patientId;
  notesAndRemarksData.eligibilityId = eligibilityId;
  notesAndRemarksData.data = data;
  notesAndRemarksData.statusflag = "A";

  try {
    if (isScheduled) {
      await db.sequelize.transaction(async (t) => {
        const foundPatient = await models.SchedulePatients.findOne({
          where: {
            patientId: patientId
          },
          transaction: t
        });

        const notesAndRemarksCreated = await models.ENotesAndRemark.create(
          notesAndRemarksData,
          {
            transaction: t
          }
        );
        await foundPatient.addENotesAndRemark(notesAndRemarksCreated, {
          transaction: t
        });

        res.status(200).send({
          data: notesAndRemarksCreated,
          message: "Notes and Remarks Created Succesfully"
        });
      });
    } else {
      await db.sequelize.transaction(async (t) => {
        const foundPatient = await models.ManualPatients.findOne({
          where: {
            patientId: patientId
          },
          transaction: t
        });

        const notesAndRemarksCreated = await models.ENotesAndRemark.create(
          notesAndRemarksData,
          {
            transaction: t
          }
        );
        await foundPatient.addENotesAndRemark(notesAndRemarksCreated, {
          transaction: t
        });

        res.status(200).send({
          data: notesAndRemarksCreated,
          message: "Notes and Remarks Created Succesfully"
        });
      });
    }
  } catch (error) {
    res.status(400).send({
      data: error,
      message: "Notes and Remarks Creation Failed "
    });
  }
};

// Get Notes and Remarks
module.exports.getNotesAndRemarksByPatientId = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  const { eligibilityId } = req.query;
  try {
    const response = await models.ENotesAndRemark.findAll({
      where: { patientId: patientId, eligibilityId: eligibilityId },
      order: [["createdAt", "DESC"]]
    });
    res.status(200).send({
      data: response,
      message: "Notes and Remarks data fetched"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({
      error: error,
      message: "Notes and Remarks details fetch failed"
    });
  }
};

module.exports.updateNotesAndRemarks = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { data } = req.body;
  const { id } = req.params;
  let updatedNotesAndRemarks = {};
  updatedNotesAndRemarks.data = data;
  try {
    let response = await models.ENotesAndRemark.update(updatedNotesAndRemarks, {
      where: { id: id },
      returning: true
    });
    res.status(200).send({
      data: response,
      message: "Notes and Remarks details updated"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({
      error: error,
      message: "Notes and Remarks details update failed"
    });
  }
};

module.exports.deleteNotesAndRemarks = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    let response = await models.ENotesAndRemark.destroy({
      where: { id: id },
      returning: true
    });
    res.status(200).send({
      data: response,
      message: "Notes and Remarks details deleted"
    });
  } catch (error) {
    console.log({ error });
    res.status(400).send({
      error: error,
      message: "Notes and Remarks details deletion failed"
    });
  }
};

// Get Miscellaneous
module.exports.getAllMiscellaneous = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  const { eligibilityId } = req.query;
  try {
    let response = await models.EMiscellaneous.findAll({
      where: { patientId: patientId, eligibilityId: eligibilityId },
      order: [["createdAt", "DESC"]],
      raw: true
    });
    res.status(200).send({
      data: response,
      message: "Miscellaneous details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Miscellaneous details fetch failed" });
  }
};

module.exports.getMiscellaneousById = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    let response = await models.EMiscellaneous.findOne({
      where: { id: id },
      raw: true
    });
    res.status(200).send({
      data: response,
      message: "Miscellaneous details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Miscellaneous details fetch failed" });
  }
};

module.exports.updateMiscellaneous = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { question, answer } = req.body;
  const { id } = req.params;
  let updatedMiscellaneousData = {};
  updatedMiscellaneousData.question = question;
  updatedMiscellaneousData.answer = answer;
  try {
    let response = await models.EMiscellaneous.update(
      updatedMiscellaneousData,
      {
        where: { id: id },
        returning: true
      }
    );
    res.status(200).send({
      data: response,
      message: "Miscellaneous details updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Miscellaneous details updation failed" });
  }
};

module.exports.deleteMiscellaneous = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { id } = req.params;
  try {
    let response = await models.EMiscellaneous.destroy({
      where: { id: id },
      returning: true
    });
    res.status(200).send({
      data: response,
      message: "Miscellaneous details deleted"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "Miscellaneous details deletion failed" });
  }
};

// Create Miscellaneous
module.exports.createmiscellaneous = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, question, answer, isScheduled, eligibilityId } = req.body;

  let miscellaneousData = {};
  miscellaneousData.patientId = patientId;
  miscellaneousData.eligibilityId = eligibilityId;
  miscellaneousData.question = question;
  miscellaneousData.answer = answer;
  miscellaneousData.statusflag = "A";

  const updatePatientData = {};
  updatePatientData.isVerified = true;

  try {
    if (isScheduled) {
      await db.sequelize.transaction(async (t) => {
        const foundPatient = await models.SchedulePatients.findOne({
          where: {
            patientId: patientId
          },
          transaction: t
        });

        const miscellaneousCreated = await models.EMiscellaneous.create(
          miscellaneousData,
          {
            transaction: t
          }
        );
        await foundPatient.addEMiscellaneous(miscellaneousCreated, {
          transaction: t
        });

        await models.SchedulePatients.update(updatePatientData, {
          where: {
            patientId: patientId
          },
          transaction: t
        });

        res.status(200).send({
          data: miscellaneousCreated,
          message: "Miscellaneous Created Succesfully"
        });
      });
    } else {
      await db.sequelize.transaction(async (t) => {
        const foundPatient = await models.ManualPatients.findOne({
          where: {
            patientId: patientId
          },
          transaction: t
        });

        const miscellaneousCreated = await models.EMiscellaneous.create(
          miscellaneousData,
          {
            transaction: t
          }
        );
        await foundPatient.addEMiscellaneous(miscellaneousCreated, {
          transaction: t
        });

        await models.ManualPatients.update(updatePatientData, {
          where: {
            patientId: patientId
          },
          transaction: t
        });

        res.status(200).send({
          data: miscellaneousCreated,
          message: "Miscellaneous Created Succesfully"
        });
      });
    }
  } catch (error) {
    console.log(error);
    res.status(400).send({
      error: error,
      message: "Miscellaneous Creation failed"
    });
  }
};

module.exports.getEligibilityByPatient = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  try {
    const response = await models.PatientEligibility.findByPk(patientId);
    res.status(200).send({
      data: response,
      message: "patient eligibility details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "patient eligibility fetch failed" });
  }
};

module.exports.getPastBenefitHistory = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId, currentEligibilityId } = req.query;
  try {
    const response = await models.PatientEligibility.findAll({
      where: {
        patientId,
        eligibilityId: {
          [Sequelize.Op.not]: currentEligibilityId
        }
      },
      attributes: [
        "patientId",
        "eligibilityId",
        "createdAt",
        "updatedAt",
        "id",
        "uniqueId"
      ],
      raw: true,
      order: [["createdAt", "DESC"]],
      limit: 5
    });
    res.status(200).send({
      data: response,
      message: "patient eligibility details fetched"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "patient eligibility fetch failed" });
  }
};

module.exports.editEligibility = async (req, res) => {
  // #swagger.tags = ['Eligibility']
  const { patientId } = req.params;
  const {
    coInsurance,
    payer,
    subscriber,
    patient,
    planBenefits,
    deductible,
    limitationAndMaximum,
    notCovered,
    maximum,
    limitations,
    miscellaneous,
    notesAndRemarks
  } = req.body;

  const updateEligibility = {};

  updateEligibility.verificationType = "Manual Updated";
  updateEligibility.lastverified = `${new Date()}`;
  if (coInsurance !== undefined) updateEligibility.coInsurance = coInsurance;
  if (payer !== undefined) updateEligibility.payer = payer;
  if (deductible !== undefined) updateEligibility.deductible = deductible;
  if (limitationAndMaximum !== undefined)
    updateEligibility.limitationAndMaximum = limitationAndMaximum;
  if (notCovered !== undefined) updateEligibility.notCovered = notCovered;
  if (maximum !== undefined) updateEligibility.maximum = maximum;
  if (limitations !== undefined) updateEligibility.limitations = limitations;
  if (miscellaneous !== undefined)
    updateEligibility.miscellaneous = miscellaneous;
  if (notesAndRemarks !== undefined)
    updateEligibility.notesAndRemarks = notesAndRemarks;
  if (subscriber !== undefined) updateEligibility.subscriber = subscriber;
  if (patient !== undefined) updateEligibility.patient = patient;
  if (planBenefits !== undefined) updateEligibility.planBenefits = planBenefits;

  try {
    const response = await models.PatientEligibility.update(updateEligibility, {
      where: {
        patientId: patientId
      }
    });
    res.status(200).send({
      data: response,
      message: "patient eligibility details updated"
    });
  } catch (error) {
    console.log({ error });
    res
      .status(400)
      .send({ error: error, message: "patient eligibility update failed" });
  }
};

module.exports.getreport = async (req, res) => {
  try {
    const { patientId, basicReport, eligibilityId } = req.body;
    let activecoveragecolumns = {};
    let coinsurancecolumns = {};
    let deductiblecolumns = {};
    let adaprocedurecolumns = {};
    let notcoveredcolumns = {};
    let limitationcolumns = {};
    const params = {
      patientId: patientId
    };
    const code = {}
    if (req.query.code) {
      const codes = req.query.code.split(',')
      code['code'] = {
        [Op.in]: codes
      }
    }
    if (eligibilityId) {
      params["eligibilityId"] = eligibilityId;
    }
    try {
      async.parallel(
        {
          activecoverage: function (callback) {
            let obj = {
              planCoverageDescription: false,
              effectiveDateFrom: false,
              planPeriod: false,
              percent: false,
              waitingPeriodApplies: false,
              auth: false,
              message: false,
              insuranceType: false,
              code: false,
              waitingPeriod: false,
              coverageLevel: false
            };
            let responseData = [];
            Promise.all([
              models.EActiveCoverages.findAll({
                where: { ...params, ...code }
              }),
              models.EADAProcedure.findAll({
                where: { ...params, ...code }
              }),
              models.ECoInsurance.findAll({
                where: { ...params, ...code }
              }),
              models.EDeductible.findAll({
                where: { ...params, ...code }
              }),
              models.ELimitationMaximum.findAll({
                where: { ...params, ...code }
              }),
              models.ENotCovered.findAll({
                where: { ...params, ...code }
              })
            ])
              .then(
                async ([
                  table1Data,
                  table2Data,
                  table3Data,
                  table4Data,
                  table5Data,
                  table6Data
                ]) => {
                  const response = [
                    ...table1Data,
                    ...table2Data,
                    ...table3Data,
                    ...table4Data,
                    ...table5Data,
                    ...table6Data
                  ];
                  await removeEmptyValues(obj, response);
                  obj = Object.assign(obj, {
                    serviceType: true,
                    code: true,
                    network: true
                  });
                  let arrangedData = groupBy(response, "serviceType");
                  if (arrangedData && Object.keys(arrangedData).length > 0) {
                    for (let i in arrangedData) {
                      let dataCheck = {
                        type: i,
                        activeCoverage: arrangedData[i]
                      };
                      responseData.push(dataCheck);
                    }
                  }
                  activecoveragecolumns = obj;
                  callback(null, responseData);
                }
              )
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          coinsurance: function (callback) {
            let obj = {
              serviceType: false,
              network: false,
              coverageLevel: false,
              percent: false,
              insuranceType: false,
              code: false,
              planPeriod: false,
              planCoverageDescription: false,
              amount: false,
              type: false
            };
            models.ECoInsurance.findAll({
              where: { patientId: patientId, ...code },
              raw: true
            })
              .then((res) => {
                removeEmptyValues(obj, res);
                coinsurancecolumns = obj;
                callback(null, res);
              })
              .catch((err) => {
                console.error("Error fetching ECoInsurance:", err);
                callback(err, null);
              });
          },
          notesandremarks: function (callback) {
            models.ENotesAndRemark.findAll({
              where: { patientId: patientId }
            })
              .then((res3) => {
                callback(null, res3);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          benefithistory: function (callback) {
            models.EBenefitHistory.findAll({
              where: { patientId: patientId },
              raw: true
            })
              .then((res4) => {
                callback(null, res4);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          deductibles: function (callback) {
            let obj = {
              serviceType: false,
              code: false,
              network: false,
              coverageLevel: false,
              planPeriod: false,
              amount: false,
              planCoverageDescription: false,
              message: false
            };
            models.EDeductible.findAll({
              where: { patientId: patientId, ...code },
              raw: true
            })
              .then((response1) => {
                removeEmptyValues(obj, response1);
                deductiblecolumns = obj;
                callback(null, response1);
              })
              .catch((err) => {
                console.error("Error fetching EDeductible:", err);
                callback(err); // Pass error to the callback
              });
          },
          miscellaneous: function (callback) {
            models.EMiscellaneous.findAll({ where: { patientId: patientId } })
              .then((response2) => {
                callback(null, response2);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          susbscriber: function (callback) {
            models.ESubscriber.findOne({ where: { patientId: patientId } })
              .then((subres) => {
                callback(null, subres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          limitationmaximum: function (callback) {
            let obj = {
              serviceType: false,
              code: false,
              network: false,
              coverageLevel: false,
              planPeriod: false,
              amount: false,
              insuranceType: false,
              auth: false,
              limitation: false,
              serviceDates: false,
              planCoverageDescription: false,
              benefitAge: false,
              message: false
            };
            models.ELimitationMaximum.findAll({
              where: { patientId: patientId, ...code }
            })
              .then((limmax) => {
                removeEmptyValues(obj, limmax);
                limitationcolumns = obj;
                callback(null, limmax);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          epatients: function (callback) {
            models.EPatient.findOne({
              where: { patientId: patientId }
            })
              .then((patres) => {
                callback(null, patres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          payer: function (callback) {
            models.EPayer.findAll({ where: { patientId: patientId } })
              .then((payer) => {
                callback(null, payer);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          patients: function (callback) {
            let patientModel = req.body.isScheduled
              ? models.SchedulePatients
              : models.ManualPatients;
            patientModel
              .findOne({ where: { patientId: patientId } })
              .then((patres) => {
                callback(null, patres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          attachments: function (callback) {
            let patientModel = models.PatientAttachments;
            patientModel
              .findAll({ where: { patientId: patientId } })
              .then((attachmentsres) => {
                callback(null, attachmentsres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          adaprocedures: function (callback) {
            const params = {
              patientId: patientId
            };
            if (req.query.code) {
              const codes = req.query.code.split(',')
              params['code'] = {
                [Op.in]: codes
              };
            }
            let obj = {
              coverageLevel: false,
              percent: false,
              auth: false,
              limitation: false,
              ageLimit: false,
              message: false,
              insuranceType: false
            };

            Promise.all([
              models.EActiveCoverages.findAll({ where: params }),
              models.EADAProcedure.findAll({ where: params }),
              models.ECoInsurance.findAll({ where: params }),
              models.EDeductible.findAll({ where: params }),
              models.ELimitationMaximum.findAll({ where: params }),
              models.ENotCovered.findAll({ where: params })
            ])
              .then(
                async ([
                  table1Data,
                  table2Data,
                  table3Data,
                  table4Data,
                  table5Data,
                  table6Data
                ]) => {
                  const response = [
                    ...table1Data,
                    ...table2Data,
                    ...table3Data,
                    ...table4Data,
                    ...table5Data,
                    ...table6Data
                  ];
                  await removeEmptyValues(obj, response);
                  obj = Object.assign(obj, {
                    serviceType: true,
                    code: true,
                    network: true
                  });
                  adaprocedurecolumns = obj;
                  callback(null, response);
                }
              )
              .catch((err) => {
                callback(err, null);
                console.error("Error occurred:", err);
              });
          },
          notcovered: function (callback) {
            let obj = {
              serviceType: false,
              network: false,
              coverageLevel: false,
              message: false,
              planPeriod: false,
              amount: false,
              code: false
            };
            models.ENotCovered.findAll({
              where: { patientId: patientId, ...code },
              raw: true
            })
              .then(async (res) => {
                await removeEmptyValues(obj, res);
                notcoveredcolumns = obj;
                callback(null, res);
              })
              .catch((err) => {
                callback(err, null);
                console.error("Error occurred:", err);
              });
          }
        },
        (error, result) => {
          result["activecoveragecolumns"] = activecoveragecolumns;
          result["coinsurancecolumns"] = coinsurancecolumns;
          result["deductiblecolumns"] = deductiblecolumns;
          result["adaprocedurecolumns"] = adaprocedurecolumns;
          result["notcoveredcolumns"] = notcoveredcolumns;
          result["limitationcolumns"] = limitationcolumns;
          if (error) {
            console.error("Error in async.parallel:", error);
            res.status(500).send({
              error: error,
              message: "Failed to fetch PDF data"
            });
          } else {
            const generateReport = async () => {
              const browser = await puppeteer.launch({
                executablePath: "/usr/bin/google-chrome",
                args: ["--no-sandbox", "--disable-setuid-sandbox"]
              });
              const page = await browser.newPage();
              const downArrow = `<svg xmlns="
                                  http://www.w3.org/2000/svg"
                                  viewBox="0 0 320 512"><!--! Font Awesome Free 6.5.1 by @fontawesome -
                                  https://fontawesome.com
                                  License -
                                  https://fontawesome.com/license/free
                                  (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc. --><path d="M137.4 374.6c12.5 12.5 32.8 12.5 45.3 0l128-128c9.2-9.2 11.9-22.9 6.9-34.9s-16.6-19.8-29.6-19.8L32 192c-12.9 0-24.6 7.8-29.6 19.8s-2.2 25.7 6.9 34.9l128 128z"/></svg>`;

              const deductibleRemainingFiltered = result.deductibles.filter(
                (deductible) => deductible.planPeriod?.toLowerCase() === "remaining"
              );

              const deductibleNonRemainingFiltered = result.deductibles.filter(
                (deductible) =>
                  deductible.planPeriod?.toLowerCase() !== "remaining" && deductible.planPeriod !== null
              );
              const deductibleRemainingNumerator =
                deductibleRemainingFiltered.reduce(
                  (acc, deductible) => acc.add(deductible?.amount),
                  new Set()
                ).size === 1
                  ? `$${deductibleRemainingFiltered[0].amount}`
                  : "Varies";
              const deductibleRemainingDenominator =
                deductibleNonRemainingFiltered.reduce(
                  (acc, deductible) => acc.add(deductible?.amount),
                  new Set()
                ).size === 1
                  ? `$${deductibleNonRemainingFiltered[0].amount}`
                  : "Varies";
              const activeCoverage = result.activecoverage
                .map(
                  (item) => `
              <tr class='table-rows'>
              <td colspan="7">
                  ${item?.type != "null"
                      ? `${downArrow} ${item.type}`
                      : `${downArrow}-`
                    }
              </td>
              </tr>
              ${item.activeCoverage
                      .map(
                        (item) => `
                <tr >
              ${result.activecoveragecolumns.serviceType
                            ? `<td>${item?.message != null ? `${downArrow}` : ""}
                      ${item?.serviceType ? item.serviceType : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.network
                            ? `<td>${item?.network ? item.network : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.code
                            ? `<td>${item?.code ? item.code : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.effectiveDateFrom
                            ? `<td>${item?.effectiveDateFrom ? item.effectiveDateFrom : "-"
                            }</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.planPeriod
                            ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.percent
                            ? `<td>${item?.percent ? item.percent : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.waitingPeriodApplies
                            ? `<td>${item?.waitingPeriodApplies
                              ? item.waitingPeriodApplies
                              : "-"
                            }</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.auth
                            ? `<td>${item?.auth ? item.auth : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.insuranceType
                            ? `<td>${item?.insuranceType ? item.insuranceType : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.coverageLevel
                            ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.planCoverageDescription
                            ? `<td>${item?.planCoverageDescription
                              ? item.planCoverageDescription
                              : "-"
                            }</td>`
                            : ""
                          }
                            
              ${item?.message != null && result.activecoveragecolumns.message
                            ? `
                            <td style="padding=5px;"><p style="text-wrap: pretty; font-size:8px; padding:0; margin:0; ">${item.message}</p></td>`
                            : ``
                          }
                            </tr>
                `
                      )
                      .join("")}
              `
                )
                .join("");

              const deductibles = result.deductibles
                .map(
                  (item) => {
                    return (
                      `<tr>
                    ${result.deductiblecolumns.serviceType
                        ? `<td>${item?.message != null ? `${downArrow}` : ""}
                    ${item?.serviceType ? item.serviceType : "-"}</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.code
                        ? `<td>${item?.code ? item.code : "-"}</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.network
                        ? `<td>${item?.network ? item.network : "-"}</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.coverageLevel
                        ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"
                        }</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.planPeriod
                        ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.amount
                        ? `<td>${item?.amount ? item.amount : "-"}</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.insuranceType
                        ? `<td>${item?.insuranceType ? item.insuranceType : "-"
                        }</td>`
                        : ""
                      } 
                    ${result.deductiblecolumns.planCoverageDescription
                        ? `<td>${item?.planCoverageDescription
                          ? item.planCoverageDescription
                          : "-"
                        }</td>`
                        : ""
                      } 
                      ${item?.message != null && result.deductiblecolumns.message
                        ? `
                            <td style="padding=5px;"><p style="text-wrap: pretty; font-size:8px;  padding:0; margin:0;">${item.message}</p></td>`
                        : ``
                      }
              </tr>
              `)
                  })
                .join("");

              const coInsurance = result.coinsurance
                .map(
                  (item) =>
                    `<tr>
                    ${result.coinsurancecolumns.serviceType
                      ? `<td>${item?.message != null ? `${downArrow}` : ""}
                    ${item?.serviceType ? item.serviceType : "-"}</td>`
                      : ""
                    } 
                    ${result.coinsurancecolumns.code
                      ? `<td>${item?.code ? item.code : "-"}</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.planPeriod
                      ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.network
                      ? `<td>${item?.network ? item.network : "-"}</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.coverageLevel
                      ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"
                      }</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.percent
                      ? `<td>${item?.percent ? item.percent : "-"}</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.amount
                      ? `<td>${item?.amount ? item.amount : "-"}</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.planCoverageDescription
                      ? `<td>${item?.planCoverageDescription
                        ? item.planCoverageDescription
                        : "-"
                      }</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.insuranceType
                      ? `<td>${item?.insuranceType ? item.insuranceType : "-"
                      }</td>`
                      : ""
                    }  
                    ${result.coinsurancecolumns.type
                      ? `<td>${item?.type ? item.type : "-"}</td>`
                      : ""
                    }
                       ${item?.message != null && result.coinsurancecolumns.message
                      ? `
                            <td style="padding=5px;"><p style="text-wrap: pretty; font-size:8px;  padding:0; margin:0;">${item.message}</p></td>`
                      : ``
                    }
              </tr>
              `
                )
                .join("");
              const limitationRemainingFiltered = result.limitationmaximum.filter(
                (limitation) => limitation.planPeriod?.toLowerCase() === "remaining"
              );
              const limitationNonRemainingFiltered = result.limitationmaximum.filter(
                (limitation) => limitation.planPeriod?.toLowerCase() !== "remaining"
              );

              const limitaitonRemainingNumerator =
                limitationRemainingFiltered.reduce(
                  (acc, limitation) => acc.add(limitation?.amount),
                  new Set()
                ).size === 1
                  ? `$${limitationRemainingFiltered[0].amount}`
                  : "Varies";

              const limitationRemainingDenominator =
                limitationNonRemainingFiltered.reduce(
                  (acc, limitation) => acc.add(limitation?.amount),
                  new Set()
                ).size === 1
                  ? `$${limitationNonRemainingFiltered[0].amount}`
                  : "Varies";
              const limitation = result.limitationmaximum
                .map(
                  (item) => {
                    return (
                      `<tr>
                    ${result.limitationcolumns.serviceType
                        ? `
                    <td>${item?.message != null ? `${downArrow}` : ""}
                    ${item?.serviceType ? item.serviceType : "-"}</td>
                    `
                        : ""
                      }
                    ${result.limitationcolumns.code
                        ? `<td>${item?.code ? item.code : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.network
                        ? `<td>${item?.network ? item.network : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.coverageLevel
                        ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"
                        }</td>`
                        : ""
                      }
                    ${result.limitationcolumns.planPeriod
                        ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.amount
                        ? `<td>${item?.amount ? item.amount : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.auth
                        ? `<td>${item?.auth ? item.auth : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.limitation
                        ? `<td>${item?.limitation ? item.limitation : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.benefitAge
                        ? `<td>${item?.benefitAge ? item.benefitAge : "-"}</td>`
                        : ""
                      }
                    ${result.limitationcolumns.serviceDates
                        ? `<td>${item?.serviceDates ? item.serviceDates : "-"
                        }</td>`
                        : ""
                      }
                    ${result.limitationcolumns.insuranceType
                        ? `<td>${item?.insuranceType ? item.insuranceType : "-"
                        }</td>`
                        : ""
                      }
                       ${item?.message != null && result.limitationcolumns.message
                        ? `
                            <td style="padding=5px;"><p style="text-wrap: pretty; font-size:8px;  padding:0; margin:0;">${item.message}</p></td>`
                        : ``
                      }
              </tr>
              `
                    )
                  })
                .join("");
              const adaProcedure = result.adaprocedures
                .map(
                  (item) =>
                    `<tr>
                    ${adaprocedurecolumns.code
                      ? `
                    <td> ${item.message ? downArrow : ""}
              ${item?.code ? item.code : "-"}
              </td>`
                      : ""
                    }
              ${adaprocedurecolumns.serviceType
                      ? `
              <td>${item?.serviceType ? item.serviceType : "-"}</td>
              `
                      : ""
                    }
              ${adaprocedurecolumns.network
                      ? `
              <td>${item?.network ? item.network : "-"}</td>
              `
                      : ""
                    }
              ${adaprocedurecolumns.coverageLevel
                      ? `
              <td>${item?.coverageLevel ? item.coverageLevel : "-"}</td>
              `
                      : ""
                    }
              ${adaprocedurecolumns.coverageLevel
                      ? `
              <td>${item?.percent ? item.percent : "-"}</td>
              `: ''
                    }
              ${adaprocedurecolumns.auth
                      ? `
              <td>${item?.auth ? item.auth : "-"}</td>
              `
                      : ""
                    }
              ${adaprocedurecolumns.limitation
                      ? `
              <td>${item?.limitation ? item.limitation : "-"}</td>
              `
                      : ""
                    }
              ${adaprocedurecolumns.ageLimit
                      ? `
              <td>${item?.ageLimit ? item.ageLimit : "-"}</td>
              `
                      : ""
                    }
                       ${item?.message != null && adaprocedurecolumns.message
                      ? `
                            <td style="padding=5px;"><p style="text-wrap: pretty; font-size:8px;  padding:0; margin:0;">${item.message}</p></td>`
                      : ``
                    }
              </tr>
              `
                )
                .join("");

              const benefithistory = result.benefithistory
                .map(
                  (item) =>
                    `<tr>
              <td>${item?.serviceType ? item.serviceType : "-"}</td>
              <td>${item?.doses ? item.doses : "-"}</td>
              <td>${item?.provider ? item.provider : "-"}</td>
              <td>${item?.procedure ? item.procedure : "-"}</td>
              <td>${item?.benefitsConsumed ? item.benefitsConsumed : "-"}</td>
              </tr>`
                )
                .join("");

              const Attachments = result.attachments
                .map(
                  (item) => `
              <tr>
                <td>${item.fileName}</td>
                <td>${item.description}</td>
                <td>${new Date(item.updatedAt).toLocaleDateString("en-GB")}</td>
              </tr>
              `
                )
                .join("");

              const notCovered = result.notcovered.map(
                (item) => `
              <tr>
                  ${notcoveredcolumns.serviceType
                    ? `
              <td>${item?.serviceType ? item.serviceType : "-"}</td>
              `
                    : ""
                  }
                  ${notcoveredcolumns.network
                    ? `
              <td>${item?.network ? item.network : "-"}</td>
              `
                    : ""
                  }
                  ${notcoveredcolumns.coverageLevel
                    ? `
              <td>${item?.coverageLevel ? item.coverageLevel : "-"}</td>
              `
                    : ""
                  }
                  ${notcoveredcolumns.planPeriod
                    ? `
              <td>${item?.planPeriod ? item.planPeriod : "-"}</td>
              `
                    : ""
                  }
                  ${notcoveredcolumns.amount
                    ? `
              <td>${item?.amount ? item.amount : "-"}</td>
              `
                    : ""
                  }
                  ${notcoveredcolumns.code
                    ? `
              <td>${item?.code ? item.code : "-"}</td>
              `
                    : ""
                  }
                     ${item?.message != null && result.notcoveredcolumns.message
                    ? `
                            <td style="padding=5px;"><p style="text-wrap: pretty; font-size:8px;  padding:0; margin:0;">${item.message}</p></td>`
                    : ``
                  }
              </tr>
              `
              );
              // HTML content
              const content = `
                  <html>
                  <head>
                  </head>
                  <style>
                          svg {
                            width:7px;
                            height:10px;
                          }
                          .primary-color {    
                              color: #13af8f;
                          }
                          table {
                              width: 100%;
                              border-collapse: collapse;
                          }
                          thead {
                              display: table-header-group;
                          }
                          tr{
                            border-top: 1px solid #dee2e6;
                          }
                         td{
                            font-size:10px !important;
                          }
                          th, td {
                              padding: 5px 5px;
                              text-align: left;
                          }
                          th{
                            font-size:10px;
                          }
                          body {
                            font-family: 'Roboto', sans-serif;
                            font-style: normal !important;
                            margin: 0;
                            padding:20px;
                            box-sizing:border-box;
                        }
                    
                        p,
                        h1,
                        h2,
                        h3,
                        h4,
                        h5,
                        h6 {
                            margin: 0;
                            padding: 0;
                        }
                    
                        address {
                            font-style: normal;
                            line-height: 20px;
                            font-size: 12px;
                            font-weight: 500;
                        }
                        .header {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            width: 70%;
                            /* Adjusted width */
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            -webkit-align-items: center;
                            /* For older WebKit */
                            align-items: center;
                            padding-top: 40px;
                            margin-bottom: 20px;
                        }
                    
                        .div-img {
                            height: 100px;
                            width: 250px;
                        }
                    
                        .div-img img {
                            object-fit: contain;
                            width: 100%;
                            height: 100%;
                        }
                    
                        .sub-details {
                            margin-top: 15px;
                        }
                    
                        .sub-details .details {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            -webkit-flex-wrap: wrap;
                            /* For older WebKit */
                            flex-wrap: wrap;
                        }
                    
                        .details li {
                            min-height: 50px;
                            width: 50%;
                        }
                    
                        .details p {
                            font-size: 10px;
                            font-weight: 600;
                            margin-top: 5px;
                        }
                    
                        ul {
                            margin: 0;
                            padding: 0;
                            list-style: none;
                        }
                    
                        .plans {
                            display: -webkit-flex;
                            /* For older WebKit */
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            display: flex;
                            -webkit-flex-wrap: wrap;
                            /* For older WebKit */
                            flex-wrap: wrap;
                            row-gap: 20px;
                            width: 42%
                        }
                    
                        .plan-container {
                            width: 100%;
                            -webkit-flex-wrap: no-wrap;
                            /* For older WebKit */
                            flex-wrap: no-wrap;
                            display: -webkit-flex;
                            /* For older WebKit */
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            display: flex;
                            border: 1px solid #d0d0d0;
                            border-radius: 10px;
                            margin-top: 15px;
                        }
                    
                        h5 {
                            font-size: 10px;
                            font-weight: 400;
                        }
                    
                        .info {
                            width: 58%;
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            border: 2px solid #92dacb;
                            border-radius: 10px;
                            padding: 10px;
                            background-color: #f4fffd;
                        }
                    
                        .coverage-info .coverage-details {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                        }
                    
                        .cov-details {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                        }
                    
                        .plans li {
                            border: 1px solid #d0d0d0;
                            width: calc(50% - 12px);
                            margin-left: 10px;
                            border-radius: 10px;
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-align-items: center;
                            /* For older WebKit */
                            -webkit-justify-content: center;
                            /* For older WebKit */
                            -webkit-flex-direction: column;
                            align-items: center;
                            flex-direction: column;
                            justify-content: center;
                        }
                    
                        .plan-container li {
                            border: none !important;
                            width: calc(25% - 12px);
                        }
                    
                        .mb-15 {
                            margin-bottom: 15px;
                        }
                    
                        .plans li>p {
                            margin-bottom: 15px;
                            font-size: 10px;
                            font-weight: 600;
                        }
                    
                        .plans li div {
                            text-align: center;
                        }
                    
                        .plans li .plan-amount {
                            font-weight: 600;
                            font-size: 12px;
                        }
                    
                        .plans li .plan-amount sub {
                            font-size: 12px;
                            font-weight: 400;
                        }
                    
                        .plans button {
                            width: 80px;
                            border-radius: 16px;
                            color: green;
                            border: 1px solid green;
                            font-weight: 600;
                            padding: 7px;
                        }
                    
                        label {
                            color: #13af8f;
                            font-size: 12px;
                        }
                    
                        .days {
                            font-size: 12px;
                            margin-top: 10px;
                        }
                    
                        .plan-container {
                            padding: 10px;
                            width: 97%;
                        }
                    
                        .cover-date {
                            font-size: 14px;
                            font-weight: 500;
                            margin-top: 10px;
                        }
                        .container-table{
                          margin-top: 15px;
                          border: 1px solid #d0d0d0;
                          border-radius: 10px;
                        }
                    .container-table p{
                      font-size:16px;
                      font-weigth:600;
                      margin:15px 10px;
                      padding:10px 0;
                    }
                    .mb-15{
                      margin-bottom:15px;
                    }
                    .mt-15{
                      margin-top:15px;
                    }
                    .w50{
                      width:50%;
                    }
              .patient-payer-info,.con-borders{
                  margin-top: 25px;
                  border: 1px solid #d0d0d0;
                  border-radius: 10px;
                  padding: 10px;
              }
              .ques-border {
                padding: 15px;
                border: 1px solid #dee2e6;
                margin: 15px;
                font-size: 14px;
                font-weight: 500;
                min-width: 40%;
            }
        
            .ques-border .ques {
                border-bottom: 1px solid black;
                padding-bottom: 7px;
            }
        
            .ques-border .ans {
                padding-top: 7px;
            }
        
            textarea {
                padding: 10px;
                margin: 10px 20px;
                height: 250px;
                width: 300px;
            }
            .d-flex{
              display:flex;
              justify-content:space-between;
              flex-warp:warp;
            }
            .thinBorder {
              border-bottom: 5px solid #F6F6F6;
              padding-bottom: 15px;
          }
          
                      </style>
                  <body>
                 
                  <div>
          <div class="header">
              <address>
                  ToothHQ Dental<br>
                  (214)731-0124<br>
                  <a href="" target="_blank">https://mytoothhq.com/</a><br>
                  Specialists Carrollton<br>
                  1500 W Hebron Pkwy,<br>
                  SUITE 108 Carrollton TX 75010
              </address>
              <div class="div-img">
                  <img src="${imageDataUri}" />
              </div>
          </div>
          <div class="cov-details">
              <div class="info">
                  <div class="subs-info">
                      <div>
                          <h5>Subscriber Information</h5>
                          <div class="sub-details">
                              <ul class="details">
                                  <li>
                                      <label>First Name</label>
                                      <p>${result?.susbscriber?.firstName}</p>
                                  </li>
                                  <li>
                                      <label>Last Name</label>
                                      <p>${result?.susbscriber?.lastName}</p>
                                  </li>
                                  <li>
                                      <label>DOB</label>
                                      <p>${new Date(
                result?.susbscriber?.dateOfBirth
              ).toLocaleDateString("en-GB")}</p>
                                  </li>
                                  <li>
                                      <label>Gender</label>
                                      <p>${result?.susbscriber?.gender}</p>
                                  </li>
                                  <li>
                                      <label>Relationship</label>
                                      <p>Self</p>
                                  </li>
                                  <li>
                                      <label>Member ID</label>
                                      <p>${result?.susbscriber?.plan?.subscriberId
                }</p>
                                  </li>
                              </ul>
                          </div>
                      </div>
  
                  </div>
                  <div class="coverage-info">
                      <div class="coverage-details">
                          <h5>Coverage</h5>
                          <h5 class="primary-color">Primary Insurance</h5>
                      </div>
                      <div class="sub-details">
                          <ul class="details">
                              <li>
                                  <label>Effective Date</label>
                                  <p>${result?.epatients.plan ? result.epatients.plan.effectiveDateFrom
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>End Date</label>
                                  <p>${result?.epatients.plan ? result.epatients.plan.effectiveDateTo
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>Status</label>
                                  <p>${new Date(result.epatients.plan.effectiveDateFrom) >= new Date()
                  ? "Active"
                  : "Inactive"
                }</p>
                              </li>
                              <li>
                                  <label>Coverage Type</label>
                                  <p>Dental : Family ,Active Coverage Group Policy</p>
                              </li>
                              <li>
                                  <label>Insurance Name</label>
                                  <p>${result?.patients?.insuranceName
                  ? result?.patients?.insuranceName
                  : "-"
                }</p>
                              </li>
                          </ul>
                      </div>
  
                  </div>
              </div>
              <ul class="plans">
                  <li>
                      <p>Dental Coverage</p>
                      <button type="button">Active</button>
                  </li>
                  <li>
                      <p>Remaining Benefits</p>
                      <div class="plan-amount">${limitaitonRemainingNumerator}<sub>/${limitationRemainingDenominator}</sub></div>
                  </li>
                  <li>
                      <p>Last Verified</p>
                      <div>
                          <p style="font-size:12px;">${result?.patients?.lastVerified
                  ? new Date(
                    result.patients?.lastVerified
                  ).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                  })
                  : "-"
                }</p>
                          <p class="days"></p>
                      </div>
                  </li>
                  <li>
                      <p>Deductible Remaining</p>
                      <div class="plan-amount">${deductibleRemainingNumerator}<sub>/${deductibleRemainingDenominator}</sub></div>
                  </li>
              </ul>
          </div>
          <ul class="plans plan-container">
              <li>
                  <p>Dental Coverage</p>
                  <button type="button">Active</button>
                  <div class="cover-date" style="font-size:12px;">24/02/2023-23/04/2024</div>
              </li>
              <li>
                  <p>Remaining Benefits</p>
                  <div class="plan-amount">${limitaitonRemainingNumerator}<sub>/${limitationRemainingDenominator}</sub></div>
              </li>
              <li>
                  <p>Deductible Remaining</p>
                  <div class="plan-amount">${deductibleRemainingNumerator}<sub>/${deductibleRemainingDenominator}</sub></div>
              </li>
              <li>
                  <p>Last Verified</p>
                  <div>
                      <p style="font-size:12px;">01/23/2023</p>
                      <p class="days">26 Days ago</p>
                  </div>
              </li>
          </ul>
      </div>
              <div class='container-table'>
              <p>Active Coverage</p>
              ${result.activecoverage.length > 0
                  ? `<div class="tableData">
                <table>
                  <thead>
                        <tr>
                        ${activecoveragecolumns.serviceType
                    ? "<th>Service Type</th>"
                    : ""
                  }
                        ${activecoveragecolumns.network
                    ? "<th>Network</th>"
                    : ""
                  }
                        ${activecoveragecolumns.code ? "<th>ADA Code</th>" : ""}
                        ${activecoveragecolumns.effectiveDateFrom
                    ? "<th>Effective Date</th>"
                    : ""
                  }
                        ${activecoveragecolumns.planPeriod
                    ? "<th>Plan period</th>"
                    : ""
                  }
                        ${activecoveragecolumns.percent
                    ? "<th>Percentage</th>"
                    : ""
                  }
                        ${activecoveragecolumns.waitingPeriodApplies
                    ? "<th>Waiting Period Applies</th>"
                    : ""
                  }
                        ${activecoveragecolumns.auth ? "<th>Auth</th>" : ""}
                        ${activecoveragecolumns.insuranceType
                    ? "<th>Insurance Type</th>"
                    : ""
                  }
                        ${activecoveragecolumns.coverageLevel
                    ? "<th>Coverage Level</th>"
                    : ""
                  }
                        ${activecoveragecolumns.planCoverageDescription
                    ? "<th>Plan Coverage</th>"
                    : ""
                  }
                        ${activecoveragecolumns.message
                    ? "<th style='width:20%;'>Disclaimers</th>"
                    : ""
                  }
                        </tr>
                  </thead>
                  <tbody>
                        ${activeCoverage}
                  </tbody>
                </table>
              </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
          </div>
  
                ${!basicReport
                  ? `
  
            <div class='container-table'>
            <p>Co Insurance/Co Payer</p>
            ${result.coinsurance.length > 0
                    ? `<div class="tableData">
              <table>
                <thead>
                      <tr>
                      ${coinsurancecolumns.serviceType
                      ? "<th>Service Type</th>"
                      : ""
                    }
                      ${coinsurancecolumns.code ? "<th>ADA Code</th>" : ""}
                      ${coinsurancecolumns.planPeriod
                      ? "<th>Plan Period</th>"
                      : ""
                    }
                      ${coinsurancecolumns.network ? "<th>Network</th>" : ""}
                      ${coinsurancecolumns.coverageLevel
                      ? "<th>Coverage Level</th>"
                      : ""
                    }
                      ${coinsurancecolumns.percent ? "<th>Percentage</th>" : ""}
                      ${coinsurancecolumns.amount ? "<th>Amount</th>" : ""}
                      ${coinsurancecolumns.planCoverageDescription
                      ? "<th>Plan Coverage</th>"
                      : ""
                    }
                      ${coinsurancecolumns.insuranceType
                      ? "<th>Insurance Type</th>"
                      : ""
                    }
                      ${coinsurancecolumns.type ? "<th>Type</th>" : ""}
                      ${coinsurancecolumns.message
                      ? "<th style='width:20%;'>Disclaimers</th>"
                      : ""
                    }
                      </tr>
                </thead>
                <tbody>
                      ${coInsurance}
                </tbody>
              </table>
            </div>`
                    : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                  }
            </div>
            `
                  : ""
                }
      <div class='container-table'>
          <p>Deductibleee</p>
          ${result.deductibles.length > 0
                  ? `<div class="tableData">
            <table>
              <thead>
                    <tr>
                    ${deductiblecolumns.serviceType
                    ? "<th>Service Type</th>"
                    : ""
                  }
                    ${deductiblecolumns.code ? "<th>ADA Code</th>" : ""}
                    ${deductiblecolumns.network ? "<th>Network</th>" : ""}
                    ${deductiblecolumns.coverageLevel
                    ? "<th>Coverage Level</th>"
                    : ""
                  }
                    ${deductiblecolumns.planPeriod ? "<th>Plan Period</th>" : ""
                  }
                    ${deductiblecolumns.amount ? "<th>Amount</th>" : ""}
                    ${deductiblecolumns.insuranceType
                    ? "<th>Insurance Type</th>"
                    : ""
                  }
                    ${deductiblecolumns.planCoverageDescription
                    ? "<th>Plan Coverage</th>"
                    : ""
                  }
                    ${deductiblecolumns.message
                    ? "<th style='width:20%;'>Disclaimers</th>"
                    : ""
                  }
                    </tr>
              </thead>
              <tbody>
                    ${deductibles}
              </tbody>
            </table>
          </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
    
      </div>
      <div class='container-table'>
          <p>Limitation and Maximum</p>
          ${result.limitationmaximum.length > 0
                  ? `
            <div class="tableData">
            <table>
              <thead>
                    <tr>
                    ${limitationcolumns.serviceType
                    ? "<th>Service Type</th>"
                    : ""
                  }
                    ${limitationcolumns.code ? "<th>ADA Code</th>" : ""}
                    ${limitationcolumns.network ? "<th>Network</th>" : ""}
                    ${limitationcolumns.coverageLevel
                    ? "<th>Coverage Level</th>"
                    : ""
                  }
                    ${limitationcolumns.planPeriod ? "<th>Plan Period</th>" : ""
                  }
                    ${limitationcolumns.amount ? "<th>Amount</th>" : ""}
                    ${limitationcolumns.auth ? "<th>Auth</th>" : ""}
                    ${limitationcolumns.limitation ? "<th>Frequency</th>" : ""}
                    ${limitationcolumns.benefitAge
                    ? "<th>Age Restriction</th>"
                    : ""
                  }
                    ${limitationcolumns.serviceDates
                    ? "<th>Last Visit</th>"
                    : ""
                  }
                    ${limitationcolumns.insuranceType
                    ? "<th>Insurance Type</th>"
                    : ""
                  }
                    ${limitationcolumns.message
                    ? "<th style='width:20%;'>Disclaimers</th>"
                    : ""
                  }
                    </tr>
              </thead>
              <tbody>
                    ${limitation}
              </tbody>
            </table>
          </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
      </div>
      ${!basicReport
                  ? `
        <div class='container-table' style="page-break-inside:avoid;">
          <p>Not Covered</p>
          ${result.notcovered.length > 0
                    ? `<div class="tableData">
            <table>
              <thead>
                    <tr>
                    ${notcoveredcolumns.serviceType
                      ? "<th>Service Type</th>"
                      : ""
                    }
                    ${notcoveredcolumns.network ? "<th>Network</th>" : ""}
                    ${notcoveredcolumns.coverageLevel
                      ? "<th>Coverage Level</th>"
                      : ""
                    }
                    ${notcoveredcolumns.planPeriod ? "<th>Plan Period</th>" : ""
                    }
                    ${notcoveredcolumns.amount ? "<th>Amount</th>" : ""}
                    ${notcoveredcolumns.code ? "<th>ADA Code</th>" : ""}
                    ${notcoveredcolumns.message
                      ? "<th style='width:20%;'>Disclaimers</th>"
                      : ""
                    }
                    </tr>
              </thead>
              <tbody>
                    ${notCovered}
              </tbody>
            </table>
          </div>`
                    : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                  }
      </div>
        `
                  : ""
                }
      ${!basicReport
                  ? `
        <div class='container-table' style="page-break-inside:avoid;">
      <p>Ada Procedure</p>
      ${result.adaprocedures.length > 0
                    ? `<div class="tableData">
        <table>
          <thead>
                <tr>
                ${adaprocedurecolumns.code ? "<th>Code</th>" : ""}
                ${adaprocedurecolumns.serviceType ? "<th>Service Type</th>" : ""
                    }
                ${adaprocedurecolumns.network ? "<th>Networks</th>" : ""}
                ${adaprocedurecolumns.coverageLevel
                      ? "<th>Coverage Level</th>"
                      : ""
                    }
                ${adaprocedurecolumns.percent ? "<th>Percentage</th>" : ""}
                ${adaprocedurecolumns.auth
                      ? "<th>Authorization Required</th>"
                      : ""
                    }
                ${adaprocedurecolumns.limitation ? "<th>Frequency</th>" : ""}
                ${adaprocedurecolumns.ageLimit ? "<th>Age Limit</th>" : ""}
                ${adaprocedurecolumns.auth
                      ? "<th>Authorization Required</th>"
                      : ""
                    }
                  ${adaprocedurecolumns.message
                      ? "<th style='width:20%;'>Disclaimers</th>"
                      : ""
                    }
                </tr>
              </thead>
              <tbody>
                    ${adaProcedure}
              </tbody>
            </table>
          </div>`
                    : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                  }
      </div>
        `
                  : ""
                }
      
      <div class='container-table'>
          <p>Benefit History</p>
         ${result.benefithistory.length > 0
                  ? ` <div class="tableData">
          <table>
            <thead>
                  <tr>
                      <th>Service Type</th>
                      <th>Doses</th>
                      <th>Provider</th>
                      <th>Procedure</th>
                      <th>Benefits consumed</th>
                  </tr>
            </thead>
            <tbody>
                  ${benefithistory}
            </tbody>
          </table>
        </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
      </div>
      ${!basicReport
                  ? `
        <div class="patient-payer-info" style="page-break-inside:avoid;">
      <p class='payer mb-15 mb-10'>Employer Information</p>
      <div class="patient-info ">
          <div>
              <div class="patient-details">
                  <div class="sub-details">
                      <ul class="details">
                          <li>
                              <label>Employer Name</label>
                              <p>${result?.patients?.EmpName}</p>
                          </li>
                          <li>
                              <label>Enrollment Status</label>
                              <p>Individual</p>
                          </li>
                          <li>
                              <label>Employee Identification Number</label>
                              <p>${result?.patients?.EmployerNum}</p>
                          </li>
                          <li>
                              <label>Type of Plan</label>
                              <p>${result?.patients?.planType}</p>
                          </li>
                          <li>
                              <label>Group or Policy Number</label>
                              <p>00000000</p>
                          </li>
                          <li>
                              <label>Network Status</label>
                              <p>Innetwork</p>
                          </li>
                          <li>
                              <label>Network Providter Lis</label>
                              <p>Link</p>
                          </li>
                      </ul>
                  </div>
                  <div class="sub-details w50">
                      <h5 class='mb-10'>Contact Details</h5>
                      <ul class="details">
                          <li>
                              <label>City</label>
                              <p>${result?.patients?.address?.city
                    ? result?.patients?.address?.city
                    : "-"
                  }
                              </p>
                          </li>
                          <li>
                              <label>State</label>
                              <p>${result?.patients?.address?.state
                    ? result?.patients?.address?.state
                    : "-"
                  }
                              </p>
                          </li>
                          <li>
                              <label>Address</label>
                              <p>${result?.patients?.address?.address1
                    ? result?.patients?.address?.address1
                    : "-"
                  }</p>
                          </li>
                          <li>
                              <label>Zip Code</label>
                              <p>${result?.patients?.address?.zipCode
                    ? result.patients.address.zipCode
                    : "-"
                  }
                              </p>
                          </li>
                          <li>
                              <label>Phone Number</label>
                              <p>${result?.patients?.WirelessPhone}</p>
                          </li>
                          <li>
                              <label>Websire</label>
                              <p>Link</p>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
  
  
      </div>
  
  </div>
        `
                  : ""
                }
      ${!basicReport
                  ? `
        <div class='con-borders mb-15' style="page-break-inside:avoid;">
          <p class='payer mb-15 mb-10'>Miscellaneous</p>
          <h5 class='mb-10'>Caveat Question</h5>
          ${result.miscellaneous.length > 0
                    ? `
            <div class='d-flex'>
          ${result.miscellaneous
                      .map(
                        (item) => `
            <div class='ques-border'>
                  <p class='ques'>Q: ${item.question}</p>
                  <p class='ans'>A: ${item.answer}</p>
              </div>
            `
                      )
                      .join("")}
          </div>
            `
                    : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                  }
          
      </div>
  
      <div class='m-15 thinborder'></div>
  
      <div class='con-borders' style="page-break-inside:avoid;"> 
      <p class='payer mb-15'>Notes & Remarks</p>
      ${result.notesandremarks.length > 0
                    ? `
        ${result.notesandremarks
                      .map(
                        (item, i) => `
  <div class="mb-15">
  <label class="primary-color">${i + 1}.Notes</label>
  <p style="font-size:14px; margin-top:10px;">${item.data}</p>
  </div>
  `
                      )
                      .join("")}
        `
                    : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                  }
     
  </div>
  <div class='container-table'>
  <p>Upload</p>
  ${result.attachments.length > 0
                    ? `
    <div class="tableData">
  <h5 style="margin:10px; font-size:12px;">Attachments</h5>
    <table>
      <thead>
            <tr>
                <th>file Name</th>
                <th>Description</th>
                <th>Attachment Date</th>
            </tr>
      </thead>
      <tbody>
            ${Attachments}
      </tbody>
    </table>
  </div>
    `
                    : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                  }
  </div>
        `
                  : ""
                }
  
  <div class="patient-payer-info" style="page-break-inside:avoid;">
          <p class='payer mb-15 mb-10'>Patient & Payer Information</p>
          <h4>Patient Information</h4>
          <div class="patient-info  ">
              <div class='thinBorder'>
                  <div class="patient-details">
                      <div class="sub-details">
                          <h5 class='mb-15' style="font-size:14px;">Subscriber</h5>
                          <ul class="details">
                              <li>
                                  <label>First Name</label>
                                  <p>${result?.epatients?.firstName}</p>
                              </li>
                              <li>
                                  <label>Lastname</label>
                                  <p>${result?.epatients?.lastName}</p>
                              </li>
                              <li>
                                  <label>DOB</label>
                                  <p>${new Date(
                  result?.epatients?.dateOfBirth
                ).toLocaleDateString("en-GB")}</p>
                              </li>
                              <li>
                                  <label>Gender</label>
                                  <p>${result?.epatients?.gender}</p>
                              </li>
                              <li>
                                  <label>Relationship</label>
                                  <p>${result?.epatients?.relationship}</p>
                              </li>
                              <li>
                                  <label>Member ID</label>
                                  <p>${result?.epatients?.plan?.subscriberId
                }</p>
                              </li>
                          </ul>
                          <div class="sub-details">
                              <h5 class='mb-15' style="font-size:14px;">Coverage</h5>
                              <ul class="details">
                                  <li>
                                      <label>Effective Data</label>
                                      <p>${result.epatients?.plan
                  ?.effectiveDateFrom
                }</p>
                                  </li>
                                  <li>
                                      <label>End Data</label>
                                      <p>Jacob</p>
                                  </li>
                                  <li>
                                      <label>Status</label>
                                      <p>${result?.epatients?.plan
                  ?.effectiveDateFrom
                  ? "Active"
                  : "Inactive"
                }</p>
                                  </li>
  
                              </ul>
                          </div>
                      </div>
                      <div class="sub-details ">
                          <h5 class='mb-15' style="font-size:14px;">Address</h5>
                          <ul class="details">
                              <li>
                                  <label>City</label>
                                  <p>${result?.epatients?.address?.city
                  ? result?.epatients?.address?.city
                  : "-"
                }
                                  </p>
                              </li>
                              <li>
                                  <label>State</label>
                                  <p>${result?.epatients?.address?.state
                  ? result?.epatients?.address?.state
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>Address</label>
                                  <p>${result?.epatients?.address?.address1
                  ? result?.epatients?.address?.address1
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>Zip Code</label>
                                  <p>${result?.epatients?.address?.zipCode
                  ? result.epatients.address.zipCode
                  : "-"
                }</p>
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
              <div class="sub-details thinBorder mb-10">
                  <h5 class='mb-15' style="font-size:14px;">Payer</h5>
                  <ul class="details" style="width:40%">
                      <li>
                          <label>ID</label>
                          <p>${result?.payer[0]?.payerId}</p>
                      </li>
                      <li>
                          <label>Name</label>
                          <p>${result?.payer[0]?.name}</< /p>
                      </li>
                  </ul>
              </div>
              <div class="sub-details ">
                  <h4 class='mb-15' style="font-size:14px;">Plan</h4>
                  <h5 class='mb-10'>Basic</h5>
                  <ul class="details" style="width:40%">
                      <li>
                          <label>Group Name</label>
                          <p>${result?.epatients?.plan?.groupName}</p>
                      </li>
                      <li>
                          <label>Effective Date</label>
                          <p>${result?.epatients?.plan?.effectiveDateFrom}</p>
                      </li>
                      <li>
                          <label>Group Number</label>
                          <p>${result?.epatients?.plan?.groupNumber}</p>
                      </li>
                      <li>
                          <label>Req Participation</label>
                          <p>N/A</p>
                      </li>
                  </ul>
              </div>
          </div>
  
      </div>
                  </body>
                  </html>
              `;

              await page.setContent(content);

              const pdfBuffer = await page.pdf({
                format: "A4",
                margin: {
                  top: "10px",
                  right: "0px",
                  bottom: "10px",
                  left: "0px"
                },
                timeout: 0,
                path: "output.pdf"
              });
              // if (isbulkrecord) callack1();
              // res.status(200).send(result1);

              await browser.close();
              // if (!isbulkrecord) {
              res.contentType("application/pdf");
              res.send(pdfBuffer);
              // }
              // const pdfStream = new stream.PassThrough();
              // pdfStream.end(result1);
              // res.setHeader('Content-Type', 'application/pdf');
              // res.setHeader('Content-Disposition', 'attachment; filename=report.pdf');
              // pdfStream.pipe(res);
            };
            generateReport();
          }
        }
      );
    } catch (error) {
      console.log(error);
      res.status(400).send({ error });
    }
  } catch (e) {
    console.log(e);
    res.status(400).send({ e });
  }
};

module.exports.getAllPatientPdf = async (req, res) => {
  try {
    const dateThreshold = new Date();
    dateThreshold.setDate(dateThreshold.getDate() - 30);

    let whereCondition = {
      createdAt: {
        [Op.gte]: dateThreshold
      },
      isVerified: true
    };
    const bufferData = []
    const manualPatients = await models.ManualPatients.findAll({
      where: whereCondition,
      attributes: ['patientId'],
      raw: true
    });
    const schedulePatients = await models.SchedulePatients.findAll({
      where: whereCondition,
      attributes: ['patientId', 'isScheduled'],
      raw: true
    });
    const ids = [...manualPatients, ...schedulePatients]
    async.eachSeries(
      ids,
      (id, callback) => {
        getEligibilityReports(req, res, id.patientId, bufferData, callback);
      },
      async () => {
        res.status(200).send({
          data: bufferData,
          message: "Successfully Downloaded the PDF's"
        });

      }
    );
  } catch (error) {
    console.log(error)
    res.status(400).send({ error });
  }
}

async function getEligibilityReports(req, res, patientId, bufferData, callback1) {
  try {
    const basicReport = true;
    let activecoveragecolumns = {};
    let coinsurancecolumns = {};
    let deductiblecolumns = {};
    let adaprocedurecolumns = {};
    let notcoveredcolumns = {};
    let limitationcolumns = {};
    const params = {
      patientId: patientId
    };
    try {
      async.parallel(
        {
          activecoverage: function (callback) {
            let obj = {
              planCoverageDescription: false,
              effectiveDateFrom: false,
              planPeriod: false,
              percent: false,
              waitingPeriodApplies: false,
              auth: false,
              message: false,
              insuranceType: false,
              code: false,
              waitingPeriod: false,
              coverageLevel: false
            };
            let responseData = [];
            Promise.all([
              models.EActiveCoverages.findAll({
                where: params
              }),
              models.EADAProcedure.findAll({ where: params }),
              models.ECoInsurance.findAll({ where: params }),
              models.EDeductible.findAll({ where: params }),
              models.ELimitationMaximum.findAll({
                where: params
              }),
              models.ENotCovered.findAll({ where: params })
            ])
              .then(
                async ([
                  table1Data,
                  table2Data,
                  table3Data,
                  table4Data,
                  table5Data,
                  table6Data
                ]) => {
                  const response = [
                    ...table1Data,
                    ...table2Data,
                    ...table3Data,
                    ...table4Data,
                    ...table5Data,
                    ...table6Data
                  ];
                  await removeEmptyValues(obj, response);
                  obj = Object.assign(obj, {
                    serviceType: true,
                    code: true,
                    network: true
                  });
                  let arrangedData = groupBy(response, "serviceType");
                  if (arrangedData && Object.keys(arrangedData).length > 0) {
                    for (let i in arrangedData) {
                      let dataCheck = {
                        type: i,
                        activeCoverage: arrangedData[i]
                      };
                      responseData.push(dataCheck);
                    }
                  }
                  activecoveragecolumns = obj;
                  callback(null, responseData);
                }
              )
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          notesandremarks: function (callback) {
            models.ENotesAndRemark.findAll({
              where: { patientId: patientId }
            })
              .then((res3) => {
                callback(null, res3);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          benefithistory: function (callback) {
            models.EBenefitHistory.findAll({
              where: { patientId: patientId },
              raw: true
            })
              .then((res4) => {
                callback(null, res4);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          deductibles: function (callback) {
            let obj = {
              serviceType: false,
              code: false,
              network: false,
              coverageLevel: false,
              planPeriod: false,
              amount: false,
              planCoverageDescription: false,
              message: false
            };
            models.EDeductible.findAll({
              where: { patientId: patientId },
              raw: true
            })
              .then((response1) => {
                removeEmptyValues(obj, response1);
                deductiblecolumns = obj;
                callback(null, response1);
              })
              .catch((err) => {
                console.error("Error fetching EDeductible:", err);
                callback(err); // Pass error to the callback
              });
          },
          susbscriber: function (callback) {
            models.ESubscriber.findOne({ where: { patientId: patientId } })
              .then((subres) => {
                callback(null, subres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          limitationmaximum: function (callback) {
            let obj = {
              serviceType: false,
              code: false,
              network: false,
              coverageLevel: false,
              planPeriod: false,
              amount: false,
              insuranceType: false,
              auth: false,
              limitation: false,
              serviceDates: false,
              planCoverageDescription: false,
              benefitAge: false,
              message: false
            };
            models.ELimitationMaximum.findAll({
              where: { patientId: patientId }
            })
              .then((limmax) => {
                removeEmptyValues(obj, limmax);
                limitationcolumns = obj;
                callback(null, limmax);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          epatients: function (callback) {
            models.EPatient.findOne({
              where: { patientId: patientId }
            })
              .then((patres) => {
                callback(null, patres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          payer: function (callback) {
            models.EPayer.findAll({ where: { patientId: patientId } })
              .then((payer) => {
                callback(null, payer);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          },
          patients: function (callback) {
            let patientModel = req.body.isScheduled
              ? models.SchedulePatients
              : models.ManualPatients;
            patientModel
              .findOne({ where: { patientId: patientId } })
              .then((patres) => {
                callback(null, patres);
              })
              .catch((err) => {
                console.error("Error occurred:", err);
                callback(err, null);
              });
          }
        },
        (error, result) => {
          result["activecoveragecolumns"] = activecoveragecolumns;
          result["deductiblecolumns"] = deductiblecolumns;
          result["limitationcolumns"] = limitationcolumns;
          if (error) {
            console.error("Error in async.parallel:", error);
            res.status(500).send({
              error: error,
              message: "Failed to fetch PDF data"
            });
          } else {
            const generateReport = async () => {
              const browser = await puppeteer.launch({
                executablePath: "/usr/bin/google-chrome",
                args: ["--no-sandbox", "--disable-setuid-sandbox"]
              });
              const page = await browser.newPage();

              const downArrow = `<svg xmlns="
                                  http://www.w3.org/2000/svg"
                                  viewBox="0 0 320 512"><!--! Font Awesome Free 6.5.1 by @fontawesome -
                                  https://fontawesome.com
                                  License -
                                  https://fontawesome.com/license/free
                                  (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc. --><path d="M137.4 374.6c12.5 12.5 32.8 12.5 45.3 0l128-128c9.2-9.2 11.9-22.9 6.9-34.9s-16.6-19.8-29.6-19.8L32 192c-12.9 0-24.6 7.8-29.6 19.8s-2.2 25.7 6.9 34.9l128 128z"/></svg>`;

              const activeCoverage = result.activecoverage
                .map(
                  (item) => `
              <tr class='table-rows'>
              <td colspan="7">
                  ${item?.type != "null"
                      ? `${downArrow} ${item.type}`
                      : `${downArrow}-`
                    }
              </td>
              </tr>
              ${item.activeCoverage
                      .map(
                        (item) => `
                <tr >
              ${result.activecoveragecolumns.serviceType
                            ? `<td>${item?.message != null ? `${downArrow}` : ""}
                      ${item?.serviceType ? item.serviceType : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.network
                            ? `<td>${item?.network ? item.network : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.code
                            ? `<td>${item?.code ? item.code : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.effectiveDateFrom
                            ? `<td>${item?.effectiveDateFrom ? item.effectiveDateFrom : "-"
                            }</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.planPeriod
                            ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.percent
                            ? `<td>${item?.percent ? item.percent : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.waitingPeriodApplies
                            ? `<td>${item?.waitingPeriodApplies
                              ? item.waitingPeriodApplies
                              : "-"
                            }</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.auth
                            ? `<td>${item?.auth ? item.auth : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.insuranceType
                            ? `<td>${item?.insuranceType ? item.insuranceType : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.coverageLevel
                            ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"}</td>`
                            : ""
                          }
              ${result.activecoveragecolumns.planCoverageDescription
                            ? `<td>${item?.planCoverageDescription
                              ? item.planCoverageDescription
                              : "-"
                            }</td>`
                            : ""
                          }
              </tr>
              ${item?.message != null && result.activecoveragecolumns.message
                            ? `<tr class="disclaimer" >
                            <td colspan="7"><p style="font-size:10px;">${item.message}</p></td>
                    </tr>`
                            : ``
                          }
                `
                      )
                      .join("")}
              `
                )
                .join("");

              const deductibles = result.deductibles
                .map(
                  (item) =>
                    `<tr>
                    ${result.deductiblecolumns.serviceType
                      ? `<td>${item?.message != null ? `${downArrow}` : ""}
                    ${item?.serviceType ? item.serviceType : "-"}</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.code
                      ? `<td>${item?.code ? item.code : "-"}</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.network
                      ? `<td>${item?.network ? item.network : "-"}</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.coverageLevel
                      ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"
                      }</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.planPeriod
                      ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.amount
                      ? `<td>${item?.amount ? item.amount : "-"}</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.insuranceType
                      ? `<td>${item?.insuranceType ? item.insuranceType : "-"
                      }</td>`
                      : ""
                    } 
                    ${result.deductiblecolumns.planCoverageDescription
                      ? `<td>${item?.planCoverageDescription
                        ? item.planCoverageDescription
                        : "-"
                      }</td>`
                      : ""
                    } 
              </tr>
              ${item?.message != null && result.deductiblecolumns.message
                      ? `<tr class="disclaimer">
                          <td  colspan="7"><p style="font-size:10px;">${item.message}</p></td>
                        </tr>`
                      : ``
                    }`
                )
                .join("");


              const limitation = result.limitationmaximum
                .map(
                  (item) =>
                    `<tr>
                    ${result.limitationcolumns.serviceType
                      ? `
                    <td>${item?.message != null ? `${downArrow}` : ""}
                    ${item?.serviceType ? item.serviceType : "-"}</td>
                    `
                      : ""
                    }
                    ${result.limitationcolumns.code
                      ? `<td>${item?.code ? item.code : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.network
                      ? `<td>${item?.network ? item.network : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.coverageLevel
                      ? `<td>${item?.coverageLevel ? item.coverageLevel : "-"
                      }</td>`
                      : ""
                    }
                    ${result.limitationcolumns.planPeriod
                      ? `<td>${item?.planPeriod ? item.planPeriod : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.amount
                      ? `<td>${item?.amount ? item.amount : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.auth
                      ? `<td>${item?.auth ? item.auth : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.limitation
                      ? `<td>${item?.limitation ? item.limitation : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.benefitAge
                      ? `<td>${item?.benefitAge ? item.benefitAge : "-"}</td>`
                      : ""
                    }
                    ${result.limitationcolumns.serviceDates
                      ? `<td>${item?.serviceDates ? item.serviceDates : "-"
                      }</td>`
                      : ""
                    }
                    ${result.limitationcolumns.insuranceType
                      ? `<td>${item?.insuranceType ? item.insuranceType : "-"
                      }</td>`
                      : ""
                    }
              </tr>
              ${item?.message != null && result.limitationcolumns.message
                      ? `<tr class="disclaimer">
                    <td  colspan="7"><p style="font-size:10px;">${item.message}</p></td>
                  </tr>`
                      : ``
                    }`
                )
                .join("");

              const benefithistory = result.benefithistory
                .map(
                  (item) =>
                    `<tr>
              <td>${item?.serviceType ? item.serviceType : "-"}</td>
              <td>${item?.doses ? item.doses : "-"}</td>
              <td>${item?.provider ? item.provider : "-"}</td>
              <td>${item?.procedure ? item.procedure : "-"}</td>
              <td>${item?.benefitsConsumed ? item.benefitsConsumed : "-"}</td>
              </tr>`
                )
                .join("");

              // HTML content
              const content = `
                  <html>
                  <head>
                  
                  </head>
                  <style>
                          svg {
                            width:7px;
                            height:10px;
                          }
                          .primary-color {    
                              color: #13af8f;
                          }
                          table {
                              width: 100%;
                              border-collapse: collapse;
                          }
                          thead {
                              display: table-header-group;
                          }
                          tr{
                            border-top: 1px solid #dee2e6;
                          }
                         td{
                            font-size:10px !important;
                          }
                          th, td {
                              padding: 8px 5px;
                              text-align: left;
                          }
                          th{
                            font-size:10px;
                          }
                          body {
                            font-family: 'Roboto', sans-serif;
                            font-style: normal !important;
                            margin: 0;
                            padding:20px;
                            box-sizing:border-box;
                        }
                    
                        p,
                        h1,
                        h2,
                        h3,
                        h4,
                        h5,
                        h6 {
                            margin: 0;
                            padding: 0;
                        }
                    
                        address {
                            font-style: normal;
                            line-height: 20px;
                            font-size: 14px;
                            font-weight: 500;
                        }
                        .header {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            width: 70%;
                            /* Adjusted width */
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            -webkit-align-items: center;
                            /* For older WebKit */
                            align-items: center;
                            padding-top: 40px;
                            margin-bottom: 20px;
                        }
                    
                        .div-img {
                            height: 100px;
                            width: 250px;
                        }
                    
                        .div-img img {
                            object-fit: contain;
                            width: 100%;
                            height: 100%;
                        }
                    
                        .sub-details {
                            margin-top: 25px;
                        }
                    
                        .sub-details .details {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            -webkit-flex-wrap: wrap;
                            /* For older WebKit */
                            flex-wrap: wrap;
                        }
                    
                        .details li {
                            min-height: 60px;
                            width: 50%;
                        }
                    
                        .details p {
                            font-size: 12px;
                            font-weight: 500;
                            margin-top: 10px;
                        }
                    
                        ul {
                            margin: 0;
                            padding: 0;
                            list-style: none;
                        }
                    
                        .plans {
                            display: -webkit-flex;
                            /* For older WebKit */
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            display: flex;
                            -webkit-flex-wrap: wrap;
                            /* For older WebKit */
                            flex-wrap: wrap;
                            row-gap: 20px;
                            width: 42%
                        }
                    
                        .plan-container {
                            width: 100%;
                            -webkit-flex-wrap: no-wrap;
                            /* For older WebKit */
                            flex-wrap: no-wrap;
                            display: -webkit-flex;
                            /* For older WebKit */
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            display: flex;
                            border: 1px solid #d0d0d0;
                            border-radius: 10px;
                            margin-top: 30px;
                        }
                    
                        h5 {
                            font-size: 12px;
                            font-weight: 400;
                        }
                    
                        .info {
                            width: 58%;
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                            border: 2px solid #92dacb;
                            border-radius: 10px;
                            padding: 20px;
                            margin-right: 10px;
                            background-color: #f4fffd;
                        }
                    
                        .coverage-info .coverage-details {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-justify-content: space-between;
                            /* For older WebKit */
                            justify-content: space-between;
                        }
                    
                        .cov-details {
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                        }
                    
                        .plans li {
                            border: 1px solid #d0d0d0;
                            width: calc(50% - 12px);
                            margin-left: 10px;
                            border-radius: 10px;
                            display: -webkit-flex;
                            /* For older WebKit */
                            display: flex;
                            -webkit-align-items: center;
                            /* For older WebKit */
                            -webkit-justify-content: center;
                            /* For older WebKit */
                            -webkit-flex-direction: column;
                            align-items: center;
                            flex-direction: column;
                            justify-content: center;
                        }
                    
                        .plan-container li {
                            border: none !important;
                            width: calc(25% - 12px);
                        }
                    
                        .mb-15 {
                            margin-bottom: 15px;
                        }
                    
                        .plans li>p {
                            margin-bottom: 30px;
                            font-size: 10px;
                            font-weight: 600;
                        }
                    
                        .plans li div {
                            text-align: center;
                        }
                    
                        .plans li .plan-amount {
                            font-weight: 600;
                            font-size: 14px;
                        }
                    
                        .plans li .plan-amount sub {
                            font-size: 14px;
                            font-weight: 400;
                        }
                    
                        .plans button {
                            width: 80px;
                            border-radius: 16px;
                            color: green;
                            border: 1px solid green;
                            font-weight: 600;
                            padding: 7px;
                        }
                    
                        label {
                            color: #13af8f;
                            font-size: 12px;
                        }
                    
                        .days {
                            font-size: 12px;
                            margin-top: 10px;
                        }
                    
                        .plan-container {
                            padding: 10px;
                            width: 97%;
                        }
                    
                        .cover-date {
                            font-size: 14px;
                            font-weight: 500;
                            margin-top: 10px;
                        }
                        .container-table{
                          margin-top: 25px;
                          border: 1px solid #d0d0d0;
                          border-radius: 10px;
                        }
                    .container-table p{
                      font-size:16px;
                      font-weigth:600;
                      margin:15px 10px;
                      padding:10px 0;
                    }
                    .mb-15{
                      margin-bottom:15px;
                    }
                    .mt-15{
                      margin-top:15px;
                    }
                    .w50{
                      width:50%;
                    }
              .patient-payer-info,.con-borders{
                  margin-top: 25px;
                  border: 1px solid #d0d0d0;
                  border-radius: 10px;
                  padding: 10px;
              }
              .ques-border {
                padding: 15px;
                border: 1px solid #dee2e6;
                margin: 15px;
                font-size: 14px;
                font-weight: 500;
                min-width: 40%;
            }
        
            .ques-border .ques {
                border-bottom: 1px solid black;
                padding-bottom: 7px;
            }
        
            .ques-border .ans {
                padding-top: 7px;
            }
        
            textarea {
                padding: 10px;
                margin: 10px 20px;
                height: 250px;
                width: 300px;
            }
            .d-flex{
              display:flex;
              justify-content:space-between;
              flex-warp:warp;
            }
            .thinBorder {
              border-bottom: 5px solid #F6F6F6;
              padding-bottom: 15px;
          }
          
                      </style>
                  <body>
                 
                  <div>
          <div class="header">
              <address>
                  ToothHQ Dental<br>
                  (214)731-0124<br>
                  <a href="" target="_blank">https://mytoothhq.com/</a><br>
                  Specialists Carrollton<br>
                  1500 W Hebron Pkwy,<br>
                  SUITE 108 Carrollton TX 75010
              </address>
              <div class="div-img">
                  <img src="${imageDataUri}" />
              </div>
          </div>
          <div class="cov-details">
              <div class="info">
                  <div class="subs-info">
                      <div>
                          <h5>Subscriber Information</h5>
                          <div class="sub-details">
                              <ul class="details">
                                  <li>
                                      <label>First Name</label>
                                      <p>${result?.susbscriber?.firstName}</p>
                                  </li>
                                  <li>
                                      <label>Last Name</label>
                                      <p>${result?.susbscriber?.lastName}</p>
                                  </li>
                                  <li>
                                      <label>DOB</label>
                                      <p>${new Date(
                result?.susbscriber?.dateOfBirth
              ).toLocaleDateString("en-GB")}</p>
                                  </li>
                                  <li>
                                      <label>Gender</label>
                                      <p>${result?.susbscriber?.gender}</p>
                                  </li>
                                  <li>
                                      <label>Relationship</label>
                                      <p>Self</p>
                                  </li>
                                  <li>
                                      <label>Member ID</label>
                                      <p>${result?.susbscriber?.plan?.subscriberId
                }</p>
                                  </li>
                              </ul>
                          </div>
                      </div>
  
                  </div>
                  <div class="coverage-info">
                      <div class="coverage-details">
                          <h5>Coverage</h5>
                          <h5 class="primary-color">Primary Insurance</h5>
                      </div>
                      <div class="sub-details">
                          <ul class="details">
                              <li>
                                  <label>Effective Date</label>
                                  <p>${result?.patients?.effectiveDateFrom
                  ? result.patients.effectiveDateFrom
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>End Date</label>
                                  <p>11/23/2023</p>
                              </li>
                              <li>
                                  <label>Status</label>
                                  <p>${result?.patients?.effectiveDateFrom
                  ? "Active"
                  : "Inactive"
                }</p>
                              </li>
                              <li>
                                  <label>Coverage Type</label>
                                  <p>Dental : Family ,Active Coverage Group Policy</p>
                              </li>
                              <li>
                                  <label>Insurance Name</label>
                                  <p>${result?.patients?.insuranceName
                  ? result?.patients?.insuranceName
                  : "-"
                }</p>
                              </li>
                          </ul>
                      </div>
  
                  </div>
              </div>
              <ul class="plans">
                  <li class='mb-15'>
                      <p>Dental Coverage</p>
                      <button type="button">Active</button>
                  </li>
                  <li class='mb-15'>
                      <p>Remaining Benefits</p>
                      <div class="plan-amount">$800<sub>/$1000</sub></div>
                  </li>
                  <li>
                      <p>Last Verified</p>
                      <div>
                          <p>${result?.patients?.lastVerified
                  ? new Date(
                    result.patients?.lastVerified
                  ).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                  })
                  : "-"
                }</p>
                          <p class="days"></p>
                      </div>
                  </li>
                  <li>
                      <p>Deductible Remaining</p>
                      <div class="plan-amount">$800<sub>/$800</sub></div>
                  </li>
              </ul>
          </div>
          <ul class="plans plan-container">
              <li>
                  <p>Dental Coverage</p>
                  <button type="button">Active</button>
                  <div class="cover-date">24/02/2023-23/04/2024</div>
              </li>
              <li>
                  <p>Remaining Benefits</p>
                  <div class="plan-amount">$800<sub>/$1000</sub></div>
              </li>
              <li>
                  <p>Deductible Remaining</p>
                  <div class="plan-amount">$800<sub>/$800</sub></div>
              </li>
              <li>
                  <p>Last Verified</p>
                  <div>
                      <p>01/23/2023</p>
                      <p class="days">26 Days ago</p>
                  </div>
              </li>
          </ul>
      </div>
              <div class='container-table'>
              <p>Active Coverage</p>
              ${result.activecoverage.length > 0
                  ? `<div class="tableData">
                <table>
                  <thead>
                        <tr>
                        ${activecoveragecolumns.serviceType
                    ? "<th>Service Type</th>"
                    : ""
                  }
                        ${activecoveragecolumns.network
                    ? "<th>Network</th>"
                    : ""
                  }
                        ${activecoveragecolumns.code ? "<th>ADA Code</th>" : ""}
                        ${activecoveragecolumns.effectiveDateFrom
                    ? "<th>Effective Date</th>"
                    : ""
                  }
                        ${activecoveragecolumns.planPeriod
                    ? "<th>Plan period</th>"
                    : ""
                  }
                        ${activecoveragecolumns.percent
                    ? "<th>Percentage</th>"
                    : ""
                  }
                        ${activecoveragecolumns.waitingPeriodApplies
                    ? "<th>Waiting Period Applies</th>"
                    : ""
                  }
                        ${activecoveragecolumns.auth ? "<th>Auth</th>" : ""}
                        ${activecoveragecolumns.insuranceType
                    ? "<th>Insurance Type</th>"
                    : ""
                  }
                        ${activecoveragecolumns.coverageLevel
                    ? "<th>Coverage Level</th>"
                    : ""
                  }
                        ${activecoveragecolumns.planCoverageDescription
                    ? "<th>Plan Coverage</th>"
                    : ""
                  }
                        </tr>
                  </thead>
                  <tbody>
                        ${activeCoverage}
                  </tbody>
                </table>
              </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
          </div>

      <div class='container-table'>
          <p>Deductible</p>
          ${result.deductibles.length > 0
                  ? `<div class="tableData">
            <table>
              <thead>
                    <tr>
                    ${deductiblecolumns.serviceType
                    ? "<th>Service Type</th>"
                    : ""
                  }
                    ${deductiblecolumns.code ? "<th>ADA Code</th>" : ""}
                    ${deductiblecolumns.network ? "<th>Network</th>" : ""}
                    ${deductiblecolumns.coverageLevel
                    ? "<th>Coverage Level</th>"
                    : ""
                  }
                    ${deductiblecolumns.planPeriod ? "<th>Plan Period</th>" : ""
                  }
                    ${deductiblecolumns.amount ? "<th>Amount</th>" : ""}
                    ${deductiblecolumns.insuranceType
                    ? "<th>Insurance Type</th>"
                    : ""
                  }
                    ${deductiblecolumns.planCoverageDescription
                    ? "<th>Plan Coverage</th>"
                    : ""
                  }
                    </tr>
              </thead>
              <tbody>
                    ${deductibles}
              </tbody>
            </table>
          </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
    
      </div>
      <div class='container-table'>
          <p>Limitation and Maximum</p>
          ${result.limitationmaximum.length > 0
                  ? `
            <div class="tableData">
            <table>
              <thead>
                    <tr>
                    ${limitationcolumns.serviceType
                    ? "<th>Service Type</th>"
                    : ""
                  }
                    ${limitationcolumns.code ? "<th>ADA Code</th>" : ""}
                    ${limitationcolumns.network ? "<th>Network</th>" : ""}
                    ${limitationcolumns.coverageLevel
                    ? "<th>Coverage Level</th>"
                    : ""
                  }
                    ${limitationcolumns.planPeriod ? "<th>Plan Period</th>" : ""
                  }
                    ${limitationcolumns.amount ? "<th>Amount</th>" : ""}
                    ${limitationcolumns.auth ? "<th>Auth</th>" : ""}
                    ${limitationcolumns.limitation ? "<th>Frequency</th>" : ""}
                    ${limitationcolumns.benefitAge
                    ? "<th>Age Restriction</th>"
                    : ""
                  }
                    ${limitationcolumns.serviceDates
                    ? "<th>Last Visit</th>"
                    : ""
                  }
                    ${limitationcolumns.insuranceType
                    ? "<th>Insurance Type</th>"
                    : ""
                  }
                    </tr>
              </thead>
              <tbody>
                    ${limitation}
              </tbody>
            </table>
          </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
      </div>
      
      <div class='container-table'>
          <p>Benefit History</p>
         ${result.benefithistory.length > 0
                  ? ` <div class="tableData">
          <table>
            <thead>
                  <tr>
                      <th>Service Type</th>
                      <th>Doses</th>
                      <th>Provider</th>
                      <th>Procedure</th>
                      <th>Benefits consumed</th>
                  </tr>
            </thead>
            <tbody>
                  ${benefithistory}
            </tbody>
          </table>
        </div>`
                  : `<p style="font-size:18px;" class="primary-color">NO RECORDS FOUND</p>`
                }
      </div>
      ${!basicReport
                  ? `
        <div class="patient-payer-info" style="page-break-inside:avoid;">
      <p class='payer mb-15 mb-10'>Employer Information</p>
      <div class="patient-info ">
          <div>
              <div class="patient-details">
                  <div class="sub-details">
                      <ul class="details">
                          <li>
                              <label>Employer Name</label>
                              <p>${result?.patients?.EmpName}</p>
                          </li>
                          <li>
                              <label>Enrollment Status</label>
                              <p>Individual</p>
                          </li>
                          <li>
                              <label>Employee Identification Number</label>
                              <p>${result?.patients?.EmployerNum}</p>
                          </li>
                          <li>
                              <label>Type of Plan</label>
                              <p>${result?.patients?.planType}</p>
                          </li>
                          <li>
                              <label>Group or Policy Number</label>
                              <p>00000000</p>
                          </li>
                          <li>
                              <label>Network Status</label>
                              <p>Innetwork</p>
                          </li>
                          <li>
                              <label>Network Providter Lis</label>
                              <p>Link</p>
                          </li>
                      </ul>
                  </div>
                  <div class="sub-details w50">
                      <h5 class='mb-10'>Contact Details</h5>
                      <ul class="details">
                          <li>
                              <label>City</label>
                              <p>${result?.patients?.address?.city
                    ? result?.patients?.address?.city
                    : "-"
                  }
                              </p>
                          </li>
                          <li>
                              <label>State</label>
                              <p>${result?.patients?.address?.state
                    ? result?.patients?.address?.state
                    : "-"
                  }
                              </p>
                          </li>
                          <li>
                              <label>Address</label>
                              <p>${result?.patients?.address?.address1
                    ? result?.patients?.address?.address1
                    : "-"
                  }</p>
                          </li>
                          <li>
                              <label>Zip Code</label>
                              <p>${result?.patients?.address?.zipCode
                    ? result.patients.address.zipCode
                    : "-"
                  }
                              </p>
                          </li>
                          <li>
                              <label>Phone Number</label>
                              <p>${result?.patients?.WirelessPhone}</p>
                          </li>
                          <li>
                              <label>Websire</label>
                              <p>Link</p>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
  
  
      </div>
  
  </div>
        `
                  : ""
                }
  
  <div class="patient-payer-info" style="page-break-inside:avoid;">
          <p class='payer mb-15 mb-10'>Patient & Payer Information</p>
          <h4>Patient Information</h4>
          <div class="patient-info  ">
              <div class='thinBorder'>
                  <div class="patient-details">
                      <div class="sub-details">
                          <h5 class='mb-15' style="font-size:14px;">Subscriber</h5>
                          <ul class="details">
                              <li>
                                  <label>First Name</label>
                                  <p>${result?.epatients?.firstName}</p>
                              </li>
                              <li>
                                  <label>Lastname</label>
                                  <p>${result?.epatients?.lastName}</p>
                              </li>
                              <li>
                                  <label>DOB</label>
                                  <p>${new Date(
                  result?.epatients?.dateOfBirth
                ).toLocaleDateString("en-GB")}</p>
                              </li>
                              <li>
                                  <label>Gender</label>
                                  <p>${result?.epatients?.gender}</p>
                              </li>
                              <li>
                                  <label>Relationship</label>
                                  <p>${result?.epatients?.relationship}</p>
                              </li>
                              <li>
                                  <label>Member ID</label>
                                  <p>${result?.epatients?.plan?.subscriberId
                }</p>
                              </li>
                          </ul>
                          <div class="sub-details">
                              <h5 class='mb-15' style="font-size:14px;">Coverage</h5>
                              <ul class="details">
                                  <li>
                                      <label>Effective Data</label>
                                      <p>${result.epatients?.plan
                  ?.effectiveDateFrom
                }</p>
                                  </li>
                                  <li>
                                      <label>End Data</label>
                                      <p>Jacob</p>
                                  </li>
                                  <li>
                                      <label>Status</label>
                                      <p>${result?.epatients?.plan
                  ?.effectiveDateFrom
                  ? "Active"
                  : "Inactive"
                }</p>
                                  </li>
  
                              </ul>
                          </div>
                      </div>
                      <div class="sub-details ">
                          <h5 class='mb-15' style="font-size:14px;">Address</h5>
                          <ul class="details">
                              <li>
                                  <label>City</label>
                                  <p>${result?.epatients?.address?.city
                  ? result?.epatients?.address?.city
                  : "-"
                }
                                  </p>
                              </li>
                              <li>
                                  <label>State</label>
                                  <p>${result?.epatients?.address?.state
                  ? result?.epatients?.address?.state
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>Address</label>
                                  <p>${result?.epatients?.address?.address1
                  ? result?.epatients?.address?.address1
                  : "-"
                }</p>
                              </li>
                              <li>
                                  <label>Zip Code</label>
                                  <p>${result?.epatients?.address?.zipCode
                  ? result.epatients.address.zipCode
                  : "-"
                }</p>
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
              <div class="sub-details thinBorder mb-10">
                  <h5 class='mb-15' style="font-size:14px;">Payer</h5>
                  <ul class="details" style="width:40%">
                      <li>
                          <label>ID</label>
                          <p>${result?.payer[0]?.payerId}</p>
                      </li>
                      <li>
                          <label>Name</label>
                          <p>${result?.payer[0]?.name}</< /p>
                      </li>
                  </ul>
              </div>
              <div class="sub-details ">
                  <h4 class='mb-15' style="font-size:14px;">Plan</h4>
                  <h5 class='mb-10'>Basic</h5>
                  <ul class="details" style="width:40%">
                      <li>
                          <label>Group Name</label>
                          <p>${result?.epatients?.plan?.groupName}</p>
                      </li>
                      <li>
                          <label>Effective Date</label>
                          <p>${result?.epatients?.plan?.effectiveDateFrom}</p>
                      </li>
                      <li>
                          <label>Group Number</label>
                          <p>${result?.epatients?.plan?.groupNumber}</p>
                      </li>
                      <li>
                          <label>Req Participation</label>
                          <p>N/A</p>
                      </li>
                  </ul>
              </div>
          </div>
  
      </div>
                  </body>
                  </html>
              `;

              await page.setContent(content);

              const pdfBuffer = await page.pdf({
                format: "A4",
                margin: {
                  top: "10px",
                  right: "0px",
                  bottom: "10px",
                  left: "0px"
                },
                path: "output.pdf"
              });
              bufferData.push(pdfBuffer);
              await browser.close();
              callback1()
            };
            generateReport();
          }
        }
      );
    } catch (error) {
      console.log(error);
      res.status(400).send({ error });
    }
  } catch (e) {
    console.log(e);
    res.status(400).send({ e });
  }
}