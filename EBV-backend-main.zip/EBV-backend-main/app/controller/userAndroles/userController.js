const axios = require("axios");
const nodemailer = require("nodemailer");
// const { successMail } = require("./template");
const fs = require("fs").promises;
const path = require("path");
const { check, validationResult } = require("express-validator");
const GENYUS_IAM = process.env.GENYUS_IAM;

const transporter = nodemailer.createTransport({
  host: process.env.SMTP,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.FROM_MAIL,
    pass: process.env.PASS,
  },
});

const sendEmail = async (subject, text, email_id, clinic_name) => {
  try {
    const templatePath = path.join(__dirname, "email.html");
    const templateContent = await fs.readFile(templatePath, "utf8");
    const logoPath = path.join(__dirname, "company_logo.png");

    const htmlContent = templateContent
      .replace(/{{text}}/g, text)
      .replace(/{{clinicName}}/g, clinic_name);

    const mailOptions = {
      from: process.env.FROM_MAIL,
      to: email_id,
      bcc: [
        "lenin.k@genyus.dev",
        "amaljith.r@genyus.dev",
        "meenakshi.s@genyus.dev",
        "upendhra@genyus.dev",
      ],
      subject: subject,
      html: htmlContent,
      attachments: [
        {
          filename: "company_logo.png",
          path: logoPath,
          cid: "companyLogo",
        },
        {
          filename: "thanks_logo.png",
          path: path.join(__dirname, "thanks_logo.png"),
          cid: "thanksLogo",
        },
      ],
    };
    // Send email
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
  }
};



module.exports.create = async function (req, res) {
  // #swagger.tags = ['User Account']
  const { practiceId, subscriptionId } = req.query;
  let {
    userName,
    adminId,
    locations,
    email,
    phoneNumber,
    userType,
    status,
    mobileNumber,
    country,
    timezone,
    photo,
    address,
    city,
    state,
    zipcode,
  } = req.body;
  const { authorization } = req.headers;
  const baseURL = `${GENYUS_IAM}/api/user/create?practiceId=${practiceId}&subscriptionId=${subscriptionId}`;

  try {
    const response = await axios.post(baseURL, {
      userName,
      adminId,
      locations,
      email,
      status,
      phoneNumber,
      userType,
      mobileNumber,
      country,
      timezone,
      photo,
      address,
      city,
      state,
      zipcode,

    },{ headers: {"Authorization" : authorization} });

    res.status(200).json({
      data: response.data.data,
      message: "user created successfully",
    });
  } catch (error) {
    console.error( error.response );
    
    if(error.response.status == 401){
      res.status(401).json({
        "error": "Unauthorized: Invalid token."
      });
      return
    }
    if(error.response.status == 403){
      return res.status(403).json({ message: error.response.data.message });
    }
    console.log(error.response.status);
    res.status(500).json({ error: error.response.data.error , message: "user creation failed" });
  }
};

// UserAccountcontroller.js
module.exports.getAll = async function (req, res) {
  // #swagger.tags = ['User Account']
  const { practiceId } = req.query;
  const { authorization } = req.headers;

  const baseURL = `${GENYUS_IAM}/api/user/getall?practiceId=${practiceId}`;

  try {
    const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
    res.status(200).send({
      data: response?.data?.data,
      message: "All users fetched successfully",
    });
  } catch (error) {
    console.error(error);
    if(error.response.status == 401){
      res.status(401).json({
        "error": "Unauthorized: Invalid token."
      });
      return
    }
    res
      .status(500)
      .json({ message: "Error fetching user accounts", error: error.message });
  }
};

module.exports.getUserById = async function (req, res) {
  // #swagger.tags = ['User Account']
  const { user_id } = req.params;
  //practice id will come from token
  const { practiceId } = req.query;
  const { authorization } = req.headers;

  const baseURL = `${GENYUS_IAM}/api/user/get/${user_id}?practiceId=${practiceId}`;
  try {
    const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
    res.status(200).send({ data: response.data.data });
  } catch (error) {
    console.error({ error });
    if(error.response.status == 401){
      res.status(401).json({
        "error": "Unauthorized: Invalid token."
      });
      return
    }
    res.status(400).json({
      error: error?.response?.data,
      message: "User details fetch failed",
    });
  }
};

module.exports.update = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['User Account']
    const { user_id } = req.params;
  const { authorization } = req.headers;

    //practice id will come from token
    const { practiceId } = req.query;
    const { subscriptionId } = req.query;
    const baseURL = `${GENYUS_IAM}/api/user/update/${user_id}?practiceId=${practiceId}&subscriptionId=${subscriptionId}`;

    const {
      userName,
      adminId,
      practices,
      locations,

      email,
      phoneNumber,
      userType,
      status,
      mobileNumber,
      country,
      timezone,
      photo,
      address,
      city,
      state,
      zipcode,
    } = req.body;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "User Update failed" });
    }

    try {
      const response = await axios.put(baseURL, {
        userName,
        adminId,
        practices,
        locations,

        email,
        phoneNumber,
        userType,
        status,
        mobileNumber,
        country,
        timezone,
        photo,
        address,
        city,
        state,
        zipcode,
      },{ headers: {"Authorization" : authorization} });
      res.status(200).send({
        data: response.data.data,
      });
    } catch (error) {
      console.error({ error });
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      if(error.response.status == 403){
        return res.status(403).json({ message:  error.response.data.message });
        }
      res.status(500).send({
        error: error.message,
        message: "Failed to update user details",
      });
    }
  },
];

module.exports.delete = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['UserAccount']
    const { user_id } = req.params;
    const { authorization } = req.headers;

    //practice id will come from token
    const { practiceId } = req.query;
    const baseURL = `${GENYUS_IAM}/api/user/delete/${user_id}?practiceId=${practiceId}`;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "User Delelte failed" });
    }

    try {
      const response = await axios.delete(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).send({
        data: response.data.data,
      });
    } catch (error) {
      console.error({ error });
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res.status(500).send({
        error: error.message,
        message: "Failed to delete user details",
      });
    }
  },
];

module.exports.getLocationById = [
  check("userId").notEmpty().withMessage("userId is required"),
  async function (req, res) {
    // #swagger.tags = ['UserAccount']
    const { userId } = req.params;
    const { authorization } = req.headers;

    const baseURL = `${GENYUS_IAM}/api/user/locations/${userId}`;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "User Delelte failed" });
    }
    try {
      const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).send({
        data: response.data.data,
      });
    } catch (error) {
      console.log({ error });
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res.status(400).send({
        error: error.message || error,
        message: "user details fetch failed",
      });
    }
  },
];

module.exports.getUserByLocation = [
  check("locationId").notEmpty().withMessage("LocationId is required"),
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['UserAccount']
    const { locationId, practiceId } = req.query;
    const { authorization } = req.headers;

    const baseURL = `${GENYUS_IAM}/api/user/getbylocation?practiceId=${practiceId}&locationId=${locationId}`;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "User Details Fetch failed" });
    }

    try {
      const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).send({
        data: response.data.data,
      });
    } catch (error) {
      console.error({ error });
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res.status(500).send({
        error: error.message || error,
        message: "Failed to fetch user details",
      });
    }
  },
];
