const axios = require("axios");
const { check, validationResult } = require("express-validator");
const GENYUS_IAM = process.env.GENYUS_IAM;

module.exports.create = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['User Roles']
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "Roles fetch failed" });
    }

    let {
      roleName,
      permissions,
      roleType,
      admin,
      practiceId,
      products,
      modules,
      features,
    } = req.body;
    const { authorization } = req.headers;

    const baseURL = `${GENYUS_IAM}/api/role/create`;

    try {
      const response = await axios.post(baseURL, {
        roleName,
        permissions,
        roleType,
        admin,
        practiceId,
        products,
        modules,
        features,
      },{ headers: {"Authorization" : authorization} });
      res.status(200).json({
        data: response.data.data,
        message: "User role created successfully",
      });
    } catch (error) {
      console.log(error);
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res
        .status(500)
        .json({ error: error, message: "User role creation failed" });
    }
  },
];

module.exports.getAll = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['User Roles']
    const { practiceId } = req.query;
    const { authorization } = req.headers;
    const baseURL = `${GENYUS_IAM}/api/role/getdefault/${practiceId}`;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "Roles fetch failed" });
    }

    try {
      const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).json({
        data: response.data.data,
        message: "All user roles fetched successfully",
        practiceLogo: response.data.practiceLogo
      });
    } catch (error) {
      console.error("Error fetching user roles:", error);
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res
        .status(500)
        .json({ error: error.message, message: "Failed to fetch user roles" });
    }
  },
];

module.exports.getRoleById = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['User Roles']
    const { practiceId } = req.query;
    const { authorization } = req.headers;
    const { roleId } = req.params;
    const baseURL = `${GENYUS_IAM}/api/role/get/${roleId}?practiceId=${practiceId}`;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "Roles fetch failed" });
    }
    try {
      const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).json({
        data: response.data.data,
        message: "User role fetched successfully",
      });
    } catch (error) {
      console.error("Error fetching user role:", error);
      res
        .status(500)
        .json({ error: error.message, message: "Failed to fetch user role" });
    }
  },
];

module.exports.getroleProductsById = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['User Roles']
    const { practiceId } = req.query;
    const { roleId } = req.params;
    const { authorization } = req.headers;

    const baseURL = `${GENYUS_IAM}/api/role/getroleproducts/${roleId}?practiceId=${practiceId}`;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "Roles fetch failed" });
    }
    try {
      const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).json({
        data: response.data.data,
        message: "User role fetched successfully",
      });
    } catch (error) {
      console.error("Error fetching user role:", error);
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res
        .status(500)
        .json({ error: error.message, message: "Failed to fetch user role" });
    }
  },
];

//get update details by role_name
module.exports.update = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
    // #swagger.tags = ['User Roles']
    const { roleId } = req.params;
    const { authorization } = req.headers;

    // const { practiceId } = req.query;
    const {
      roleName,
      permissions,
      roleType,
      adminId,
      products,
      practiceId,
      modules,
      features,
    } = req.body;

    const baseURL = `${GENYUS_IAM}/api/role/update/${roleId}?practiceId=${practiceId}`;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
        .status(400)
        .json({ error: errorMessages, msg: "Roles update failed" });
    }

    try {
      const response = await axios.put(baseURL, {
        roleName,
        permissions,
        roleType,
        adminId,
        products,
        modules,
        features,
      },{ headers: {"Authorization" : authorization} });
      res.status(200).json({
        data: response.data.data,
        message: "User role details updated successfully",
      });
    } catch (error) {
      console.error("Error updating user role:", error);
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res
        .status(500)
        .json({ error: error.message, message: "Failed to update user role" });
    }
  },
];

module.exports.delete = [
  check("practiceId").notEmpty().withMessage("PracticeId is required"),
  async function (req, res) {
  // #swagger.tags = ["User Roles"]
    
  const { practiceId } = req.query;
    const { roleId } = req.params;
    const { authorization } = req.headers;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return res
      .status(400)
      .json({ error: errorMessages, msg: "Roles deletion failed" });
    }
    const baseURL = `${GENYUS_IAM}/api/role/delete/${roleId}?practiceId=${practiceId}`;
    try {
      const response = await axios.delete(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).json({
        data: response.data.data,
        message: "Role deleted successfully",
      });
    } catch (error) {
      console.log(error);
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res.status(500).json({ error: error, message: "Role deletion failed" });
    }
  },
];
