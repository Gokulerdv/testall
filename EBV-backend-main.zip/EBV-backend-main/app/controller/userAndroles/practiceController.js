const axios = require("axios");
const GENYUS_IAM = process.env.GENYUS_IAM;

module.exports.getPracticeById = async function (req, res) {
    // #swagger.tags = ['Practice']
    const { practiceId } = req.params;
    const { authorization } = req.headers;
  
    const baseURL = `${GENYUS_IAM}/api/practice/get/${practiceId}`;
  
    try {
      const response = await axios.get(baseURL,{ headers: {"Authorization" : authorization} });
      res.status(200).send({
        data: response.data.data,
        message: "Pratices details fetched successfully"
      });
    } catch (error) {
      console.log({ error });
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res.status(400).send({
        error: error,
        data: [],
        message: "Product details fetch failed"
      });
    }
  };
  module.exports.getAllPractice = async function (req, res) {
    // #swagger.tags = ['Practice']
    const { authorization } = req.headers;
  
    const baseURL = `${GENYUS_IAM}/api/practice/getall`;
  
    try {
      const response = await axios.get(baseURL);
      res.status(200).send({
        data: response.data.data,
        message: "Pratices details fetched successfully"
      });
    } catch (error) {
      console.log({ error });
      if(error.response.status == 401){
        res.status(401).json({
          "error": "Unauthorized: Invalid token."
        });
        return
      }
      res.status(400).send({
        error: error,
        data: [],
        message: "Product details fetch failed"
      });
    }
  };