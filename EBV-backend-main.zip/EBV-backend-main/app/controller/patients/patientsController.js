const axios = require("axios");
const async = require("async");
const AWS = require("aws-sdk");
const sqs = new AWS.SQS({ region: "ap-south-1" });
const { v4: uuidv4 } = require("uuid");
const moment = require("moment");
const path = require("path");
const { Op } = require("sequelize");
const db = require("../../../db/model");
const ODcontroller = require("../opendental/opendentalController");
const models = require("../../../db/model");
const { isEmpty } = require("lodash");
const puppeteer = require("puppeteer");
const nodemailer = require("nodemailer");
const {
  successMail,
  errorMail,
  demographic,
  technicalError,
  updatePatientEmail,
  deletePatient,
} = require("./template");
const fs = require("fs").promises;
const { createNotification } = require("../settings/notificationController");
const DentalExchangeApiPath = process.env.DENTALXCHANGE_URL;
const queueUrl = process.env.QUEUE_URL;
const headers = {
  "API-Key": process.env.DENTALXCHANGE_API_KEY,
  username: process.env.DENTALXCHANGE_USERNAME,
  password: process.env.DENTALXCHANGE_PASSWORD,
};

AWS.config.update({
  accessKeyId: process.env.GENYUS_AWS_ACCESS_KEY_ID,
  region: process.env.AWS_DDS_REGION,
  secretAccessKey: process.env.GENYUS_AWS_SECRET_ACCESS_KEY,
});

// Error codes
const demographicsErrorCodes = [
  "90",
  "2001",
  "2002",
  "2003",
  "2005",
  "2007",
  "2009",
  "2012",
];
const technicalErrorCodes = [
  "100",
  "101",
  "160",
  "170",
  "1000",
  "2004",
  "2010",
  "1",
];
const notLinkedErrorCodes = ["110", "120", "130", "140", "150"];

const getAuditLogErrorMessage = (code) => {
  let errCode = code.toString();

  if (demographicsErrorCodes.includes(errCode)) {
    return "Demographic Error";
  } else if (technicalErrorCodes.includes(errCode)) {
    return "Technical Error";
  } else if (notLinkedErrorCodes.includes(errCode)) {
    return "Not Linked";
  } else if (code.toString() === "null") {
    return "Success";
  } else {
    return null;
  }
};
const OpenDentalApiPath = process.env.OPEN_DENTAL_URL;
const OpenDentalAuthorization = process.env.OPEN_DENTAL_AUTHORIZATION;

async function generatePatientId() {
  const lastRecord = await models.ManualPatients.findOne({
    order: [["id", "DESC"]],
  });
  const nextId = lastRecord ? lastRecord.id + 1 : 1;
  return "M" + nextId;
}

async function generateEligibilityId() {
  return uuidv4();
}

//non required api to check eligibility (---)
module.exports.checkPatientEligibility = async (req, res) => {
  try {
    const response = await axios.post(DentalExchangeApiPath, req.body, {
      headers: headers,
    });
    res.status(200).send({ data: response?.data });
  } catch (error) {
    console.log(error);
    res.status(400).send({ message: error?.response?.data, error });
  }
};

function createorupdatePatients(body, patientId, uniqueId, isScheduled) {
  const {
    addedFrom,
    adminId,
    verificationType,
    statusflag,
    firstName,
    lastName,
    dateOfBirth,
    memberId,
    groupId,
    relationship,
    procedureCode,
    procedureType,
    provider,
    providerFirstName,
    providerLastName,
    providerNpi,
    providerTaxId,
    insurancePayer,
    payerIdCode,
    dependentFirstName,
    dependentLastName,
    dependentDateOfBirth,
    typeOfService,
    practiceNameAndLoc,
    appointmentType,
    scheduleAppointment,
    speciality,
    isVerified,
    isVerifiedManually,
    lastVerified,
    remainingBenefits,
    effectiveDateFrom,
    effectiveEndDate,
    gender,
    insuranceDateOfBirth,
    // insuranceLastName,
    email,
    appointmentRenderingProvider,
    empenrollmentstatus,
    employerId,
    employeeId,
    // empnetworkstatus,
    empemail,
    empWirelessPhone,
    empAddress,
    empAddress2,
    empCity,
    empZip,
    empState,
    empWebSite,
    medicaidId,
    medical,
    dental,
    others,
    primary,
    secondary,
    tertiary,
  } = body;

  // if (typeof (scheduleAppointment) === 'string') body['scheduleAppointment'] = null;
  if (scheduleAppointment && scheduleAppointment != "")
    body["scheduleAppointment"] = moment(new Date(scheduleAppointment));
  else body["scheduleAppointment"] = null;

  // if (typeof (insuranceDateOfBirth) === 'string') body['insuranceDateOfBirth'] = null;
  if (insuranceDateOfBirth && insuranceDateOfBirth != "")
    body["insuranceDateOfBirth"] = moment(new Date(insuranceDateOfBirth));
  else body["insuranceDateOfBirth"] = null;

  // if (typeof (dependentDateOfBirth) === 'string') body['dependentDateOfBirth'] = null;
  if (dependentDateOfBirth && dependentDateOfBirth != "")
    body["dependentDateOfBirth"] = moment(new Date(dependentDateOfBirth));
  else body["dependentDateOfBirth"] = null;

  // if (typeof (dateOfBirth) === 'string') body['dateOfBirth'] = null;
  if (dateOfBirth && dateOfBirth != "")
    body["dateOfBirth"] = moment(new Date(dateOfBirth));
  else body["dateOfBirth"] = null;

  const newPatient = {};
  newPatient.isScheduled = isScheduled ? true : false;
  newPatient.uniqueId =
    uniqueId !== undefined && uniqueId ? uniqueId : req.body.uniqueId;
  newPatient.medical = medical || false;
  newPatient.dental = dental || false;
  newPatient.others = others || false;
  newPatient.primary = primary || false;
  newPatient.secondary = secondary || false;
  newPatient.tertiary = tertiary || false;
  newPatient.procedureType = procedureType || null;
  if (patientId !== undefined) newPatient.patientId = patientId;
  else newPatient.patientId = req.body.patientId || null;
  if (addedFrom !== undefined)
    newPatient.addedFrom = addedFrom || !isScheduled ? "manual" : null;
  // if (adminId !== undefined) newPatient.adminId = adminId;
  if (verificationType !== undefined)
    newPatient.verificationType = verificationType;
  if (statusflag !== undefined) newPatient.statusflag = statusflag;
  if (firstName !== undefined) newPatient.firstName = firstName;
  if (firstName !== undefined) newPatient.subscriberFirstName = firstName;
  if (lastName !== undefined) newPatient.lastName = lastName;
  if (lastName !== undefined) newPatient.subscriberLastName = lastName;
  if (dateOfBirth && dateOfBirth !== undefined)
    newPatient.dateOfBirth = `${new Date(dateOfBirth)}`;
  if (dateOfBirth && dateOfBirth !== undefined)
    newPatient.subscriberDateOfBirth = `${new Date(dateOfBirth)}`;
  if (memberId !== undefined) newPatient.memberId = memberId;
  if (groupId !== undefined) newPatient.groupId = groupId;
  if (relationship !== undefined) newPatient.relationship = relationship;
  if (procedureCode !== undefined) newPatient.procedureCode = procedureCode;
  if (provider !== undefined) newPatient.provider = provider;
  if (providerFirstName !== undefined)
    newPatient.providerFirstName = providerFirstName;
  if (providerLastName !== undefined)
    newPatient.providerLastName = providerLastName;
  if (providerNpi !== undefined) newPatient.providerNpi = providerNpi;
  if (providerTaxId !== undefined) newPatient.providerTaxId = providerTaxId;
  if (insurancePayer !== undefined) newPatient.insurancePayer = insurancePayer;
  if (payerIdCode !== undefined) newPatient.payerIdCode = payerIdCode;
  if (dependentFirstName !== undefined)
    newPatient.dependentFirstName = dependentFirstName;
  if (dependentLastName !== undefined)
    newPatient.dependentLastName = dependentLastName;
  if (dependentDateOfBirth && dependentDateOfBirth !== undefined)
    newPatient.dependentDateOfBirth = `${new Date(dependentDateOfBirth)}`;
  if (relationship?.toString() === "18") {
    newPatient.dependentFirstName = firstName;
    newPatient.dependentLastName = lastName;
    newPatient.dependentDateOfBirth = `${new Date(dateOfBirth)}`;
  }
  if (typeOfService !== undefined) newPatient.typeOfService = typeOfService;
  if (practiceNameAndLoc !== undefined)
    newPatient.practiceNameAndLoc = practiceNameAndLoc;
  if (appointmentType !== undefined)
    newPatient.appointmentType = appointmentType;
  newPatient.scheduleAppointment =
    scheduleAppointment && scheduleAppointment !== ""
      ? new Date(scheduleAppointment)
      : null;
  if (speciality !== undefined) newPatient.speciality = speciality;
  if (isVerified !== undefined) newPatient.isVerified = isVerified;
  if (isVerifiedManually !== undefined)
    newPatient.isVerifiedManually = isVerifiedManually;
  if (lastVerified !== undefined) newPatient.lastVerified = lastVerified;
  if (remainingBenefits !== undefined)
    newPatient.remainingBenefits = remainingBenefits;
  if (effectiveDateFrom && !isEmpty(effectiveDateFrom))
    newPatient.effectiveDateFrom = `${new Date(effectiveDateFrom)}` || null;
  if (effectiveEndDate && !isEmpty(effectiveEndDate))
    newPatient.effectiveEndDate = `${new Date(effectiveEndDate)}` || null;
  if (gender != undefined) newPatient.gender = gender;

  // if (insuranceDateOfBirth && !isEmpty(insuranceDateOfBirth))
  //   newPatient.insuranceDateOfBirth = new Date(insuranceDateOfBirth) || null;

  // if (insuranceLastName !== undefined)
  //   newPatient.insuranceLastName = insuranceLastName;

  if (email !== undefined) newPatient.email = email;
  if (appointmentRenderingProvider !== undefined)
    newPatient.appointmentRenderingProvider =
      appointmentRenderingProvider || null;
  if (empenrollmentstatus != undefined)
    newPatient.empenrollmentstatus = empenrollmentstatus;
  if (employeeId != undefined) newPatient.employeeId = employeeId;
  if (employerId != undefined) newPatient.employerId = employerId;
  if (empemail != undefined) newPatient.empemail = empemail;
  if (empWirelessPhone != undefined)
    newPatient.empWirelessPhone = empWirelessPhone;
  if (empAddress != undefined) newPatient.empAddress = empAddress;
  if (empAddress2 != undefined) newPatient.empAddress2 = empAddress2;
  if (empCity != undefined) newPatient.empCity = empCity;
  if (empZip != undefined) newPatient.empZip = empZip;
  if (empState != undefined) newPatient.empState = empState;
  if (empWebSite != undefined) newPatient.empWebSite = empWebSite;
  if (medicaidId != undefined) newPatient.medicaidId = medicaidId;
  return newPatient;
}

module.exports.getPatientById = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { patientId, isScheduled } = req.query;
  try {
    if (isScheduled) {
      const patient = await models.SchedulePatients.findByPk(patientId);
      res.status(200).send({
        data: patient,
        message: "patient details fetched",
      });
    } else {
      const patient = await models.ManualPatients.findByPk(patientId);
      res.status(200).send({
        data: patient,
        message: "patient details fetched",
      });
    }
  } catch (error) {
    res.status(400).send({ error: error, message: "patient fetch failed" });
  }
};

const verifyPatient = async (newPatientData) => {
  const { payloadData, adminId } = newPatientData;
  const verificationStartDate = new Date();
  const res = await axios.post(DentalExchangeApiPath, payloadData, {
    headers: headers,
  });
  const verificationData = {
    ...res.data.response,
    patientId: (newPatientData && newPatientData.patientId) || "",
    adminId: adminId,
    verificationType: "onAdd",
    status: res?.data?.status || null,
    verificationStartDate,
  };
  return verificationData;
};

const deleteOldestEligibility = async (
  sixthOldestRecord,
  deletedEligibilityId,
  t
) => {
  await sixthOldestRecord.destroy({ transaction: t });
  await models.ECoInsurance.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });
  await models.EPatient.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });
  await models.EPayer.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });

  await models.EDeductible.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });

  await models.ESubscriber.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });

  await models.ELimitationMaximum.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });

  await models.ENotCovered.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });
  await models.EActiveCoverages.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });
  await models.ENotesAndRemark.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });
  await models.EMiscellaneous.destroy({
    where: {
      eligibilityId: deletedEligibilityId,
    },
    transaction: t,
  });
};

const createSubEligibilityDatas = async (
  verificationData,
  newEligibility,
  eligibilityId,
  t,
  adminSettings
) => {
  const {
    patientId,
    coInsurance,
    payer,
    subscriber,
    patient,
    deductible,
    limitationAndMaximum,
    notCovered,
    notesAndRemarks,
    activeCoverage,
    copayment,
  } = verificationData;

  const { ishistory } = adminSettings;

  let updatedcoInsurance = [];
  let updatedCopayment = [];

  //coInsurance and copayment creation
  if (newEligibility?.coInsurance?.length > 0) {
    updatedcoInsurance = coInsurance.map((data) => {
      data.type = "CoInsurance";
      return { ...data, patientId, eligibilityId };
    });
  }
  if (newEligibility?.copayment?.length > 0) {
    updatedCopayment = copayment.map((data) => {
      data.type = "CoPayment";
      return { ...data, patientId, eligibilityId };
    });
  }

  const updatedcoInsuranceData = [...updatedcoInsurance, ...updatedCopayment];

  //* E-CoInsurance Creation
  if (ishistory) {
    updatedcoInsuranceData.length > 0 &&
      (await models.ECoInsurance.bulkCreate(updatedcoInsuranceData, {
        transaction: t,
      }));
  } else {
    const exisitingCoInsurance = await models.ECoInsurance.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
      raw: true,
    });
    if (exisitingCoInsurance.length > 0) {
      await models.ECoInsurance.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      }).then(async () => {
        updatedcoInsuranceData.length > 0 &&
          (await models.ECoInsurance.bulkCreate(updatedcoInsuranceData, {
            transaction: t,
          }));
      });
    } else {
      updatedcoInsuranceData.length > 0 &&
        (await models.ECoInsurance.bulkCreate(updatedcoInsuranceData, {
          transaction: t,
        }));
    }
  }

  //* E-Patient Creation
  const updatedpatientData = { ...patient, eligibilityId, patientId };

  if (patient.dateOfBirth && patient.dateOfBirth != "") {
    updatedpatientData.dateOfBirth = moment(new Date(patient.dateOfBirth));
  } else updatedpatientData.dateOfBirth = null;
  if (ishistory) {
    await models.EPatient.create(updatedpatientData, {
      transaction: t,
    });
  } else {
    const exisitingpatient = await models.EPatient.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
    });

    if (exisitingpatient.length > 0) {
      await models.EPatient.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          await models.EPatient.create(updatedpatientData, {
            transaction: t,
          });
        })
        .catch((err) => console.log(err, "<---427"));
    } else {
      updatedpatientData &&
        (await models.EPatient.create(updatedpatientData, {
          transaction: t,
        }));
    }
  }

  //** */

  //* E- Payer Creation
  const updatedpayerData = { ...payer, eligibilityId };
  updatedpayerData.payerId = payer?.id;
  updatedpayerData.patientId = patientId;
  delete updatedpayerData.id;
  if (ishistory) {
    await models.EPayer.create(updatedpayerData, {
      transaction: t,
    });
  } else {
    const exisitingpayer = await models.EPayer.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
    });

    if (exisitingpayer.length > 0) {
      await models.EPayer.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          await models.EPayer.create(updatedpayerData, {
            transaction: t,
          });
        })
        .catch((err) => console.log(err));
    } else {
      updatedpayerData &&
        (await models.EPayer.create(updatedpayerData, {
          transaction: t,
        }));
    }
  }

  //** */
  //* E-Deductible Creation
  const updateddeductible =
    newEligibility.deductible.length > 0 &&
    deductible.map((data) => {
      return { ...data, patientId, eligibilityId };
    });
  if (ishistory) {
    newEligibility.deductible.length > 0 &&
      (await models.EDeductible.bulkCreate(updateddeductible, {
        transaction: t,
      }));
  } else {
    const exisitingdeductible = await models.EDeductible.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
    });

    if (exisitingdeductible.length > 0) {
      await models.EDeductible.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          newEligibility.deductible.length > 0 &&
            (await models.EDeductible.bulkCreate(updateddeductible, {
              transaction: t,
            }));
        })
        .catch((err) => console.log(err));
    } else {
      newEligibility.deductible.length > 0 &&
        (await models.EDeductible.bulkCreate(updateddeductible, {
          transaction: t,
        }));
    }
  }
  //** */
  //* E-Subscriber Creation
  const updatedsubscriberDetails = {
    ...subscriber,
    patientId,
    eligibilityId,
  };
  if (subscriber.dateOfBirth && subscriber.dateOfBirth != "") {
    updatedsubscriberDetails.dateOfBirth = moment(
      new Date(patient.dateOfBirth)
    );
  } else updatedsubscriberDetails.dateOfBirth = null;

  if (ishistory) {
    await models.ESubscriber.create(updatedsubscriberDetails, {
      transaction: t,
    });
  } else {
    const exisitingsubscriber = await models.ESubscriber.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
    });

    if (exisitingsubscriber.length > 0) {
      await models.ESubscriber.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          await models.ESubscriber.create(updatedsubscriberDetails, {
            transaction: t,
          });
        })
        .catch((err) => console.log(err));
    } else {
      updatedsubscriberDetails &&
        (await models.ESubscriber.create(updatedsubscriberDetails, {
          transaction: t,
        }));
    }
  }
  //** */

  //* E Limitation and Maximum Creation
  const updatedlimitationAndMaximum =
    newEligibility.limitationAndMaximum.length > 0 &&
    limitationAndMaximum.map((data) => {
      return { ...data, patientId, eligibilityId };
    });

  if (ishistory) {
    newEligibility.limitationAndMaximum.length > 0 &&
      (await models.ELimitationMaximum.bulkCreate(updatedlimitationAndMaximum, {
        transaction: t,
      }));
  } else {
    const exisitinglimitationAndMaximum =
      await models.ELimitationMaximum.findAll({
        where: {
          patientId: patientId,
        },
        transaction: t,
      });

    if (exisitinglimitationAndMaximum.length > 0) {
      await models.ELimitationMaximum.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          newEligibility.limitationAndMaximum.length > 0 &&
            (await models.ELimitationMaximum.bulkCreate(
              updatedlimitationAndMaximum,
              {
                transaction: t,
              }
            ));
        })
        .catch((err) => console.log(err));
    } else {
      newEligibility.limitationAndMaximum.length > 0 &&
        (await models.ELimitationMaximum.bulkCreate(
          updatedlimitationAndMaximum,
          {
            transaction: t,
          }
        ));
    }
  }
  //** */

  //* E-Notcovered creation
  const updatednotCovered =
    newEligibility.notCovered.length > 0 &&
    notCovered.map((data) => {
      return { ...data, patientId, eligibilityId };
    });

  if (ishistory) {
    newEligibility.notCovered.length > 0 &&
      (await models.ENotCovered.bulkCreate(updatednotCovered, {
        transaction: t,
      }));
  } else {
    const exisitingnotCovered = await models.ENotCovered.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
    });

    if (exisitingnotCovered.length > 0) {
      await models.ENotCovered.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          newEligibility.notCovered.length > 0 &&
            (await models.ENotCovered.bulkCreate(updatednotCovered, {
              transaction: t,
            }));
        })
        .catch((err) => console.log(err));
    } else {
      newEligibility.notCovered.length > 0 &&
        (await models.ENotCovered.bulkCreate(updatednotCovered, {
          transaction: t,
        }));
    }
  }

  //** */
  //* E-Active Coverage Creation
  const updatedactiveCoverage =
    newEligibility.activeCoverage.length > 0 &&
    activeCoverage.map((data) => {
      return { ...data, patientId, eligibilityId };
    });

  if (ishistory) {
    newEligibility.activeCoverage.length > 0 &&
      (await models.EActiveCoverages.bulkCreate(updatedactiveCoverage, {
        transaction: t,
      }));
  } else {
    const exisitingactiveCoverage = await models.EActiveCoverages.findAll({
      where: {
        patientId: patientId,
      },
      transaction: t,
    });

    if (exisitingactiveCoverage.length > 0) {
      await models.EActiveCoverages.destroy({
        where: {
          patientId: patientId,
        },
        transaction: t,
      })
        .then(async () => {
          newEligibility.activeCoverage.length > 0 &&
            (await models.EActiveCoverages.bulkCreate(updatedactiveCoverage, {
              transaction: t,
            }));
        })
        .catch((err) => console.log(err));
    } else {
      newEligibility.activeCoverage.length > 0 &&
        (await models.EActiveCoverages.bulkCreate(updatedactiveCoverage, {
          transaction: t,
        }));
    }
  }
};

module.exports.verifyPatients = verifyPatient;
//second callback
const createEligibility = async (verificationData, response) => {
  const {
    patientId,
    coInsurance,
    payer,
    subscriber,
    patient,
    planBenefits,
    deductible,
    limitationAndMaximum,
    notCovered,
    limitations,
    miscellaneous,
    notesAndRemarks,
    activeCoverage,
    copayment,
    errors,
    adminId,
  } = verificationData;

  const eligibilityId = await generateEligibilityId();

  const newEligibility = {
    patientId,
    adminId,
    uniqueId: uuidv4(),
    verificationType: "onAdd",
    lastVerified: `${new Date()}`,
    coInsurance: coInsurance || [],
    payer: payer || {},
    deductible: deductible || [],
    subscriber: subscriber || {},
    limitationAndMaximum: limitationAndMaximum || [],
    notCovered: notCovered || [],
    limitations: limitations || [],
    miscellaneous: miscellaneous || [],
    notesAndRemarks: notesAndRemarks || [],
    activeCoverage: activeCoverage || [],
    copayment: copayment || [],
    errors: errors || [],
    patient: patient || [],
  };
  let resultantData = null;
  try {
    if (verificationData?.status?.code === 0) {
      await db.sequelize.transaction(async (t) => {
        if (limitationAndMaximum && limitationAndMaximum.length > 0) {
          limitationAndMaximum.forEach((limits) => {
            if (
              limits &&
              limits?.limitation &&
              Array.isArray(limits.limitation)
            )
              limits.limitation = limits.limitation[0];
          });
        }

        const adminSettings = await models.GeneralSettings.findOne({
          where: {
            adminId,
          },
          attributes: ["adminId", "ishistory"],
          raw: true,
        });

        let response = {};

        //** */ Patient Eligiibility Creation
        if (adminSettings?.ishistory) {
          response = await models.PatientEligibility.create(
            {
              ...newEligibility,
              eligibilityId,
            },
            {
              transaction: t,
            }
          );
        } else {
          const existingData = await models.PatientEligibility.findAll({
            where: {
              patientId,
            },
            raw: true,
          });

          if (existingData?.length > 0) {
            await models.PatientEligibility.destroy({
              where: {
                patientId: patientId,
              },
              transaction: t,
            }).then(async () => {
              response = await models.PatientEligibility.create(
                {
                  ...newEligibility,
                  eligibilityId,
                },
                {
                  transaction: t,
                }
              );
            });
          }
        }

        const allEligibilities = await models.PatientEligibility.findAll({
          where: { patientId: patientId },
          raw: true,
          transaction: t,
        });

        if (allEligibilities.length > 5) {
          const sixthOldestRecord = await models.PatientEligibility.findOne({
            where: { patientId: patientId },
            attributes: [
              "patientId",
              "eligibilityId",
              "createdAt",
              "updatedAt",
              "id",
              "uniqueId",
            ],
            order: [["createdAt", "ASC"]],
            transaction: t,
          });
          if (!isEmpty(sixthOldestRecord)) {
            const deletedEligibilityId = sixthOldestRecord.eligibilityId;

            await deleteOldestEligibility(
              sixthOldestRecord,
              deletedEligibilityId,
              t
            );
          }
        }

        await createSubEligibilityDatas(
          verificationData,
          newEligibility,
          eligibilityId,
          t,
          adminSettings
        );
        resultantData = response?.dataValues
          ? response?.dataValues
          : verificationData;
      });
      return resultantData;
    } else {
      return verificationData;
    }
  } catch (e) {
    console.log(e, "<-----824");
    throw e; // Propagate the error up
  }
};

//Third callback
const updatePatientAfterVerify = async (
  createdEligibility,
  isScheduled,
  isFailed
) => {
  const { patientId } = createdEligibility;
  const updatePatientData = {};
  let resultdata = {};

  if (typeof createdEligibility?.errors === "string")
    createdEligibility.errors = JSON.parse(createdEligibility?.errors);

  if (isFailed) {
    updatePatientData.isVerified = false;
    updatePatientData.lastVerified = `${new Date()}`;

    updatePatientData.verificationError =
      createdEligibility?.status?.description;

    updatePatientData.verificationErrCode =
      createdEligibility?.status?.code || "2001";

    updatePatientData.verificationErrMessages =
      createdEligibility?.errors || null;

    const upsertData = createOrUpdateEligibilityData(
      resultdata,
      updatePatientData,
      patientId,
      isScheduled
    );
    return upsertData;
  }

  const remainingBenefits = {
    limitationAndMaximum: createdEligibility?.limitationAndMaximum,
    deductible: createdEligibility?.deductible,
    limitations: createdEligibility?.limitations,
    maximum: createdEligibility?.maximum,
  };
  let parsedPatient = "";
  if (
    createdEligibility?.patient &&
    typeof createdEligibility?.patient === "string"
  )
    parsedPatient = JSON.parse(createdEligibility?.patient);
  else parsedPatient = createdEligibility?.patient;
  const effectiveDateFrom = parsedPatient?.plan?.effectiveDateFrom || null;
  const effectiveEndDate = parsedPatient?.plan?.effectiveDateTo || null;

  updatePatientData.remainingBenefits = remainingBenefits;
  updatePatientData.effectiveDateFrom = effectiveDateFrom;
  updatePatientData.effectiveEndDate = effectiveEndDate;
  updatePatientData.isVerified = true;
  updatePatientData.verificationError = null;
  updatePatientData.verificationErrCode = null;
  updatePatientData.verificationErrMessages = null;

  if (typeof createdEligibility?.errors === "string") {
    createdEligibility.errors = JSON.parse(createdEligibility?.errors);
  }

  if (createdEligibility?.errors?.length > 0) {
    updatePatientData.verificationErrMessages =
      createdEligibility?.errors || null;
    updatePatientData.isVerified = false;
    updatePatientData.effectiveDateFrom = null;
    updatePatientData.verificationErrCode = "2001";
  }

  updatePatientData.lastVerified = `${new Date()}`;
  updatePatientData.statusflag = "A";
  updatePatientData.eligibilityId = createdEligibility.eligibilityId;

  const upsertData = await createOrUpdateEligibilityData(
    resultdata,
    updatePatientData,
    patientId,
    isScheduled
  );
  return upsertData;
};

const createOrUpdateEligibilityData = async (
  resultdata,
  updatePatientData,
  patientId,
  isScheduled
) => {
  try {
    let result = null;
    if (isScheduled) {
      updatePatientData.isScheduled = true;
      await models.SchedulePatients.update(updatePatientData, {
        where: {
          patientId: patientId,
        },
      })
        .then(async (data) => {
          //fifth  callback
          resultdata = await models.SchedulePatients.findByPk(patientId);
          result = resultdata;
          return resultdata;
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      await models.ManualPatients.update(updatePatientData, {
        where: {
          patientId: patientId,
        },
      })
        .then(async (data) => {
          //fifth  callback
          resultdata = await models.ManualPatients.findByPk(patientId, {
            raw: true,
          });
          result = resultdata;
          return resultdata;
        })
        .catch((err) => {
          console.log(err);
        });
    }

    return result;
  } catch (error) {
    console.log(error);
  }
};

module.exports.getCoinsurance = async (req, res) => {
  try {
    const ins = await models.ECoInsurance.findAll({
      where: {
        patientId: req.params.id,
      },
    });

    res.status(200).send({ data: ins, message: "Success" });
  } catch (error) {
    res.status(400).send({ error: error, message: "patient update failed" });
  }
};

module.exports.addPatient = async (req, res) => {
  // #swagger.tags = ['Patients']
  const eligibilityId = await generateEligibilityId();
  const uniqueId = uuidv4();
  const patientId = await generatePatientId();
  const {
    addedFrom,
    adminId,
    verificationType,
    statusflag,
    firstName,
    lastName,
    dateOfBirth,
    memberId,
    groupId,
    relationship,
    procedureCode,
    procedureType,
    provider,
    providerFirstName,
    providerLastName,
    providerNpi,
    providerTaxId,
    insurancePayer,
    payerIdCode,
    dependentFirstName,
    dependentLastName,
    dependentDateOfBirth,
    typeOfService,
    practiceNameAndLoc,
    appointmentType,
    scheduleAppointment,
    speciality,
    isVerified,
    isVerifiedManually,
    lastVerified,
    remainingBenefits,
    effectiveDateFrom,
    effectiveEndDate,
    gender,
    insuranceDateOfBirth,
    insuranceLastName,
    email,
    appointmentRenderingProvider,
    empenrollmentstatus,
    employerId,
    employeeId,
    empnetworkstatus,
    empemail,
    empWirelessPhone,
    empAddress,
    empAddress2,
    empCity,
    empZip,
    empState,
    empWebSite,
    medicaidId,
    medical,
    dental,
    others,
    primary,
    secondary,
    tertiary,
  } = req.body;
  const body = {
    addedFrom,
    adminId,
    verificationType,
    statusflag,
    firstName,
    lastName,
    memberId,
    groupId,
    relationship,
    procedureCode,
    procedureType,
    provider,
    providerFirstName,
    providerLastName,
    providerNpi,
    providerTaxId,
    insurancePayer,
    payerIdCode,
    dependentFirstName,
    dependentLastName,
    typeOfService,
    practiceNameAndLoc,
    appointmentType,
    speciality,
    isVerified,
    isVerifiedManually,
    lastVerified,
    remainingBenefits,
    effectiveDateFrom,
    effectiveEndDate,
    gender,
    insuranceLastName,
    email,
    appointmentRenderingProvider,
    empenrollmentstatus,
    employerId,
    employeeId,
    empnetworkstatus,
    empemail,
    empWirelessPhone,
    empAddress,
    empAddress2,
    empCity,
    empZip,
    empState,
    empWebSite,
    medicaidId,
    medical,
    dental,
    others,
    primary,
    secondary,
    tertiary,
  };
  if (scheduleAppointment && scheduleAppointment != "")
    body["scheduleAppointment"] = moment(new Date(scheduleAppointment));
  else body["scheduleAppointment"] = null;

  if (insuranceDateOfBirth && insuranceDateOfBirth != "")
    body["insuranceDateOfBirth"] = moment(new Date(insuranceDateOfBirth));
  else body["insuranceDateOfBirth"] = null;

  if (dependentDateOfBirth && dependentDateOfBirth != "")
    body["dependentDateOfBirth"] = moment(new Date(dependentDateOfBirth));
  else body["dependentDateOfBirth"] = null;

  if (dateOfBirth && dateOfBirth != "")
    body["dateOfBirth"] = moment(new Date(dateOfBirth));
  else body["dateOfBirth"] = null;
  const userNotifications = await models.UserNotification.findAll({
    raw: true,
  });
  const patientNotifications = await models.PatientNotification.findAll({
    raw: true,
  });
  let patientmanualnotify = null;
  let usermanualNotify = null;
  const getNotification = (notifications, typeofnotify) =>
    notifications &&
    notifications.find(
      (notification) => notification.typeofnotify === typeofnotify
    );
  patientmanualnotify = getNotification(patientNotifications, "manual");
  usermanualNotify = getNotification(userNotifications, "manual");
  const newPatient = createorupdatePatients(body, patientId, uniqueId);
  const data = { ...newPatient };

  const payloadData = {
    provider: {
      type: "1",
      firstName: (data && data.providerFirstName) || "",
      lastName: (data && data.providerLastName) || "",
      npi: (data && data.providerNpi) || "",
      taxId: (data && data.providerTaxId) || "",
    },
    payer: {
      name: (data && data.insurancePayer) || "",
      payerIdCode: (data && data.payerIdCode) || "",
    },
    patient: {
      dateOfBirth:
        (data &&
          data.dependentDateOfBirth &&
          moment(new Date(data.dependentDateOfBirth)).format("YYYY-MM-DD")) ||
        "",
      memberId: (data && data.memberId) || "",
      firstName: (data && data.dependentFirstName) || "",
      lastName: (data && data.dependentLastName) || "",
      relationship: (data && data.relationship) || "",
    },
    subscriber: {
      dateOfBirth:
        (data &&
          data.dateOfBirth &&
          moment(new Date(data.dateOfBirth)).format("YYYY-MM-DD")) ||
        "",
      memberId: (data && data.memberId) || "",
      firstName: (data && data.firstName) || "",
      lastName: (data && data.lastName) || "",
    },
  };

  const toVerifyData = {
    payloadData: payloadData || {},
    patientId: data.patientId || "",
    adminId: adminId || "",
  };

  // first callback
  try {
    // await db.sequelize.transaction(async (t) => {
    const verificationData = await verifyPatient(toVerifyData);
    if (
      verificationData &&
      verificationData.status &&
      verificationData.status.code === 0
    ) {
      const remainingBenefits = {
        limitationAndMaximum: verificationData?.limitationAndMaximum,
        deductible: verificationData?.deductible,
        limitations: verificationData?.limitations,
        maximum: verificationData?.maximum,
      };

      let payer = { ...verificationData?.payer };
      payer.payerId = verificationData?.payer?.id || null;
      payer.patientId = patientId;
      payer.eligibilityId = eligibilityId;
      delete payer?.id;

      const coInsuranceData =
        verificationData?.coInsurance &&
        verificationData?.coInsurance.map((data) => {
          return { ...data, patientId, eligibilityId };
        });
      const deductibleData =
        verificationData?.deductible &&
        verificationData?.deductible.map((data) => {
          return { ...data, patientId, eligibilityId };
        });
      const limitationAndMaximumData =
        verificationData?.limitationAndMaximum &&
        verificationData?.limitationAndMaximum.map((data) => {
          return { ...data, patientId, eligibilityId };
        });
      // const miscellaneousData =
      //   verificationData?.miscellaneous &&
      //   verificationData?.miscellaneous.map((data) => {
      //     return { ...data, patientId };
      //   });
      const notCoveredData =
        verificationData?.notCovered &&
        verificationData?.notCovered.map((data) => {
          return { ...data, patientId, eligibilityId };
        });
      data.ECoInsurances = coInsuranceData;
      data.EADAProcedures = coInsuranceData;
      // data.EBenefitHistories = verificationData?.coInsurance;
      data.EDeductibles = deductibleData;
      data.ELimitationMaximums = limitationAndMaximumData;
      // data.EMiscellaneous = miscellaneousData;
      data.ENotCovereds = notCoveredData;
      // data.ENotesAndRemarks = verificationData?.notCovered;

      const updatedpatientData = {
        ...verificationData?.patient,
        eligibilityId,
        patientId,
      };

      if (
        verificationData?.patient.dateOfBirth &&
        verificationData?.patient.dateOfBirth != ""
      ) {
        updatedpatientData.dateOfBirth = moment(
          new Date(verificationData?.patient.dateOfBirth)
        );
      } else updatedpatientData.dateOfBirth = null;

      data.EPatients = updatedpatientData;
      data.EPayers = payer;
      data.EPlanBenfits = {
        ...verificationData?.planBenefits,
        eligibilityId,
      };

      const updatedsubscriberDetails = {
        ...verificationData?.subscriber,
        patientId,
        eligibilityId,
      };

      if (
        verificationData?.subscriber.dateOfBirth &&
        verificationData?.subscriber.dateOfBirth != ""
      ) {
        updatedsubscriberDetails.dateOfBirth = moment(
          new Date(verificationData?.subscriber.dateOfBirth)
        );
      } else updatedsubscriberDetails.dateOfBirth = null;

      data.ESubscribers = updatedsubscriberDetails;
      const effectiveDateFrom =
        verificationData?.patient?.plan?.effectiveDateFrom || null;

      const effectiveEndDate =
        verificationData?.patient?.plan?.effectiveDateTo || null;

      data.eligibilityId = eligibilityId;
      data.remainingBenefits = remainingBenefits;
      data.effectiveDateFrom = effectiveDateFrom;
      data.effectiveEndDate = effectiveEndDate;
      data.lastVerified = `${new Date()}`;
      data.statusflag = "A";
      data.isVerified = true;
      data.verificationError = null;
      data.verificationErrCode = null;
      data.verificationErrMessages = null;
      if (typeof verificationData?.errors === "string")
        verificationData.errors = JSON.parse(verificationData?.errors);
      if (verificationData?.errors?.length > 0) {
        data.verificationErrMessages = verificationData?.errors || [];
        data.isVerified = false;
        data.verificationErrCode = "2001";
      }
      if (data.isVerified) {
        let patverified =
          JSON.parse(patientmanualnotify?.notifyinapp || "[]").includes(
            "success"
          ) || false;
        let usrverified =
          JSON.parse(usermanualNotify?.notifyinapp || "[]").includes(
            "success"
          ) || false;
        if (usrverified && usermanualNotify.isinapp) {
          const { subject } = successMail();
          let notificationData = {
            patientId: data.patientId,
            patientName: data.firstName + " " + data.lastName,
            message: subject,
            isSuccess: true,
            adminId: adminId,
          };
          await createNotification(notificationData);
          // Notification Create along with its Template
        }
        if (usrverified && usermanualNotify.isemail) {
          const { subject, text } = successMail();
          await sendEmail(subject, text, data.firstName, data.lastName);
          // Send an Email to User{Admin} along with its template
        } // Email to be sent to PatientNotification
        if (usrverified && usermanualNotify.issms) {
          // Send an SMS to user (Admin) along with templae
        }
        if (patverified && patientmanualnotify.isemail) {
          const { subject, text } = successMail();
          await sendEmail(subject, text, data.firstName, data.lastName);
          // Send an Email to patient  along with its template - - {response?.dataValues.emailId}
        }
        if (patverified && patientmanualnotify.issms) {
          // Send an SMS to patient along with template - {response?.dataValues.WirelessPhone}
        }
      } else {
        sendnotifications(
          null,
          usermanualNotify,
          patientmanualnotify,
          data,
          data.verificationErrCode
        );
      }

      const subModelCreations = {
        include: [
          models.ECoInsurance,
          // models.EActiveCoverages,
          models.EADAProcedure,
          // models.EBenefitHistory,
          models.EDeductible,
          models.ELimitationMaximum,
          // models.EMiscellaneous,
          models.ENotCovered,
          // models.ENotesAndRemark,
          models.EPatient,
          models.EPayer,
          models.EPlanBenfit,
          models.ESubscriber,
        ],
        // transaction: t
      };
      data.adminId = adminId;
      if (effectiveDateFrom === null) {
        data.lastVerified = `${new Date()}`;
        data.statusflag = "A";
        data.isVerified = false;
        data.verificationError =
          "Payer is currently experiencing problems and is unable to respond, please try again later.";
        data.verificationErrCode = "2010";
        data.verificationErrMessages = null;
        data.remainingBenefits = null;
      }

      const newPatient = await models.ManualPatients.create(
        data,
        subModelCreations
      );

      if (effectiveDateFrom === null) {
        await logaudit(
          "Technical Error",
          data?.patientId,
          data?.addedFrom,
          newPatient?.addedFrom,
          data?.scheduleAppointment,
          newPatient?.lastVerified,
          verificationData?.verificationStartDate,
          newPatient?.lastVerified,
          adminId,
          newPatient?.createdAt
        );
        return res.status(400).send({
          checkEligibilityPayload: payloadData,
          error: "Effective date null",
          verificationData,
          message:
            "Patient Created Succesfully but Eligibility Verification failed",
        });
      }
      const newEligibility = await models.PatientEligibility.create({
        ...verificationData,
        adminId,
        eligibilityId,
      });

      // console.log("success", data?.patientId, "<---1404");
      await logaudit(
        "Success",
        data?.patientId,
        data?.addedFrom,
        newPatient?.addedFrom,
        data?.scheduleAppointment,
        newPatient?.lastVerified,
        verificationData?.verificationStartDate,
        newPatient?.lastVerified,
        adminId,
        newPatient?.createdAt
      );
      return res.status(200).send({
        data: {
          checkEligibilityPayload: payloadData,
          newPatient,
          newEligibility,
        },
        message: "Success",
      });
    } else {
      data.lastVerified = `${new Date()}`;
      data.statusflag = "A";
      data.isVerified = false;
      data.verificationError = verificationData.status.description || null;
      data.verificationErrCode = verificationData.status.code || null;
      data.verificationErrMessages = null;

      sendnotifications(
        null,
        usermanualNotify,
        patientmanualnotify,
        data,
        verificationData.status.code
      );
      updatePatientModels(data, patientId);
      return res.status(400).send({
        checkEligibilityPayload: payloadData,
        error: verificationData.status,
        verificationData,
        message:
          "Patient Created Succesfully but Eligibility Verification failed",
      });
    }
  } catch (error) {
    if (newPatient && newPatient.uniqueId) {
      data.isVerified = false;
      data.lastVerified = `${new Date()}`;
      if (error?.response && error?.response?.data) {
        data.verificationError =
          error?.response?.data?.status?.description || null;
        data.verificationErrCode = error?.response?.data?.status?.code || null;
        data.verificationErrMessages = error?.response?.data?.messages || null;
      }
      sendnotifications(
        error,
        usermanualNotify,
        patientmanualnotify,
        data,
        error?.response?.data?.status?.code
      );
      updatePatientModels(data, patientId)
        .then(async () => {
          return res.status(400).send({
            checkEligibilityPayload: payloadData,
            error: error,
            verificationData,
            message:
              "Patient Created Succesfully but Eligibility Verification failed",
          });
        })
        .catch(async (err) => {
          let logMessage = getAuditLogErrorMessage(
            `${data?.verificationErrCode}`
          );
          await logaudit(
            logMessage,
            data?.patientId,
            data?.addedFrom,
            data?.addedFrom,
            data?.scheduleAppointment,
            data?.lastVerified,
            new Date(), // verification start date
            data?.lastVerified,
            adminId,
            data?.createdAt
          );
          return res.status(400).send({
            checkEligibilityPayload: payloadData,
            error: err,
            message:
              "Patient Created Succesfully but Eligibility Verification failed",
          });
        });
    } else {
      await logaudit(
        "Technical Error",
        data?.patientId,
        data?.addedFrom,
        data?.addedFrom,
        data?.scheduleAppointment,
        data?.lastVerified,
        data?.lastVerified,
        adminId,
        data?.createdAt
      );

      return res.status(400).send({
        checkEligibilityPayload: payloadData,
        error: error,
        message: "patient update failed",
      });
    }
  }
};

async function updatePatientModels(data, patientId) {
  const patientData = await models.ManualPatients.findByPk(patientId);
  if (patientData) {
    await models.ManualPatients.update(data)
      .then((data) => {
        console.log(data);
      })
      .catch((err) => {
        throw err;
      });
  } else {
    await models.ManualPatients.create(data)
      .then((data) => {
        console.log(data);
      })
      .catch((err) => {
        throw err;
      });
  }
}

module.exports.updatePatient = async (req, res) => {
  // #swagger.tags = ['Patients']
  let notificationData = null;
  let {
    addedFrom,
    uniqueId,
    patientId,
    isScheduled,
    firstName,
    lastName,
    adminId,
    dateOfBirth,
    groupId,
    memberId,
    relationship,
    procedureCode,
    procedureType,
    provider,
    insurancePayer,
    payerIdCode,
    statusflag,
    subscriberFirstName,
    subscriberLastName,
    dependentFirstName,
    dependentLastName,
    insurancePhoneNumber,
    EmployerNum,
    email,
    planType,
    WirelessPhone,
    subscriberZip,
    subscriberState,
    subscriberCity,
    subscriberAddress1,
    subscriberDateOfBirth,
    subscriberAddress,
    employerId,
    employeeId,
    empnetworkstatus,
    empemail,
    isexclude,
    dependentDateOfBirth,
    verificationType,
    typeOfService,
    practiceNameAndLoc,
    appointmentType,
    scheduleAppointment,
    speciality,
    appointmentRenderingProvider,
    providerNpi,
    providerTaxId,
    providerFirstName,
    providerLastName,
    insuranceLastName,
    insuranceDateOfBirth,
    subscriberId,
    gender,
    EmpName,
    empAddress,
    empAddress2,
    empCity,
    empState,
    empWebSite,
    empWirelessPhone,
    empZip,
    empenrollmentstatus,
    State,
    Zip,
    effectiveDateFrom,
    effectiveEndDate,
    City,
    Address2,
    Address,
  } = req.body;

  const updateOpendentalPatient = async () => {
    const updateBody = {};
    if (lastName) updateBody.LName = lastName;
    if (firstName) updateBody.FName = firstName;
    if (dateOfBirth && dateOfBirth != "")
      updateBody.Birthdate = moment(new Date(dateOfBirth));

    try {
      await axios.put(
        `${OpenDentalApiPath}/patients/${patientId}`,
        updateBody,
        {
          headers: {
            Authorization: OpenDentalAuthorization,
          },
        }
      );
    } catch (error) {
      console.log(error?.response, "<----1418");
    }
  };

  try {
    let updatePatient = {
      addedFrom,
      uniqueId,
      patientId,
      isScheduled,
      firstName,
      lastName,
      adminId,
      dateOfBirth,
      groupId,
      memberId,
      relationship,
      procedureCode,
      procedureType,
      provider,
      insurancePayer,
      payerIdCode,
      statusflag,
      subscriberFirstName,
      subscriberLastName,
      dependentFirstName,
      dependentLastName,
      insurancePhoneNumber,
      EmployerNum,
      email,
      planType,
      WirelessPhone,
      subscriberZip,
      subscriberState,
      subscriberCity,
      subscriberAddress1,
      subscriberDateOfBirth,
      subscriberAddress,
      employerId,
      employeeId,
      empnetworkstatus,
      empemail,
      isexclude,
      dependentDateOfBirth,
      verificationType,
      typeOfService,
      practiceNameAndLoc,
      appointmentType,
      scheduleAppointment,
      speciality,
      appointmentRenderingProvider,
      providerNpi,
      providerTaxId,
      providerFirstName,
      providerLastName,
      insuranceLastName,
      insuranceDateOfBirth,
      subscriberId,
      gender,
      EmpName,
      empAddress,
      empAddress2,
      empCity,
      empState,
      empWebSite,
      empWirelessPhone,
      empZip,
      empenrollmentstatus,
      State,
      Zip,
      effectiveDateFrom,
      effectiveEndDate,
      City,
      Address2,
      Address,
    };
    const userNotifications = await models.UserNotification.findAll({
      raw: true,
    });
    userupdateNotify =
      userNotifications &&
      userNotifications.filter(
        (notification) => notification.typeofnotify === "ispatientupdate"
      )[0];
    if (scheduleAppointment && scheduleAppointment != "")
      updatePatient["scheduleAppointment"] = moment(
        new Date(scheduleAppointment)
      );
    else updatePatient["scheduleAppointment"] = null;
    if (insuranceDateOfBirth && insuranceDateOfBirth != "")
      updatePatient["insuranceDateOfBirth"] = moment(
        new Date(insuranceDateOfBirth)
      );
    else updatePatient["insuranceDateOfBirth"] = null;
    if (dependentDateOfBirth && dependentDateOfBirth != "")
      updatePatient["dependentDateOfBirth"] = moment(
        new Date(dependentDateOfBirth)
      );
    else updatePatient["dependentDateOfBirth"] = null;

    if (dateOfBirth && dateOfBirth != "")
      updatePatient["dateOfBirth"] = moment(new Date(dateOfBirth));
    else updatePatient["dateOfBirth"] = null;

    if (req?.body?.isScheduled?.toString() === "true") {
      await updateOpendentalPatient();
      const updatedPatient = await models.SchedulePatients.update(
        updatePatient,
        {
          where: { uniqueId: uniqueId },
          returning: true,
        }
      );
      if (
        JSON.parse(userupdateNotify.notifyinapp).includes("opendental") &&
        updatedPatient &&
        updatedPatient[1] &&
        updatedPatient[1][0] &&
        updatedPatient[1][0].datavalues &&
        updatedPatient[1][0].datavalues.addedFrom.toLowerCase() === "opendental"
      ) {
        if (userupdateNotify.isinapp) {
          const { subject } = updatePatientEmail();
          notificationData = {
            patientId: updatedPatient[1][0].dataValues.patientId,
            patientName:
              updatedPatient[1][0].dataValues.firstName +
              " " +
              updatedPatient[1][0].dataValues.lastName,
            message: subject,
            isPatientUpdate: true,
            adminId: updatedPatient[1][0].dataValues.adminId,
          };
          await createNotification(notificationData);
        }
        if (userupdateNotify.isemail) {
          const { subject, text } = updatePatientEmail();
          await sendEmail(
            subject,
            text,
            updatedPatient[1][0].dataValues.firstName,
            updatedPatient[1][0].dataValues.lastName
          );
        }
        if (userupdateNotify.issms) {
          //text notification trigger for update in opendental patients
        }
      }
      res.status(200).send({
        data: updatedPatient,
        notificationData,
        message: "patient details updated",
      });
    } else {
      const updatedPatient = await models.ManualPatients.update(updatePatient, {
        where: { uniqueId: uniqueId },
        returning: true,
      });
      if (
        (JSON.parse(userupdateNotify.notifyinapp).includes("manual") &&
          updatedPatient &&
          updatedPatient[1] &&
          updatedPatient[1][0] &&
          updatedPatient[1][0].dataValues &&
          updatedPatient[1][0].dataValues.addedFrom === null) ||
        "manual"
      ) {
        if (userupdateNotify.isinapp) {
          const { subject } = updatePatientEmail();
          notificationData = {
            patientId: updatedPatient[1][0].dataValues.patientId,
            patientName:
              updatedPatient[1][0].dataValues.firstName +
              " " +
              updatedPatient[1][0].dataValues.lastName,
            message: subject,
            isPatientUpdate: true,
            adminId: updatedPatient[1][0].dataValues.adminId,
          };
          await createNotification(notificationData);
        }
        if (userupdateNotify.isemail) {
          const { subject, text } = updatePatientEmail();
          await sendEmail(
            subject,
            text,
            updatedPatient[1][0].dataValues.firstName,
            updatedPatient[1][0].dataValues.lastName
          );
        }
        if (userupdateNotify.issms) {
          //text notification trigger for update in opendental patients
        }
      } else {
        if (
          JSON.parse(userupdateNotify.notifyinapp).includes("csv") &&
          updatedPatient &&
          updatedPatient[1] &&
          updatedPatient[1][0] &&
          updatedPatient[1][0].dataValues &&
          updatedPatient[1][0].dataValues.addedFrom === "csv"
        ) {
          if (userupdateNotify.isinapp) {
            const { subject } = updatePatientEmail();
            notificationData = {
              patientId: updatedPatient[1][0].dataValues.patientId,
              patientName:
                updatedPatient[1][0].dataValues.firstName +
                " " +
                updatedPatient[1][0].dataValues.lastName,
              message: subject,
              isPatientUpdate: true,
              adminId: updatedPatient[1][0].dataValues?.adminId,
            };
            await createNotification(notificationData);
          }
          if (userupdateNotify.isemail) {
            const { subject, text } = updatePatientEmail();
            await sendEmail(
              subject,
              text,
              updatedPatient[1][0].dataValues.firstName,
              updatedPatient[1][0].dataValues.lastName
            );
          }
          if (userupdateNotify.issms) {
            //text notification trigger for update in csv imported patients
          }
        }
      }

      res.status(200).send({
        data: updatedPatient,
        notificationData,
        message: "patient details updated 1642",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(400).send({ error: error, message: "patient update failed" });
  }
};

module.exports.addPatientAttachments = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { patientId } = req.params;
  const { fileName, base64File, description, isPatientCard } = req.body;

  const attachment = {
    patientId,
    fileName,
    base64File,
    description,
    isPatientCard,
  };

  try {
    const response = await models.PatientAttachments.create(attachment);
    res.status(200).send({
      data: response?.dataValues,
      message: "patient details updated",
    });
  } catch (error) {
    res.status(400).send({ error: error, message: "patient update failed" });
  }
};

module.exports.getAllPatientAttachments = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { patientId } = req.params;
  try {
    const response = await models.PatientAttachments.findAll({
      where: {
        patientId: patientId,
      },
    });
    const data = response.map((record) => record.get({ plain: true }));

    res.status(200).send({
      data: data,
      message: "patient attachement details fetched",
    });
  } catch (error) {
    res.status(400).send({ error: error, message: "patient update failed" });
  }
};

module.exports.deletePatientAttachments = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { attachmentId } = req.params;
  try {
    //*
    //*** */
    //********* */
    const response = await models.PatientAttachments.destroy({
      where: {
        uniqueId: attachmentId,
      },
    });

    if (response === 0) {
      res.status(404).send({
        message: `Patient attachement ID ${attachmentId} is not found`,
      });
    } else {
      res.status(200).send({
        deletedId: attachmentId,
        message: "Patient attachement deleted successfully",
      });
    }
  } catch (error) {
    console.log(error);
    res
      .status(400)
      .send({ error: error, message: "Patient attachement delete failed" });
  }
};

module.exports.addScheduledPatient = async (req, res) => {
  // #swagger.tags = ['Patients']
  try {
    const isScheduled = true;
    async function generatePatientId() {
      const lastRecord = await models.ManualPatients.findOne({
        order: [["id", "DESC"]],
      });
      const nextId = lastRecord ? lastRecord.id + 1 : 1;
      return "M" + nextId;
    }
    const uniqueId = uuidv4();
    const patientId = await generatePatientId();
    const {
      addedFrom,
      adminId,
      verificationType,
      statusflag,
      firstName,
      lastName,
      dateOfBirth,
      memberId,
      groupId,
      relationship,
      procedureCode,
      procedureType,
      provider,
      providerFirstName,
      providerLastName,
      providerNpi,
      providerTaxId,
      insurancePayer,
      payerIdCode,
      dependentFirstName,
      dependentLastName,
      dependentDateOfBirth,
      typeOfService,
      practiceNameAndLoc,
      appointmentType,
      scheduleAppointment,
      speciality,
      isVerified,
      isVerifiedManually,
      lastVerified,
      remainingBenefits,
      effectiveDateFrom,
      effectiveEndDate,
      gender,
      insuranceDateOfBirth,
      insuranceLastName,
      email,
      appointmentRenderingProvider,
      empenrollmentstatus,
      employerId,
      employeeId,
      empnetworkstatus,
      empemail,
      empWirelessPhone,
      empAddress,
      empAddress2,
      empCity,
      empZip,
      empState,
      empWebSite,
      medicaidId,
      medical,
      dental,
      others,
      primary,
      secondary,
      tertiary,
    } = req.body;
    const body = {
      addedFrom,
      adminId,
      verificationType,
      statusflag,
      firstName,
      lastName,
      dateOfBirth,
      memberId,
      groupId,
      relationship,
      procedureCode,
      procedureType,
      provider,
      providerFirstName,
      providerLastName,
      providerNpi,
      providerTaxId,
      insurancePayer,
      payerIdCode,
      dependentFirstName,
      dependentLastName,
      dependentDateOfBirth,
      typeOfService,
      practiceNameAndLoc,
      appointmentType,
      scheduleAppointment,
      speciality,
      isVerified,
      isVerifiedManually,
      lastVerified,
      remainingBenefits,
      effectiveDateFrom,
      effectiveEndDate,
      gender,
      insuranceDateOfBirth,
      insuranceLastName,
      email,
      appointmentRenderingProvider,
      empenrollmentstatus,
      employerId,
      employeeId,
      empnetworkstatus,
      empemail,
      empWirelessPhone,
      empAddress,
      empAddress2,
      empCity,
      empZip,
      empState,
      empWebSite,
      medicaidId,
      medical,
      dental,
      others,
      primary,
      secondary,
      tertiary,
    };
    const newPatient = createorupdatePatients(
      body,
      patientId,
      uniqueId,
      isScheduled
    );
    const response = await models.SchedulePatients.create(newPatient);

    res.status(200).send({
      data: response,
      message: "Patient Schedule Created ",
    });
  } catch (error) {
    console.log(error);
    res
      .status(400)
      .send({ error: error, message: "Patient Schedule Creation Failed" });
  }
};

module.exports.deletePatients = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { uniqueId, isScheduled } = req.query;

  let notificationData = null;
  let response = null;

  try {
    const userNotifications = await models.UserNotification.findAll({
      raw: true,
    });
    const userdeleteNotify = userNotifications.find(
      (notification) => notification.typeofnotify === "ispatientdelete"
    );

    const handleNotification = async (foundPatient, source) => {
      if (
        userdeleteNotify &&
        JSON.parse(userdeleteNotify.notifyinapp).includes(source)
      ) {
        if (userdeleteNotify.isinapp) {
          const { subject } = deletePatient();
          notificationData = {
            patientId: foundPatient.patientId,
            patientName: `${foundPatient.firstName} ${foundPatient.lastName}`,
            message: subject,
            isPatientDelete: true,
            adminId: foundPatient.adminId,
          };
          await createNotification(notificationData);
        }
        if (userdeleteNotify.isemail) {
          const { subject, text } = deletePatient();
          await sendEmail(
            subject,
            text,
            foundPatient.firstName,
            foundPatient.lastName
          );
        }
        if (userdeleteNotify.issms) {
          // Add SMS notification logic here
        }
      }
    };

    if (isScheduled && isScheduled?.toLowerCase() === "true") {
      const foundPatient = await models.SchedulePatients.findOne({
        where: { uniqueId },
        raw: true,
        attributes: [
          "firstName",
          "lastName",
          "patientId",
          "uniqueId",
          "isScheduled",
          "addedFrom",
        ],
      });

      if (foundPatient?.patientId) {
        await models.PatientEligibility.destroy({
          where: { patientId: foundPatient.patientId },
        });
        await models.ODPatients.destroy({
          where: { patientId: foundPatient.patientId },
        });
      }

      response = await models.SchedulePatients.destroy({ where: { uniqueId } });

      if (
        foundPatient &&
        foundPatient.addedFrom.toLowerCase() === "opendental"
      ) {
        await handleNotification(foundPatient, "opendental");
      }
    } else {
      const foundPatient = await models.ManualPatients.findOne({
        where: { uniqueId },
        raw: true,
      });

      if (foundPatient?.patientId) {
        await models.PatientEligibility.destroy({
          where: { patientId: foundPatient.patientId },
        });
      }

      response = await models.ManualPatients.destroy({ where: { uniqueId } });

      if (foundPatient) {
        const source = foundPatient.addedFrom
          ? foundPatient.addedFrom.toLowerCase()
          : "manual";
        await handleNotification(foundPatient, source);
      }
    }

    if (response === 0) {
      res.status(400).send({ message: `Patient ID ${uniqueId} is not found` });
    } else {
      res.status(200).send({
        deletedId: uniqueId,
        notificationData,
        message: "Patient deleted successfully",
      });
    }
  } catch (error) {
    console.log("ERRORR", error);
    res.status(400).send({ error, message: "Patient delete failed" });
  }
};

module.exports.importPatientsFromCSV = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { patientsData } = req.body;

  let index = 0;
  let newPatientData = [];
  let newPatientError = [];
  let errorMessages = [];

  const addPatientFromCsv = async (patient, callback) => {
    const uniqueId = uuidv4();
    index++;
    const newPatient = {};
    const {
      subscriberFirstName,
      subscriberLastName,
      subscriberDateOfBirth,
      memberId,
      groupId,
      relationship,
      typeOfService,
      practiceNameAndLoc,
      appointmentType,
      scheduleAppointment,
      speciality,
      gender,
      appointmentRenderingProvider,
      procedureCode,
      procedureType,
      provider,
      insurancePayer,
      insuranceType,
      payerIdCode,
      dependentFirstName,
      dependentLastName,
      dependentDateOfBirth,
      providerNpi,
    } = patient;

    if (!isEmpty(subscriberFirstName))
      newPatient.subscriberFirstName = subscriberFirstName;
    if (!isEmpty(subscriberLastName))
      newPatient.subscriberLastName = subscriberLastName;

    if (!isEmpty(subscriberDateOfBirth))
      newPatient.subscriberDateOfBirth = new Date(subscriberDateOfBirth);

    if (!isEmpty(memberId)) newPatient.memberId = memberId;
    if (!isEmpty(groupId)) newPatient.groupId = groupId;
    if (!isEmpty(relationship)) newPatient.relationship = relationship;
    if (!isEmpty(typeOfService)) newPatient.typeOfService = typeOfService;
    if (!isEmpty(practiceNameAndLoc))
      newPatient.practiceNameAndLoc = practiceNameAndLoc;
    if (!isEmpty(appointmentType)) newPatient.appointmentType = appointmentType;
    if (!isEmpty(scheduleAppointment))
      newPatient.scheduleAppointment = new Date(scheduleAppointment);

    if (!isEmpty(speciality)) newPatient.speciality = speciality;
    if (!isEmpty(gender)) newPatient.gender = gender;
    if (!isEmpty(appointmentRenderingProvider))
      newPatient.appointmentRenderingProvider = appointmentRenderingProvider;
    if (!isEmpty(procedureCode)) newPatient.procedureCode = procedureCode;
    if (!isEmpty(procedureType)) newPatient.procedureType = procedureType;
    if (!isEmpty(provider)) newPatient.provider = provider;

    if (!isEmpty(dependentFirstName))
      newPatient.dependentFirstName = dependentFirstName;
    if (!isEmpty(dependentLastName))
      newPatient.dependentLastName = dependentLastName;
    if (!isEmpty(dependentDateOfBirth))
      newPatient.dependentDateOfBirth = new Date(dependentDateOfBirth);

    if (!isEmpty(subscriberFirstName))
      newPatient.firstName = subscriberFirstName;
    if (!isEmpty(subscriberLastName)) newPatient.lastName = subscriberLastName;
    if (!isEmpty(subscriberDateOfBirth))
      newPatient.dateOfBirth = new Date(subscriberDateOfBirth);

    if (!isEmpty(relationship) && relationship?.toString() !== "18") {
      if (!isEmpty(dependentFirstName))
        newPatient.firstName = dependentFirstName;
      if (!isEmpty(dependentLastName)) newPatient.lastName = dependentLastName;
      if (!isEmpty(dependentDateOfBirth))
        newPatient.dateOfBirth = new Date(dependentDateOfBirth);
      newPatient.gender = null;
    }

    if (!isEmpty(insurancePayer)) newPatient.insurancePayer = insurancePayer;
    if (!isEmpty(insuranceType)) newPatient.insuranceType = insuranceType;
    if (!isEmpty(payerIdCode)) newPatient.payerIdCode = payerIdCode;

    if (insurancePayer && insurancePayer.toLowerCase().includes("medicaid")) {
      if (!isEmpty(memberId)) newPatient.medicaidId = memberId;
    }
    newPatient.providerNpi = providerNpi;

    const providerData = await models.Provider.findOne({
      where: {
        npiId: providerNpi,
      },
      raw: true,
    });

    const providerName = providerData && providerData?.doctorName.split(" ");
    // Check if there's a prefix like "Dr"
    const prefix =
      providerName &&
      providerName.length >= 1 &&
      providerName[0] &&
      providerName[0];

    const firstName =
      providerName && providerName.length >= 2 && providerName[1];

    const lastName =
      providerName &&
      providerName.length >= 3 &&
      providerName.length === 3 &&
      providerName[2];
    if (prefix && prefix.toLowerCase() === "dr") {
      newPatient.providerFirstName = firstName || "John";
      newPatient.providerLastName = lastName || "Smith";
    } else {
      newPatient.providerFirstName = prefix || "John";
      newPatient.providerLastName = firstName || "Smith";
    }

    newPatient.providerNpi = providerData?.npiId || "1111111111";
    newPatient.providerTaxId = providerData?.taxId || "1111111111";
    newPatient.uniqueId = uniqueId;
    newPatient.addedFrom = "csv";

    const manualPatients = await models.ManualPatients.findAll({
      where: {
        memberId: newPatient.memberId,
        dateOfBirth: newPatient.dateOfBirth,
      },
      attributes: ["patientId"],
      raw: true,
    });

    const schedulePatients = await models.SchedulePatients.findAll({
      where: {
        memberId: newPatient.memberId,
        dateOfBirth: newPatient.dateOfBirth,
      },
      attributes: ["patientId"],
      raw: true,
    });

    const allPatients = [...manualPatients, ...schedulePatients];

    const procedureCodeData = await models.ProcedureCode.findOne({
      where: {
        procedureCode,
      },
      raw: true,
    });

    let isProcedureCodeInValid;

    if (procedureCodeData !== null) {
      isProcedureCodeInValid =
        procedureCodeData?.procedureType.toLowerCase() !==
        procedureType.toLowerCase();
    }

    const isError =
      !isEmpty(allPatients) ||
      procedureCodeData === null ||
      isProcedureCodeInValid;

    if (isError) {
      newPatient.error = true;
      newPatient.errorMessage = [];
      newPatient.errorRowIndex = index;

      if (procedureCodeData === null) {
        let error = {};
        error.rowIndex = index;
        error.message = `Procedure Code given at row number ${index} is not valid`;

        newPatient.errorMessage = [...newPatient.errorMessage, error.message];
        errorMessages = [...errorMessages, error];
      }

      if (isProcedureCodeInValid) {
        let error = {};
        error.rowIndex = index;
        error.message = `Procedure Type given at row number ${index} does not belong to procedure code given`;

        newPatient.errorMessage = [...newPatient.errorMessage, error.message];
        errorMessages = [...errorMessages, error];
      }

      if (!isEmpty(allPatients)) {
        let error = {};
        error.rowIndex = index;
        error.message = `Patient at row number ${index} is already present`;

        newPatient.errorMessage = [...newPatient.errorMessage, error.message];
        errorMessages = [...errorMessages, error];
      }

      newPatientError.push(newPatient);
    } else {
      newPatientData.push(newPatient);
    }
    callback();
  };

  const addUploadedPatients = async (patient, callback) => {
    const newpatientId = await generatePatientId();
    patient.patientId = newpatientId;

    try {
      await models.ManualPatients.create(patient);
      callback();
    } catch (error) {
      console.log(error, "2432");
      res.status(400).send(error);
    }
  };
  try {
    async.eachSeries(
      patientsData,
      (patient, callback) => {
        addPatientFromCsv(patient, callback);
      },
      async () => {
        if (newPatientError.length > 0) {
          res.status(400).send({
            error: errorMessages,
            msg: `${newPatientError.length} Invalid Patient Data found`,
            inValidData: newPatientError,
            validData: newPatientData,
          });
        } else {
          async.eachSeries(
            newPatientData,
            (patient, callback) => {
              addUploadedPatients(patient, callback);
            },
            () => {
              res.status(200).send({
                msg: `${index} Patient(s) added successfully from csv`,
                addedPatients: newPatientData,
              });
            }
          );
        }
      }
    );
  } catch (err) {
    console.error("Error:", err);
    res.status(400).send(err);
  }
};

module.exports.exclude = async (req, res) => {
  // #swagger.tags = ['Patients']
  try {
    if (req.body.isScheduled) {
      const response = await models.SchedulePatients.update(
        {
          isexclude: true,
        },
        { where: { uniqueId: req.params.uniqueId } }
      );
      res.status(200).send({
        data: response,
        message: "Patient updated successfully",
      });
    } else {
      const response = await models.ManualPatients.update(
        {
          isexclude: true,
        },
        { where: { uniqueId: req.params.uniqueId } }
      );
      res.status(200).send({
        data: response,
        message: "Patient updated successfully",
      });
    }
  } catch (error) {
    res.status(400).send({ error: error, message: "Patient Update failed" });
  }
};

const transporter = nodemailer.createTransport({
  host: process.env.SMTP,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.FROM_MAIL,
    pass: process.env.PASS,
  },
});

const sendEmail = async (subject, text, firstName, lastName) => {
  try {
    const templatePath = path.join(__dirname, "email.html");
    const templateContent = await fs.readFile(templatePath, "utf8");
    const logoPath = path.join(__dirname, "company_logo.png");

    const htmlContent =
      templateContent &&
      templateContent
        .replace(/{{text}}/g, text)
        .replace(/{{firstName}}/g, firstName)
        .replace(/{{lastName}}/g, lastName);

    const mailOptions = {
      from: process.env.FROM_MAIL,
      to: [
        "meenakshi.s@genyus.dev",
        "upendhra@genyus.dev",
        "agilesh.b@genyus.dev",
        "vishnupriya@clubitssolutions.com",
        "lenin.k@genyus.dev",
      ],
      subject: subject,
      html: htmlContent || "",
      attachments: [
        {
          filename: "company_logo.png",
          path: logoPath,
          cid: "companyLogo",
        },
        {
          filename: "thanks_logo.png",
          path: path.join(__dirname, "thanks_logo.png"),
          cid: "thanksLogo",
        },
      ],
    };
    // Send email
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully.");
  } catch (error) {
    console.error("Error sending email:", error);
  }
};

module.exports.verifyNow = async (req, res) => {
  //   // #swagger.tags = ['Patients']
  const startDate = new Date();
  const { uniqueId, adminId } = req.query;
  try {
    const userNotifications = await models.UserNotification.findAll({
      raw: true,
    });
    const patientNotifications = await models.PatientNotification.findAll({
      raw: true,
    });
    // Patients
    let patientscheduleNotify = null;
    let patientcsvnotify = null;
    let patientmanualnotify = null;

    // Users
    let userScheduleNotify = null;
    let usercsvNotify = null;
    let usermanualNotify = null;

    let isPayerAvailable = false;
    let isScheduled = req.query.isScheduled
      ? JSON.parse(req.query.isScheduled)
      : false;
    let response = null;
    const getNotification = (notifications, typeofnotify) =>
      notifications &&
      notifications.find(
        (notification) => notification.typeofnotify === typeofnotify
      );

    if (isScheduled) {
      patientscheduleNotify = getNotification(
        patientNotifications,
        "opendental"
      );
      userScheduleNotify = getNotification(userNotifications, "opendental");
    } else {
      if (!isScheduled) {
        if (response?.dataValues.addedFrom === "csv") {
          patientcsvnotify = getNotification(patientNotifications, "csv");
          usercsvNotify = getNotification(patientNotifications, "csv");
        } else {
          patientmanualnotify = getNotification(patientNotifications, "manual");
          usermanualNotify = getNotification(userNotifications, "manual");
        }
      }
    }
    if (isScheduled) {
      response = await models.SchedulePatients.findOne({
        where: { uniqueId: uniqueId },
      });
    } else {
      response = await models.ManualPatients.findOne({
        where: { uniqueId: uniqueId },
      });
    }
    if (response?.dataValues?.payerIdCode) {
      let payerData = await models.InsurancePayer.findOne({
        where: { payerId: response?.dataValues?.payerIdCode },
        raw: true,
      });
      if (payerData)
        isPayerAvailable = Object.keys(payerData).length > 0 ? true : false;
    }
    const payloadData = {
      provider: {
        type: "1",
        firstName:
          (response?.dataValues && response?.dataValues.providerFirstName) ||
          "",
        lastName:
          (response?.dataValues && response?.dataValues.providerLastName) || "",
        npi: (response?.dataValues && response?.dataValues.providerNpi) || "",
        taxId:
          (response?.dataValues && response?.dataValues.providerTaxId) || "",
      },
      payer: {
        name:
          (response?.dataValues && response?.dataValues.insurancePayer) || "",
        payerIdCode:
          (response?.dataValues && response?.dataValues.payerIdCode) || "",
      },
      patient: {
        dateOfBirth:
          (response?.dataValues &&
            response?.dataValues.dependentDateOfBirth &&
            moment(new Date(response?.dataValues.dependentDateOfBirth)).format(
              "YYYY-MM-DD"
            )) ||
          "",
        memberId: (response?.dataValues && response?.dataValues.memberId) || "",
        firstName:
          (response?.dataValues && response?.dataValues.dependentFirstName) ||
          "",
        lastName:
          (response?.dataValues && response?.dataValues.dependentLastName) ||
          "",
        relationship:
          (response?.dataValues && response?.dataValues.relationship) || "",
      },
      subscriber: {
        dateOfBirth:
          (response?.dataValues &&
            response?.dataValues.subscriberDateOfBirth &&
            moment(new Date(response?.dataValues.subscriberDateOfBirth)).format(
              "YYYY-MM-DD"
            )) ||
          "",
        memberId: (response?.dataValues && response?.dataValues.memberId) || "",
        firstName:
          (response?.dataValues && response?.dataValues.subscriberFirstName) ||
          "",
        lastName:
          (response?.dataValues && response?.dataValues.subscriberLastName) ||
          "",
      },
    };
    const toVerifyData = {
      payloadData: payloadData || {},
      patientId: response?.dataValues.patientId || "",
      adminId: adminId || "",
    };
    if (response && !isPayerAvailable) {
      let patnotlinked = false;
      let usrnotlinked = false;
      // Need to changes in Switch Case
      let notificationData = null;
      if (isScheduled) {
        patnotlinked = JSON.parse(
          patientscheduleNotify?.notifyinapp || "[]"
        ).includes("notlinked");
        usrnotlinked = JSON.parse(
          userScheduleNotify?.notifyinapp || "[]"
        ).includes("notlinked");
        const {
          createNotification,
        } = require("../settings/notificationController");
        if (usrnotlinked && userScheduleNotify?.isinapp) {
          const { subject } = errorMail();
          notificationData = {
            patientId: response.dataValues.patientId,
            patientName:
              response.dataValues.firstName +
              " " +
              response.dataValues.lastName,
            message: subject,
            notlinked: true,
            adminId: adminId,
          };
          await createNotification(notificationData);
          // Notification Create along with its Template
        }
        if (usrnotlinked && userScheduleNotify?.isemail) {
          const { subject, text } = errorMail();
          await sendEmail(
            subject,
            text,
            response.dataValues.firstName,
            response.dataValues.lastName
          );
          // Send an Email to User{Admin} along with its template   // error email
        } // Email to be sent to PatientNotification
        if (usrnotlinked && userScheduleNotify?.issms) {
          // Send an SMS to user (Admin) along with templae
        }
        if (patnotlinked && patientscheduleNotify?.isemail) {
          const { subject, text } = errorMail();
          await sendEmail(
            subject,
            text,
            response.dataValues.firstName,
            response.dataValues.lastName
          );
          await createNotification(notificationData);
          // Send an Email to patient  along with its template - - {response?.dataValues.emailId}
        }
        if (patnotlinked && patientscheduleNotify?.issms) {
          // Send an SMS to patient along with template - {response?.dataValues.WirelessPhone}
        }
      } else {
        let patsettings = null;
        let usrsettings = null;
        if (response?.dataValues?.addedFrom === "csv") {
          patnotlinked = JSON.parse(
            patientcsvnotify?.notifyinapp || "[]"
          ).includes("notlinked");
          usrnotlinked = JSON.parse(
            usercsvNotify?.notifyinapp || "[]"
          ).includes("notlinked");
          patsettings = patientcsvnotify;
          usrsettings = usercsvNotify;
        } else {
          patnotlinked = JSON.parse(
            patientmanualnotify?.notifyinapp || "[]"
          ).includes("notlinked");
          usrnotlinked = JSON.parse(
            usermanualNotify?.notifyinapp || "[]"
          ).includes("notlinked");
          patsettings = patientcsvnotify;
          usrsettings = usercsvNotify;
        }
        if (usrnotlinked && usrsettings?.isinapp) {
          const { subject } = errorMail();
          notificationData = {
            patientId: response?.dataValues?.patientId,
            patientName:
              response?.dataValues?.firstName +
              " " +
              response?.dataValues?.lastName,
            message: subject,
            notlinked: true,
            adminId: adminId,
          };
          await createNotification(notificationData);
          // Notification Create along with its Template
        }
        if (usrnotlinked && usrsettings?.isemail) {
          const { subject, text } = errorMail();
          await sendEmail(
            subject,
            text,
            response?.dataValues?.firstName,
            response?.dataValues?.lastName
          );
        }
        if (usrnotlinked && usrsettings?.issms) {
          // Send an SMS to user (Admin) along with templae
        }
        if (patnotlinked && patsettings?.isemail) {
          const { subject, text } = errorMail();
          await sendEmail(
            subject,
            text,
            response?.dataValues?.firstName,
            response?.dataValues?.lastName
          );
          // Send an Email to patient  along with its template - - {response?.dataValues.emailId}
        }
        if (patnotlinked && patsettings?.issms) {
          //Trigger - Send an SMS to patient along with template - {response?.dataValues.WirelessPhone}
        }
      }

      response.set({
        // not linked error
        isVerified: false,
        lastVerified: `${new Date()}`,
        verificationError: "This Insurance Payer is not Linked",
        verificationErrCode: "110",
        verificationErrMessages: null,
        effectiveDateFrom: null,
        effectiveEndDate: null,
        remainingBenefits: null,
      });
      let logMessage = getAuditLogErrorMessage(
        `${response?.dataValues?.verificationErrCode}`
      );
      await logaudit(
        logMessage,
        response?.dataValues?.patientId,
        response?.dataValues?.addedFrom,
        response?.dataValues?.addedFrom,
        response?.dataValues?.scheduleAppointment,
        response?.dataValues?.lastVerified,
        startDate,
        response?.dataValues?.lastVerified,
        adminId,
        response?.dataValues?.createdAt
      );
      await response.save();
      throw res.status(400).send({
        checkEligibilityPayload: payloadData,
        notificationData,
        status: `${"This Insurance Payer is not Linked"}`,
        message: "patient added verification failed",
      });
    }
    verifyPatient(toVerifyData)
      .then((verificationData) => {
        //second callback
        //update on patient eligibilities
        createEligibility(verificationData)
          .then((data) => {
            // third callback
            let isFailed = false;
            if (data?.status?.code && data?.status?.code !== 0) isFailed = true;
            updatePatientAfterVerify(data, isScheduled, isFailed)
              .then(async (updatedPatient) => {
                let patverified = false;
                let usrverified = false;
                // Need to changes in Switch Case
                let notificationData = null;
                if (isScheduled) {
                  patverified = JSON.parse(
                    patientscheduleNotify?.notifyinapp || "[]"
                  ).includes("success");
                  usrverified = JSON.parse(
                    userScheduleNotify?.notifyinapp || "[]"
                  ).includes("success");
                  const {
                    createNotification,
                  } = require("../settings/notificationController");
                  if (usrverified && userScheduleNotify?.isinapp) {
                    if (
                      technicalErrorCodes.includes(
                        response?.dataValues?.verificationErrCode
                      )
                    ) {
                      const { subject } = technicalError();
                      notificationData = {
                        patientId: response?.dataValues?.patientId,
                        patientName:
                          response?.dataValues?.firstName +
                          " " +
                          response?.dataValues?.lastName,
                        message: subject,
                        istechnical: true,
                        adminId: response?.dataValues.adminId,
                      };
                      await createNotification(notificationData);
                    } else {
                      const { subject } = successMail();
                      notificationData = {
                        patientId: response.dataValues.patientId,
                        patientName:
                          response.dataValues.firstName +
                          " " +
                          response.dataValues.lastName,
                        message: subject,
                        isSuccess: true,
                        adminId: response?.dataValues.adminId,
                      };
                      await createNotification(notificationData);
                    }
                  }
                  if (usrverified && userScheduleNotify?.isemail) {
                    const { subject, text } = errorMail();
                    await sendEmail(
                      subject,
                      text,
                      response.dataValues.firstName,
                      response.dataValues.lastName
                    );
                    // Send an Email to User{Admin} along with its template   // error email
                  } // Email to be sent to PatientNotification
                  if (usrverified && userScheduleNotify?.issms) {
                    // Trigger - Send an SMS to user (Admin) along with templae
                  }
                  if (patverified && patientscheduleNotify?.isemail) {
                    const { subject, text } = errorMail();
                    await sendEmail(
                      subject,
                      text,
                      response.dataValues.firstName,
                      response.dataValues.lastName
                    );
                    // Send an Email to patient  along with its template - - {response?.dataValues.emailId}
                  }
                  if (patverified && patientscheduleNotify?.issms) {
                    // Send an SMS to patient along with template - {response?.dataValues.WirelessPhone}
                  }
                } else {
                  if (
                    response?.dataValues?.addedFrom === "csv" ||
                    !isScheduled
                  ) {
                    patverified = JSON.parse(
                      patientmanualnotify?.notifyinapp || "[]"
                    ).includes("success");
                    usrverified = JSON.parse(
                      usermanualNotify?.notifyinapp || "[]"
                    ).includes("success");
                    if (usrverified && usermanualNotify?.isinapp) {
                      if (
                        demographicsErrorCodes.includes(
                          response?.dataValues?.verificationErrCode
                        )
                      ) {
                        const { subject } = demographic();
                        notificationData = {
                          patientId: response?.dataValues?.patientId,
                          patientName:
                            response?.dataValues?.firstName +
                            " " +
                            response?.dataValues?.lastName,
                          message: subject,
                          demographic: true,
                          adminId: response?.dataValues?.adminId,
                        };
                        await createNotification(notificationData);
                      } else {
                        const { subject } = successMail();
                        notificationData = {
                          patientId: response?.dataValues?.patientId,
                          patientName:
                            response?.dataValues?.firstName +
                            " " +
                            response?.dataValues?.lastName,
                          message: subject,
                          isSuccess: true,
                          adminId: response?.dataValues?.adminId,
                        };
                        await createNotification(notificationData);
                      }
                    }
                    if (usrverified && usermanualNotify?.isemail) {
                      const { subject, text } = errorMail();
                      await sendEmail(
                        subject,
                        text,
                        response?.dataValues?.firstName,
                        response?.dataValues?.lastName
                      );
                    }
                    if (usrverified && usermanualNotify?.issms) {
                      // Trigger - Send an SMS to user (Admin) along with templae
                    }
                    if (patverified && patientmanualnotify?.isemail) {
                      const { subject, text } = errorMail();
                      await sendEmail(
                        subject,
                        text,
                        response?.dataValues?.firstName,
                        response?.dataValues?.lastName
                      );
                    }
                    if (patverified && patientmanualnotify?.issms) {
                      // Trigger - Send an SMS to patient along with template - {response?.dataValues.WirelessPhone}
                    }
                  }
                }
                let logMessage = getAuditLogErrorMessage(
                  `${response?.dataValues?.verificationErrCode}`
                );
                await logaudit(
                  logMessage,
                  response?.dataValues?.patientId,
                  response?.dataValues?.addedFrom,
                  response?.dataValues?.addedFrom,
                  response?.dataValues?.scheduleAppointment,
                  response?.dataValues?.lastVerified,
                  startDate,
                  response?.dataValues?.lastVerified,
                  response?.dataValues?.adminId || "18",
                  response?.dataValues?.createdAt
                );
                res.status(200).send({
                  data: {
                    checkEligibilityPayload: payloadData,
                    patient: updatedPatient,
                    eligibility: verificationData,
                  },
                  message: "patient details added verified and updated",
                });
              })
              .catch((err) => {
                console.log(err);
                res.status(400).send({
                  checkEligibilityPayload: payloadData,
                  message: "Patient update after verification failed",
                });
              });
          })
          .catch((err) => {
            console.log(err, "2999");
            res.status(400).send({
              checkEligibilityPayload: payloadData,
              error: err,
              message: "verification done saving verification data failed",
            });
          });
      })
      .catch(async (err) => {
        if (isScheduled) {
          if (response) {
            response.set({
              isVerified: false,
              lastVerified: `${new Date()}`,
              verificationError:
                err?.response?.data?.status?.description || null,
              verificationErrCode: err?.response?.data?.status?.code || null,
              verificationErrMessages: err?.response?.data?.messages || null,
              remainingBenefits: null,
              effectiveDateFrom: null,
              effectiveEndDate: null,
            });
            // await logaudit(
            //   "Technical Error",
            //   response?.dataValues?.patientId,
            //   response?.dataValues?.addedFrom,
            //   "Manual",
            //   response?.dataValues?.scheduleAppointment,
            //   new Date(),
            //   startDate,
            //   new Date(),
            //   "18"
            // );
            await response.save();
            sendnotifications(
              err,
              userScheduleNotify,
              patientscheduleNotify,
              response?.dataValues
            );
            res.status(400).send({
              checkEligibilityPayload: payloadData,
              status: err?.response?.data,
              error: err,
              message: "patient added verification failed",
            });
          }
        } else {
          if (response) {
            response.set({
              isVerified: false,
              lastVerified: `${new Date()}`,
              verificationError:
                err?.response?.data?.status?.description || null,
              verificationErrCode: err?.response?.data?.status?.code || null,
              verificationErrMessages: err?.response?.data?.messages || null,
              remainingBenefits: null,
              effectiveDateFrom: null,
              effectiveEndDate: null,
            });
            console.log(
              "3147",
              response?.dataValues.patientId,
              "resp",
              "response"
            );
            let logMessage = getAuditLogErrorMessage(
              `${response?.dataValues?.verificationErrCode}`
            );
            await logaudit(
              logMessage,
              response?.dataValues?.patientId,
              response?.dataValues?.addedFrom,
              response?.dataValues?.addedFrom,
              response?.dataValues?.scheduleAppointment,
              response?.dataValues?.lastVerified,
              startDate,
              response?.dataValues?.lastVerified,
              response?.dataValues?.adminId,
              response?.dataValues?.createdAt
            );
            await response.save();
            sendnotifications(
              err,
              usermanualNotify,
              patientmanualnotify,
              response?.dataValues
            );
            res.status(400).send({
              checkEligibilityPayload: payloadData,
              status: err?.response?.data,
              error: err,
              message: "patient added verification failed",
            });
          }
        }
      });
  } catch (e) {
    console.log("-----error", e);
  }
};

async function sendnotifications(
  err,
  userNotify,
  patientNotify,
  response,
  errcode
) {
  let code = err?.response?.data?.status?.code
    ? err?.response?.data?.status?.code
    : errcode;
  let demographicerr = demographicsErrorCodes?.includes(code?.toString());
  let technicalerr = technicalErrorCodes?.includes(code?.toString());
  let notLinkederr = notLinkedErrorCodes?.includes(code);
  let usrdemographic = false;
  let usrtechnical = false;
  let usrnotlinked = false;
  let patdemographic = false;
  let pattechnical = false;
  let patnotlinked = false;
  usrnotlinked = getErrors(userNotify, "notlinked");
  patnotlinked = getErrors(patientNotify, "notlinked");
  if (demographicerr) {
    usrdemographic = getErrors(userNotify, "demographic");
    patdemographic = getErrors(patientNotify, "demographic");
    const {
      createNotification,
    } = require("../settings/notificationController");
    if (usrdemographic && userNotify?.isinapp) {
      const { subject } = demographic();
      notificationData = {
        patientId: response.patientId,
        patientName: response.firstName + " " + response.lastName,
        message: subject,
        demographic: true,
        adminId: response?.adminId || "",
      };
      await createNotification(notificationData);
    }
    if (usrdemographic && userNotify?.isemail) {
      const { subject, text } = demographic();
      await sendEmail(subject, text, response?.firstName, response?.lastName);
    }
    if (usrdemographic && userNotify?.issms) {
      // Trigger - Send an SMS to user (Admin) along with templae
    } // Trigger - SMS to be sent to PatientNotiication
    if (patdemographic && patientNotify?.isemail) {
      const { subject, text } = demographic();
      await sendEmail(subject, text, response?.firstName, response?.lastName);
      // Send an Email to patient  along with its template - - {responsedataValues.emailId}
    } // Email to be sent to PatientNotification
    if (patdemographic && patientNotify?.issms) {
      // Send an SMS to patient along with template - {responsedataValues.WirelessPhone}
    } // SMS to be sent to PatientNotiication
  }
  if (technicalerr) {
    usrtechnical = getErrors(userNotify, "technical");
    pattechnical = getErrors(patientNotify, "technical");
    if (usrtechnical && userNotify?.isinapp) {
      const { subject } = technicalError();
      notificationData = {
        patientId: response?.patientId,
        patientName: response?.firstName + " " + response?.lastName,
        message: subject,
        istechnical: true,
        adminId: response?.adminId || "",
      };
      await createNotification(notificationData);
      // Notification Create along with its Template
    }
    if (usrtechnical && userNotify?.isemail) {
      const { subject, text } = technicalError();
      await sendEmail(subject, text, response?.firstName, response?.lastName);
    }
    if (usrtechnical && userNotify?.issms) {
      // Send an SMS to user (Admin) along with templae
    }
    if (pattechnical && patientNotify?.isemail) {
      const { subject, text } = technicalError();
      await sendEmail(subject, text, response?.firstName, response?.lastName);
      // Send an Email to patient  along with its template - - {responsedataValues.emailId}
    }
    if (pattechnical && patientNotify?.issms) {
      // Send an SMS to patient along with template - {responsedataValues.WirelessPhone}
    }
  }

  if (notLinkederr && usrnotlinked) {
    if (usrnotlinked && userNotify?.isinapp) {
      const { subject } = errorMail();
      notificationData = {
        patientId: response?.patientId,
        patientName: response?.firstName + " " + response?.lastName,
        message: subject,
        notlinked: true,
        adminId: response?.adminId || "",
      };
      await createNotification(notificationData);
    }
    if (usrnotlinked && userNotify?.isemail) {
      const { subject, text } = errorMail();
      await sendEmail(subject, text, response?.firstName, response?.lastName);
    } // Email to be sent to PatientNotification
    if (usrnotlinked && userNotify?.issms) {
    }
    if (patnotlinked && patientNotify?.isemail) {
      const { subject, text } = errorMail();
      await sendEmail(subject, text, response?.firstName, response?.lastName);
    }
    if (patnotlinked && patientNotify?.issms) {
    }
  }
}

function getErrors(notify, error) {
  if (notify) {
    return JSON.parse(notify?.notifyinapp).includes(error);
  } else return false;
}

module.exports.verifyPatientNow = verifyPatientNow;
async function verifyPatientNow(data, iscron, adminid, callback) {
  // #swagger.tags = ['Patients']
  try {
    const { uniqueId, adminId } = data;
    let isPayerAvailable = false;
    let isScheduled = data.isScheduled;
    let response = null;
    if (isScheduled) {
      response = await models.SchedulePatients.findOne({
        where: {
          uniqueId: uniqueId,
          isexclude: false,
        },
      });
    } else {
      response = await models.ManualPatients.findOne({
        where: { uniqueId: uniqueId, isexclude: false },
      });
    }
    if (!response) callback();
    if (response?.dataValues?.payerIdCode) {
      let payerData = await models.InsurancePayer.findOne({
        where: { payerId: response?.dataValues?.payerIdCode },
        raw: true,
      });
      if (payerData)
        isPayerAvailable = Object.keys(payerData).length > 0 ? true : false;
    }
    const payloadData = {
      provider: {
        type: "1",
        firstName:
          (response?.dataValues && response?.dataValues?.providerFirstName) ||
          "",
        lastName:
          (response?.dataValues && response?.dataValues?.providerLastName) ||
          "",
        npi: (response?.dataValues && response?.dataValues?.providerNpi) || "",
        taxId:
          (response?.dataValues && response?.dataValues?.providerTaxId) || "",
      },
      payer: {
        name:
          (response?.dataValues && response?.dataValues?.insurancePayer) || "",
        payerIdCode:
          (response?.dataValues && response?.dataValues?.payerIdCode) || "",
      },
      patient: {
        dateOfBirth:
          (response?.dataValues &&
            response?.dataValues?.dependentDateOfBirth &&
            moment(response?.dataValues?.dependentDateOfBirth).format(
              "YYYY-MM-DD"
            )) ||
          "",
        memberId:
          (response?.dataValues && response?.dataValues?.memberId) || "",
        firstName:
          (response?.dataValues && response?.dataValues?.dependentFirstName) ||
          "",
        lastName:
          (response?.dataValues && response?.dataValues?.dependentLastName) ||
          "",
        relationship:
          (response?.dataValues && response?.dataValues?.relationship) || "",
      },
      subscriber: {
        dateOfBirth:
          (response?.dataValues &&
            response?.dataValues?.subscriberDateOfBirth &&
            moment(
              new Date(response?.dataValues?.subscriberDateOfBirth)
            ).format("YYYY-MM-DD")) ||
          "",
        memberId:
          (response?.dataValues && response?.dataValues?.memberId) || "",
        firstName:
          (response?.dataValues && response?.dataValues?.subscriberFirstName) ||
          "",
        lastName:
          (response?.dataValues && response?.dataValues?.subscriberLastName) ||
          "",
      },
    };
    const toVerifyData = {
      payloadData: payloadData || {},
      patientId: response?.dataValues?.patientId || "",
      adminId: adminId || adminid || "",
    };

    if (response && !isPayerAvailable) {
      response.set({
        isVerified: false,
        lastVerified: `${new Date()}`,
        verificationError: "This Insurance Payer is not Linked",
        verificationErrCode: "110",
        verificationErrMessages: null,
        effectiveDateFrom: null,
        effectiveEndDate: null,
        remainingBenefits: null,
      });
      // console.log(response?.dataValues?.patientId, "<----3430");
      let logMessage = getAuditLogErrorMessage(
        `${response?.dataValues?.verificationErrCode}`
      );
      await logaudit(
        logMessage,
        response?.dataValues?.patientId,
        response?.dataValues?.addedFrom,
        response?.dataValues?.addedFrom,
        response?.dataValues?.scheduleAppointment,
        response?.dataValues?.lastVerified,
        new Date(), //startDate,
        response?.dataValues?.lastVerified,
        adminId,
        response?.dataValues?.createdAt
      );
      await response.save();
      callback && callback();
    } else {
      verifyPatient(toVerifyData)
        .then((verificationData) => {
          //second callback
          //update on patient eligibilities
          createEligibility(verificationData)
            .then((data) => {
              // third callback
              let isFailed = false;
              if (data?.status?.code && data?.status?.code !== 0)
                isFailed = true;
              updatePatientAfterVerify(data, isScheduled, isFailed)
                .then((updatedPatient) => {
                  callback && callback();
                })
                .catch((err) => {
                  console.log(err);
                  callback && callback();
                });
            })
            .catch((err) => {
              console.log(err);
              callback && callback();
            });
        })
        .catch(async (err) => {
          if (isScheduled) {
            if (response) {
              response.set({
                isVerified: false,
                lastVerified: `${new Date()}`,
                verificationError:
                  err?.response?.data?.status?.description || null,
                verificationErrCode: err?.response?.data?.status?.code || null,
                verificationErrMessages: err?.response?.data?.messages || null,
                remainingBenefits: null,
                effectiveDateFrom: null,
                effectiveEndDate: null,
              });
              // console.log(response?.dataValues?.patientId, "<----3487");
              let logMessage = getAuditLogErrorMessage(
                `${response?.dataValues?.verificationErrCode}`
              );
              await logaudit(
                logMessage,
                response?.dataValues?.patientId,
                response?.dataValues?.addedFrom,
                response?.dataValues?.addedFrom,
                response?.dataValues?.scheduleAppointment,
                response?.dataValues?.lastVerified,
                new Date(), //startDate,
                response?.dataValues?.lastVerified,
                adminId || "",
                response?.dataValues?.createdAt
              );
              await response.save();
              callback && callback();
            }
          } else {
            if (response) {
              response.set({
                isVerified: false,
                lastVerified: `${new Date()}`,
                verificationError:
                  err?.response?.data?.status?.description || null,
                verificationErrCode: err?.response?.data?.status?.code || null,
                verificationErrMessages: err?.response?.data?.messages || null,
                remainingBenefits: null,
                effectiveDateFrom: null,
                effectiveEndDate: null,
              });
              // console.log(response?.dataValues?.patientId, "<----3519");
              let logMessage = getAuditLogErrorMessage(
                `${response?.dataValues?.verificationErrCode}`
              );
              await logaudit(
                logMessage,
                response?.dataValues?.patientId,
                response?.dataValues?.addedFrom,
                response?.dataValues?.addedFrom,
                response?.dataValues?.scheduleAppointment,
                response?.dataValues?.lastVerified,
                new Date(), //startDate,
                response?.dataValues?.lastVerified,
                adminId || "",
                response?.dataValues?.createdAt
              );
              await response.save();
              callback && callback();
              // res.status(400).send({
              //   checkEligibilityPayload: payloadData,
              //   status: err?.response?.data,
              //   error: err,
              //   message: "patient added verification failed"
              // });
            }
          }
        });
    }
  } catch (e) {
    callback && callback();
  }
}

module.exports.fetchOpendentalData = fetchOpendentalData;
async function fetchOpendentalData(req, res, fetchdays, patids) {
  try {
    let odPatients = null;
    if (patids && patids.length > 0) {
      odPatients = await models.ODPatients.findAll({
        where: {
          patientId: {
            [Op.in]: patids,
          },
          PatStatus: "Patient",
        },
      });
    } else {
      odPatients = await models.ODPatients.findAll({
        where: {
          PatCreatedAt: {
            [Op.gte]: moment().subtract(fetchdays, "days").toDate(),
          },
          PatStatus: "Patient",
        },
      });
    }
    const definitionValues = await ODcontroller.getDefinitions(req, res);
    for (const val of odPatients) {
      let data = { ...val.dataValues };
      if (data.patientId) {
        const familyData = await models.ODFamilyModules.findOne({
          where: { patientId: data?.patientId },
          raw: true,
        });
        data.medicaidId = data?.MedicaidID || null;
        data.dependentFirstName = data?.firstName || null;
        data.dependentLastName = data?.lastName || null;
        data.dependentDateOfBirth = data?.dateOfBirth || null;
        if (familyData) {
          data.memberId = familyData?.SubscriberID || null;
          data.groupId = familyData?.GroupNum || null;
          data.planType = familyData?.planType || null;
          data.EmployerNum = familyData?.EmployerNum || null;
          data.EmpName = familyData?.employer || null;
          // Primary, Secondary, tertiary
          data.medical = familyData.Ordinaltype === "Medical";
          data.dental =
            familyData.Ordinaltype === "Primary" ||
            familyData.Ordinaltype === "Secondary";
          data.others = familyData.Ordinaltype === "Other insurance";
          data.primary = familyData.Ordinal === "1";
          data.secondary = familyData.Ordinal === "2";
          data.tertiary = familyData.Ordinal === "3";

          const carriersData = await models.ODCarriers.findOne({
            where: { CarrierNum: familyData?.CarrierNum },
            raw: true,
          });
          if (carriersData) {
            data.insurancePayer = carriersData?.payersName || null;
            data.insuranceName = carriersData?.payersName || null;
            data.insurancePhoneNumber = carriersData?.Phone || null;
            data.payerIdCode = carriersData?.payerIdCode || null;
          }

          if (familyData.Relationship === "Self") data.relationship = "18";
          else if (familyData.Relationship === "Child")
            data.relationship = "19";
          else if (familyData.Relationship === "Spouse")
            data.relationship = "01";
          else if (familyData.Relationship === "Employee")
            data.relationship = "20";
          else if (familyData.Relationship === "Unknown")
            data.relationship = "21";
          else if (familyData.Relationship === "Handicapped Dependent")
            data.relationship = "22";
          else if (familyData.Relationship === "Signifcant Other")
            data.relationship = "29";
          else if (familyData.Relationship === "Other Adult")
            data.relationship = "34";
          else if (familyData.Relationship === "Injured Plaintiff")
            data.relationship = "41";
          else if (familyData.Relationship === "Life Partner")
            data.relationship = "53";
          else if (familyData.Relationship === "Dependent")
            data.relationship = "76";
          else if (familyData.Relationship === "Other")
            data.relationship = "99";
          else data.relationship = null;

          const subscriberDetails = await models.ODPatients.findOne({
            where: {
              patientId: familyData?.Subscriber,
            },
            raw: true,
          });
          data.subscriberFirstName = subscriberDetails?.firstName || null;
          data.subscriberLastName = subscriberDetails?.lastName || null;
          data.subscriberDateOfBirth = subscriberDetails?.dateOfBirth || null;
          if (familyData.Relationship === "Self") {
            data.subscriberFirstName = data?.firstName || null;
            data.subscriberLastName = data?.lastName || null;
            data.subscriberDateOfBirth = data?.dateOfBirth || null;
          }
          data.subscriberAddress = subscriberDetails?.Address || null;
          data.subscriberAddress1 = subscriberDetails?.Address2 || null;
          data.subscriberCity = subscriberDetails?.City || null;
          data.subscriberZip = subscriberDetails?.Zip || null;
          data.subscriberState = subscriberDetails?.State || null;
        }

        const inSubplans = await models.ODInsSub.findOne({
          where: { Subscriber: data?.patientId },
          raw: true,
        });

        if (inSubplans) {
          // should come from family modules
          //getting member ID
          // data.memberId = inSubplans.SubscriberID || null;
          const insPlanNum = await models.ODInsPlans.findOne({
            where: { PlanNum: inSubplans?.PlanNum },
            raw: true,
          });

          // Getting CarrierNum
          if (insPlanNum) {
            // data.groupId = insPlanNum?.groupNumber || null;
            if (insPlanNum?.PlanType === "p")
              data.insurancePlan = "PPO Percentage";
            if (insPlanNum?.PlanType === "f") data.insurancePlan = "Flat Copay";
            if (insPlanNum?.PlanType === "c") data.insurancePlan = "Capitation";
            if (insPlanNum?.PlanType === "") data.insurancePlan = "Percentage";
            if (insPlanNum?.CarrierNum) {
            }
          }
        }
        // const patPlanDetails = await ODPatPlansModel.findOne({
        //   where: { PatNum: data.patientId },
        //   raw: true
        // });
        const odClinics = await models.ODClinics.findOne({
          where: {
            ClinicNum: data?.ClinicNum,
          },
          raw: true,
        });
        if (odClinics && odClinics)
          data.practiceNameAndLoc = odClinics?.Abbr + " " + odClinics?.State;
        const appointment = await models.ODAppointments.findAll({
          limit: 1,
          where: {
            patientId: data?.patientId,
          },
          order: [["AptDateTime", "DESC"]],
          raw: true,
        });
        if (data?.PriProv) {
          const providersData = await models.ODProvider.findOne({
            where: { ProvNum: data?.PriProv },
            raw: true,
          });
          data.provider =
            providersData?.firstName + " " + providersData?.lastName || null;
          data.providerFirstName = providersData?.firstName || null;
          data.providerLastName = providersData?.lastName || null;
          data.providerNpi = providersData?.NationalProvID || null;
          data.providerTaxId = providersData?.SSN || null;
          data.appointmentRenderingProvider =
            providersData?.firstName + " " + providersData?.lastName || null;
          await definitionValues.filter((values) => {
            if (
              values?.DefNum?.toString() ===
              providersData?.Specialty?.toString()
            ) {
              data.speciality = values.ItemName;
            }
          });
        } else {
          if (appointment && appointment.length > 0 && appointment[0]) {
            const appProviderData = await models.ODProvider.findOne({
              where: { ProvNum: appointment[0].ProvNum },
              raw: true,
            });
            data.appointmentRenderingProvider =
              appProviderData?.firstName + " " + appProviderData?.lastName ||
              null;
          }
        }
        if (appointment && appointment.length > 0 && appointment[0]) {
          data.scheduleAppointment =
            new Date(`${appointment[0]?.AptDateTime}`) || null;
          const appointmentType = await models.ODAppointmentTypes.findOne({
            where: { AppointmentTypeNum: appointment[0]?.AppointmentTypeNum },
            raw: true,
          });

          const procedureLogs = await models.ODProcedureLog.findAll({
            where: { AptNum: appointment[0].AptNum, PatNum: data?.patientId },
            raw: true,
          });
          if (procedureLogs?.length > 0) {
            let string = "";
            let proCat = "";
            for (const proc of procedureLogs) {
              if (proc) {
                const procedureCodes = await models.ODProcedureCode.findOne({
                  where: { ProcCode: proc.procCode },
                  raw: true,
                });
                if (procedureCodes) {
                  if (proCat === "") proCat += procedureCodes?.procedureType;
                  else proCat += "," + procedureCodes?.procedureType;
                }
                if (string === "") string += proc?.procCode;
                else string += "," + proc?.procCode;
              }
            }
            data.typeOfService = proCat || null;
            data.procedureCode = string || null;
          }

          if (appointmentType)
            data.appointmentType = appointmentType?.AppointmentTypeName;
        }
      }
      try {
        const existingPatient = await models.SchedulePatients.findByPk(
          data?.patientId
        );
        data.addedFrom = "OpenDental";
        data.verificationType = "OpenDental"; // manual/auto/onAdd/OpenDental
        if (existingPatient) {
          // Update existing appointment type
          delete data.patientId;
          await existingPatient.update(data);
        } else {
          // Create new appointment type
          data.uniqueId = uuidv4();
          data.isVerified = false;
          data.isScheduled = true;
          await models.SchedulePatients.create({ ...data });
        }
      } catch (error) {
        return res
          .status(400)
          .send({ error: error, message: "Scheduled data creation error" });
      }
    }
  } catch (e) {
    return res.status(500).send({ error: e });
  }
}

module.exports.createSchedulePatients = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { adminId } = req.query;
  if (adminId) {
    let patids = [];
    const generalsettings = await models.GeneralSettings.findOne({
      where: { adminId: adminId },
      raw: true,
    });
    let daystoconsider = 0;
    if (
      generalsettings?.verifyschedulestandard >
      generalsettings?.verifyschedulemedicaid
    )
      daystoconsider = generalsettings?.verifyschedulestandard;
    else daystoconsider = generalsettings?.verifyschedulemedicaid;
    const dateFormated = moment().add(daystoconsider, "d").format("YYYY-MM-DD");
    const response = await axios.get(
      `${OpenDentalApiPath}/appointments?dateStart=${moment().format(
        "YYYY-MM-DD"
      )}&dateEnd=${dateFormated}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );
    const addAppointments = async (data, callback) => {
      patids.push(data.PatNum);
      const appointmentData = {};
      appointmentData.addedFrom = "OpenDental";
      appointmentData.AptDateTime = `${data?.AptDateTime}`;
      appointmentData.AppointmentTypeNum = `${data?.AppointmentTypeNum}`;
      appointmentData.patientId = `${data?.PatNum}`;
      appointmentData.ProvNum = `${data?.ProvNum}`;

      try {
        const existingPatient = await models.ODAppointments.findByPk(
          `${data.AptNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(appointmentData);
          callback();
        } else {
          // Create new patient
          await models.ODAppointments.create({
            AptNum: `${data.AptNum}`,
            ...appointmentData,
          });
          callback();
        }
      } catch (error) {
        console.log(error);
      }
    };

    async.eachSeries(
      response.data,
      (data, callback) => {
        addAppointments(data, callback);
        updatePatients(data.PatNum);
      },
      async () => {
        try {
          await fetchOpendentalData(req, res, 7, patids);
          const allPatients = await models.SchedulePatients.findAll({
            raw: true,
          });
          return res.status(200).send({
            data: allPatients,
            message: `Data fetched and updated`,
          });
        } catch (error) {
          console.log(error);
          return res.status(500).send({ error: error });
        }
      }
    );
  }
};
module.exports.logaudit = logaudit;
async function logaudit(
  successType,
  patientId,
  sourceFrom,
  verificationType,
  appointmentDate,
  lastVerified,
  startDate,
  endDate,
  adminId,
  patientCreatedTime
) {
  try {
    await models.auditlog.create({
      successType: successType,
      patientId: patientId,
      sourceFrom: sourceFrom,
      verificationType: verificationType,
      appointmentDate: appointmentDate,
      lastVerified: lastVerified,
      startDate: startDate,
      endDate: endDate,
      adminId: adminId,
      patientCreatedTime: patientCreatedTime,
    });
  } catch (e) {
    console.log(e, "<--3808");
  }
}

const updatePatients = async (patientNum) => {
  try {
    const response = await axios.get(
      `${OpenDentalApiPath}/patients/${patientNum}`,
      {
        headers: {
          Authorization: OpenDentalAuthorization,
        },
      }
    );

    // function to get all patients
    const addPatient = async (newPatient) => {
      const newData = {};
      newData.lastName = `${newPatient?.LName}`;
      newData.firstName = `${newPatient?.FName}`;
      newData.Preferred = `${newPatient?.Preferred}`;
      newData.PatStatus = `${newPatient?.PatStatus}`;
      newData.Gender = `${newPatient?.Gender}`;
      newData.Position = `${newPatient?.Position}`;
      newData.dateOfBirth = `${newPatient?.Birthdate}`;
      newData.SSN = `${newPatient?.SSN}`;
      newData.Address = `${newPatient?.Address}`;
      newData.Address2 = `${newPatient?.Address2}`;
      newData.City = `${newPatient?.City}`;
      newData.State = `${newPatient?.State}`;
      newData.Zip = `${newPatient?.Zip}`;
      newData.HmPhone = `${newPatient?.HmPhone}`;
      newData.WkPhone = `${newPatient?.WkPhone}`;
      newData.WirelessPhone = `${newPatient?.WirelessPhone}`;
      newData.email = `${newPatient?.Email}`;
      newData.PriProv = `${newPatient?.PriProv}`;
      newData.priProvAbbr = `${newPatient?.priProvAbbr}`;
      newData.secProvAbbr = `${newPatient?.secProvAbbr}`;
      newData.BillingType = `${newPatient?.BillingType}`;
      newData.ChartNumber = `${newPatient?.ChartNumber}`;
      newData.ClinicNum = `${newPatient.ClinicNum}`;
      newData.statusflag = "A";
      newData.patientId = `${newPatient?.PatNum}`;
      newData.isScheduled = true;
      newData.PatCreatedAt = `${newPatient.DateTStamp}`;

      try {
        const existingPatient = await models.ODPatients.findByPk(
          `${newPatient.PatNum}`
        );

        if (existingPatient) {
          // Update existing patient
          await existingPatient.update(newData);
        } else {
          // Create new patient
          await models.ODPatients.create({
            patientId: `${newPatient.PatNum}`,
            ...newData,
          });
        }
      } catch (error) {
        console.log(error);
      }
    };
    addPatient(response.data);
  } catch (e) {
    console.log("-------addpatient error", e);
  }
};

module.exports.getallFamilyModules = async (req, res) => {
  // #swagger.tags = ['Patients']
  const OpenDentalApiPath = process.env.OPEN_DENTAL_URL;
  const OpenDentalAuthorization = process.env.OPEN_DENTAL_AUTHORIZATION;
  try {
    const odPatients = await models.ODPatients.findAll();
    for (const val of odPatients) {
      if (val.dataValues) {
        const response = await axios.get(
          `${OpenDentalApiPath}/familymodules/${val.dataValues.patientId}/Insurance`,
          {
            headers: {
              Authorization: OpenDentalAuthorization,
            },
          }
        );
        const responseData = response && response.data;
        if (responseData && responseData.length > 0) {
          async.eachSeries(
            responseData,
            async (data, callback) => {
              const familyModuleData = {};
              familyModuleData.patientId = `${data?.PatNum}`;
              familyModuleData.relationship = `${data?.Relationship}`;
              familyModuleData.subscriberId = `${data?.SubscriberID}`;
              familyModuleData.groupId = `${data?.GroupNum}`;
              familyModuleData.InsuranceName = `${data?.CarrierName}`;
              familyModuleData.Insurance = `${data?.CarrierNum}`;
              familyModuleData.EmployerNum = `${data?.EmployerNum}`;
              familyModuleData.planType = `${data?.planType}`;
              familyModuleData.Plan_Type = `${data?.PlanType}`;
              familyModuleData.InsSubNum = `${data?.InsSubNum}`;
              familyModuleData.PlanNum = `${data?.PlanNum}`;
              const existingFamilyModule = await ODFamilyModulesModel.findByPk(
                `${data?.subscriber}`
              );

              if (existingFamilyModule) {
                // Update existing insSubsData
                await existingFamilyModule.update(familyModuleData);
                count = count + 1;
                callback();
              } else {
                // Create new insSubsData
                await ODFamilyModulesModel.create({
                  subscriber: data.subscriber,
                  ...familyModuleData,
                });
                callback();
              }
            },
            () => {
              //
            }
          );
        }
      }
    }
    return res.status(200).send({
      data: [],
      message: `FamilyModules Data fetched and updated`,
    });
  } catch (e) {
    res
      .status(400)
      .send({ error: e, message: "Scheduled data creation error" });
  }
};

module.exports.getallPatientsData = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { isHistory, adminId } = req.query;
  try {
    const dateThreshold = new Date();
    const adminSettings = await models.GeneralSettings.findOne({
      where: {
        adminId,
      },
      raw: true
    });
    const historyDays = adminSettings?.activedays || 30;

    dateThreshold.setDate(dateThreshold.getDate() - Number(historyDays));

    let whereCondition;

    if (isHistory && isHistory.toString() === "true") {
      // Patients whose lastVerified is more than 30 days old
      whereCondition = {
        lastVerified: {
          [Op.lt]: dateThreshold,
        },
      };
    } else {
      // Patients whose lastVerified is either null or within the last 30 days
      whereCondition = {
        [Op.or]: [
          { lastVerified: null },
          { lastVerified: { [Op.gte]: dateThreshold } },
        ],
      };
    }

    const manualPatients = await models.ManualPatients.findAll({
      where: whereCondition,
    });
    const schedulePatients = await models.SchedulePatients.findAll({
      where: whereCondition,
    });

    const allPatients = [...manualPatients, ...schedulePatients];

    // Get all unique payerIdCodes
    const payerIdCodes = [
      ...new Set(allPatients.map((item) => item.payerIdCode)),
    ];
    const payers = await models.InsurancePayer.findAll({
      where: { payerId: payerIdCodes },
      attributes: ["payerId", "payerLogo"],
    });

    const payersMap = payers.reduce((map, payer) => {
      map[payer.payerId] = payer.payerLogo;
      return map;
    }, {});

    const formattedData = allPatients.map((item) => {
      const allData = item.get({ plain: true });

      const formatDate = (date) =>
        date ? moment(date).format("DD-MM-YYYY") : "";

      return {
        ...allData,
        payerLogo: payersMap[allData.payerIdCode] || null,
        scheduleAppointmentDate: formatDate(allData.scheduleAppointment),
        lastVerifiedDate: formatDate(allData.lastVerified),
        dateOfBirthDate: formatDate(allData.dateOfBirth),
      };
    });

    res.status(200).send({
      data: formattedData,
      message: "Patient details fetched",
    });
  } catch (e) {
    console.log(e);
    res.status(400).send({ error: e, message: "Patient Fetch failed" });
  }
};

module.exports.getfile = async (req, res) => {
  try {
    let filePath = path.join(__dirname, "Uploadpatienttemplate.csv");
    res.download(filePath);
  } catch (e) {
    res.status(400).send({ error: e, message: "Download failed" });
  }
};

module.exports.bulkVerify = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { ids } = req.body;
  try {
    async.eachSeries(
      ids,
      (id, callback) => {
        verifyPatientNow(id, false, callback);
      },
      () => {
        res.status(200).send({
          message: "Patient Verification Completed",
        });
      }
    );
  } catch (e) {
    res.status(400).send({ error: e, message: "Patient Verification failed" });
  }
};

module.exports.bulkVerifyAll = async (req, res) => {
  try {
    const { isPrimary, isSecondary } = req.query;
    const dateThreshold = new Date();
    dateThreshold.setDate(dateThreshold.getDate() - 30);

    let whereCondition = {
      createdAt: {
        [Op.gte]: dateThreshold,
      },
    };

    if (isPrimary && isPrimary.toString() === "true")
      whereCondition.primary = true;
    if (isSecondary && isSecondary.toString() === "true")
      whereCondition.secondary = true;

    const manualPatients = await models.ManualPatients.findAll({
      where: whereCondition,
      attributes: ["uniqueId"],
      raw: true,
    });

    const schedulePatients = await models.SchedulePatients.findAll({
      where: whereCondition,
      attributes: ["uniqueId", "isScheduled"],
      raw: true,
    });

    const ids = [...manualPatients, ...schedulePatients];
    async.eachSeries(
      ids,
      (id, callback) => {
        verifyPatientNow(id, false, callback);
      },
      () => {
        res.status(200).send({
          message: "Patient Verification Completed",
        });
      }
    );
  } catch (e) {
    res.status(400).send({ error: e, message: "Bulk Verification failed" });
  }
};

const receiveMessages = async () => {
  const params = {
    QueueUrl: queueUrl,
    MaxNumberOfMessages: 1, // Adjusted to process up to 10 messages at a time
    WaitTimeSeconds: 20, // Long polling
  };

  try {
    const data = await sqs.receiveMessage(params).promise();
    if (data.Messages) {
      for (const message of data.Messages) {
        const patientData = JSON.parse(message.Body);
        console.log(`Processing patient data --->`, patientData);
        try {
          await verifyPatientNow(patientData, false);
          await deleteMessage(message.ReceiptHandle);
        } catch (error) {
          console.error(`Error processing message: ${error.message}`);
        }
      }
    }
  } catch (error) {
    console.error(`Error receiving messages: ${error.message}`);
  }
};

const deleteMessage = async (receiptHandle) => {
  const params = {
    QueueUrl: queueUrl,
    ReceiptHandle: receiptHandle,
  };

  try {
    await sqs.deleteMessage(params).promise();
    console.log(`Message deleted`);
  } catch (error) {
    console.error(`Error deleting message: ${error.message}`);
  }
};

// setInterval(receiveMessages, 3000);

module.exports.bulkexclude = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { ids } = req.body;
  try {
    if (ids?.length > 0) {
      async.eachSeries(
        ids,
        (id, callback) => {
          if (id.isScheduled) {
            models.SchedulePatients.update(
              { isexclude: true },
              {
                where: {
                  uniqueId: id.uniqueId,
                },
              }
            )
              .then(() => {
                callback();
              })
              .catch((err) => console.log(err));
          } else {
            models.ManualPatients.update(
              { isexclude: true },
              {
                where: {
                  uniqueId: id.uniqueId,
                },
              }
            )
              .then(() => {
                callback();
              })
              .catch((err) => console.log(err));
          }
        },
        () => {
          res.status(200).send({
            message: "Patient Verification Completed",
          });
        }
      );
    } else {
      res.status(400).send({
        message: "No Records Found",
      });
    }
  } catch (e) {
    console.log(e);
    res.status(400).send({ error: e, message: "No Records Found" });
  }
};

module.exports.bulkpdfdownload = async (req, res) => {
  // #swagger.tags = ['Patients']
  const { manualPatientsIds, schedulePatientIds } = req.body;

  try {
    // if (ids?.length > 0) {

    const schedulePatientsData = await models.SchedulePatients.findAll({
      where: {
        uniqueId: {
          [Op.in]: schedulePatientIds,
        },
      },
    });
    const manualPatientData = await models.ManualPatients.findAll({
      where: {
        uniqueId: {
          [Op.in]: manualPatientsIds,
        },
      },
    });
    const allPatients = [...schedulePatientsData, ...manualPatientData];
    for (let patient of allPatients) {
      const payerlogo = await models.InsurancePayer.findOne({
        where: { payerId: patient.payerIdCode },
      });
      patient.payerLogo = payerlogo?.payerLogo ? payerlogo.payerLogo : null;
    }
    const columns = [
      "patientId",
      "Patient Name",
      "typeOfService",
      "practiceNameAndLoc",
      "appointmentType",
      "Insurance  Name",
      "remainingBenefits",
      "scheduleAppointment",
      "lastVerified",
      "memberId",
      "status",
      "speciality",
      "dateOfBirth",
      "appointmentRenderingProvider",
      "Insurance Name & Plan",
    ];
    const tableData =
      allPatients?.length > 0 &&
      allPatients
        .map((item, i) => {
          let str = "";
          const className = i % 2 === 0 ? "even-row" : "odd-row";
          for (const column of columns) {
            let columnValue = item[column] || "-";

            if (item[column] && item[column] instanceof Date) {
              columnValue = moment(item[column]).format("DD/MM/YYYY");
            }
            if (column === "Patient Name") {
              columnValue = `${item.firstName} ${item.lastName}`.trim();
            } else if (column === "subscriberName") {
              columnValue =
                `${item.subscriberFirstName} ${item.subscriberLastName}`.trim();
            } else if (column === "dependentName") {
              columnValue =
                `${item.dependentFirstName} ${item.dependentLastName}`.trim();
            } else if (column === "insuranceName") {
              columnValue = `<img src="${item.payerLogo}" />`;
            } else if (column === "Insurance Name & Plan") {
              columnValue = `${
                item.insuranceName ? item.insuranceName + "/" : ""
              }${item.insurancePlan ? item.insurancePlan : ""}`.trim();
            }
            if (column === "status") {
              item.effectiveDateFrom
                ? (str += `<td><span class="active">Active<span></td>`)
                : (str += `<td><span class="inactive">InActive<span></td>`);
            } else {
              str += `<td><span class=${
                column === "Patient Name" || column === "patientId"
                  ? "underlined"
                  : ""
              }>${columnValue}</span></td>`;
            }
          }
          return `<tr class="${className}">${str}</tr>`;
        })
        .join("");
    const browser = await puppeteer.launch({
      executablePath: "/usr/bin/google-chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
    const page = await browser.newPage();
    const tableHeaders =
      columns?.length > 0 &&
      columns
        .map(
          (item) =>
            item &&
            `
        <th>${item
          .replace(/([A-Z])/g, " $1")
          .trim()
          .replace(/^\w/, (c) => c.toUpperCase())}</th>
    `
        )
        .join("");
    const content = `
<html>
<head>
</head>
<style>
.active{
  width:50px;
  padding:4px;
  border-radius:10px;
  background-color:#E9F6ED;
  border:1px solid green;
}
.Inactive{
  width:50px;
  padding:4px;
  border-radius:10px;
  background-color:#FBE9EA;
  border:1px solid red;
}
h1,h2,h3,h4,h5,h6,p,li,ul{
  margin:0;
  padding:0;
}
body {
  font-family: 'Roboto', sans-serif;
  font-style: normal !important;
  margin: 0;
  padding:20px;
  box-sizing:border-box;
}
table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #dee2e6;
}
thead {
  display: table-header-group;
}
tr{
border-top: 1px solid #dee2e6;
}
td{
font-size:10px !important;
}
th, td {
  padding: 8px 5px;
  text-align: left;
}
th{
font-size:10px;
}
.d-flex{
  display: -webkit-flex;
  display: flex;
}
.jbw{
  -webkit-justify-content: space-between;
  justify-content: space-between;
}
.alc{
  -webkit-align-items: center;
  align-items: center;
}
.fw{
  flex-wrap:wrap;
  -webkit-flex-wrap: wrap;
}
.w-50{
  width: 50%;
}
.fs-12{
  font-size: 12px;
}
.fw-500{
  font-weight: 500;
}
.w-100{
  width: 100%;
}
li{
  list-style-type:none;
}
.labelColor{
  color:#9F9F9F;
}
.pendingList{
  width:75%;
}
.tal{
  text-align: left;
}
.mb-10{
  margin-bottom:10px;
}
.mb-30{
  margin-bottom:30px;
}
.flex-grow {
  flex-grow: 1; 
  flex-basis: 0;
}
.fs-14{
  font-size:14px;
} 
.even-row {
  background: #fafafa;
}
.odd-row {
  background: #f5f5f5;
}
.underlined {
  text-decoration: underline;
  color: #8dbdca;
}
</style>
<body>
<table>
      <thead>
            <tr>
            ${tableHeaders} 
            </tr>
      </thead>
      <tbody>
      ${tableData}
      </tbody>
      </table>
</div>
</body>
</html>`;
    await page.setContent(content);
    const pdfBuffer = await page.pdf({
      format: "Ledger",
      path: "output.pdf",
    });
    await browser.close();
    res.contentType("application/pdf");
    res.status(200).send(pdfBuffer);
  } catch (e) {
    console.log(e);
    res.status(400).send({ error: e, message: "No Records Found" });
  }
};
