const successMail = () => {
    return {
        subject: "Dental Eligibility Verification - Successful Verification",
        text: `     We are pleased to inform you that the eligibility 
        verification for a patient has been successfully completed. 
        Please review the patient details from the attachment.`
    };
}

const errorMail = () => {
    return {
        subject: "Dental Eligibility Verification - Not Linked with Clearing House",
        text: `     We regret to inform you that the eligibility verification for a 
        patient was unsuccessful as the payer is not linked with our clearing house. 
        Please review the patient details from the attachment and proceed with manual 
        verification through the specific insurance payer portal.`
    };
}

const demographic = () => {
    return {
        subject: "Dental Eligibility Verification - Invalid Demographic Info",
        text: `     We encountered an issue while verifying the eligibility for a 
        patient due to invalid demographic information. Please review the patient 
        details from the attachment and update the demographic information accordingly 
        for accurate verification.`
    };
}

const technicalError = () => {
    return {
        subject: "Dental Eligibility Verification - Technical Error",
        text: `     We apologize for the inconvenience, but we encountered a technical 
        error while verifying the eligibility for a patient. Please review the patient 
        details from the attachment and check the error log from the settings module 
        for more details. Reach out to our technical support team for assistance if needed.`
    };
}

const updatePatientEmail = (patientName) => {
    return {
        subject: "Patient Information Update - Please Verify",
        text: `This is to inform you that patient information (${patientName}) has been updated in the
         Eligibility Verification (EBV) application.Please review the attached file for 
         the updated patient details and verify their eligibility accordingly.`
    }
}

const deletePatient = () => {
    return {
        subject: "Patient Information Deletion Notification",
        text: `We regret to inform you that patient information has been deleted from the EBV 
        application.Please find attached the details of the deleted patient for your reference.`
    }
}
module.exports = {
    successMail,
    errorMail,
    demographic,
    technicalError,
    updatePatientEmail,
    deletePatient
};
