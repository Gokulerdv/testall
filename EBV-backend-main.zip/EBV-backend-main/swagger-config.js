const swaggerJSDoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0', // Specify the OpenAPI version
    info: {
      title: 'UAT-KUBE-EBV-Collections',
      version: '1.0.0',
      description: '',
    },
  },
  // Specify API routes and controller files
  apis: ['./routes/*.js', './controller/*.js'],
};

const swaggerSpec = swaggerJSDoc(options);

module.exports = swaggerSpec;
