const swaggerAutogen = require("swagger-autogen")();
const doc = {
  info: {
    title: "EBV-APIs",
    description: "Version 3.0"
  },
  host: "kube.zylensolutions.com",
  basePath:"/",
  tags: [
    {
      name: "Opendental",
      description: "Endpoints related to opendental operations"
    },
    {
      name: "Patients",
      description: "Endpoints related to patients operations"
    },
    {
      name: "Eligibility",
      description: "Endpoints related to eligibility operations"
    }
  ]
};

const outputFile = "./swagger-output.json";
const routes = ["./app.js"];

swaggerAutogen(outputFile, routes, doc);
