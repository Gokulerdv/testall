# Node-DDB-Boilerplate
Boilerplate for ExpressJS with Amazon DynamoDB 

1. To intall packages
    npm install or yarn

2. To run the server
    npm start or yarn start
    
3. cmd to create tables
    npx sequelize-cli db:migrate
