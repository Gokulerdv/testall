const serverless = require('serverless-http');
const app = require('./app');
const loadSequelize = require('./db/model');

let sequelize = null;

module.exports.handler = async (event, context) => {
  if (!sequelize) {
    sequelize = await loadSequelize();
  } else {
    sequelize.connectionManager.initPools();
    if (sequelize.connectionManager.hasOwnProperty("getConnection")) {
      delete sequelize.connectionManager.getConnection;
    }
  }

  const serverlessHandler = serverless(app);

  return serverlessHandler(event, context).finally(async () => {
    await sequelize.connectionManager.close();
  });
};
