import FormBuilder from "../components/form-builder/main";

export const BuilderPage = () => {
  return (
    <>
      <FormBuilder />
    </>
  );
};

export default BuilderPage;
