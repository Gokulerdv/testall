import { FormBuilderContext } from "../components/form-builder/main";
import Preview from "../components/form-builder/preview";
import data from "../example-form-data.json";

export const ViewerPage = () => {
  return (
    <>
      <FormBuilderContext.Provider value={{ state: data.form } as any}>
        <Preview />
      </FormBuilderContext.Provider>
    </>
  );
};

export default ViewerPage;
