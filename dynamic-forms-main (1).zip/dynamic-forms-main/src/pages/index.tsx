/* eslint-disable @typescript-eslint/no-explicit-any */
import { faEye } from "@fortawesome/free-solid-svg-icons";
import {
  Button,
  Link,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { NavLink, useNavigate } from "react-router-dom";
// import Card, { CardBody } from "../ui/Card";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useSuspenseQuery } from "@tanstack/react-query";

// import { useState } from "react";

export const getAllForms = async (): Promise<any> => {
  const url = `${import.meta.env.VITE_API_HOST}/patient/form/list`;

  const response = await (
    await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
  ).json();
  return response;
};

const HomePage = () => {
  const navigate = useNavigate();

  const { data: forms } = useSuspenseQuery({
    queryKey: ["forms", "getAll"],
    queryFn: getAllForms,
  });

  return (
    <>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableCell align="right" colSpan={5}>
              <Button
                color="primary"
                variant="contained"
                component={NavLink}
                to="builder"
              >
                + Add Form
              </Button>
            </TableCell>
          </TableHead>
          <TableHead>
            <TableRow>
              <TableCell>Form ID</TableCell>
              <TableCell align="left">Form Name</TableCell>
              <TableCell align="left">Created Date</TableCell>
              <TableCell align="left">Created By</TableCell>
              <TableCell align="left">Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {forms?.data?.map((row: any) => (
              <TableRow key={row?.FormId}>
                <TableCell component="th" scope="row">
                  {row?.FormId}
                </TableCell>
                <TableCell align="left">{row?.FormName}</TableCell>
                <TableCell align="left">
                  {new Date(row?.CreatedDate).toLocaleDateString()}
                </TableCell>
                <TableCell align="left">{row?.CreatedBy}</TableCell>
                <TableCell align="left">
                  <Link
                    component="button"
                    variant="body2"
                    onClick={() => {
                      navigate("/builder", { state: row?.FormId });
                    }}
                  >
                    <FontAwesomeIcon
                      icon={faEye}
                      style={{ marginRight: "6px" }}
                    />
                  </Link>
                  {/* <Link>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </Link> */}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
};

export default HomePage;
