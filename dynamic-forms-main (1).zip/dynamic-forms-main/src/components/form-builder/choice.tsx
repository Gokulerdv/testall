import { faCheck, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import Button from "../../ui/Button";
import Card from "../../ui/Card";
import Grid from "../../ui/Grid";
import Menu from "../../ui/Menu";
import Stack from "../../ui/Stack";
import Typography from "../../ui/Typography";
import CardHeaderContents from "./card-header-contents";
import { useFormBuilderContext } from "./main";
import {
  ChoiceContext,
  ChoiceState,
  useChoice,
  useChoiceContext,
} from "./use-choice";

export type ChoiceProps = {
  focused: boolean;
  index?: number;
  defaultState?: ChoiceState;
};

export const Choice = ({ defaultState, ...props }: ChoiceProps) => {
  const choice = useChoice({ props, defaultState });

  const formBuilder = useFormBuilderContext();

  React.useEffect(() => {
    if (props.index === undefined) return;

    formBuilder.dispatcher({
      type: "set-question-state",
      payload: {
        index: props.index,
        state: choice.state,
      },
    });
  }, [choice.state]);

  return (
    <>
      <ChoiceContext.Provider value={choice}>
        {props.focused ? (
          <ChoiceFocused />
        ) : (
          <div
            onClick={() => {
              formBuilder.dispatcher({
                type: "set-question-index-in-focus",
                payload: props.index as number,
              });
            }}
          >
            <ChoicePreview state={choice.state} index={props.index as number} />
          </div>
        )}
      </ChoiceContext.Provider>
    </>
  );
};

export type ChoicePreviewProps = {
  state: ChoiceState;
  index: number;
};

export const ChoicePreview = (props: ChoicePreviewProps) => {
  const name = React.useId();
  const [showOtherOptionTextField, setShowOtherOptionTextField] =
    React.useState<boolean>(false);

  return (
    <div className="mt-3 mb-3">
      <Typography as="h6">
        {props.index + 1}. {props.state.question}
      </Typography>
      {props.state.subtitle ? (
        <Typography as="small">{props.state.subtitle}</Typography>
      ) : null}
      {props.state.isDropdown ? (
        <>
          <select
            className="form-select"
            name={`question-${props.index}`}
            onChange={(event) => {
              if (event.target.value === "Other") {
                return setShowOtherOptionTextField(true);
              }
              return setShowOtherOptionTextField(false);
            }}
          >
            {props.state.options.map((option) => (
              <option value={String(option)}>{option}</option>
            ))}
            {props.state.otherOption ? (
              <option value={props.state.otherOption}>
                {props.state.otherOption}
              </option>
            ) : null}
          </select>
          {showOtherOptionTextField ? (
            <input
              name={`question-${props.index}`}
              type="text"
              className="form-control"
              placeholder="Enter your answer"
            />
          ) : null}
        </>
      ) : (
        <>
          {props.state.options.map((option) => (
            <ChoiceOptionPreview
              key={String(option)}
              name={`question-${props.index}`}
              label={option}
              multiple={props.state.multiple}
            />
          ))}
          {props.state.otherOption ? (
            <ChoiceOptionPreview
              key={String(props.state.otherOption)}
              name={`question-${props.index}`}
              label={
                <input
                  type="text"
                  className="form-control"
                  placeholder="Other"
                />
              }
              multiple={props.state.multiple}
            />
          ) : null}
        </>
      )}
    </div>
  );
};

export type ChoiceOptionPreviewProps = {
  name: string;
  label: React.ReactNode;
  multiple: boolean;
  index?: number;
};

export const ChoiceOptionPreview = (props: ChoiceOptionPreviewProps) => {
  const id = React.useId();

  return (
    <div className="form-check">
      {props.multiple ? (
        <input
          className="form-check-input"
          type="checkbox"
          name={props.name}
          id={id}
          value={String(props.label)}
        />
      ) : (
        <input
          className="form-check-input"
          type="radio"
          name={props.name}
          id={id}
          value={String(props.label)}
        />
      )}
      <label className="form-check-label" htmlFor={id}>
        {props.label}
      </label>
    </div>
  );
};

// TODO: Validation

export const ChoiceFocused = () => {
  const { state, dispatcher, props } = useChoiceContext();
  const name = React.useId();

  return (
    <Card>
      <Card.Head>
        <Card.Header title="" action={<CardHeaderContents />} />
      </Card.Head>

      <Card.Body>
        <Grid.Row>
          <Grid.Col cols="auto">{(props.index ?? 0) + 1}.</Grid.Col>
          <Grid.Col>
            <input
              type="text"
              className="w-100 form-control form-control-sm"
              value={state.question}
              onChange={(event) =>
                dispatcher({
                  type: "set-question",
                  payload: event.target.value,
                })
              }
            />
            {state.subtitle !== undefined ? (
              <input
                type="text"
                className="w-100 mt-3 form-control form-control-sm"
                placeholder="Enter your subtitle"
                value={state.subtitle}
                onChange={(event) =>
                  dispatcher({
                    type: "set-subtitle",
                    payload: event.target.value,
                  })
                }
              />
            ) : null}
            <Stack className="mt-3">
              {state.options.map((option, index) => (
                <ChoiceOption
                  name={name}
                  option={option}
                  index={index}
                  key={index}
                />
              ))}
              {state.otherOption ? (
                <ChoiceOption name={name} option={state.otherOption} disabled />
              ) : null}
              <Stack orientation="horizontal">
                <Button
                  onClick={() =>
                    dispatcher({
                      type: "add-option",
                      payload: `Option ${state.options.length + 1}`,
                    })
                  }
                >
                  Add Option
                </Button>
                {state.otherOption ? null : (
                  <Button
                    onClick={() =>
                      dispatcher({
                        type: "add-other-option",
                        payload: "Other",
                      })
                    }
                  >
                    Add Other Option
                  </Button>
                )}
              </Stack>
            </Stack>
          </Grid.Col>
        </Grid.Row>
      </Card.Body>
      <Card.Footer>
        <Stack orientation="horizontal" justifyContent="end">
          <div className="form-check form-switch me-3">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckChecked"
              checked={state.multiple}
              onChange={() => dispatcher({ type: "toggle-multiple" })}
              disabled={state.isDropdown}
            />
            <label
              className="form-check-label"
              htmlFor="flexSwitchCheckChecked"
            >
              Multiple Answer
            </label>
          </div>
          <div className="form-check form-switch me-3">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckChecked"
              checked={state.required}
              onChange={() => dispatcher({ type: "toggle-required" })}
            />
            <label
              className="form-check-label"
              htmlFor="flexSwitchCheckChecked"
            >
              Required
            </label>
          </div>
          <Menu
            dropdown={<Menu.Dropdown />}
            trigger={<Menu.Trigger size="sm" />}
            {...{
              options: state.multiple
                ? [
                    {
                      as: "a",
                      id: "1",
                      label: (
                        <>
                          {state.subtitle !== undefined ? (
                            <FontAwesomeIcon icon={faCheck} />
                          ) : null}{" "}
                          subtitle
                        </>
                      ),
                      onClick: () => dispatcher({ type: "toggle-subtitle" }),
                    },
                  ]
                : [
                    {
                      as: "a",
                      id: "1",
                      label: (
                        <>
                          {state.subtitle !== undefined ? (
                            <FontAwesomeIcon icon={faCheck} />
                          ) : null}{" "}
                          subtitle
                        </>
                      ),
                      onClick: () => dispatcher({ type: "toggle-subtitle" }),
                    },
                    {
                      as: "a",
                      id: "2",
                      label: (
                        <>
                          {state.isDropdown ? (
                            <FontAwesomeIcon icon={faCheck} />
                          ) : null}{" "}
                          dropdown
                        </>
                      ),
                      onClick: () => dispatcher({ type: "toggle-dropdown" }),
                    },
                  ],
              name: "choice-menu-dropdown",
            }}
          />
        </Stack>
      </Card.Footer>
    </Card>
  );
};

export type ChoiceOptionProps = {
  name: string;
  option: ChoiceState["options"][0];
  index?: number;
  disabled?: boolean;
};

export const ChoiceOption = (props: ChoiceOptionProps) => {
  const { state, dispatcher } = useChoiceContext();

  return (
    <Grid.Row alignItems="center">
      <Grid.Col cols="auto">
        <div className="form-check">
          {state.multiple ? (
            <input
              className="form-check-input"
              type="checkbox"
              name={props.name}
              readOnly
              checked={false}
              tabIndex={-1}
            />
          ) : (
            <input
              className="form-check-input"
              type="radio"
              name={props.name}
              readOnly
              checked={false}
              tabIndex={-1}
            />
          )}
        </div>
      </Grid.Col>

      <Grid.Col>
        <Stack>
          <Stack.Item cols="12">
            <input
              type="text"
              value={String(props.option)}
              onChange={(event) => {
                if (props.index === undefined) return;
                dispatcher({
                  type: "set-option",
                  payload: { option: event.target.value, index: props.index },
                });
              }}
              disabled={props.disabled}
            />

            <Button
              onClick={() =>
                props.index !== undefined
                  ? dispatcher({
                      type: "remove-option",
                      payload: props.index,
                    })
                  : dispatcher({
                      type: "remove-other-option",
                    })
              }
            >
              <FontAwesomeIcon icon={faTrash} />
            </Button>
          </Stack.Item>
        </Stack>
      </Grid.Col>
    </Grid.Row>
  );
};

export default Choice;
