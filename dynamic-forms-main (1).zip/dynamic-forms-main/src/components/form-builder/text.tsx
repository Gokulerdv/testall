import { faCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import Card from "../../ui/Card";
import Grid from "../../ui/Grid";
import Menu from "../../ui/Menu";
import Stack from "../../ui/Stack";
import Typography from "../../ui/Typography";
import CardHeaderContents from "./card-header-contents";
import { useFormBuilderContext } from "./main";
import { TextContext, TextState, useText, useTextContext } from "./use-text";

export type TextProps = {
  focused: boolean;
  index?: number;
};

export const Text = (props: TextProps) => {
  const formBuilder = useFormBuilderContext();

  const text = useText({ props });

  React.useEffect(() => {
    if (props.index === undefined) return;

    formBuilder.dispatcher({
      type: "set-question-state",
      payload: {
        index: props.index,
        state: text.state,
      },
    });
  }, [text.state]);

  return (
    <>
      <TextContext.Provider value={text}>
        {props.focused ? (
          <TextFocused />
        ) : (
          <div
            onClick={() => {
              formBuilder.dispatcher({
                type: "set-question-index-in-focus",
                payload: props.index as number,
              });
            }}
          >
            <TextPreview state={text.state} index={props.index as number} />
          </div>
        )}
      </TextContext.Provider>
    </>
  );
};

export type TextPreviewProps = {
  state: TextState;
  index: number;
};

export const TextPreview = (props: TextPreviewProps) => {
  return (
    <div className="mt-4 mb-4">
      <Typography as="h6">
        {props.index + 1}. {props.state.question}
      </Typography>
      {props.state.subtitle ? (
        <Typography as="small">{props.state.subtitle}</Typography>
      ) : null}
      {props.state.longAnswer ? (
        <textarea
          name={`question-${props.index}`}
          className="w-100 mt-3 form-control form-control-sm"
          placeholder="Enter your answer"
        />
      ) : (
        <input
          name={`question-${props.index}`}
          className="form-control form-control-sm "
          type="text"
          placeholder="Answer"
        />
      )}
    </div>
  );
};

export const TextFocused = () => {
  const { state, dispatcher, props } = useTextContext();

  return (
    <>
      <Card>
        <Card.Head>
          <Card.Header title="" action={<CardHeaderContents />} />
        </Card.Head>

        <Card.Body>
          <Grid.Row>
            <Grid.Col cols="auto">
              <Typography className="float-end">
                {(props.index ?? 0) + 1}.
              </Typography>
            </Grid.Col>
            <Grid.Col>
              <input
                className="form-control form-control-sm"
                type="text"
                placeholder="Question"
                value={state.question}
                onChange={(event) =>
                  dispatcher({
                    type: "set-question",
                    payload: event.target.value,
                  })
                }
              />

              {state.subtitle !== undefined ? (
                <input
                  type="text"
                  className="w-100 mt-3 form-control form-control-sm"
                  placeholder="Enter your subtitle"
                  value={state.subtitle}
                  onChange={(event) =>
                    dispatcher({
                      type: "set-subtitle",
                      payload: event.target.value,
                    })
                  }
                />
              ) : null}

              <Stack className="mt-4">
                <div className="w-100 mb-3 ">
                  {state.longAnswer ? (
                    <textarea
                      className="w-100 mt-3 form-control form-control-sm"
                      placeholder="Enter your subtitle"
                      disabled
                    />
                  ) : (
                    <input
                      className="form-control form-control-sm "
                      type="text"
                      placeholder="Answer"
                      disabled
                    />
                  )}
                </div>
              </Stack>
            </Grid.Col>
          </Grid.Row>
        </Card.Body>

        <Card.Footer>
          <Stack orientation="horizontal" justifyContent="end">
            <div className="form-check form-switch me-3">
              <input
                className="form-check-input"
                type="checkbox"
                role="switch"
                id="flexSwitchCheckChecked"
                checked={state.required}
                onChange={() => dispatcher({ type: "toggle-required" })}
              />
              <label
                className="form-check-label"
                htmlFor="flexSwitchCheckChecked"
              >
                Required
              </label>
            </div>
            <div className="form-check form-switch me-3">
              <input
                className="form-check-input"
                type="checkbox"
                role="switch"
                id="flexSwitchCheckChecked"
                checked={state.longAnswer}
                onChange={() => dispatcher({ type: "toggle-long-answer" })}
              />
              <label
                className="form-check-label"
                htmlFor="flexSwitchCheckChecked"
              >
                Long Answer
              </label>
            </div>

            <Menu
              dropdown={<Menu.Dropdown />}
              trigger={<Menu.Trigger size="sm" />}
              {...{
                options: [
                  {
                    as: "a",
                    id: "1",
                    label: (
                      <>
                        {state.subtitle !== undefined ? (
                          <FontAwesomeIcon icon={faCheck} />
                        ) : null}{" "}
                        subtitle
                      </>
                    ),
                    onClick: () => dispatcher({ type: "toggle-subtitle" }),
                  },
                ],
                name: "choice-menu-dropdown",
              }}
            />
          </Stack>
        </Card.Footer>
      </Card>
    </>
  );
};
export default Text;
