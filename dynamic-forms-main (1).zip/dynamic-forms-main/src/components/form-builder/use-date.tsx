import React from "react";
import { DateProps } from "./date";

export type DateContextValue = {
  state: DateState;
  dispatcher: React.Dispatch<DATE_ACTIONS>;
  props: DateProps;
};

export const DateContext = React.createContext<DateContextValue | null>(null);

export const useDateContext = () => {
  const context = React.useContext(DateContext);

  if (!context)
    throw new Error(
      "Could not find the DateContext. Make sure you have a DateContext.Provider defined above the current component."
    );

  return context;
};

export type DateState = {
  type: "date";
  question: string;
  subtitle?: string;
  required: boolean;
};

export type DATE_ACTIONS =
  | {
      type: "set-question";
      payload: string;
    }
  | {
      type: "toggle-subtitle";
    }
  | {
      type: "set-subtitle";
      payload: string;
    }
  | {
      type: "toggle-required";
    };

export const reducer = (
  previousState: DateState,
  action: DATE_ACTIONS
): DateState => {
  switch (action.type) {
    case "set-question": {
      return {
        ...previousState,
        question: action.payload,
      };
    }
    case "toggle-subtitle": {
      return {
        ...previousState,
        subtitle: previousState.subtitle === undefined ? "" : undefined,
      };
    }
    case "set-subtitle": {
      return {
        ...previousState,
        subtitle: action.payload,
      };
    }
    case "toggle-required": {
      return {
        ...previousState,
        required: !previousState.required,
      };
    }
    default: {
      return { ...previousState };
    }
  }
};

export type UseDateProps = {
  props: DateProps;
};

export const useDate = ({ props }: UseDateProps): DateContextValue => {
  const [state, dispatcher] = React.useReducer(reducer, {
    type: "date",
    question: "Question",
    required: false,
  });

  return {
    state,
    dispatcher,
    props,
  };
};
