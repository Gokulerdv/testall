/* eslint-disable @typescript-eslint/no-explicit-any */
import { Button, CircularProgress, Container } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import FormBuilderAddButton from "./add-button";
import Choice from "./choice";
import Date from "./date";
import Header from "./header";
import Preview from "./preview";
import PreviewButton from "./preview-button";
import Text from "./text";
import { TextState } from "./use-text";

export const createForm = async (data: any): Promise<any> => {
  const url = `${import.meta.env.VITE_API_HOST}/patient/form/creation`;
  const response = await (
    await fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
  ).json();
  return response;
};

export type QuestionState = { type: "choice"; [key: string]: unknown };
export type DateState = { type: "date"; [key: string]: unknown };

export type FORM_BUILDER_ACTIONS =
  | {
      type: "add-choice";
    }
  | {
      type: "add-text";
    }
  | {
      type: "add-date";
    }
  | {
      type: "reset-to-json";
    }
  | {
      type: "set-question-state";
      payload: {
        index: number;
        state: QuestionState | TextState | DateState;
      };
    }
  | {
      type: "reset-question-states";
    }
  | {
      type: "set-mode";
      payload: FormBuilderState["mode"];
    }
  | {
      type: "set-question-index-in-focus";
      payload: number;
    }
  | {
      type: "increment-question-index-in-focus";
    }
  | {
      type: "move-question-to-next";
    }
  | {
      type: "move-question-to-previous";
    }
  | {
      type: "delete-question";
    }
  | {
      type: "copy-question";
    }
  | {
      type: "set-name";
      payload: string;
    }
  | {
      type: "set-description";
      payload: string;
    }
  | {
      type: "set-header-in-focus";
    }
  | {
      type: "change-view-mode";
      payload: boolean;
    };

export type FormBuilderState = {
  name: string;
  mode: "builder" | "preview";
  description: string;
  questions: JSX.Element[];
  // toJson: number;
  questionStates: Array<QuestionState | TextState | DateState>;
  questionIndexInFocus?: number;
  isHeaderInFocus: boolean;
  viewMode: boolean;
};

export const reducer = (
  previousState: FormBuilderState,
  action: FORM_BUILDER_ACTIONS
): FormBuilderState => {
  switch (action.type) {
    case "add-choice": {
      const questions = [...previousState.questions];
      questions.splice(
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus + 1,
        0,
        <Choice focused />
      );

      return {
        ...previousState,
        questions,
      };
    }
    case "add-text": {
      const questions = [...previousState.questions];
      questions.splice(
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus + 1,
        0,
        <Text focused />
      );

      return {
        ...previousState,
        questions,
      };
    }
    case "add-date": {
      const questions = [...previousState.questions];
      questions.splice(
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus + 1,
        0,
        <Date focused />
      );

      return {
        ...previousState,
        questions,
      };
    }
    case "set-question-state": {
      const questionStates = [...previousState.questionStates];

      questionStates[action.payload.index] = action.payload.state;

      return {
        ...previousState,
        questionStates,
      };
    }
    case "reset-question-states": {
      return {
        ...previousState,
        questionStates: [],
      };
    }
    case "set-mode": {
      return {
        ...previousState,
        mode: action.payload,
      };
    }
    case "set-question-index-in-focus": {
      return {
        ...previousState,
        questionIndexInFocus: action.payload,
        isHeaderInFocus: false,
      };
    }
    case "increment-question-index-in-focus": {
      return {
        ...previousState,
        questionIndexInFocus:
          previousState.questionIndexInFocus === undefined
            ? 0
            : previousState.questionIndexInFocus + 1,
      };
    }
    case "move-question-to-next": {
      const questions = [...previousState.questions];
      const nextIndex =
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus + 1;
      const focusedIndex =
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus;

      const nextQuestion = questions[nextIndex];
      const focusedQuestion = questions[focusedIndex];

      questions[focusedIndex] = nextQuestion;
      questions[nextIndex] = focusedQuestion;

      return {
        ...previousState,
        questions,
        questionIndexInFocus:
          previousState.questionIndexInFocus === undefined
            ? 0
            : previousState.questionIndexInFocus + 1,
      };
    }
    case "move-question-to-previous": {
      const questions = [...previousState.questions];
      const previousIndex =
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus - 1;
      const focusedIndex =
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus;

      const previousQuestion = questions[previousIndex];
      const focusedQuestion = questions[focusedIndex];

      questions[focusedIndex] = previousQuestion;
      questions[previousIndex] = focusedQuestion;

      return {
        ...previousState,
        questions,
        questionIndexInFocus:
          previousState.questionIndexInFocus === undefined
            ? 0
            : previousState.questionIndexInFocus - 1,
      };
    }
    case "delete-question": {
      if (previousState.questionIndexInFocus === undefined)
        return { ...previousState };

      const questions = previousState.questions.filter(
        (_option, index) => index !== previousState.questionIndexInFocus
      );

      const nextIndexInFocus =
        previousState.questions.length === 1
          ? undefined
          : previousState.questionIndexInFocus > 0
          ? previousState.questionIndexInFocus - 1
          : previousState.questionIndexInFocus;

      return {
        ...previousState,
        questions,
        questionIndexInFocus: nextIndexInFocus,
      };
    }
    case "copy-question": {
      if (previousState.questionIndexInFocus === undefined)
        return { ...previousState };

      const questions = [...previousState.questions];

      questions.splice(
        previousState.questionIndexInFocus === undefined
          ? 0
          : previousState.questionIndexInFocus + 1,
        0,
        previousState.questions[previousState.questionIndexInFocus]
      );

      const nextIndexInFocus = previousState.questionIndexInFocus + 1;

      return {
        ...previousState,
        questions,
        questionIndexInFocus: nextIndexInFocus,
      };
    }
    case "set-name": {
      return {
        ...previousState,
        name: action.payload,
      };
    }
    case "set-description": {
      return {
        ...previousState,
        description: action.payload,
      };
    }
    case "set-header-in-focus": {
      return {
        ...previousState,
        isHeaderInFocus: true,
        questionIndexInFocus: undefined,
      };
    }
    case "change-view-mode": {
      return {
        ...previousState,
        viewMode: action.payload,
      };
    }
    default: {
      return { ...previousState };
    }
  }
};

export type FormBuilderContextValue = {
  state: FormBuilderState;
  dispatcher: React.Dispatch<FORM_BUILDER_ACTIONS>;
  props: FormBuilderProps;
};

export const FormBuilderContext =
  React.createContext<FormBuilderContextValue | null>(null);

export const useFormBuilderContext = () => {
  const context = React.useContext(FormBuilderContext);

  if (!context)
    throw new Error(
      "Could not find the FormBuilderContext. Make sure you have a FormBuilderContext.Provider defined above the current component."
    );

  return context;
};

export const useFormBuilder = (
  props: FormBuilderProps
): FormBuilderContextValue => {
  const [state, dispatcher] = React.useReducer(reducer, {
    mode: "builder",
    name: "Untitled form",
    description: "",
    questions: [],
    questionStates: [],
    isHeaderInFocus: false,
    viewMode: false,
  });

  return {
    state: state,
    dispatcher: dispatcher,
    props,
  };
};

export type FormBuilderProps = {};

const getFormById = (id: string) => async (): Promise<any> => {
  const url = `${import.meta.env.VITE_API_HOST}/patient/form/details`;

  const response = await (
    await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ FormId: id }),
    })
  ).json();

  return response;
};

export const FormBuilder = (props: FormBuilderProps) => {
  const formBuilder = useFormBuilder(props);
  const navigate = useNavigate();
  const location = useLocation();
  const formId = location.state;
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    const fetchForm = async (formId: any) => {
      if (formId) {
        setLoading(true);
        try {
          const response = getFormById(formId);
          const result = await response();
          const formData = result.data.form;
          formBuilder.dispatcher({
            type: "change-view-mode",
            payload: true,
          });
          formBuilder.dispatcher({
            type: "set-mode",
            payload: "preview",
          });
          formBuilder.dispatcher({
            type: "set-name",
            payload: `${formData?.name}`,
          });
          formBuilder.dispatcher({
            type: "set-description",
            payload: `${formData?.description}`,
          });
          formData?.questionStates?.map((ques: any, index: any) => {
            formBuilder.dispatcher({
              type: "set-question-state",
              payload: {
                index: index,
                state: ques,
              },
            });
          });
        } catch (error) {
          console.log(error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchForm(formId);
  }, [formId]);

  const formCreation: any = useMutation({
    mutationKey: ["form/create"],
    mutationFn: createForm,
  });

  const formSubmission = async () => {
    try {
      await formCreation.mutateAsync({
        form: {
          name: formBuilder.state.name,
          description: formBuilder.state.description,
          questionStates: formBuilder.state.questionStates,
        },
        loginUser: "4",
      });
      navigate("/");
    } catch (error) {
      console.log(error);
    }
  };
  if (loading) {
    return (
      <>
        <CircularProgress />
      </>
    );
  }

  return (
    <FormBuilderContext.Provider value={formBuilder}>
      <Container style={{ display: "flex", justifyContent: "end" }}>
        <Button
          color="primary"
          variant="outlined"
          style={{ marginRight: "15px" }}
          onClick={() => {
            formBuilder.dispatcher({
              type: "change-view-mode",
              payload: true,
            });
            navigate("/");
          }}
        >
          Cancel
        </Button>
        {!formBuilder.state.viewMode && (
          <Button
            color="primary"
            variant="outlined"
            style={{ marginRight: "15px" }}
          >
            Save as Draft
          </Button>
        )}
        <PreviewButton />
        {formBuilder.state.mode === "builder" ? (
          <Button
            color="primary"
            variant="contained"
            style={{ marginLeft: "15px" }}
            onClick={formSubmission}
          >
            Publish
          </Button>
        ) : null}
      </Container>

      <div className="my-3">
        {formBuilder.state.mode === "builder" ? (
          <Header focused={formBuilder.state.isHeaderInFocus} />
        ) : null}
      </div>

      <div hidden={formBuilder.state.mode === "preview"}>
        <div className="my-3">
          {formBuilder.state.questions.map((element, index) => (
            <>
              {React.cloneElement(element, {
                ...element.props,
                focused: formBuilder.state.questionIndexInFocus === index,
                index,
              })}
              {formBuilder.state.questionIndexInFocus === index ? (
                <FormBuilderAddButton />
              ) : null}
            </>
          ))}
        </div>
      </div>

      {formBuilder.state.mode === "preview" ? <Preview /> : null}
      {formBuilder.state.mode === "builder" &&
      formBuilder.state.questions.length === 0 ? (
        <FormBuilderAddButton />
      ) : null}
    </FormBuilderContext.Provider>
  );
};

export default FormBuilder;
