import Card from "../../ui/Card";
import Grid from "../../ui/Grid";
import Typography from "../../ui/Typography";
import { useFormBuilderContext } from "./main";

export type HeaderProps = {
  focused: boolean;
};

export const Header = (props: HeaderProps) => {
  const formBuilder = useFormBuilderContext();

  return (
    <>
      <TextFocused />
    </>
  );
};

export type HeaderPreviewProps = {};

export const HeaderPreview = (props: HeaderPreviewProps) => {
  const formBuilder = useFormBuilderContext();

  return (
    <>
      <Typography as="h6">{formBuilder.state.name}</Typography>
      <Typography as="small">{formBuilder.state.description}</Typography>
    </>
  );
};

export const TextFocused = () => {
  const formBuilder = useFormBuilderContext();

  return (
    <>
      <Card>
        <Card.Body>
          <Grid.Row>
            <Grid.Col>
              <input
                className="form-control form-control-sm"
                type="text"
                placeholder="Add form title"
                value={formBuilder.state.name}
                onChange={(event) =>
                  formBuilder.dispatcher({
                    type: "set-name",
                    payload: event.target.value,
                  })
                }
              />

              <input
                type="text"
                className="w-100 mt-3 form-control form-control-sm"
                placeholder="Add form description"
                value={formBuilder.state.description}
                onChange={(event) =>
                  formBuilder.dispatcher({
                    type: "set-description",
                    payload: event.target.value,
                  })
                }
              />
            </Grid.Col>
          </Grid.Row>
        </Card.Body>
      </Card>
    </>
  );
};
export default Header;
