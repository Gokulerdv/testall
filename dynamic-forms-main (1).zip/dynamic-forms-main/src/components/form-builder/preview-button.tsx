import { Button } from "@mui/material";
import { useFormBuilderContext } from "./main";

export const PreviewButton = () => {
  const formBuilder = useFormBuilderContext();

  return (
    <>
      {!formBuilder.state.viewMode &&
        (formBuilder.state.mode === "preview" ? (
          <Button
            color="primary"
            variant="contained"
            onClick={() => {
              formBuilder.dispatcher({
                type: "set-mode",
                payload: "builder",
              });
            }}
          >
            Back to Form Builder
          </Button>
        ) : (
          <Button
            color="primary"
            variant="outlined"
            onClick={() =>
              formBuilder.dispatcher({ type: "set-mode", payload: "preview" })
            }
          >
            Preview
          </Button>
        ))}
    </>
  );
};

export default PreviewButton;
