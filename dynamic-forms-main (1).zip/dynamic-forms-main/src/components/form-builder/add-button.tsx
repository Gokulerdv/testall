/* eslint-disable @typescript-eslint/ban-types */
import { Button } from "@mui/material";
import React from "react";
import Stack from "../../ui/Stack";
import { useFormBuilderContext } from "./main";

export type ACTION = {
  type: "toggle-clicked";
};

export type State = {
  isClicked: boolean;
};

export const reducer = (previousState: State, action: ACTION): State => {
  switch (action.type) {
    case "toggle-clicked": {
      return {
        ...previousState,
        isClicked: !previousState.isClicked,
      };
    }
    default: {
      return {
        ...previousState,
      };
    }
  }
};

export type FormBuilderAddButtonProps = {};

export const FormBuilderAddButton = () => {
  const [state, dispatcher] = React.useReducer(reducer, {
    isClicked: false,
  });

  const formBuilder = useFormBuilderContext();

  return (
    <>
      <Button
        color="primary"
        variant="outlined"
        size="large"
        style={{ width: "inherit", marginTop: "25px" }}
        onClick={() => dispatcher({ type: "toggle-clicked" })}
      >
        {state.isClicked ? (
          <Stack orientation="horizontal" gap="3">
            <Button
              variant="outlined"
              style={{ marginRight: "10px" }}
              onClick={() => {
                formBuilder.dispatcher({ type: "add-choice" });
                formBuilder.dispatcher({
                  type: "increment-question-index-in-focus",
                });
              }}
            >
              Choice
            </Button>

            <Button
              variant="outlined"
              style={{ marginRight: "10px" }}
              onClick={() => {
                formBuilder.dispatcher({ type: "add-text" });
                formBuilder.dispatcher({
                  type: "increment-question-index-in-focus",
                });
              }}
            >
              Text
            </Button>

            <Button
              variant="outlined"
              style={{ marginRight: "10px" }}
              onClick={() => {
                formBuilder.dispatcher({ type: "add-date" });
                formBuilder.dispatcher({
                  type: "increment-question-index-in-focus",
                });
              }}
            >
              Date
            </Button>
          </Stack>
        ) : (
          "Add Question"
        )}
      </Button>
    </>
  );
};

export default FormBuilderAddButton;
