import React from "react";
import { TextProps } from "./text";

export type TextContextValue = {
  state: TextState;
  dispatcher: React.Dispatch<TEXT_ACTIONS>;
  props: TextProps;
};

export const TextContext = React.createContext<TextContextValue | null>(null);

export const useTextContext = () => {
  const context = React.useContext(TextContext);

  if (!context) throw new Error("");

  return context;
};

export type TextState = {
  type: "text";
  question: string;
  required: boolean;
  longAnswer: boolean;
  subtitle?: string;
};

export type TEXT_ACTIONS =
  | {
      type: "set-question";
      payload: string;
    }
  | {
      type: "toggle-required";
    }
  | {
      type: "toggle-long-answer";
    }
  | {
      type: "toggle-subtitle";
    }
  | {
      type: "set-subtitle";
      payload: string;
    };

export const reducer = (
  previousState: TextState,
  action: TEXT_ACTIONS
): TextState => {
  switch (action.type) {
    case "set-question": {
      return {
        ...previousState,
        question: action.payload,
      };
    }
    case "toggle-required": {
      return {
        ...previousState,
        required: !previousState.required,
      };
    }
    case "toggle-long-answer": {
      return {
        ...previousState,
        longAnswer: !previousState.longAnswer,
      };
    }
    case "toggle-subtitle": {
      return {
        ...previousState,
        subtitle: previousState.subtitle === undefined ? "" : undefined,
      };
    }
    case "set-subtitle": {
      return {
        ...previousState,
        subtitle: action.payload,
      };
    }
    default: {
      return { ...previousState };
    }
  }
};

export type UseTextProps = {
  props: TextProps;
};

export const useText = ({ props }: UseTextProps): TextContextValue => {
  const [state, dispatcher] = React.useReducer(reducer, {
    type: "text",
    question: "Question",
    required: false,
    longAnswer: false,
  });

  return {
    state,
    dispatcher,
    props,
  };
};
