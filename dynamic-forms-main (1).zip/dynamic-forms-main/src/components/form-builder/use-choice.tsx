import React from "react";
import { ChoiceProps } from "./choice";

export type ChoiceContextValue = {
  state: ChoiceState;
  dispatcher: React.Dispatch<CHOICE_ACTIONS>;
  props: ChoiceProps;
};

export const ChoiceContext = React.createContext<ChoiceContextValue | null>(
  null
);

export const useChoiceContext = () => {
  const context = React.useContext(ChoiceContext);

  if (!context)
    throw new Error(
      "Could not find the ChoiceContext. Make sure you have a ChoiceContext.Provider defined above the current component."
    );

  return context;
};

export type ChoiceState = {
  type: "choice";
  question: string;
  options: String[];
  otherOption?: string;
  subtitle?: string;
  required: boolean;
  multiple: boolean;
  isDropdown: boolean;
};

export type CHOICE_ACTIONS =
  | {
      type: "add-option";
      payload: string;
    }
  | {
      type: "add-other-option";
      payload: string;
    }
  | {
      type: "remove-option";
      payload: number;
    }
  | {
      type: "remove-other-option";
    }
  | {
      type: "set-question";
      payload: string;
    }
  | {
      type: "set-option";
      payload: {
        index: number;
        option: string;
      };
    }
  | {
      type: "toggle-subtitle";
    }
  | {
      type: "set-subtitle";
      payload: string;
    }
  | {
      type: "toggle-required";
    }
  | {
      type: "toggle-multiple";
    }
  | {
      type: "toggle-dropdown";
    };

export const reducer = (
  previousState: ChoiceState,
  action: CHOICE_ACTIONS
): ChoiceState => {
  switch (action.type) {
    case "add-option": {
      return {
        ...previousState,
        options: [...previousState.options, action.payload],
      };
    }
    case "add-other-option": {
      return {
        ...previousState,
        otherOption: action.payload,
      };
    }
    case "remove-option": {
      return {
        ...previousState,
        options: previousState.options.filter(
          (_option, index) => index !== action.payload
        ),
      };
    }
    case "remove-other-option": {
      return {
        ...previousState,
        otherOption: undefined,
      };
    }
    case "set-question": {
      return {
        ...previousState,
        question: action.payload,
      };
    }
    case "set-option": {
      return {
        ...previousState,
        options: previousState.options.map((option, index) =>
          index === action.payload.index ? action.payload.option : option
        ),
      };
    }
    case "toggle-subtitle": {
      return {
        ...previousState,
        subtitle: previousState.subtitle === undefined ? "" : undefined,
      };
    }
    case "set-subtitle": {
      return {
        ...previousState,
        subtitle: action.payload,
      };
    }
    case "toggle-required": {
      return {
        ...previousState,
        required: !previousState.required,
      };
    }
    case "toggle-multiple": {
      return {
        ...previousState,
        multiple: !previousState.multiple,
      };
    }
    case "toggle-dropdown": {
      return {
        ...previousState,
        isDropdown: !previousState.isDropdown,
      };
    }
    default: {
      return { ...previousState };
    }
  }
};

export type UseChoiceProps = {
  props: ChoiceProps;
  defaultState?: ChoiceState;
};

export const useChoice = ({
  props,
  defaultState = {
    type: "choice",
    question: "Question",
    options: ["Option 1", "Option 2"],
    required: false,
    multiple: false,
    isDropdown: false,
  },
}: UseChoiceProps): ChoiceContextValue => {
  const [state, dispatcher] = React.useReducer(reducer, defaultState);

  return {
    state,
    dispatcher,
    props,
  };
};
