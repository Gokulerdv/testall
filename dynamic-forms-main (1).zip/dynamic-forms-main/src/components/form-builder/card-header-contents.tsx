import {
  faArrowDown,
  faArrowUp,
  faPaste,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Button from "../../ui/Button";
import Stack from "../../ui/Stack";
import { useFormBuilderContext } from "./main";

export type CardHeaderContentsProps = {};

export const CardHeaderContents = () => {
  const formBuilder = useFormBuilderContext();

  return (
    <>
      <Stack orientation="horizontal" justifyContent="end">
        <Button
          onClick={() => formBuilder.dispatcher({ type: "copy-question" })}
        >
          <FontAwesomeIcon icon={faPaste} />
        </Button>
        <Button
          onClick={() => formBuilder.dispatcher({ type: "delete-question" })}
        >
          <FontAwesomeIcon icon={faTrash} />
        </Button>
        <Button
          disabled={
            (formBuilder.state.questionIndexInFocus === undefined
              ? 0
              : formBuilder.state.questionIndexInFocus) === 0
          }
          onClick={() =>
            formBuilder.dispatcher({ type: "move-question-to-previous" })
          }
        >
          <FontAwesomeIcon icon={faArrowUp} />
        </Button>
        <Button
          disabled={
            (formBuilder.state.questionIndexInFocus === undefined
              ? 0
              : formBuilder.state.questionIndexInFocus) ===
            formBuilder.state.questions.length - 1
          }
          onClick={() =>
            formBuilder.dispatcher({ type: "move-question-to-next" })
          }
        >
          <FontAwesomeIcon icon={faArrowDown} />
        </Button>
      </Stack>
    </>
  );
};

export default CardHeaderContents;
