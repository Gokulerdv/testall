import { faCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import Card from "../../ui/Card";
import Grid from "../../ui/Grid";
import Menu from "../../ui/Menu";
import Stack from "../../ui/Stack";
import Typography from "../../ui/Typography";
import CardHeaderContents from "./card-header-contents";
import { useFormBuilderContext } from "./main";
import { DateContext, DateState, useDate, useDateContext } from "./use-date";

export type DateProps = {
  index?: number;
  focused: boolean;
};

export const Date = (props: DateProps) => {
  const date = useDate({ props });
  const formBuilder = useFormBuilderContext();

  React.useEffect(() => {
    if (props.index === undefined) return;

    formBuilder.dispatcher({
      type: "set-question-state",
      payload: {
        index: props.index,
        state: date.state,
      },
    });
  }, [date.state]);

  return (
    <>
      <DateContext.Provider value={date}>
        {props.focused ? (
          <DateFocused />
        ) : (
          <div
            onClick={() =>
              formBuilder.dispatcher({
                type: "set-question-index-in-focus",
                payload: props.index as number,
              })
            }
          >
            <DatePreview state={date.state} index={props.index as number} />
          </div>
        )}
      </DateContext.Provider>
    </>
  );
};

export type DatePreviewProps = {
  state: DateState;
  index: number;
};

export const DatePreview = (props: DatePreviewProps) => {
  return (
    <div className="mt-3 mb-3">
      <Typography as="h6">
        {props.index + 1}. {props.state.question}
      </Typography>
      {props.state.subtitle ? (
        <Typography as="small">{props.state.subtitle}</Typography>
      ) : null}
      <input
        type="date"
        name={`question-${props.index}`}
        className="w-100 mt-3 form-control form-control-sm"
      />
    </div>
  );
};

export const DateFocused = () => {
  const { state, dispatcher, props } = useDateContext();

  return (
    <Card>
      <Card.Head>
        <Card.Header title="" action={<CardHeaderContents />} />
      </Card.Head>

      <Card.Body>
        <Grid.Row>
          <Grid.Col cols="auto">{(props.index ?? 0) + 1}.</Grid.Col>
          <Grid.Col>
            <input
              type="text"
              className="w-100 form-control form-control-sm"
              value={state.question}
              onChange={(event) =>
                dispatcher({
                  type: "set-question",
                  payload: event.target.value,
                })
              }
            />
            {state.subtitle !== undefined ? (
              <input
                type="text"
                className="w-100 mt-3 form-control form-control-sm"
                placeholder="Enter your subtitle"
                value={state.subtitle}
                onChange={(event) =>
                  dispatcher({
                    type: "set-subtitle",
                    payload: event.target.value,
                  })
                }
              />
            ) : null}
            <input
              type="date"
              className="w-100 mt-3 form-control form-control-sm"
              disabled
            />
          </Grid.Col>
        </Grid.Row>
      </Card.Body>
      <Card.Footer>
        <Stack orientation="horizontal" justifyContent="end">
          <div className="form-check form-switch me-3">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckChecked"
              checked={state.required}
              onChange={() => dispatcher({ type: "toggle-required" })}
            />
            <label
              className="form-check-label"
              htmlFor="flexSwitchCheckChecked"
            >
              Required
            </label>
          </div>
          <Menu
            dropdown={<Menu.Dropdown />}
            trigger={<Menu.Trigger size="sm" />}
            {...{
              options: [
                {
                  as: "a",
                  id: "1",
                  label: (
                    <>
                      {state.subtitle !== undefined ? (
                        <FontAwesomeIcon icon={faCheck} />
                      ) : null}{" "}
                      subtitle
                    </>
                  ),
                  onClick: () => dispatcher({ type: "toggle-subtitle" }),
                },
              ],
              name: "choice-menu-dropdown",
            }}
          />
        </Stack>
      </Card.Footer>
    </Card>
  );
};

export default Date;
