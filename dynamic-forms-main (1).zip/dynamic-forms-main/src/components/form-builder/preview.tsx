import { Button } from "@mui/material";
import Stack from "../../ui/Stack";
import { ChoicePreview, ChoicePreviewProps } from "./choice";
import { DatePreview, DatePreviewProps } from "./date";
import { HeaderPreview } from "./header";
import { useFormBuilderContext } from "./main";
import { TextPreview, TextPreviewProps } from "./text";

export type PreviewProps = {};

export const Preview = (props: PreviewProps) => {
  const formBuilder = useFormBuilderContext();

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();

        // new Array = [] length = 3
        // fill = [undefined, undefined, undefined]
        // map = [{name: "question-0", value: ""}, {name: "question-1", value: ""}, undefined]
        // filter = [{...}, {...}]
        // reduce = { "question-0": "", "question-1": "" }

        const values = new Array(event.currentTarget.elements.length)
          .fill(undefined)
          .map((_, index) => {
            const element = event.currentTarget.elements.item(index);
            if (
              (element as any)?.name &&
              ((element as any)?.type === "radio" ||
                (element as any)?.type === "checkbox")
            ) {
              if ((element as any)?.value === "[object Object]") {
                return {
                  name: (element as any)?.name,
                  type: (element as any)?.type,
                  value: (element as any)?.checked
                    ? ((element as any)?.nextElementSibling?.firstChild as any)
                        ?.value
                    : "",
                };
              }

              return {
                name: (element as any)?.name,
                type: (element as any)?.type,
                value: (element as any)?.checked ? (element as any)?.value : "",
              };
            }

            if ((element as any)?.name) {
              return {
                name: (element as any)?.name,
                value: (element as any)?.value,
              };
            }
          })
          .filter((value) => value)
          .reduce((acc, curr) => {
            if (curr?.type === "checkbox") {
              return {
                ...acc,
                [curr?.name]:
                  acc[curr?.name] && curr?.value
                    ? [...(acc[curr?.name] as unknown[]), curr?.value]
                    : curr?.value
                    ? [curr?.value]
                    : acc[curr?.name] || [],
              };
            }

            return { ...acc, [curr?.name]: acc[curr?.name] || curr?.value };
          }, {} as Record<string, unknown>);

        console.log({ values, state: formBuilder.state });
      }}
    >
      <Stack gap="3">
        <HeaderPreview />

        {formBuilder.state.questionStates.map((state, index) => (
          <>
            {state.type === "choice" ? (
              <ChoicePreview
                index={index}
                {...{ state: state as ChoicePreviewProps["state"] }}
              />
            ) : null}

            {state.type === "text" ? (
              <TextPreview
                index={index}
                {...{ state: state as TextPreviewProps["state"] }}
              />
            ) : null}

            {state.type === "date" ? (
              <DatePreview
                index={index}
                {...{ state: state as DatePreviewProps["state"] }}
              />
            ) : null}
          </>
        ))}

        {!formBuilder.state.viewMode && (
          <Button variant="contained" type="submit">
            Submit
          </Button>
        )}
      </Stack>
    </form>
  );
};

export default Preview;
