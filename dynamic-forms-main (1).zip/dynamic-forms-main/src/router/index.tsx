import { CircularProgress } from "@mui/material";
import React from "react";
import { Outlet, createBrowserRouter } from "react-router-dom";
import Container from "../ui/Container";
import Stack from "../ui/Stack";

const LazyHomePage = React.lazy(() => import("../pages/index"));
const LazyViewerPage = React.lazy(() => import("../pages/viewer"));
const LazyBuilderPage = React.lazy(() => import("../pages/builder"));

const LazyHomePageWithFallback = () => (
  <React.Suspense fallback={<CircularProgress />}>
    <LazyHomePage />
  </React.Suspense>
);
const LazyViewerPageWithFallback = () => (
  <React.Suspense fallback={<CircularProgress />}>
    <LazyViewerPage />
  </React.Suspense>
);
const LazyBuilderPageWithFallback = () => (
  <React.Suspense fallback={<CircularProgress />}>
    <LazyBuilderPage />
  </React.Suspense>
);

export const router = createBrowserRouter([
  {
    path: "/*",
    element: (
      <Container>
        <Stack gap="3" className="my-3">
          <Outlet />
        </Stack>
      </Container>
    ),
    children: [
      {
        path: "",
        element: <LazyHomePageWithFallback />,
      },

      {
        path: "viewer",
        element: <LazyViewerPageWithFallback />,
      },
      {
        path: "builder",
        element: <LazyBuilderPageWithFallback />,
      },
    ],
  },
]);

export default router;
