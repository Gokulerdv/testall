import { createBrowserRouter } from "react-router-dom";

import LazyProtectedOCRPageWithFallback from "./lazy/protected/ocr";

export const router = createBrowserRouter([
  {
    path: "/*",
    element: <LazyProtectedOCRPageWithFallback />,
  },
]);

export default router;
