import {
  Box,
  Button,
  Card,
  CardHeader,
  CardContent,
  CardMedia,
  CircularProgress,
} from "@mui/material";

import React, { useState, useRef } from "react";

export default function MultiActionAreaCard() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedImageBackup, setSelectedImageBackup] = useState<string | null>(
    null
  );
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [loadingFlag, setLoadingFlag] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | string>("");
  const [fileUploaded, setFileUploaded] = useState(false);

  const handleButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const onFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      if (!event.target.files) return;

      const [file] = event.target.files;
      setSelectedFile(event.target.files[0]);
      setFileUploaded(true);

      const imageUrl = URL.createObjectURL(file);
      setSelectedImage(imageUrl);

      const formData = new FormData();
      formData.append("image", file);
      event.target.value = " ";
    } catch (error) {
      console.log(error);
    }
  };

  const onHandleImageDetection = async () => {
    try {
      setLoadingFlag(true);
      const formData = new FormData();
      formData.append("file", selectedFile);

      setSelectedImageBackup(selectedImage);

      if (selectedImage) {
        const response = await fetch(
          `${import.meta.env.VITE_PUBLIC_API_URL}/detect_image`,
          {
            method: "POST",
            body: formData,
          }
        );

        const myBlob = response.blob();

        const objectURL = URL.createObjectURL(await myBlob);
        setImageUrl(objectURL);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoadingFlag(false);
    }
  };

  const onClear = async () => {
    try {
      setSelectedImageBackup("");
      setSelectedImage("");
      setImageUrl("");
      setLoadingFlag(false);
      setFileUploaded(false);

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
        setSelectedFile("");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div
      className="vstack"
      style={{
        alignItems: "center",
        height: "100vh",
        marginTop: "5rem",
      }}
    >
      <Box sx={{ width: "100%", typography: "body1", textAlign: "center" }}>
        <div style={{ marginBottom: "1rem" }}>
          <h1 style={{ color: "blueviolet" }}> 2D IMAGE DETECTION</h1>
        </div>

        <div className="hstack gap-5" style={{ justifyContent: "center" }}>
          <input
            type="file"
            id="passportFileInput"
            style={{ marginLeft: "33px", width: "300px", display: "none" }}
            className="form-control"
            onChange={(e) => {
              onFileChange(e);
            }}
            ref={fileInputRef}
          />
          <Button
            onClick={handleButtonClick}
            color="secondary"
            style={{ marginLeft: "33px", width: "300px" }}
            className="btn"
          >
            {fileUploaded ? "File uploaded" : "Upload File"}
          </Button>
        </div>

        <div style={{ textAlign: "center", marginTop: "1rem" }}>
          <Button
            onClick={onHandleImageDetection}
            style={{
              color: "white",
            }}
            variant="contained"
            color="secondary"
          >
            {" "}
            Detect Image
          </Button>
          <Button
            onClick={onClear}
            style={{
              marginLeft: "10px",
              color: "white",
            }}
            variant="contained"
            color="secondary"
          >
            {" "}
            Clear{" "}
          </Button>
        </div>

        <div
          className="hstack"
          style={{
            backgroundColor: "white",
            marginTop: "12px",
            justifyContent: "center",
          }}
        ></div>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            marginTop: "2rem",
          }}
        >
          <Card style={{ margin: "1rem", width: "520px" }}>
            <CardHeader
              title="UPLOADED IMAGE"
              style={{ height: "10px", width: "520px" }}
            />
            <CardContent
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                padding: 0,
              }}
            >
              {selectedImageBackup && (
                <CardMedia
                  component="img"
                  image={selectedImageBackup}
                  alt="Selected"
                  style={{
                    maxWidth: "100%",
                    maxHeight: "100%",
                    objectFit: "contain",
                  }}
                />
              )}
            </CardContent>
          </Card>

          <Card style={{ margin: "1rem", width: "520px" }}>
            <CardHeader
              title="AI IMAGE "
              style={{ height: "10px", width: "520px" }}
            />
            <CardContent
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                padding: 0,
              }}
            >
              {!loadingFlag ? (
                imageUrl && (
                  <CardMedia
                    component="img"
                    image={imageUrl}
                    style={{
                      maxWidth: "100%",
                      maxHeight: "100%",
                      objectFit: "contain",
                    }}
                  />
                )
              ) : (
                <>
                  <CardContent
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      height: "100%",
                      marginBottom: "50px", // Set a fixed height
                    }}
                  >
                    <CircularProgress color="secondary" />
                  </CardContent>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </Box>
    </div>
  );
}
