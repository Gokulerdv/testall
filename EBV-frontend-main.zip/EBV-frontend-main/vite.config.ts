import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/patient": "http://localhost:8585",
      "/patients": "http://localhost:8585",
      "/eligibility": "http://localhost:8585",
      "/account": "http://localhost:8585",
      "/opendental": "http://localhost:8585",
      "/ocr": "http://localhost:8585",
      "/events": "http://localhost:8585",
      "/power-bi": "http://localhost:8585",
    },
  },
});
