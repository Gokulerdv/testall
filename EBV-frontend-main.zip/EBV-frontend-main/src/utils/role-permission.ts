import { useAuthContext } from "../shared/hooks/use-auth";

export const RolesPermission = (rolesPermission: string) => {
  const auth = useAuthContext();
  const permissions = auth.state.permission;
  return permissions?.includes(rolesPermission);
};
