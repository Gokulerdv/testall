/* eslint-disable @typescript-eslint/no-explicit-any */
import { urlEncodedBody } from "./url-encoded-body";

export const urlEncodedRequestOptionsForLogin = (
  details: Parameters<typeof urlEncodedBody>[0]
): RequestInit => {
  return {
    method: "POST",
    body: urlEncodedBody(details),
  };
};
