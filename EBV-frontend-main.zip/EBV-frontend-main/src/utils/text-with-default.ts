export const textWithDefault = (text?: string, skipDefault?: boolean) => {
  return skipDefault ? text ?? "" : text ? text : "";
};

export default textWithDefault;
