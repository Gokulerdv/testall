export const removePermission = (permission: string) =>
    permission
        .replace(/ /g, "")
        .replace(/delete/gi, "")
        .replace(/view/gi, "")
        .replace(/create/gi, "")
        .replace(/edit/gi, "")
        .replace(/_/g, "")
        .toLowerCase();

export const FilterPermission = (name: string, permissions: string[]) => {
    const targetName = removePermission(name);

    return permissions?.filter((permission) => {
        const permissionName = removePermission(permission);
        return (
            permissionName.includes(targetName) || targetName.includes(permissionName)
        );
    });
};