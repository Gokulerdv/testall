export const ProviderViewPermission = "PROVIDERS_VIEW";
export const ProviderEditPermission = "PROVIDERS_EDIT";
export const ProviderCreatePermission = "PROVIDERS_CREATE";
export const ProviderDeletePermission = "PROVIDERS_DELETE";

export const CreateScheduleViewPermission = "CREATE_SCHEDULE_VIEW";
export const CreateScheduleEditPermission = "CREATE_SCHEDULE_EDIT";
export const CreateScheduleCreatePermission = "CREATE_SCHEDULE_CREATE";
export const CreateScheduleDeletePermission = "CREATE_SCHEDULE_DELETE";
export const GeneralSettingsViewPermission = "GENERAL_SETTINGS_VIEW";

export const HistoryViewPermission = "HISTORY_VIEW";
export const HistoryEditPermission = "HISTORY_EDIT";
export const HistoryCreatePermission = "HISTORY_CREATE";
export const HistoryDeletePermission = "HISTORY_DELETE";

export const PendingEligibilityViewPermission = "PENDING_ELIGIBILITY_VIEW";
export const PendingEligibilityEditPermission = "PENDING_ELIGIBILITY_EDIT";
export const PendingEligibilityCreatePermission = "PENDING_ELIGIBILITY_CREATE";
export const PendingEligibilityDeletePermission = "PENDING_ELIGIBILITY_DELETE";

export const TransactionViewPermission = "TRANSACTION_VIEW";
export const TransactionEditPermission = "TRANSACTION_EDIT";
export const TransactionCreatePermission = "TRANSACTION_CREATE";
export const TransactionDeletePermission = "TRANSACTION_DELETE";

export const NewPatientViewPermission = "NEW_PATIENT_VIEW";
export const NewPatientEditPermission = "NEW_PATIENT_EDIT";
export const NewPatientCreatePermission = "NEW_PATIENT_CREATE";
export const NewPatientDeletePermission = "NEW_PATIENT_DELETE";

export const FaqViewPermission = "FAQ_VIEW";
export const FaqEditPermission = "FAQ_EDIT";
export const FaqCreatePermission = "FAQ_CREATE";
export const FaqDeletePermission = "FAQ_DELETE";

//eligibility  and manual verification as same
export const EligibilityTableEditPermission = "ELIGIBILITY_TABLE_EDIT";
export const EligibilityTableDeletePermission = "ELIGIBILITY_TABLE_DELETE";
export const EligibilityTableViewPermission = "ELIGIBILITY_TABLE_VIEW";
export const EligibilityTableCreatePermission = "ELIGIBILITY_TABLE_CREATE";
export const ManualVerificationViewPermission = "MANUAL_VERIFICATION_VIEW";
export const ManualVerificationEditPermission = "MANUAL_VERIFICATION_EDIT";
export const ManualVerificationCreateermission = "MANUAL_VERIFICATION_CREATE";
export const ManualVerificationDeletePermission = "MANUAL_VERIFICATION_DELETE";

export const InsurancePayerViewPermission = "INSURANCES/PAYERS_VIEW";
export const InsurancePayerEditPermission = "INSURANCES/PAYERS_EDIT";
export const InsurancePayerCreatePermission = "INSURANCES/PAYERS_CREATE";
export const InsurancePayerDeletePermission = "INSURANCES/PAYERS_DELETE";
export const ProcedureCodeViewPermission = "PROCEDURE_CODES_VIEW";
export const ProcedureCodeEditPermission = "PROCEDURE_CODES_EDIT";
export const ProcedureCodeCreatePermission = "PROCEDURE_CODES_CREATE";
export const ProcedureCodeDeletePermission = "PROCEDURE_CODES_DELETE";
export const BulkActionViewPermission = "BULK_ACTION_VIEW";
export const BulkActionEditPermission = "BULK_ACTION_EDIT";
export const BulkActionCreatePermission = "BULK_ACTION_CREATE";
export const BulkActionDeletePermission = "BULK_ACTION_DELETE";
export const UploadImagesViewPermission = "UPLOAD_IMAGES_VIEW";
export const UploadImagesEditPermission = "UPLOAD_IMAGES_EDIT";
export const UploadImagesCreatePermission = "UPLOAD_IMAGES_CREATE";
export const UploadImagesDeletePermission = "UPLOAD_IMAGES_DELETE";
export const ScanQrViewPermission = "SCAN_QR_VIEW";
export const ScanQrEditPermission = "SCAN_QR_EDIT";
export const ScanQrCreatePermission = "SCAN_QR_CREATE";
export const ScanQrViewDeletePermission = "SCAN_QR_DELETE";

export const ExcelVerificationViewPermission = "EXCEL_VERIFICATION_VIEW";
export const ExcelVerificationEditPermission = "EXCEL_VERIFICATION_EDIT";
export const ExcelVerificationCreatePermission = "EXCEL_VERIFICATION_CREATE";
export const ExcelVerificationDeletePermission = "EXCEL_VERIFICATION_DELETE";

//explaination
export const ScheduleVerificationViewPermission = "SCHEDULE_VERIFICATION_VIEW";
export const ScheduleVerificationEditPermission = "SCHEDULE_VERIFICATION_EDIT";
export const ScheduleVerificationCreatePermission =
  "SCHEDULE_VERIFICATION_CREATE";
export const ScheduleVerificationDeletePermission =
  "SCHEDULE_VERIFICATION_DELETE";

export const BenefitSummaryViewPermission = "BENEFIT_SUMMARY_VIEW";
export const BenefitSummaryEditPermission = "BENEFIT_SUMMARY_EDIT";
export const BenefitSummaryCreatePermission = "BENEFIT_SUMMARY_CREATE";
export const BenefitSummaryDeletePermission = "BENEFIT_SUMMARY_DELETE";

//in Doubts
export const GeneralSettingsEditPermission = "GENERAL_SETTINGS_EDIT";
export const GeneralSettingsCreatePermission = "GENERAL_SETTINGS_CREATE";
export const GeneralSettingsDeletePermission = "GENERAL_SETTINGS_DELETE";

//Not completed
export const ChatbotHelpViewPermission = "CHAT_BOT_HELP_VIEW";
export const ChatbotHelpEditPermission = "CHAT_BOT_HELP_EDIT";
export const ChatbotHelpCreatePermission = "CHAT_BOT_HELP_CREATE";
export const ChatbotHelpDeletePermission = "CHAT_BOT_HELP_DELETE";
export const SupportViewPermission = "SUPPORT_VIEW";
export const SupportEditPermission = "SUPPORT_EDIT";
export const SupportCreatePermission = "SUPPORT_CREATE";
export const SupportDeletePermission = "SUPPORT_DELETE";

export const NotificationsViewPermission = "NOTIFICATIONS_VIEW";
export const NotificationsEditPermission = "NOTIFICATIONS_EDIT";
export const NotificationsCreatePermission = "NOTIFICATIONS_CREATE";
export const NotificationsDeletePermission = "NOTIFICATIONS_DELETE";

export const AllAnalyticsViewPermission = "ALL_ANALYTICS_VIEW";
export const AllAnalyticsEditPermission = "ALL_ANALYTICS_EDIT";
export const AllAnalyticsCreatePermission = "ALL_ANALYTICS_CREATE";
export const AllAnalyticsDeletePermission = "ALL_ANALYTICS_DELETE";

export const ClearingHousePayerViewPermission =
  "CLEARING_HOUSE_PAYER_MAPPING_VIEW";
export const ClearingHousePayerEditPermission =
  "CLEARING_HOUSE_PAYER_MAPPING_EDIT";
export const ClearingHousePayerCreatePermission =
  "CLEARING_HOUSE_PAYER_MAPPING_CREATE";
export const ClearingHousePayerDeletePermission =
  "CLEARING_HOUSE_PAYER_MAPPING_DELETE";
