export const currencyFormat = (
  amount: number,
  locale: "en-US" | string = "en-US",
  currency: string = "USD"
): string => {
  return new Intl.NumberFormat([locale, "en-US"], {
    style: "currency",
    currency,
  }).format(amount);
};
