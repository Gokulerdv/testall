/* eslint-disable @typescript-eslint/no-explicit-any */
export const Config = (auth: any) => {
  return {
    Authorization: `Bearer ${auth?.state?.user?.accessToken}`,
  };
};
export default Config;
