export const base64ToFile = (
  base64: string,
  filename: string,
  mimeType: string
): File => {
  // Convert base64 string to a byte array
  const byteString = atob(base64.split(",")[1]);

  // Create an array of bytes
  const byteArray = new Uint8Array(byteString.length);
  for (let i = 0; i < byteString.length; i++) {
    byteArray[i] = byteString.charCodeAt(i);
  }

  // Create a blob from the byte array
  const blob = new Blob([byteArray], { type: mimeType });

  // Create a File object from the blob
  return new File([blob], filename, { type: mimeType });
};
