/* eslint-disable @typescript-eslint/no-explicit-any */
import { Config } from "./headers-config";
import { urlEncodedBody } from "./url-encoded-body";

export const urlEncodedRequestOptions = (
  details: Parameters<typeof urlEncodedBody>[0],
  auth: any
): RequestInit => {
  return {
    method: "POST",
    body: urlEncodedBody(details),
    headers: {
      // "Content-Type": "application/json",
      ...Config(auth),
    },
  };
};
