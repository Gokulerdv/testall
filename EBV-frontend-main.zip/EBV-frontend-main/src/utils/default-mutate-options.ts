export const defaultMutateOptions = {
  onError: (error: Error) => {
    throw error;
  },
};
