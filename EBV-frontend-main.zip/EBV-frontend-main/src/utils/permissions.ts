type RoleDetails = {
    permissions: string[];
    roleId: string;
    roleName: string;
    roleType: string;
    adminId: string;
    practiceId: string;
    status: null | string;
    createdAt: string;
    updatedAt: string;
    productDetails: ProductDetail[];
  };
  
  type ProductDetail = {
    product_id: string;
    product_name: string;
    status: boolean;
    description: string;
    createdAt: string;
    updatedAt: string;
    modules: Module[];
  };
  
  type Module = {
    module_id: string;
    module_name: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
    productProductId: null | string;
    product_id: string;
    features: Feature[];
  };
  
  type Feature = {
    permissions: string[];
    feature_id: string;
    feature_name: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
    moduleModuleId: null | string;
    module_id: string;
  };



  interface Location {
    locationId: string;
    locationName: string;
    email: string;
    phoneNumber: string;
    address: string;
    city: string;
    state: string;
    zipcode: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
    practiceId: string;
  }
  
  interface SubscriptionPractice {
    subscriptionPracticeId: string;
    subscriptionId: string;
    practiceId: string;
    is_active: boolean;
    start_date: string;
    end_date: string;
    payment_id: null | string;
    subscription_type: null | string;
    createdAt: string;
    updatedAt: string;
    practicePracticeId: string;
    subscriptionSubscriptionId: string;
  }
  
  interface Subscription {
    custombillingPeriod: null | string;
    subscriptionId: string;
    subscriptionName: string;
    locationCount: number;
    costPerLocation: number;
    totalLocationCost: number;
    userCount: number;
    costPerUser: number;
    totalUserCost: number;
    billingPeriod: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
    subscriptionpractice: SubscriptionPractice;
  }
  
  interface SubscriptionPractices {
    subscriptionPracticeId: string;
    subscriptionId: string;
    practiceId: string;
    is_active: boolean;
    start_date: string;
    end_date: string;
    payment_id: null | string;
    subscription_type: null | string;
    createdAt: string;
    updatedAt: string;
    subscriptions: Subscription[];
  }
  
  interface Practice {
    billingAddress: null | string;
    practiceId: string;
    practiceName: string;
    practiceLogo: string;
    superAdminName: string;
    email: string;
    phoneNumber: string;
    address: string;
    city: string;
    state: string;
    zipcode: string;
    instagram: string;
    linkedin: string;
    facebook: string;
    website: string;
    billingCurrency: null | string;
    billingLocation: null | string;
    billingAutoCollection: null | string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
    locations: Location[];
    subscriptionpractices: SubscriptionPractices[];
  }
  

  type Role = {
    permissions: string[];
    roleId: string;
    roleName: string;
    roleType: string;
    adminId: string;
    practiceId: string;
    status: null | string;
    createdAt: string;
    updatedAt: string;
    products: any[];
  };

  type Practices = Practice[];

  interface UserDetail {
    userId: string;
    userName: string;
    userType: string;
    email: string;
    phoneNumber: string;
    adminId: string;
    status: null | string;
    createdAt: string;
    updatedAt: string;
    practices: any[];
    roles: Role[];
    
    [key: string]: string | boolean | any;
  }