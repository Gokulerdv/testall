/* eslint-disable @typescript-eslint/no-explicit-any */
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { capitalCase } from "change-case";
import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";

export const defaultKey = "dateOfBirth";

export const getDateOfBirthValidator = (key: string) =>
  z.date({ required_error: `${capitalCase(key)} is required.` }).nullable();

export const dateOfBirthSchema = z.object({
  dateOfBirth: getDateOfBirthValidator(defaultKey),
});

export type DateOfBirthSchema = z.infer<typeof dateOfBirthSchema>;

export type DateOfBirthProps = InputProps & {
  help?: React.ReactNode;
};

export const DateOfBirth = (props: DateOfBirthProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={defaultKey}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(defaultKey)}
      </Label>
      <Controller
        name={props.name || defaultKey}
        control={control}
        render={({ fieldState, field }) => (
          <>
            <DatePicker
              className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom date-of-birth"
              selected={field.value}
              showIcon
              maxDate={new Date()}
              icon={<FontAwesomeIcon icon={faCalendarDays} />}
              calendarIconClassname="text-primary"
              isClearable
              onChange={(event: any) => {
                if (event) field.onChange(event);
                else field.onChange(null);
              }}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default DateOfBirth;
