import React from "react";

type NOTIFY_ACTION =
  | {
      type: "increment-count";
    }
  | {
      type: "decrement-count";
    }
  | {
      type: "reset-count";
    };

type State = {
  count: number;
};

const initialState: State = {
  count: 0,
};

export const reducer = (state: State, action: NOTIFY_ACTION): State => {
  switch (action.type) {
    case "increment-count": {
      return { ...state, count: state.count + 1 };
    }
    case "decrement-count": {
      return { ...state, count: state.count - 1 };
    }
    case "reset-count": {
      return { ...state, count: 0 };
    }
    default:
      return state;
  }
};

export type NotificationContextValue = {
  state: State;
  dispatcher: React.Dispatch<NOTIFY_ACTION>;
};

export const NotificationContext =
  React.createContext<NotificationContextValue | null>(null);

export const useNotificationContext = () => {
  const context = React.useContext(NotificationContext);

  if (!context) throw new Error();

  return context;
};

export const useNotify = (): NotificationContextValue => {
  const [state, dispatcher] = React.useReducer(reducer, initialState);

  return { state, dispatcher };
};
