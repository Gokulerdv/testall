import React from "react";
import { UseFormReturn } from "react-hook-form";
import useDrawerFromLocation from "./use-drawer-from-location";

export const useDialogWithFormReset = (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  methods: UseFormReturn<any>,
  state?: ReturnType<typeof useDrawerFromLocation>
) => {
  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  React.useEffect(() => {
    if (!open) return;

    methods.reset();
  }, [methods, open]);

  React.useEffect(() => {
    if (!state?.open) return;

    methods.reset();
  }, [methods, state?.open]);

  return { open, setOpen, toggle, ...state };
};
