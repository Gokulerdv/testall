import React from "react";
import { z } from "zod";
import { Account as User } from "../../apis/mocks/account/data";

const permissionSchema = z.array(z.string()).optional();
type Permissions = z.infer<typeof permissionSchema>;

export type AUTH_ACTION =
  | {
      type: "set-user";
      payload: User;
    }
  | {
      type: "reset-user";
    }
  | {
      type: "set-permission";
      payload: Permissions;
    };

export type AuthState = {
  user?: User;
  permission?: Permissions;
};

export const reducer = (state: AuthState, action: AUTH_ACTION): AuthState => {
  switch (action.type) {
    case "set-user": {
      localStorage.setItem("auth", JSON.stringify(action.payload));
      return { ...state, user: action.payload };
    }
    case "reset-user": {
      localStorage.removeItem("auth");
      localStorage.removeItem("permissions");
      return { ...state, user: undefined };
    }
    case "set-permission": {
      localStorage.setItem("permissions", JSON.stringify(action.payload));
      return { ...state, permission: action.payload };
    }
    default:
      return { ...state };
  }
};

export type AuthContextValue = {
  state: AuthState;
  dispatcher: React.Dispatch<AUTH_ACTION>;
};

export const AuthContext = React.createContext<AuthContextValue | null>(null);

export const useAuthContext = () => {
  const context = React.useContext(AuthContext);

  if (!context) throw new Error();

  return context;
};

export const useAuth = (): AuthContextValue => {
  const [state, dispatcher] = React.useReducer(reducer, {
    user: localStorage.getItem("auth")
      ? (JSON.parse(localStorage.getItem("auth") as string) as unknown as User)
      : undefined,
    permission: localStorage.getItem("permissions")
      ? (JSON.parse(
          localStorage.getItem("permissions") as string
        ) as unknown as Permissions)
      : undefined,
  });

  return { state, dispatcher };
};
