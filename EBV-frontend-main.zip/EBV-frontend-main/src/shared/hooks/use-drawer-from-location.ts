import React from "react";
import { useMatch, useNavigate } from "react-router-dom";

export type UseDrawerFromLocationProps = {
  matchPath: string;
  togglePath?: string;
  historyPopInstead?: boolean;
};

export const useDrawerFromLocation = ({
  matchPath,
  togglePath,
  historyPopInstead,
}: UseDrawerFromLocationProps) => {
  const isPathMatched = useMatch(matchPath);
  const navigate = useNavigate();

  const open = React.useMemo(() => Boolean(isPathMatched), [isPathMatched]);

  const toggle = React.useCallback(() => {
    if (historyPopInstead) {
      window.history.back();
    } else {
      navigate(togglePath ?? "..");
    }
  }, [historyPopInstead, navigate, togglePath]);

  return { open, toggle } as const;
};

export default useDrawerFromLocation;
