import axios from "axios";
import { Endpoints } from "../constants/endpoints";

const API_URL = import.meta.env.VITE_API_HOST;

export const API = axios.create({
  baseURL: API_URL
});



async function getAllUser(id: string) {
  const response = await API.get(Endpoints.getAllUser(id));
  return response.data;
}

async function createUser(subscriptionId: any, practiceId: any, payload: any) {
  const response = await API.post(
    Endpoints.createUser(subscriptionId, practiceId),
    payload
  );
  return response.data;
}

async function getRoleById(roleId: string, practiceId: string) {
  const response = await API.get(Endpoints.getRoleById(practiceId, roleId), {
    params: {
      roleId: roleId
    }
  });
  return response.data;
}
async function getProductsbyRole(roleId: string, practiceId: string) {
  const response = await API.get(Endpoints.getProductbyRole(roleId, practiceId),
  );
  return response.data;
}
async function getAllPractices(id: string) {
  const response = await API.get(Endpoints.getAllPractices(id));
  return response.data;
}

async function getAllRoles(id: string) {
  const response = await API.get(Endpoints.getAllRole(id));
  return response.data;
}

async function getByUserId(id: string) {
  const response = await API.get(Endpoints.getByUserId(id));
  return response.data;
}

async function getByUserPracticeId(id: string) {
  const response = await API.get(Endpoints.getUserByPracticeId(id));
  return response?.data;
}

async function requestDemo(practiceId: string) {
  const response = await API.get(Endpoints.requestDemo(practiceId));
  return response.data;
}
async function updateUser(userid: string, id: string, payload: any, subscriptionId: string) {
  const response = await API.put(Endpoints.updateUser(id, userid, subscriptionId), payload);
  return response.data;
}

async function deleteUser(id: string, practiceId: string) {
  const response = await API.delete(Endpoints.deleteUser(id, practiceId));
  return response.data;
}

async function deactivateUser(userid: string, id: string, payload: any, subscriptionId: string) {
  const response = await API.put(Endpoints.updateUser(id, userid, subscriptionId), payload);
  return response.data;
}

async function demoRequest(payload: any) {
  const response = await API.post(Endpoints.requestForDemo(), payload);
  return response.data;
}
async function getAllRolesByPractice(id: string) {
  const response = await API.get(Endpoints.getAllRolesByPractice(id));
  return response.data;
}
async function getPracticeById(id: string) {
  const response = await API.get(Endpoints.getPracticeById(id));
  return response.data;
}
async function getUserLocations(userId: string) {
  const response = await API.get(Endpoints.getUserLocations(userId));
  return response.data;
}
async function getUserByLocation(locationId: string, practiceId: string) {
  const response = await API.get(
    Endpoints.getUserByLocation(locationId, practiceId)
  );
  return response?.data;
}

export const UserServices = {
  getRoleById,
  getAllPractices,
  getAllRoles,
  createUser,
  getAllUser,
  getByUserId,
  getPracticeById,
  updateUser,
  deleteUser,
  deactivateUser,
  getByUserPracticeId,
  requestDemo,
  demoRequest,
  getAllRolesByPractice,
  getUserLocations,
  getUserByLocation,
  getProductsbyRole,
};
