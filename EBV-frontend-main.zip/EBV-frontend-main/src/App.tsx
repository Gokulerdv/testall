import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import React, { useEffect } from "react";
import { RouterProvider } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import globalRouter from "./router/global";
import { AuthContext, useAuth } from "./shared/hooks/use-auth";
import {
  NotificationContext,
  useNotify,
} from "./shared/hooks/use-notification";

const queryClient = new QueryClient();

const App: React.FC = () => {
  const auth = useAuth();
  const state = useNotify();

  const PARENT_URL = import.meta.env.VITE_CUSTOMER_PORTAL_FRONTEND;

  useEffect(() => {
    console.log("Came inside IFrame Message trigger function ------------>");

    const requestLocalStorage = () => {
      window.parent.postMessage("getLocalStorage", PARENT_URL);
    };

    const handleMessage = (event: MessageEvent) => {
      if (`${event.origin}/` !== PARENT_URL) {
        console.log(
          "Event origin mismatch:",
          `${event.origin}/`,
          "Expected:",
          PARENT_URL
        );
        return;
      }

      const newAuthData = event.data;
      const currentAuthData = localStorage.getItem("auth");
      console.log("Event received from parent URL--->", PARENT_URL);

      if (currentAuthData !== newAuthData) {
        console.log("Processing event message");
        localStorage.setItem("auth", newAuthData);
        auth.dispatcher({ type: "set-user", payload: JSON.parse(newAuthData) });
        auth.dispatcher({
          type: "set-permission",
          payload: JSON.parse(
            newAuthData.userData?.practice?.locations[0]?.role?.permissions
          ),
        });

        window.location.reload();
      }
    };

    window.addEventListener("message", handleMessage);
    requestLocalStorage();

    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, [PARENT_URL, auth]);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthContext.Provider value={auth}>
        <NotificationContext.Provider value={state}>
          <RouterProvider router={globalRouter} />
        </NotificationContext.Provider>
      </AuthContext.Provider>
      <ToastContainer />
      {import.meta.env.DEV && (
        <ReactQueryDevtools
          initialIsOpen={false}
          buttonPosition="bottom-left"
          position="bottom"
        />
      )}
    </QueryClientProvider>
  );
};

export default App;
