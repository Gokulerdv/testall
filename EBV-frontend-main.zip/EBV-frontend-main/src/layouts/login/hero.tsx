import { Row, Container } from "reactstrap";
import LoginBanner from "./banner";

export const LoginHero = () => {
  return (
    <Container className="h-100 px-lg-5">
      <Row className="h-100">
        <div className="vstack gap-5 h-100 justify-content-center">
          <div className="mt-4">
            <h3 className="text-white mb-0">One Integrated Solution</h3>
            <h4 className="text-black">for your Practice</h4>
          </div>

          <div className="mb-5">
            <p className="text-white">
              Revenue | Appointments | Treatment Plans
            </p>
          </div>

          <LoginBanner />
        </div>
      </Row>
    </Container>
  );
};

export default LoginHero;
