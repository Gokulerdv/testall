import { Container, Row, Col } from "reactstrap";
import LoginHero from "./hero";
import LoginContent from "./content";

export const Login = () => {
  return (
    <Container fluid className="h-100">
      <Row className="h-100">
        <Col
          md="7"
          style={{
            background: "linear-gradient(88deg, #007BED 0%, #C350EC 97.19%)",
          }}
          className="h-100"
        >
          <LoginHero />
        </Col>

        <Col className="h-100 overflow-scroll">
          <LoginContent />
        </Col>
      </Row>
    </Container>
  );
};

export default Login;
