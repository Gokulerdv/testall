import PageContent from "./page-content";
import PageTitle from "./page-title";

export const Page = () => {
  return (
    <div
      className="vstack h-100 w-100 bg-body-tertiary "
      style={{ marginLeft: "5rem", overflowX: "scroll" }}
    >
      <PageTitle />

      <PageContent />
    </div>
  );
};

export default Page;
