import {
  Outlet,
  Route,
  Routes,
  useLocation,
  useSearchParams,
} from "react-router-dom";
import { Breadcrumb, BreadcrumbItem, Container } from "reactstrap";
import styles from "./page-title.module.scss";

export const PageTitle = () => {
  const { state } = useLocation();
  return (
    <Container
      fluid
      className="px-4 py-2 bg-body-secondary overflow-x-auto d-flex align-items-center"
      style={{ minHeight: "3rem", maxHeight: "3rem" }}
    >
      <Breadcrumb className={`flex-nowrap ${styles["page-title"]} `}>
        <Routes>
          <Route
            path="/"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">Dashboard</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />

          <Route
            path="/eligibility"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">
                    {state?.isHistory ? "History" : "Eligibility Verification"}
                  </h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />

          <Route
            path="/eligibility/patient-benefit-information/:id"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">Patient Benefit Information</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />

          <Route
            path="/eligibility/patient-benefit-information/:id/report"
            element={<ReportPageTitle />}
          />

          <Route
            path="/settings"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">Settings</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />
          <Route
            path="/permissions"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">Permissions</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />
          <Route
            path="/user"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">User</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />
          <Route
            path="/user/roles"
            element={
              <>
                {/* <BreadcrumbItem>
                  <h5 className="mb-0">Role</h5>
                </BreadcrumbItem>
                <Outlet /> */}
              </>
            }
          />

          <Route
            path="/report"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">Report</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />

          <Route
            path="/faq"
            element={
              <>
                <BreadcrumbItem>
                  <h5 className="mb-0">Frequently Asked Question</h5>
                </BreadcrumbItem>
                <Outlet />
              </>
            }
          />
        </Routes>
      </Breadcrumb>
    </Container>
  );
};

export const ReportPageTitle = () => {
  const [searchParams] = useSearchParams();

  const type = searchParams.get("type");

  return (
    <>
      <BreadcrumbItem>
        <h5 className="mb-0">
          Patient Benefit Information -{" "}
          {type === "detailed" ? "Detailed Report" : "Basic Report"}
        </h5>
      </BreadcrumbItem>

      <Outlet />
    </>
  );
};

export default PageTitle;
