import React from "react";
import BottomNavbar from "./bottom-navbar";
import Page from "./page";
import SideNavbar from "./side-navbar";
import TopNavbar from "./top-navbar";

export const GlobalLayout = () => {
  const [origin, setOrigin] = React.useState("");
  React.useEffect(() => {
    window.addEventListener("message", (event) => {
      setOrigin(`${event.origin}/`);
    });
  }, []);

  return (
    <>
      <div className="overflow-hidden vstack h-100">
        {origin === import.meta.env.VITE_CUSTOMER_PORTAL_FRONTEND ? null : (
          <TopNavbar />
        )}

        <div className="overflow-auto hstack flex-grow-1 h-100 w-100">
          <SideNavbar />

          <Page />
        </div>

        <BottomNavbar />
      </div>
    </>
  );
};

export default GlobalLayout;
