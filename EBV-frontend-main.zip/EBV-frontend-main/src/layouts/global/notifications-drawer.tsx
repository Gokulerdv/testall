/* eslint-disable @typescript-eslint/no-explicit-any */
import { faBell } from "@fortawesome/free-regular-svg-icons";
import {
  faCircleCheck,
  faTriangleExclamation,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { useState } from "react";
import {
  Badge,
  Button,
  Col,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import { useNotificationContext } from "../../shared/hooks/use-notification";
import { Config } from "../../utils/headers-config";
import timeAgo from "../../utils/time-ago";

const NotificationsDrawer = () => {
  const auth = useAuth();

  const getAllNotification = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/notification/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const updateNotification = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/notification/update/${
      data.notificationId
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const [open, setOpen] = useState(false);
  const { state } = useNotificationContext();
  const notify = useNotificationContext();

  const queryClient = useQueryClient();

  const { data: notifications } = useSuspenseQuery({
    queryKey: ["notifications", "getAll"],
    queryFn: getAllNotification,
  });

  const formatDate = (rawDate: string) => {
    const date = new Date(rawDate);
    const formattedDate = `${date.toDateString().slice(3)}`;
    return formattedDate;
  };

  const notificationUpdate = useMutation({
    mutationKey: ["notification", "update"],
    mutationFn: updateNotification,
  });

  const handleRead = async (notificationId: string) => {
    try {
      await notificationUpdate.mutateAsync({
        notificationId: notificationId,
        data: { isRead: true },
      });
      notify.dispatcher({ type: "decrement-count" });
    } catch (error) {
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["notifications", "getAll"],
      });
    }
  };

  const toggle = () => {
    setOpen(!open);
    queryClient.invalidateQueries({
      queryKey: ["notifications", "getAll"],
    });
  };
  return (
    <>
      <Button
        color="link"
        className="rounded-circle position-relative"
        onClick={toggle}
      >
        <FontAwesomeIcon size="xl" icon={faBell} />
        {state.count > 0 && (
          <span className="top-0 position-absolute start-100 translate-middle badge rounded-pill bg-danger">
            {state.count}
            <span className="visually-hidden">unread messages</span>
          </span>
        )}
      </Button>
      <div>
        <Offcanvas
          isOpen={open}
          toggle={toggle}
          direction="end"
          style={{ width: "40%" }}
        >
          <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
            Notifications
          </OffcanvasHeader>

          <OffcanvasBody>
            {notifications?.data?.map((notification: any) => {
              return (
                <Row
                  style={{ color: `${notification?.isRead && "#808080"}` }}
                  onClick={() => {
                    handleRead(notification?.id);
                  }}
                >
                  <Col xs={1}>
                    <p
                      style={{
                        textAlign: "center",
                        fontSize: "1.2rem",
                      }}
                    >
                      {notification?.isSuccess || notification?.isScheduled ? (
                        <FontAwesomeIcon
                          icon={faCircleCheck}
                          style={{ color: "green" }}
                        />
                      ) : (
                        <FontAwesomeIcon
                          icon={faTriangleExclamation}
                          style={{ color: "#BB2124" }}
                        />
                      )}
                    </p>
                  </Col>
                  <Col className="ps-0" style={{ marginTop: "0.125rem" }}>
                    <Row>
                      <p className="mb-1">
                        {notification?.isSuccess
                          ? "Verified"
                          : notification?.isScheduled
                          ? "Success"
                          : "Pending"}{" "}
                        {!notification?.isRead && (
                          <Badge
                            pill
                            color="danger"
                            style={{
                              fontSize: "0.4rem",
                              verticalAlign: "middle",
                              color: "#BB2124",
                            }}
                          >
                            .
                          </Badge>
                        )}
                      </p>
                    </Row>
                    <Row>
                      <p className="mb-1 small">
                        {notification?.patientName} - {notification?.patientId}
                      </p>
                    </Row>
                    <Row>
                      <p className="mb-1 small">{notification?.message}</p>
                    </Row>
                    <Row style={{ color: "#808080" }}>
                      <Col>
                        <p className="mb-0 small">
                          {timeAgo(notification?.createdAt)}
                        </p>
                      </Col>
                      <Col className="text-end ">
                        <p className="small">
                          {formatDate(notification?.createdAt)}
                        </p>
                      </Col>
                    </Row>
                  </Col>
                  <hr />
                </Row>
              );
            })}
          </OffcanvasBody>
        </Offcanvas>
      </div>
    </>
  );
};
export default NotificationsDrawer;
