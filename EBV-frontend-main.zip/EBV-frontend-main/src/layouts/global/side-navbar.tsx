import { faCircleCheck, faFile } from "@fortawesome/free-regular-svg-icons";
import {
  faChartLine,
  faGears,
  faQuestion,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { CSSProperties, useState } from "react";
import { NavLink as RouterNavLink } from "react-router-dom";
import {
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  NavLink as Link,
  UncontrolledDropdown,
} from "reactstrap";
import {
  EligibilityTableViewPermission,
  FaqViewPermission,
  HistoryViewPermission,
} from "../../utils/constant";
import { RolesPermission } from "../../utils/role-permission";

export const SIDE_NAVBAR_WIDTH = "4.5rem";

const _activeStyles: CSSProperties = {
  backgroundColor: "white",
  color: "black",
  borderLeft: "0.25rem solid #FF9C27",
  fontSize: "0.625rem",
};

const getActiveStyles = ({
  isActive,
}: {
  isActive: boolean;
}): CSSProperties => {
  return isActive
    ? _activeStyles
    : {
        color: "white",
        fontSize: "0.625rem",
      };
};

export const SideNavbar = () => {
  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");
  const userData = userDetails?.userData;
  const [activeEligibility, setActiveEligibility] = useState(false);
  return (
    <div className="d-none d-lg-block h-100">
      <div
        className="p-0 vstack h-100"
        style={{
          width: SIDE_NAVBAR_WIDTH,
          background: "linear-gradient(to top, #007BED 0%, #C350EC 97.19%)",
          position: "fixed",
          zIndex: "1",
        }}
      >
        <RouterNavLink to="/" className="text-decoration-none">
          {({ isActive }) => (
            <Link
              className="text-decoration-none"
              style={getActiveStyles({ isActive })}
            >
              <div
                className="gap-2 vstack align-items-center justify-content-center"
                style={{
                  minWidth: "4.5rem",
                  minHeight: "4.5rem",
                  marginLeft: isActive ? "-0.25rem" : "",
                }}
                onClick={() => {
                  setActiveEligibility(false);
                }}
              >
                <FontAwesomeIcon icon={faChartLine} fontSize="1.25rem" />

                <p className="mb-0" style={{ marginTop: "-0.25rem" }}>
                  Dashboard
                </p>
              </div>
            </Link>
          )}
        </RouterNavLink>

        <UncontrolledDropdown direction={"end"}>
          <DropdownToggle data-toggle="dropdown" tag="nav">
            <Link className="text-decoration-none">
              <div
                className="gap-2 vstack align-items-center justify-content-center "
                style={
                  activeEligibility
                    ? {
                        backgroundColor: "white",
                        color: "black",
                        borderLeft: "0.25rem solid #FF9C27",
                        fontSize: "0.625rem",
                        minWidth: "4.5rem",
                        minHeight: "4.5rem",
                      }
                    : {
                        minWidth: "4.5rem",
                        minHeight: "4.5rem",
                        color: "white",
                        cursor: "pointer",
                      }
                }
              >
                <FontAwesomeIcon icon={faCircleCheck} fontSize="1.25rem" />
                <p
                  className="mb-0"
                  style={{
                    marginTop: "-0.25rem",
                    fontSize: "0.7rem",
                  }}
                >
                  Eligibility
                </p>
              </div>
            </Link>
          </DropdownToggle>
          <DropdownMenu>
            {RolesPermission(EligibilityTableViewPermission) && (
              <DropdownItem onClick={() => setActiveEligibility(true)}>
                <RouterNavLink
                  to="/eligibility"
                  className="text-decoration-none"
                >
                  Eligibility Verification
                </RouterNavLink>
              </DropdownItem>
            )}
            {RolesPermission(HistoryViewPermission) && (
              <DropdownItem onClick={() => setActiveEligibility(true)}>
                <RouterNavLink
                  to="/eligibility"
                  state={{ isHistory: true }}
                  className="text-decoration-none"
                >
                  History
                </RouterNavLink>
              </DropdownItem>
            )}
          </DropdownMenu>
        </UncontrolledDropdown>

        <RouterNavLink to="/settings" className="text-decoration-none">
          {({ isActive }) => (
            <Link
              className="text-decoration-none"
              style={getActiveStyles({ isActive })}
            >
              <div
                className="gap-2 vstack align-items-center justify-content-center"
                style={{
                  minWidth: "4.5rem",
                  minHeight: "4.5rem",
                  marginLeft: isActive ? "-0.25rem" : "",
                }}
                onClick={() => {
                  setActiveEligibility(false);
                }}
              >
                <FontAwesomeIcon icon={faGears} fontSize="1.25rem" />

                <p className="mb-0" style={{ marginTop: "-0.25rem" }}>
                  Settings
                </p>
              </div>
            </Link>
          )}
        </RouterNavLink>
        <RouterNavLink to="/permissions" className="text-decoration-none">
          {({ isActive }) => (
            <Link
              className="text-decoration-none"
              style={getActiveStyles({ isActive })}
            >
              <div
                className="gap-2 vstack align-items-center justify-content-center"
                style={{
                  minWidth: "4.5rem",
                  minHeight: "4.5rem",
                  marginLeft: isActive ? "-0.25rem" : "",
                }}
                onClick={() => {
                  setActiveEligibility(false);
                }}
              >
                <FontAwesomeIcon icon={faGears} fontSize="1.25rem" />

                <p className="mb-0" style={{ marginTop: "-0.25rem" }}>
                  Permissions
                </p>
              </div>
            </Link>
          )}
        </RouterNavLink>
        {userData?.userType === "SUPER_ADMIN" && (
          <RouterNavLink to="/user" className="text-decoration-none">
            {({ isActive }) => (
              <Link
                className="text-decoration-none"
                style={getActiveStyles({ isActive })}
              >
                <div
                  className="gap-2 vstack align-items-center justify-content-center"
                  style={{
                    minWidth: "4.5rem",
                    minHeight: "4.5rem",
                    marginLeft: isActive ? "-0.25rem" : "",
                  }}
                  onClick={() => {
                    setActiveEligibility(false);
                  }}
                >
                  <FontAwesomeIcon icon={faUser} fontSize="1.25rem" />

                  <p className="mb-0" style={{ marginTop: "-0.25rem" }}>
                    User
                  </p>
                </div>
              </Link>
            )}
          </RouterNavLink>
        )}

        <RouterNavLink to="/reports" className="text-decoration-none">
          {({ isActive }) => (
            <Link
              className="text-decoration-none"
              style={getActiveStyles({ isActive })}
            >
              <div
                className="gap-2 vstack align-items-center justify-content-center"
                style={{
                  minWidth: "4.5rem",
                  minHeight: "4.5rem",
                  marginLeft: isActive ? "-0.25rem" : "",
                }}
                onClick={() => {
                  setActiveEligibility(false);
                }}
              >
                <FontAwesomeIcon icon={faFile} fontSize="1.25rem" />

                <p className="mb-0" style={{ marginTop: "-0.25rem" }}>
                  Report
                </p>
              </div>
            </Link>
          )}
        </RouterNavLink>

        {RolesPermission(FaqViewPermission) && (
          <RouterNavLink to="/faq" className="text-decoration-none">
            {({ isActive }) => (
              <Link
                className="text-decoration-none"
                style={getActiveStyles({ isActive })}
              >
                <div
                  className="gap-2 vstack align-items-center justify-content-center"
                  style={{
                    minWidth: "4.5rem",
                    minHeight: "4.5rem",
                    marginLeft: isActive ? "-0.25rem" : "",
                  }}
                  onClick={() => {
                    setActiveEligibility(false);
                  }}
                >
                  <FontAwesomeIcon icon={faQuestion} fontSize="1.25rem" />

                  <p className="mb-0" style={{ marginTop: "-0.25rem" }}>
                    FAQ
                  </p>
                </div>
              </Link>
            )}
          </RouterNavLink>
        )}
      </div>
    </div>
  );
};

export default SideNavbar;
