import React from "react";
import UserRedirect from "../../user-redirect";
import LoadingIndicator from "../../../components/loading-indicator";

const LazyLoginForgotPasswordPage = React.lazy(
  () => import("../../../pages/login/forgot-password")
);

const LazyLoginForgotPasswordPageWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <UserRedirect>
      <LazyLoginForgotPasswordPage />
    </UserRedirect>
  </React.Suspense>
);

export default LazyLoginForgotPasswordPageWithFallback;
