import React from "react";
import UserRedirect from "../../user-redirect";
import LoadingIndicator from "../../../components/loading-indicator";

const LazyLoginResetPasswordPage = React.lazy(
  () => import("../../../pages/login/reset-password")
);

const LazyLoginResetPasswordPageWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <UserRedirect>
      <LazyLoginResetPasswordPage />
    </UserRedirect>
  </React.Suspense>
);

export default LazyLoginResetPasswordPageWithFallback;
