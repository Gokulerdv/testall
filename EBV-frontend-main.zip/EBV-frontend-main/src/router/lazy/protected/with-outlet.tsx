import { Outlet } from "react-router-dom";

export type RouteWithOutletProps = {
  children: JSX.Element;
};

export const WithOutlet = (props: RouteWithOutletProps) => {
  return (
    <>
      {props.children}
      <Outlet />
    </>
  );
};

export default WithOutlet;
