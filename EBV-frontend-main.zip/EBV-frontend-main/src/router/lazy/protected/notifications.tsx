import React from "react";
import ProtectedRoute from "../../protected-route";
import LoadingIndicator from "../../../components/loading-indicator";

const LazyNotificationsPage = React.lazy(
  () => import("../../../layouts/global/notifications-drawer")
);

const LazyProtectedNotificationsWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyNotificationsPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedNotificationsWithFallback;
