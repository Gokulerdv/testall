import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyProtectedPatientBenefitInformation = React.lazy(
  () => import("../../../../pages/patient-benefit-information")
);

const LazyProtectedPatientBenefitInformationWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedPatientBenefitInformation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedPatientBenefitInformationWithFallback;
