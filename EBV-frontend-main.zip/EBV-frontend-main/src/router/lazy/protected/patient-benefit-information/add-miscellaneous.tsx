import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyPatientBenefitInformationAddMiscellaneousPage = React.lazy(
  () =>
    import("../../../../pages/patient-benefit-information/add-miscellaneous")
);

const LazyProtectedPatientBenefitInformationAddMiscellaneousWithFallback =
  () => (
    <React.Suspense fallback={<LoadingIndicator />}>
      <ProtectedRoute>
        <LazyPatientBenefitInformationAddMiscellaneousPage />
      </ProtectedRoute>
    </React.Suspense>
  );

export default LazyProtectedPatientBenefitInformationAddMiscellaneousWithFallback;
