import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyProtectedPatientBenefitReportInformation = React.lazy(
  () =>
    import("../../../../pages/eligibility/patient-benefit-information/report")
);

const LazyProtectedPatientBenefitInformationReportWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedPatientBenefitReportInformation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedPatientBenefitInformationReportWithFallback;
