import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyEligibilityDeleteModalPage = React.lazy(
  () => import("../../../../pages/eligibility/delete-modal")
);

const LazyProtectedEligibilityDeleteModalWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyEligibilityDeleteModalPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedEligibilityDeleteModalWithFallback;
