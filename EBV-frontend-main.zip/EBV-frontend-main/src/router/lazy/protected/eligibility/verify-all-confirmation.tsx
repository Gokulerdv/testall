import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyVerifyAllConfirmation = React.lazy(
  () => import("../../../../pages/eligibility/verify-all-confirmation")
);

const LazyProtectedVerifyAllConfirmationWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyVerifyAllConfirmation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedVerifyAllConfirmationWithFallback;
