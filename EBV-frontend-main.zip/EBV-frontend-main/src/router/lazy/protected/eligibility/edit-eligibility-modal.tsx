import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyEligibilityEditEligibilityModalPage = React.lazy(
  () => import("../../../../pages/eligibility/edit-eligibility-modal")
);

const LazyProtectedEligibilityEditEligibilityModalWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyEligibilityEditEligibilityModalPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedEligibilityEditEligibilityModalWithFallback;
