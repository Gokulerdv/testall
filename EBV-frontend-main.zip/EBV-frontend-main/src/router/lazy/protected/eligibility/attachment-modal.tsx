import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyEligibilityAttachmentModalPage = React.lazy(
  () => import("../../../../pages/eligibility/attachment-modal")
);

const LazyProtectedEligibilityAttachmentModalWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyEligibilityAttachmentModalPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedEligibilityAttachmentModalWithFallback;
