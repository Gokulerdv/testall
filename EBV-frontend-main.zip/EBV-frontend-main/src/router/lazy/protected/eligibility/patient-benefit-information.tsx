import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyEligibilityPatientBenefitInformationPage = React.lazy(
  () => import("../../../../pages/eligibility/patient-benefit-information")
);

const LazyProtectedEligibilityPatientBenefitInformationPageWithFallback =
  () => (
    <React.Suspense fallback={<LoadingIndicator />}>
      <ProtectedRoute>
        <LazyEligibilityPatientBenefitInformationPage />
      </ProtectedRoute>
    </React.Suspense>
  );

export default LazyProtectedEligibilityPatientBenefitInformationPageWithFallback;
