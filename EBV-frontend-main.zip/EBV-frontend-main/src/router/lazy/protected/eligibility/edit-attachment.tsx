import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyEligibilityEditAttachmentPage = React.lazy(
  () => import("../../../../pages/eligibility/edit-attachment")
);

const LazyProtectedEligibilityEditAttachmentWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyEligibilityEditAttachmentPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedEligibilityEditAttachmentWithFallback;
