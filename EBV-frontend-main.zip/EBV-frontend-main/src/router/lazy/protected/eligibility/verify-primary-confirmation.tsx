import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyVerifyPrimaryConfirmation = React.lazy(
  () => import("../../../../pages/eligibility/verify-primary-confirmation")
);

const LazyProtectedVerifyPrimaryConfirmationWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyVerifyPrimaryConfirmation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedVerifyPrimaryConfirmationWithFallback;
