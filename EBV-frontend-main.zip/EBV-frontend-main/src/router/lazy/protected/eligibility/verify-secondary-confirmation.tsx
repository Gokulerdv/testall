import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyVerifySecondaryConfirmation = React.lazy(
  () => import("../../../../pages/eligibility/verify-secondary-confirmation")
);

const LazyProtectedVerifySecondaryConfirmationWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyVerifySecondaryConfirmation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedVerifySecondaryConfirmationWithFallback;
