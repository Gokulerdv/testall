import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyEligibilityAddAttachmentPage = React.lazy(
  () => import("../../../../pages/eligibility/add-attachment")
);

const LazyProtectedEligibilityAddAttachmentWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyEligibilityAddAttachmentPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedEligibilityAddAttachmentWithFallback;
