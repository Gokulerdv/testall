import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyDownloadAllConfirmation = React.lazy(
  () => import("../../../../pages/eligibility/download-all-confirmation")
);

const LazyProtectedDownloadAllConfirmationWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyDownloadAllConfirmation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedDownloadAllConfirmationWithFallback;
