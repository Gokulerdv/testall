import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedReportDeleteConfirmation = React.lazy(
  () => import("../../../../pages/reports/modals/delete-confirmation")
);

const LazyProtectedReportDeleteConfirmationWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedReportDeleteConfirmation />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedReportDeleteConfirmationWithFallback;
