import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedGeneratePendingEligibility = React.lazy(
  () =>
    import(
      "../../../../pages/reports/drawers/generate-report/generate-pending-eligibility"
    )
);

const LazyProtectedGeneratePendingEligibilityWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedGeneratePendingEligibility />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedGeneratePendingEligibilityWithFallback;
