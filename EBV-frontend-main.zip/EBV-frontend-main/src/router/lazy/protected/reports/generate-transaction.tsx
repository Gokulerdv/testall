import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedGenerateTransaction = React.lazy(
  () =>
    import(
      "../../../../pages/reports/drawers/generate-report/generate-transaction"
    )
);

const LazyProtectedGenerateTransactionWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedGenerateTransaction />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedGenerateTransactionWithFallback;
