import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedNewPatientReports = React.lazy(
  () =>
    import("../../../../pages/reports/drawers/create-new-report/new-patient")
);

const LazyProtectedNewPatientReportWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedNewPatientReports />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedNewPatientReportWithFallback;
