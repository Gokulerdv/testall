import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedGenerateNewPatient = React.lazy(
  () =>
    import(
      "../../../../pages/reports/drawers/generate-report/generate-new-patient"
    )
);

const LazyProtectedGenerateNewPatientWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedGenerateNewPatient />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedGenerateNewPatientWithFallback;
