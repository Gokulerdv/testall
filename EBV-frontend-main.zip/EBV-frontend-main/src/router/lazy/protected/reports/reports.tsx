import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyReportsPage = React.lazy(
  () => import("../../../../pages/reports/index")
);

const LazyProtectedReportPageWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyReportsPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedReportPageWithFallback;
