import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedPendingEligibilityReports = React.lazy(
  () =>
    import(
      "../../../../pages/reports/drawers/create-new-report/pending-eligibility"
    )
);

const LazyProtectedPendingEligibilityReportWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedPendingEligibilityReports />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedPendingEligibilityReportWithFallback;
