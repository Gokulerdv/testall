import React from "react";
import LoadingIndicator from "../../../../components/loading-indicator";
import ProtectedRoute from "../../../protected-route";

const LazyProtectedTransactionReport = React.lazy(
  () =>
    import("../../../../pages/reports/drawers/create-new-report/transaction")
);

const LazyProtectedTransactionReportWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyProtectedTransactionReport />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedTransactionReportWithFallback;
