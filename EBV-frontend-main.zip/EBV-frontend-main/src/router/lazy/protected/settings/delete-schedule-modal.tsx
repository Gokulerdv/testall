import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyDeleteScheduleModalPage = React.lazy(
  () => import("../../../../pages/settings/delete-schedule-modal")
);

const LazyProtectedDeleteScheduleModalWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyDeleteScheduleModalPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedDeleteScheduleModalWithFallback;
