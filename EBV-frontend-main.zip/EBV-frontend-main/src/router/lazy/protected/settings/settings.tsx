import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazySettingsPage = React.lazy(
  () => import("../../../../pages/settings/settings")
);

const LazyProtectedSettingsPageWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazySettingsPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedSettingsPageWithFallback;
