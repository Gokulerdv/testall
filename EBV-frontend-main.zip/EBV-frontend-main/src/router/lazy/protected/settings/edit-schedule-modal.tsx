import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazyEditScheduleModalPage = React.lazy(
  () => import("../../../../pages/settings/edit-schedule-modal")
);

const LazyProtectedEditScheduleModalWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyEditScheduleModalPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedEditScheduleModalWithFallback;
