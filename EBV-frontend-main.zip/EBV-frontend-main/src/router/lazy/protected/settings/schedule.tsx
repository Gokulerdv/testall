import React from "react";
import ProtectedRoute from "../../../protected-route";
import LoadingIndicator from "../../../../components/loading-indicator";

const LazySchedulePage = React.lazy(
  () => import("../../../../pages/settings/schedule")
);

const LazyScheduleModalPageWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazySchedulePage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyScheduleModalPageWithFallback;
