import React from "react";
import ProtectedRoute from "../../protected-route";
import LoadingIndicator from "../../../components/loading-indicator";

const LazyFaqPage = React.lazy(() => import("../../../pages/faq"));

const LazyProtectedFaqPageWithFallback = () => (
  <React.Suspense fallback={<LoadingIndicator />}>
    <ProtectedRoute>
      <LazyFaqPage />
    </ProtectedRoute>
  </React.Suspense>
);

export default LazyProtectedFaqPageWithFallback;
