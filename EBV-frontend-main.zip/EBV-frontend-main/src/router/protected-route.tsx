/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useId, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useAuth } from "../shared/hooks/use-auth";

export type ProtectedRouteProps = {
  children: React.ReactNode;
};

export const ProtectedRoute = (props: ProtectedRouteProps) => {
  const id = useId();
  const once = useRef(true);
  const [loading, setLoading] = useState(true);
  const auth = useAuth();
  const navigate = useNavigate();

  const logout = () => {
    auth.dispatcher({ type: "reset-user" });
    window.location.href = "/";
    return;
  };

  const verifyToken = async (accessToken: string) => {
    try {
      const url = `${import.meta.env.VITE_API_HOST ?? ""}/account/verify-token`;
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ accessToken }),
      });
      return response;
    } catch (error) {
      return error;
    }
  };

  const tokenRefresh = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/account/refresh`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    return response;
  };

  const _refreshAccessToken = async () => {
    try {
      const userData = auth.state.user;
      const res = await tokenRefresh({ refreshToken: userData?.refreshToken });

      if (res?.status === 200) {
        const data = await res.json();
        auth.dispatcher({
          type: "set-user",
          payload: {
            ...auth.state.user,
            accessToken: data?.access_token,
          },
        });
      } else {
        throw new Error("Token refresh failed");
      }
    } catch (error: any) {
      console.error(error);
      toast.error("Session expired. Please login again.");

      logout();
    }
  };

  React.useEffect(() => {
    const userData = auth.state.user;
    if (userData === undefined) {
      navigate("/login/");
      return;
    }

    const verifyAccessToken = async () => {
      once.current = false;
      if (!userData?.accessToken) {
        await _refreshAccessToken();
        return;
      }
      try {
        const res = (await verifyToken(userData?.accessToken)) as {
          status: number;
        };
        if (res.status !== 200) {
          throw new Error("Token verification failed");
        }
      } catch (error) {
        await _refreshAccessToken();
      } finally {
        setLoading(false);
      }
    };
    if (once.current) {
      console.log("userData", id, userData);
      verifyAccessToken();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth.state.user]);

  return <>{!loading && props.children}</>;
};

export default ProtectedRoute;
