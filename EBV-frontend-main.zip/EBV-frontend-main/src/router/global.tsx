import { Outlet, createBrowserRouter } from "react-router-dom";
import GlobalLayout from "../layouts/global";
import LoginLayout from "../layouts/login";
import BulkVerificationWarningModal from "../pages/eligibility/bulk-verification-modal";
import BulkExcludeWarningModal from "../pages/eligibility/form/fields/bulk-exclude-model.tsx";
import ConfirmationCsvModal from "../pages/eligibility/form/fields/csv-confirmation-model.tsx";
import ConfirmationPdfModal from "../pages/eligibility/form/fields/pdf-confirmation-model.tsx";
import { EditEmployerInformationFormDrawer } from "../pages/eligibility/patient-benefit-information/cards/employer-information";
import { EditMiscellaneousFormDrawer } from "../pages/eligibility/patient-benefit-information/cards/miscellaneous";
import { EditPatiendAndPayerInformationFormDrawer } from "../pages/eligibility/patient-benefit-information/cards/patient-and-payer-information";
import { EditSubscriberInformationFormDrawer } from "../pages/eligibility/patient-benefit-information/cards/subscriber-information-card";
import PatientBenefitInformation from "../pages/eligibility/patient-benefit-information/index";
import { EditActiveCoverageFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/active-coverage";
import { EditAdaProcedureFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/ada-procedure";
import { EditBenefitHistoryFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/benefit-history";
import { EditCoInsuranceFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/co-insurance";
import { EditDeductibleFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/deductible";
import { EditLimitationFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/limitation";
import { EditMaximumFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/maximum";
import { EditNotCoveredFormDrawer } from "../pages/eligibility/patient-benefit-information/tables/not-covered";
import PatientInformation from "../pages/eligibility/patient-information";
import Permissions from "../pages/Permissions/index.tsx";
import Roles from "../pages/roles/index.tsx";
import ScanDocumentPage from "../pages/scan-document";
import EditUser from "../pages/user/EditUser/index.tsx";
import UserTable from "../pages/user/UserTable/UserTable.tsx";
import LazyLoginPageWithFallback from "./lazy/login";
import LazyLoginForgotPasswordPageWithFallback from "./lazy/login/forgot-password";
import LazyLoginOtpPageWithFallback from "./lazy/login/otp";
import LazyLoginResetPasswordPageWithFallback from "./lazy/login/reset-password";
import LazyProtectedEligibilityPageWithFallback from "./lazy/protected/eligibility";
import LazyProtectedEligibilityAddAttachmentWithFallback from "./lazy/protected/eligibility/add-attachment";
import LazyProtectedEligibilityAttachmentModalWithFallback from "./lazy/protected/eligibility/attachment-modal";
import LazyProtectedEligibilityDeleteModalWithFallback from "./lazy/protected/eligibility/delete-modal";
import LazyProtectedDownloadAllConfirmationWithFallback from "./lazy/protected/eligibility/download-all-confirmation.tsx";
import LazyProtectedEligibilityEditAttachmentWithFallback from "./lazy/protected/eligibility/edit-attachment";
import LazyProtectedEligibilityEditEligibilityModalWithFallback from "./lazy/protected/eligibility/edit-eligibility-modal";
import LazyProtectedVerifyAllConfirmationWithFallback from "./lazy/protected/eligibility/verify-all-confirmation.tsx";
import LazyProtectedVerifyPrimaryConfirmationWithFallback from "./lazy/protected/eligibility/verify-primary-confirmation.tsx";
import LazyProtectedVerifySecondaryConfirmationWithFallback from "./lazy/protected/eligibility/verify-secondary-confirmation.tsx";
import LazyProtectedFaqPageWithFallback from "./lazy/protected/faq";
import LazyProtectedHomePageWithFallback from "./lazy/protected/home";
import LazyProtectedPatientBenefitInformationAddMiscellaneousWithFallback from "./lazy/protected/patient-benefit-information/add-miscellaneous";
import LazyProtectedPatientBenefitInformationReportWithFallback from "./lazy/protected/patient-benefit-information/report";
import LazyProtectedReportDeleteConfirmationWithFallback from "./lazy/protected/reports/delete-confirmation.tsx";
import LazyProtectedGenerateNewPatientWithFallback from "./lazy/protected/reports/generate-new-patient.tsx";
import LazyProtectedGeneratePendingEligibilityWithFallback from "./lazy/protected/reports/generate-pending-eligibility.tsx";
import LazyProtectedGenerateTransactionWithFallback from "./lazy/protected/reports/generate-transaction.tsx";
import LazyProtectedNewPatientReportWithFallback from "./lazy/protected/reports/new-patient-report.tsx";
import LazyProtectedPendingEligibilityReportWithFallback from "./lazy/protected/reports/pending-eligibility-report.tsx";
import LazyProtectedReportsPageWithFallback from "./lazy/protected/reports/reports";
import LazyProtectedTransactionReportWithFallback from "./lazy/protected/reports/transaction-report.tsx";
import LazyProtectedDeleteScheduleModalWithFallback from "./lazy/protected/settings/delete-schedule-modal";
import LazyProtectedEditScheduleModalWithFallback from "./lazy/protected/settings/edit-schedule-modal";
import LazyProtectedSettingsPageWithFallback from "./lazy/protected/settings/settings";
import WithOutlet from "./lazy/protected/with-outlet";

// import User from "../pages/user/index.tsx";
// import UserTable from "../pages/user/UserTable/UserTable.tsx";
// import EditUser from "../pages/user/EditUser/index.tsx";
// import Roles from "../pages/roles/index.tsx";

export const router = createBrowserRouter([
  {
    path: "/*",
    children: [
      {
        path: "scan-document",
        element: <ScanDocumentPage />,
      },
    ],
  },
  {
    path: "/*",
    element: <LoginLayout />,
    children: [
      {
        path: "login/*",
        element: <Outlet />,
        children: [
          {
            path: "",
            element: <LazyLoginPageWithFallback />,
          },
          {
            path: "otp",
            element: <LazyLoginOtpPageWithFallback />,
          },
          {
            path: "forgot-password",
            element: <LazyLoginForgotPasswordPageWithFallback />,
          },
          {
            path: "reset-password",
            element: <LazyLoginResetPasswordPageWithFallback />,
          },
        ],
      },
    ],
  },
  {
    path: "/*",
    element: <GlobalLayout />,
    children: [
      {
        path: "",
        element: <LazyProtectedHomePageWithFallback />,
      },
      {
        path: "faq",
        element: <LazyProtectedFaqPageWithFallback />,
      },
      {
        path: "eligibility/*",
        element: (
          <WithOutlet>
            <LazyProtectedEligibilityPageWithFallback />
          </WithOutlet>
        ),
        children: [
          {
            path: "verify-all-confirmation",
            element: <LazyProtectedVerifyAllConfirmationWithFallback />,
          },
          {
            path: "verify-primary-confirmation",
            element: <LazyProtectedVerifyPrimaryConfirmationWithFallback />,
          },
          {
            path: "verify-secondary-confirmation",
            element: <LazyProtectedVerifySecondaryConfirmationWithFallback />,
          },
          {
            path: "download-all-confirmation",
            element: <LazyProtectedDownloadAllConfirmationWithFallback />,
          },
          {
            path: ":id/*",
            element: <Outlet />,
            children: [
              {
                path: "delete/*",
                element: <LazyProtectedEligibilityDeleteModalWithFallback />,
              },
              {
                path: "edit/*",
                element: (
                  <LazyProtectedEligibilityEditEligibilityModalWithFallback />
                ),
              },
              // {
              //   path: "verify-warning/*",
              //   element: (
              //     <Suspense>
              //       <VerificationWarningModal />
              //     </Suspense>
              //   ),
              // },
              {
                path: "bulk-verify-warning/*",
                element: <BulkVerificationWarningModal />,
              },
              {
                path: "bulk-pdf-warning/*",
                element: <ConfirmationPdfModal />,
              },
              {
                path: "bulk-csv-warning/*",
                element: <ConfirmationCsvModal />,
              },
              {
                path: "bulk-exclude-warning/*",
                element: <BulkExcludeWarningModal />,
              },
              {
                path: "attachments/*",
                element: (
                  <WithOutlet>
                    <LazyProtectedEligibilityAttachmentModalWithFallback />
                  </WithOutlet>
                ),
                children: [
                  {
                    path: ":attachmentId/*",
                    element: <Outlet />,
                    children: [
                      {
                        path: "edit",
                        element: (
                          <LazyProtectedEligibilityEditAttachmentWithFallback />
                        ),
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            path: "patient-information/*",
            element: (
              <WithOutlet>
                <LazyProtectedEligibilityPageWithFallback />
              </WithOutlet>
            ),
            children: [
              {
                path: ":id/*",
                element: <PatientInformation />,
              },
            ],
          },
          {
            path: "patient-benefit-information/*",
            element: <Outlet />,
            children: [
              {
                path: ":id/*",
                element: (
                  <WithOutlet>
                    <PatientBenefitInformation />
                  </WithOutlet>
                ),
                children: [
                  {
                    path: "miscellaneous-edit",
                    element: <EditMiscellaneousFormDrawer />,
                  },
                  {
                    path: "employer-information-edit",
                    element: <EditEmployerInformationFormDrawer />,
                  },
                  {
                    path: "patient-and-payer-information-edit",
                    element: <EditPatiendAndPayerInformationFormDrawer />,
                  },
                  {
                    path: "subscriberinformation-edit",
                    element: <EditSubscriberInformationFormDrawer />,
                  },
                  {
                    path: "active-coverage-edit",
                    element: <EditActiveCoverageFormDrawer />,
                  },
                  {
                    path: "co-insurance-edit",
                    element: <EditCoInsuranceFormDrawer />,
                  },
                  {
                    path: "ada-procedure-edit",
                    element: <EditAdaProcedureFormDrawer />,
                  },
                  {
                    path: "deductible-edit",
                    element: <EditDeductibleFormDrawer />,
                  },
                  {
                    path: "limitation-edit",
                    element: <EditLimitationFormDrawer />,
                  },
                  {
                    path: "maximum-edit",
                    element: <EditMaximumFormDrawer />,
                  },
                  {
                    path: "not-covered-edit",
                    element: <EditNotCoveredFormDrawer />,
                  },
                  {
                    path: "benefit-history-edit",
                    element: <EditBenefitHistoryFormDrawer />,
                  },
                  {
                    path: ":patientId/*",
                    element: <Outlet />,
                    children: [
                      {
                        path: "attachments/*",
                        element: <Outlet />,
                        children: [
                          {
                            path: "add",
                            element: (
                              <LazyProtectedEligibilityAddAttachmentWithFallback />
                            ),
                          },
                        ],
                      },
                      {
                        path: "miscellaneous/*",
                        element: <Outlet />,
                        children: [
                          {
                            path: "add",
                            element: (
                              <LazyProtectedPatientBenefitInformationAddMiscellaneousWithFallback />
                            ),
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },

      {
        path: "eligibility/*",
        element: <Outlet />,
        children: [
          {
            path: "patient-benefit-information/*",
            element: <Outlet />,
            children: [
              {
                path: ":id/*",
                element: <Outlet />,
                children: [
                  {
                    path: "report",
                    element: (
                      <LazyProtectedPatientBenefitInformationReportWithFallback />
                    ),
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        path: "settings/*",
        element: (
          <WithOutlet>
            <LazyProtectedSettingsPageWithFallback />
          </WithOutlet>
        ),
        children: [
          {
            path: ":id/*",
            element: <Outlet />,
            children: [
              {
                path: "schedule-edit/*",
                element: (
                  <WithOutlet>
                    <LazyProtectedEditScheduleModalWithFallback />
                  </WithOutlet>
                ),
              },
              {
                path: "schedule-delete/*",
                element: <LazyProtectedDeleteScheduleModalWithFallback />,
              },
            ],
          },
        ],
      },
      {
        path: "reports/*",
        element: (
          <WithOutlet>
            <LazyProtectedReportsPageWithFallback />
          </WithOutlet>
        ),
        children: [
          {
            path: "pending-eligibility-report/*",
            element: (
              <WithOutlet>
                <LazyProtectedPendingEligibilityReportWithFallback />
              </WithOutlet>
            ),
            children: [
              {
                path: "delete-confirmation/*",
                element: (
                  <WithOutlet>
                    <LazyProtectedReportDeleteConfirmationWithFallback />
                  </WithOutlet>
                ),
              },
            ],
          },
          {
            path: "new-patient-report/*",
            element: (
              <WithOutlet>
                <LazyProtectedNewPatientReportWithFallback />
              </WithOutlet>
            ),
            children: [
              {
                path: "delete-confirmation/*",
                element: (
                  <WithOutlet>
                    <LazyProtectedReportDeleteConfirmationWithFallback />
                  </WithOutlet>
                ),
              },
            ],
          },
          {
            path: "transaction-report/*",
            element: (
              <WithOutlet>
                <LazyProtectedTransactionReportWithFallback />
              </WithOutlet>
            ),
            children: [
              {
                path: "delete-confirmation/*",
                element: (
                  <WithOutlet>
                    <LazyProtectedReportDeleteConfirmationWithFallback />
                  </WithOutlet>
                ),
              },
            ],
          },
          {
            path: "generate-pending-eligibility/*",
            element: (
              <WithOutlet>
                <LazyProtectedGeneratePendingEligibilityWithFallback />
              </WithOutlet>
            ),
          },
          {
            path: "generate-new-patient/*",
            element: (
              <WithOutlet>
                <LazyProtectedGenerateNewPatientWithFallback />
              </WithOutlet>
            ),
          },
          {
            path: "generate-transaction/*",
            element: (
              <WithOutlet>
                <LazyProtectedGenerateTransactionWithFallback />
              </WithOutlet>
            ),
          },
        ],
      },
      {
        path: "permissions/*",
        element: <Permissions />,
      },
      {
        path: "user",
        element: <UserTable />,
      },
      {
        path: "user/edituser/:id",
        element: <EditUser />,
      },
      {
        path: "user/roles",

        element: <Roles />,
      },

      {
        path: "faq",
        element: <LazyProtectedFaqPageWithFallback />,
      },
    ],
  },
]);

export default router;
