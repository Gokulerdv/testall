export const Endpoints = {
  getRoleById: (id: string, roleId: string) =>
    `userrole/get/${roleId}?practiceId=${id}`,
  getAllPractices: (id: string) => `practice/get/${id}`,
  getAllRole: (id: string) => `userrole/getall?practiceId=${id}`,
  createUser: (subscriptionId: any, practiceId: any) =>
    `useraccount/create/?subscriptionId=${subscriptionId}&practiceId=${practiceId}`,
  getAllUser: (id: string) => `useraccount/getall?practiceId=${id}`,
  getByUserId: (id: string) => `useraccount/get/${id}`,
  updateUser: (id: string, userid: string, subscriptionId: string) =>
    `useraccount/update/${userid}?practiceId=${id}&subscriptionId=${subscriptionId}`,
  deleteUser: (id: string, practiceId: string) =>
    `useraccount/delete/${id}?practiceId=${practiceId}`,
  getUserByPracticeId: (id: string) =>
    `useraccount/getall?practiceId=${id}`,
  requestDemo: (practiceId: string) =>
    `request-demo/product/${practiceId}`,
  requestForDemo: () => `productRequest/create/`,
  getAllRolesByPractice: (practiceId: string) =>
    `userrole/getdefault/${practiceId}`,
  getPracticeById: (id: string) => `practice/get/${id}`,
  getUserLocations: (userId: string) => `useraccount/locations/${userId}`,
  getProductbyRole: (id: string, practiceId: string) => `userrole/getroleproducts/${id}?practiceId=${practiceId}`,
  getUserByLocation: (locationId: string, practiceId: string) =>
    `useraccount/getbylocation?locationId=${locationId}&practiceId=${practiceId}`,
  refreshToken: `auth/refresh`,
  verifyToken: `auth/verify-token`,
};
