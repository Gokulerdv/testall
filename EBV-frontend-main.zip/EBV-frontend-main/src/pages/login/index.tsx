/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { isEmpty } from "lodash";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { NavLink } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Form, FormGroup, Input, Label, Spinner } from "reactstrap";
import { z } from "zod";
import { useAuthContext } from "../../shared/hooks/use-auth";
import { Config } from "../../utils/headers-config";
import Password, { passwordSchema } from "./form/fields/password";
import Username, { usernameSchema } from "./form/fields/username";
import { accountLogin } from "./service";

export const loginSchema = usernameSchema.merge(passwordSchema);

export type LoginFormData = z.infer<typeof loginSchema>;

export const Login = () => {
  const auth = useAuthContext();
  const [disable, setDisable] = React.useState(false);
  const login = useMutation({
    mutationKey: ["login"],
    mutationFn: accountLogin,
  });

  const getAll = async (userId: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/generalSettings/get/${userId}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const onSubmit: SubmitHandler<LoginFormData> = async (data) => {
    const res = await login.mutateAsync({
      email: data.username,
      password: data.password,
    });
    if (!res.status) {
      auth.dispatcher({ type: "reset-user" });
      setDisable(true);
      toast.error(res?.message, { autoClose: 1000 });
    }
  };
  React.useEffect(() => {
    if (disable === true) {
      setTimeout(() => {
        setDisable(false);
      }, 2000);
    }
  }, [disable]);

  React.useEffect(() => {
    if (!login.data) return;

    if (!isEmpty(login.data.data)) {
      auth.dispatcher({ type: "set-user", payload: login.data.data });
      auth.dispatcher({
        type: "set-permission",
        payload:
          login.data.data.userData?.practice?.locations[0]?.role?.permissions,
      });
      getAll(login.data?.data?.userData?.userId);
    }
  }, [auth, login.data]);

  const methods = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  return (
    <>
      <div className="gap-5 vstack">
        <div>
          <h5>Login</h5>
        </div>

        <>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit)}>
              <Username placeholder="John" />

              <Password placeholder="***********" />

              <div className="mb-5 hstack justify-content-between align-items-baseline">
                <FormGroup check inline>
                  <Input type="checkbox" />
                  <Label check>Remember me</Label>
                </FormGroup>

                <NavLink to="forgot-password">
                  <a className="link-primary">Forgot Password</a>
                </NavLink>
              </div>

              <Button
                type="submit"
                disabled={disable || login?.isPending}
                style={{
                  background:
                    "linear-gradient(88deg, #007BED 0%, #C350EC 97.19%)",
                }}
                className="mt-4 text-white w-100"
                onClick={methods.handleSubmit(onSubmit)}
              >
                {login?.isPending ? (
                  <Spinner size="sm">Loading...</Spinner>
                ) : (
                  "Sign In"
                )}
              </Button>

              <p className="mt-3 text-end">
                <a href="" className="link-body-emphasis">
                  Need help ?
                </a>
              </p>
            </Form>
          </FormProvider>
        </>
      </div>
    </>
  );
};

export default Login;
