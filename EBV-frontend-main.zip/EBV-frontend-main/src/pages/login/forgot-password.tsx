/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import { Button, Form, FormGroup, Input, Label } from "reactstrap";

export const ForgotPassword = () => {
  const [mobileOrEmail, setMobileOrEmail] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (event: any) => {
    event.preventDefault();
    if (!mobileOrEmail.trim()) {
      setError("Mobile or Email cannot be empty");
    } else {
      setError("");
      // Proceed with sending OTP
    }
  };

  return (
    <>
      <div className="vstack gap-5">
        <div>
          <h5>Forgot Password</h5>
          <p>Enter your email id to reset your password</p>
        </div>

        <>
          <Form onSubmit={handleSubmit}>
            <FormGroup>
              <Label for="mobile-or-email">Mobile or Email</Label>
              <Input
                id="mobile-or-email"
                name="mobileOrEmail"
                placeholder="John21@tooth.com"
                type="text"
                value={mobileOrEmail}
                onChange={(e) => setMobileOrEmail(e.target.value)}
              />
            </FormGroup>

            {error && <p className="text-danger">{error}</p>}

            <Button
              color="primary"
              type="submit"
              className="text-white w-100 mt-4"
              disabled={!mobileOrEmail.trim()}
            >
              Send OTP
            </Button>

            <p className="text-end mt-3">
              <a href="" className="link-body-emphasis">
                Need help ?
              </a>
            </p>
          </Form>
        </>
      </div>
    </>
  );
};

export default ForgotPassword;
