import { Button, Form, FormGroup, Input } from "reactstrap";

export const Otp = () => {
  return (
    <>
      <Form>
        <div className="vstack gap-5">
          <div>
            <h5>Enter OTP</h5>

            <p className="mt-4">
              Onetime password sent to <br />
              John21@tooth.com
            </p>

            <FormGroup>
              <Input id="otp" name="otp" placeholder="688499" type="tel" />
            </FormGroup>

            <p className="text-end mt-3">
              <a href="" className="link-primary">
                Resend OTP
              </a>
            </p>
          </div>

          <div>
            <Button color="primary" className="text-white w-100 mt-4">
              Confirm
            </Button>

            <p className="text-end mt-3">
              <a href="" className="link-body-emphasis">
                Need help ?
              </a>
            </p>
          </div>
        </div>
      </Form>
    </>
  );
};

export default Otp;
