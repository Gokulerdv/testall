import { Button, Form, FormGroup, Label, Input } from "reactstrap";

export const ResetPassword = () => {
  return (
    <>
      {" "}
      <div className="vstack gap-5">
        <div>
          <h5>Create New Password</h5>
        </div>

        <>
          <Form>
            <FormGroup>
              <Label for="new-password">New Password</Label>
              <Input
                id="new-password"
                name="newPassword"
                placeholder="***********"
                type="password"
              />
            </FormGroup>

            <FormGroup>
              <Label for="confirm-password">Confirm Password</Label>
              <Input
                id="confirm-password"
                name="confirmPassword"
                placeholder="***********"
                type="password"
              />
            </FormGroup>

            <Button color="primary" className="text-white w-100 mt-4">
              Create
            </Button>

            <p className="text-end mt-3">
              <a href="" className="link-body-emphasis">
                Need help ?
              </a>
            </p>
          </Form>
        </>
      </div>
    </>
  );
};

export default ResetPassword;
