/* eslint-disable @typescript-eslint/no-explicit-any */
import { urlEncodedRequestOptionsForLogin } from "../../utils/url-encoded-request-options-for-login";

export type AccountLoginBody = {
  email: string;
  password: string;
};

export const accountLogin = async (body: AccountLoginBody): Promise<any> => {
  const url = `${import.meta.env.VITE_API_HOST ?? ""}/account/login`;
  const response = await (
    await fetch(url, urlEncodedRequestOptionsForLogin(body))
  ).json();
  return response;
};
