import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Alert, Spinner } from "reactstrap";

export default function ScanDocumentPage() {
  const [searchParams] = useSearchParams();
  const [message, setMessage] = useState({ text: "", color: "info" });

  const clientId = searchParams.get("clientId");
  const ocrFile = async (formData: FormData) => {
    const response = await fetch(`${import.meta.env.VITE_API_HOST ?? ""}/ocr`, {
      method: "POST",
      body: formData,
    });

    return await response.json();
  };

  const postOcrData = (clientId: string) => async (data: unknown) => {
    const response = await fetch(
      `${import.meta.env.VITE_API_HOST ?? ""}/events?clientId=${clientId}`,
      {
        method: "POST",
        body: JSON.stringify(data),
      }
    );

    return await response.json();
  };
  const ocrFileMutation = useMutation({
    mutationKey: ["ocr-file"],
    mutationFn: ocrFile,
  });

  const postOcrDataMutation = useMutation({
    mutationKey: ["post-ocr-data"],
    mutationFn: postOcrData(clientId ?? ""),
  });

  const handleUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const [file] = event.target.files as FileList;

      const formData = new FormData();
      formData.append("image", file);

      const data = await ocrFileMutation.mutateAsync(formData);

      await postOcrDataMutation.mutateAsync(data);

      setMessage({ text: "Uploaded successfully!", color: "success" });
    } catch (error) {
      setMessage({
        text: "Failed to upload, please retry again by scanning a new QR Code!",
        color: "danger",
      });

      console.log(error);
    }
  };

  return (
    <>
      <div className="vstack">
        <div style={{ margin: "3.5rem", height: "100%" }}>
          {ocrFileMutation.isPending ? (
            <>
              <Alert color="info">
                <div className="hstack justify-content-center align-items-center gap-3">
                  <Spinner>Extracting...</Spinner>
                  <p className="mb-0">Extracting text from the document...</p>
                </div>
              </Alert>
            </>
          ) : (
            <>
              {message.text ? (
                <Alert color={message.color}>{message.text}</Alert>
              ) : (
                <div className="vstack">
                  <input
                    type="file"
                    accept="image/*"
                    capture={true}
                    onChange={handleUpload}
                    disabled={ocrFileMutation.isPending ? true : false}
                  />
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}
