import { faFile } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { CellContext } from "@tanstack/react-table";
import React from "react";
import { Link as RouterLink } from "react-router-dom";
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import { Patient } from "./apis/patients-all";

export type InsurancePayerModalProps = {
  uniqueId: string;
  info: CellContext<Patient, unknown>;
};

export const InsurancePayerModal = (props: InsurancePayerModalProps) => {
  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  return (
    <>
      <Button
        color="link"
        className={`rounded-circle p-0`}
        style={{ color: "var(--bs-danger)" }}
        onClick={toggle}
      >
        <FontAwesomeIcon icon={faFile} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md">
        <ModalHeader toggle={toggle}>
          <div className="title">Insurance Payer</div>
        </ModalHeader>

        <ModalBody>
          Unable to get patient details. Please reach the insurance via call or
          website portal.
        </ModalBody>

        <ModalFooter>
          <div className="hstack gap-2">
            <RouterLink
              to={`patient-information/${props.info.row.original.patientId}`}
              state={props.info.row.original}
            >
              <Button color="link">Patient Profile</Button>
            </RouterLink>
          </div>
        </ModalFooter>
      </Modal>
    </>
  );
};

export default InsurancePayerModal;
