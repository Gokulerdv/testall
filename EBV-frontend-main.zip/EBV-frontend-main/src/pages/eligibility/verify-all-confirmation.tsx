/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { useNotificationContext } from "../../shared/hooks/use-notification";
import { Config } from "../../utils/headers-config";

const VerifyAllConfirmation = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/verify-all-confirmation",
    togglePath: "../../eligibility?refresh=true",
    historyPopInstead: false,
  });

  const auth = useAuth();

  const adminId = auth?.state?.user?.userData?.userId;

  const bulkVerifyAll = async (search: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/bulkverifyall${search}`;

    const response = await (
      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const notify = useNotificationContext();

  const verifyAll = useMutation({
    mutationKey: ["patients/bulkverifyall"],
    mutationFn: bulkVerifyAll,
  });

  const verifyAllPatients: React.MouseEventHandler<HTMLElement> = async (
    event
  ) => {
    try {
      event.preventDefault();
      event.stopPropagation();

      const res = await verifyAll.mutateAsync(`?adminId=${adminId}`);
      res?.notificationData && notify.dispatcher({ type: "increment-count" });
      !res?.error && toast.success("Patients verified Successfully");
      if (res?.error) throw Error;
      res.data?.eligibility && res.data?.eligibility?.errors?.length
        ? toast.error("Patient verification failed!")
        : toast.success("Patient verified Successfully");
    } catch (error) {
      toast.error("Patient verification failed!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <>
      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Verify all
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to verify all the patients?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button
              outline
              color="primary"
              onClick={verifyAllPatients}
              disabled={verifyAll.isPending}
            >
              {verifyAll.isPending ? (
                <>
                  <Spinner size="sm">Verifying...</Spinner>
                  <span> Verifying...</span>
                </>
              ) : (
                <span>Yes</span>
              )}
            </Button>
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
export default VerifyAllConfirmation;
