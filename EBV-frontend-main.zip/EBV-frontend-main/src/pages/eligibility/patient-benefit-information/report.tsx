import { useSearchParams } from "react-router-dom";
import ActiveCoverageTable from "./tables/active-coverage";
import AdaProcedureTable from "./tables/ada-procedure";
import BenefitsHistoryTable from "./tables/benefit-history";
import CoInsuranceTable from "./tables/co-insurance";
import { DeductibleTable } from "./tables/deductible";
import LimitationsTable from "./tables/limitation";
import NotCoveredTable from "./tables/not-covered";
import PaymentAndPayerInformation from "./cards/patient-and-payer-information";
import SubscriberInformationCard from "./cards/subscriber-information-card";
import Insights from "./cards/insights-cards";
import { usePDF } from "react-to-pdf";
import { NotesAndRemarks } from "./cards/note-and-remark";
import { Miscellaneous } from "./cards/miscellaneous";
import { AttachmentTable } from "../../patient-benefit-information/components/attachments-table";
import React from "react";
import { Col, Row } from "reactstrap";

export const Report = () => {
  const [searchParams] = useSearchParams();
  const type = searchParams.get("type");
  const download = searchParams.get("download");
  const { toPDF, targetRef } = usePDF({ filename: "page.pdf" });
  const isFirstLoad = React.useRef(true);

  React.useEffect(() => {
    if (download === "pdf" && isFirstLoad.current) {
      try {
        toPDF();
        isFirstLoad.current = false;
      } catch (error) {
        console.error(error);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [download]);

  return (
    <React.Suspense fallback={"Loading..."}>
      <div ref={targetRef} className={`${download === "pdf" ? "p-3" : "p-0"}`}>
        <Row className="g-3 mb-5">
          <Col lg={8}>
            <SubscriberInformationCard />
          </Col>

          <Col>
            <Insights />
          </Col>
        </Row>

        <ActiveCoverageTable />

        {type === "detailed" ? <CoInsuranceTable /> : null}

        {type === "detailed" ? <AdaProcedureTable /> : null}

        <DeductibleTable />

        {type === "detailed" ? <LimitationsTable /> : null}

        <NotCoveredTable />

        <PaymentAndPayerInformation />

        <Miscellaneous />

        <NotesAndRemarks />

        <AttachmentTable />

        <BenefitsHistoryTable />
      </div>
    </React.Suspense>
  );
};

export default Report;
