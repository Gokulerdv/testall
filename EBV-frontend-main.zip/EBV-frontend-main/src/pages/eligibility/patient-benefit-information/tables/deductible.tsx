/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCaretDown,
  faCaretRight,
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import {
  CellContext,
  VisibilityState,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Form,
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import { TextWithHighlight } from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { Patient } from "../../apis/patients-all";
import CommonLoader from "../common-loader";

// TODO: TEST this after backend changes are fixed

const deductibleSchema = z.object({
  serviceType: z.string().optional().nullable(),
  code: z.string().optional().nullable(),
  network: z.string().optional().nullable(),
  coverageLevel: z.string().optional().nullable(),
  planPeriod: z.string().optional().nullable(),
  amount: z.string().optional().nullable(),
  insuranceType: z.string().optional().nullable(),
  planCoverageDescription: z.string().optional().nullable(),
  message: z.string().optional().nullable(),
});

const keyToColumnHeaderMapping = {
  serviceType: "Service Type",
  code: "ADA Code",
  network: "Network",
  coverageLevel: "Coverage Level",
  planPeriod: "Plan Period",
  amount: "Amount",
  insuranceType: "Insurance Type",
  planCoverageDescription: "Plan Coverage",
} as Record<string, string>;

export type DeductibleForm = z.infer<typeof deductibleSchema>;

const defaultData = [] as any[];

export const DeductibleTable = React.memo(() => {
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});

  const { id: patientId } = useParams() as { id: string };

  const [searchParams] = useSearchParams();

  const { state } = useLocation() as Location<Patient>;

  const { search } = useLocation();
  const auth = useAuth();

  const getAll = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAllDeductiblefilter${search}`;

    // const url = `${
    //   import.meta.env.VITE_API_HOST ?? ""
    // }/eligibility/getAllDeductible/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      keyVisibility: response?.obj ?? {},
      data: [...(response.data ?? [])].map((data: any) => ({ ...data, data })),
    };
  };

  const eligibilityId =
    searchParams.get("pastHistory") === "undefined" ||
    searchParams.get("pastHistory") === "null"
      ? state.eligibilityId
      : searchParams.get("pastHistory");

  const {
    isRefetching,
    data: { data: deductibleList, keyVisibility },
  } = useSuspenseQuery({
    queryKey: ["deductible", "getAll", patientId, search],
    queryFn: getAll(
      eligibilityId
        ? search
          ? `${search}&patientId=${patientId}&eligibilityId=${eligibilityId}`
          : `?patientId=${patientId}&eligibilityId=${eligibilityId}`
        : search
        ? `${search}&patientId=${patientId}`
        : `?patientId=${patientId}`
    ),
  });

  React.useEffect(() => {
    setColumnVisibility(
      Object.keys(keyVisibility).reduce((acc, key) => {
        return {
          ...acc,
          [keyToColumnHeaderMapping[key]]: keyVisibility[key],
        };
      }, {})
    );
  }, [keyVisibility]);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    queryClient.invalidateQueries({
      queryKey: ["deductible", "getAll"],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const editMode = searchParams.get("editMode") ?? "";
  const tableFilter = searchParams.get("tableFilter") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<any>();

    const staticColumns = [
      {
        id: "expander",
        header: () => null,
        cell: ({ row }: CellContext<any, unknown>) => {
          return row.getCanExpand() ? (
            <Button
              color="link"
              className="p-0 text-black"
              {...{
                onClick: row.getToggleExpandedHandler(),
                style: {
                  cursor: "pointer",
                },
              }}
            >
              {row.getIsExpanded() ? (
                <FontAwesomeIcon icon={faCaretDown} />
              ) : (
                <FontAwesomeIcon icon={faCaretRight} />
              )}
            </Button>
          ) : null;
        },
      },
      columnHelper.accessor((row) => row?.data?.serviceType, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue())}
          </TextWithHighlight>
        ),
        header: "Service Type",
      }),
      columnHelper.accessor((row) => row?.data?.code, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "ADA Code",
      }),
      columnHelper.accessor((row) => row?.data?.network, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() === "Other Network" ? "In and Out Network": info.getValue())}
          </TextWithHighlight>
        ),
        header: "Network",
      }),
      columnHelper.accessor((row) => row?.data?.coverageLevel, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Coverage Level",
      }),
      columnHelper.accessor((row) => row?.data?.planPeriod, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Plan Period",
      }),
      columnHelper.accessor((row) => row?.data?.amount, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Amount",
      }),
      columnHelper.accessor((row) => row?.data?.insuranceType, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Insurance Type",
      }),
      columnHelper.accessor((row) => row?.data?.planCoverageDescription, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Plan Coverage",
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="gap-3 hstack">
                  <RouterLink
                    to={`deductible-edit${search}`}
                    state={{
                      deductibleId: info.row.original.id,
                    }}
                  >
                    <Button color="link" className={`rounded-circle p-0`}>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </Button>
                  </RouterLink>

                  <DeleteModal deductibleId={info.row.original.id} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode, search]);

  const table = useReactTable({
    columns: (columns as any) ?? defaultData,
    data: deductibleList as any,
    // TODO: Add the filters logic to the table filters
    // .filter((deductible: any) =>
    //   adaCodeFilter === "true" && deductible?.data?.code
    //     ? // TODO: Get the procedure code from eligibility
    //       "D0140, D0123".includes(deductible?.data?.code)
    //     : true
    // )
    // .filter((deductible: any) =>
    //   networkFilters.length > 0 && deductible?.network
    //     ? networkFilters.includes(deductible.network)
    //     : true
    // ) ?? defaultData,
    getRowCanExpand: (row) =>
      (row.original as any).data?.message ? true : false,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    debugTable: import.meta.env.DEV ? true : false,
    state: {
      columnVisibility,
    },
    onColumnVisibilityChange: setColumnVisibility,
  });

  const renderSubComponent = ({ row }: any) => (
    <div>{row.original?.data?.message}</div>
  );

  return (
    <>
      {isRefetching ? (
        <CommonLoader label="Deductible" />
      ) : (
        <Card className="mt-3">
          <CardBody>
            {import.meta.env.DEV ? (
              <ReactTableDevtools initialIsOpen table={table} />
            ) : null}

            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Deductible</h6>

                {editMode ? <AddDeductibleForm /> : null}
              </div>
            </CardTitle>

            <table className="table mb-0 table-hover">
              <thead>
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        colSpan={header.colSpan}
                        className="border-bottom"
                      >
                        {header.isPlaceholder ? null : (
                          <div
                            {...{
                              className: "hstack align-items-center",
                              style: header.column.getCanSort()
                                ? {
                                    cursor: "pointer",
                                    userSelect: "none",
                                  }
                                : undefined,
                              onClick: header.column.getToggleSortingHandler(),
                            }}
                          >
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </div>
                        )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>

              <tbody>
                {table.getRowModel().rows.length === 0 ? (
                  <tr>
                    <td colSpan={12}>There are no records to display</td>
                  </tr>
                ) : null}
                {table.getRowModel().rows.map((row) => (
                  <React.Fragment key={row.id}>
                    <tr>
                      {row.getVisibleCells().map((cell) => {
                        return (
                          <td
                            key={cell.id}
                            style={{
                              backgroundColor: (
                                tableFilter.includes("!")
                                  ? (row.original as any)?.planPeriod !==
                                      tableFilter.split("!")[1] &&
                                    (row.original as any)?.planPeriod !==
                                      null &&
                                    (row.original as any)?.coverageLevel ===
                                      "Individual"
                                  : (row.original as any)?.planPeriod ===
                                      tableFilter &&
                                    (row.original as any)?.coverageLevel ===
                                      "Individual"
                              )
                                ? "lightgrey"
                                : "",
                            }}
                          >
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </td>
                        );
                      })}
                    </tr>

                    {row.getIsExpanded() ? (
                      <tr>
                        {/* 2nd row is a custom 1 cell row */}
                        <td colSpan={row.getVisibleCells().length}>
                          {renderSubComponent({ row })}
                        </td>
                      </tr>
                    ) : null}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>
      )}
    </>
  );
});

export const DeductibleFormFields = () => {
  return (
    <>
      <Field name="serviceType" />
      <Field name="code" />
      <Field name="network" />
      <Field name="coverageLevel" />
      <Field name="planPeriod" />
      <Field name="amount" />
      <Field name="insuranceType" />
      <Field name="planCoverageDescription" />
      <Field name="message" type="textarea" />
    </>
  );
};

export const AddDeductibleForm = () => {
  const { id: patientId } = useParams() as { id: string };
  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const create = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/createDeductible`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const deductibleListCreate = useMutation({
    mutationKey: ["deductible", "create"],
    mutationFn: create,
  });

  const queryClient = useQueryClient();

  const methods = useForm<DeductibleForm>({
    resolver: zodResolver(deductibleSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<DeductibleForm> = async (data) => {
    try {
      await deductibleListCreate.mutateAsync({
        ...data,
        isScheduled: state?.isScheduled,
        patientId,
      });

      toast.success("Deductible added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["deductible", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <div>
      <Button outline size="sm" color="primary" onClick={toggle}>
        <FontAwesomeIcon icon={faPlus} />
      </Button>

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Add Deductible
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <DeductibleFormFields />

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EditDeductibleFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id/deductible-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<DeductibleForm>({
    resolver: zodResolver(deductibleSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Deductible
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditDeductibleForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditDeductibleFormProps = {
  methods: UseFormReturn<DeductibleForm>;
  toggle: () => void;
};

export const EditDeductibleForm = ({
  methods,
  toggle,
}: EditDeductibleFormProps) => {
  const { id: patientId } = useParams() as { id: string };

  const {
    state: { deductibleId },
  } = useLocation() as Location<{ deductibleId: string }>;
  const auth = useAuth();

  const getById = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getDeductibleById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/updateDeductibleById/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const deductibleUtils = useSuspenseQuery({
    queryKey: ["deductible", "get", deductibleId],
    queryFn: getById(deductibleId),
  });

  const deductibleListUpdate = useMutation({
    mutationKey: ["deductible", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    methods.reset((deductibleUtils?.data as any)?.data);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deductibleUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<DeductibleForm> = async (data) => {
    try {
      await deductibleListUpdate.mutateAsync({
        ...data,
        id: deductibleId,
      });

      toast.success("Deductible updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["deductible", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <DeductibleFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};

export type DeleteModalProps = {
  deductibleId: number;
};

export const DeleteModal = ({ deductibleId }: DeleteModalProps) => {
  const { id: patientId } = useParams() as { id: string };

  const [open, setOpen] = React.useState(false);

  const auth = useAuth();

  const toggle = () => setOpen(!open);

  const remove = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/deleteDeductibleById/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const deductibleListRemove = useMutation({
    mutationKey: ["deductible", "remove"],
    mutationFn: remove,
  });

  const queryClient = useQueryClient();

  const deleteRow = async () => {
    try {
      await deductibleListRemove.mutateAsync(String(deductibleId));

      toast.success("Deductible deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["deductible", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default DeductibleTable;
