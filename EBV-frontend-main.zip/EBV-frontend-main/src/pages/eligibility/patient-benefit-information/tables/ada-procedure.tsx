/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCaretDown,
  faCaretRight,
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import {
  CellContext,
  VisibilityState,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Form,
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import { TextWithHighlight } from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { Patient } from "../../apis/patients-all";
import CommonLoader from "../common-loader";

// TODO: TEST this after backend changes are fixed - Frequency is not getting added or updated

const adaProcedureSchema = z.object({
  serviceType: z.string().optional().nullable(),
  code: z.string().optional().nullable(),
  network: z.string().optional().nullable(),
  coverageLevel: z.string().optional().nullable(),
  percent: z.string().optional().nullable(),
  auth: z.string().optional().nullable(),
  frequency: z.string().optional().nullable(),
  ageLimit: z.string().optional().nullable(),
  message: z.string().optional().nullable(),
});

const keyToColumnHeaderMapping = {
  code: "ADA Code",
  serviceType: "Service Type",
  network: "Network",
  coverageLevel: "Coverage Level",
  percent: "Percentage",
  auth: "Authorization Required",
  frequency: "Frequency",
  ageLimit: "Age Limit",
} as Record<string, string>;

export type AdaProcedureForm = z.infer<typeof adaProcedureSchema>;

const defaultData = [] as any[];

export const AdaProcedureTable = React.memo(() => {
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});

  const { id: patientId } = useParams() as { id: string };

  const [searchParams] = useSearchParams();

  const { state } = useLocation() as Location<Patient>;

  const { search } = useLocation();

  const auth = useAuth();

  const getAll = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAlladaprocedurefilter${search}`;

    // const url = `${
    //   import.meta.env.VITE_API_HOST ?? ""
    // }/eligibility/getAllAdaProcedure/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      keyVisibility: response?.obj ?? {},
      data: [...(response.data ?? [])].map((data: any) => ({ ...data, data })),
    };
  };

  const eligibilityId =
    searchParams.get("pastHistory") === "undefined" ||
    searchParams.get("pastHistory") === "null"
      ? state.eligibilityId
      : searchParams.get("pastHistory");

  const {
    isRefetching,
    data: { data: adaProcedureList, keyVisibility },
  } = useSuspenseQuery({
    queryKey: ["adaProcedure", "getAll", patientId, search],
    queryFn: getAll(
      eligibilityId
        ? search
          ? `${search}&patientId=${patientId}&eligibilityId=${eligibilityId}`
          : `?patientId=${patientId}&eligibilityId=${eligibilityId}`
        : search
        ? `${search}&patientId=${patientId}`
        : `?patientId=${patientId}`
    ),
  });

  React.useEffect(() => {
    setColumnVisibility(
      Object.keys(keyVisibility).reduce((acc, key) => {
        return {
          ...acc,
          [keyToColumnHeaderMapping[key]]: keyVisibility[key],
        };
      }, {})
    );
  }, [keyVisibility]);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    queryClient.invalidateQueries({
      queryKey: ["adaProcedure", "getAll"],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const editMode = searchParams.get("editMode") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<any>();

    const staticColumns = [
      {
        id: "expander",
        header: () => null,
        cell: ({ row }: CellContext<any, unknown>) => {
          return row.getCanExpand() ? (
            <Button
              color="link"
              className="p-0 text-black"
              {...{
                onClick: row.getToggleExpandedHandler(),
                style: {
                  cursor: "pointer",
                },
              }}
            >
              {row.getIsExpanded() ? (
                <FontAwesomeIcon icon={faCaretDown} />
              ) : (
                <FontAwesomeIcon icon={faCaretRight} />
              )}
            </Button>
          ) : null;
        },
      },
      columnHelper.accessor((row) => row?.data?.code, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "ADA Code",
      }),
      columnHelper.accessor((row) => row?.data?.serviceType, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue())}
          </TextWithHighlight>
        ),
        header: "Service Type",
      }),
      columnHelper.accessor((row) => row?.data?.description, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue())}
          </TextWithHighlight>
        ),
        header: "Description",
      }),
      columnHelper.accessor((row) => row?.data?.network, {
        cell: (info) => (
          <TextWithHighlight>
           {textWithDefault(info.getValue() === "Other Network" ? "In and Out Network": info.getValue())}
          </TextWithHighlight>
        ),
        header: "Network",
      }),
      columnHelper.accessor((row) => row?.data?.coverageLevel, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Coverage Level",
      }),
      columnHelper.accessor((row) => row?.data?.percent, {
        cell: (info) => {
          const percent = info.getValue()
          const insurancePercent = 100 - Number(percent)
          return(
            <TextWithHighlight>
              {textWithDefault(
                info.getValue() ? `${percent as string}% / ${insurancePercent}%` : ""
              )}
            </TextWithHighlight>
          )
        },
        header: "Percentage PAT% / INS%",
      }),
      columnHelper.accessor((row) => row?.data?.auth, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Authorization Required",
      }),
      columnHelper.accessor((row) => row?.data?.frequency, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Frequency",
      }),
      columnHelper.accessor((row) => row?.data?.ageLimit, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Age Limit",
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="gap-3 hstack">
                  <RouterLink
                    to={`ada-procedure-edit${search}`}
                    state={{
                      adaProcedureId: info.row.original.id,
                    }}
                  >
                    <Button color="link" className={`rounded-circle p-0`}>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </Button>
                  </RouterLink>

                  <DeleteModal adaProcedureId={info.row.original.id} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode, search]);

  const table = useReactTable({
    columns: (columns as any) ?? defaultData,
    data: adaProcedureList as any,
    // TODO: Add the filters logic to the table filters
    // .filter((adaProcedure: any) =>
    //   adaCodeFilter === "true" && adaProcedure?.data?.adaCode
    //     ? // TODO: Get the procedure code from eligibility
    //       "D0140, D0123".includes(adaProcedure?.data?.adaCode)
    //     : true
    // )
    // .filter((adaProcedure: any) =>
    //   networkFilters.length > 0 && adaProcedure?.network
    //     ? networkFilters.includes(adaProcedure.network)
    //     : true
    // ) ?? defaultData,
    getRowCanExpand: (row) =>
      (row.original as any).data?.message ? true : false,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    debugTable: import.meta.env.DEV ? true : false,
    state: {
      columnVisibility,
    },
    onColumnVisibilityChange: setColumnVisibility,
  });

  const renderSubComponent = ({ row }: any) => (
    <div>{row.original?.data?.message}</div>
  );

  return (
    <>
      {isRefetching ? (
        <CommonLoader label="ADA Procedure" />
      ) : (
        <Card className="mt-3">
          <CardBody>
            {import.meta.env.DEV ? (
              <ReactTableDevtools initialIsOpen table={table} />
            ) : null}

            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Ada Procedure</h6>

                {editMode ? <AddAdaProcedureForm /> : null}
              </div>
            </CardTitle>

            <table className="table mb-0 table-hover">
              <thead>
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        colSpan={header.colSpan}
                        className="border-bottom"
                      >
                        {header.isPlaceholder ? null : (
                          <div
                            {...{
                              className: "hstack align-items-center",
                              style: header.column.getCanSort()
                                ? {
                                    cursor: "pointer",
                                    userSelect: "none",
                                  }
                                : undefined,
                              onClick: header.column.getToggleSortingHandler(),
                            }}
                          >
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </div>
                        )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>

              <tbody>
                {table.getRowModel().rows.length === 0 ? (
                  <tr>
                    <td colSpan={12}>There are no records to display</td>
                  </tr>
                ) : null}
                {table.getRowModel().rows.map((row) => (
                  <React.Fragment key={row.id}>
                    <tr>
                      {row.getVisibleCells().map((cell) => (
                        <td key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      ))}
                    </tr>

                    {row.getIsExpanded() ? (
                      <tr>
                        {/* 2nd row is a custom 1 cell row */}
                        <td colSpan={row.getVisibleCells().length}>
                          {renderSubComponent({ row })}
                        </td>
                      </tr>
                    ) : null}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>
      )}
    </>
  );
});

export const AdaProcedureFormFields = () => {
  return (
    <>
      <Field name="code" />
      <Field name="serviceType" />
      <Field name="network" />
      <Field name="coverageLevel" />
      <Field name="percent" />
      <Field name="auth" />
      <Field name="frequency" />
      <Field name="ageLimit" />
      <Field name="message" type="textarea" />
    </>
  );
};

export const AddAdaProcedureForm = () => {
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();

  const create = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/createAdaProcedure`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const adaProcedureListCreate = useMutation({
    mutationKey: ["adaProcedure", "create"],
    mutationFn: create,
  });

  const queryClient = useQueryClient();

  const methods = useForm<AdaProcedureForm>({
    resolver: zodResolver(adaProcedureSchema),
  });

  const { state } = useLocation() as Location<Patient>;

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<AdaProcedureForm> = async (data) => {
    try {
      await adaProcedureListCreate.mutateAsync({
        ...data,
        isScheduled: state?.isScheduled,
        patientId,
      });

      toast.success("Ada Procedure added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["adaProcedure", "getAll", patientId],
      });

      toggle();
    }
  };

  return (
    <div>
      <Button outline size="sm" color="primary" onClick={toggle}>
        <FontAwesomeIcon icon={faPlus} />
      </Button>

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Add Ada Procedure
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <AdaProcedureFormFields />

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EditAdaProcedureFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id/ada-procedure-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<AdaProcedureForm>({
    resolver: zodResolver(adaProcedureSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Ada Procedure
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditAdaProcedureForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditAdaProcedureFormProps = {
  methods: UseFormReturn<AdaProcedureForm>;
  toggle: () => void;
};

export const EditAdaProcedureForm = ({
  methods,
  toggle,
}: EditAdaProcedureFormProps) => {
  const { id: patientId } = useParams() as { id: string };

  const auth = useAuth();

  const {
    state: { adaProcedureId },
  } = useLocation() as Location<{ adaProcedureId: string }>;

  const getById = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAdaProcedureById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const adaProcedureUtils = useSuspenseQuery({
    queryKey: ["adaProcedure", "get", adaProcedureId],
    queryFn: getById(adaProcedureId),
  });

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/updateAdaProcedureById/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const adaProcedureListUpdate = useMutation({
    mutationKey: ["adaProcedure", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    methods.reset((adaProcedureUtils?.data as any)?.data);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [adaProcedureUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<AdaProcedureForm> = async (data) => {
    try {
      await adaProcedureListUpdate.mutateAsync({
        ...data,
        id: adaProcedureId,
      });

      toast.success("Ada Procedure updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["adaProcedure", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <AdaProcedureFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};

export type DeleteModalProps = {
  adaProcedureId: number;
};

export const DeleteModal = ({ adaProcedureId }: DeleteModalProps) => {
  const { id: patientId } = useParams() as { id: string };

  const [open, setOpen] = React.useState(false);
  const auth = useAuth();

  const toggle = () => setOpen(!open);

  const remove = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/deleteAdaProcedureById/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const adaProcedureListRemove = useMutation({
    mutationKey: ["adaProcedure", "remove"],
    mutationFn: remove,
  });

  const queryClient = useQueryClient();

  const deleteRow = async () => {
    try {
      await adaProcedureListRemove.mutateAsync(String(adaProcedureId));

      toast.success("Ada Procedure deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["adaProcedure", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default AdaProcedureTable;
