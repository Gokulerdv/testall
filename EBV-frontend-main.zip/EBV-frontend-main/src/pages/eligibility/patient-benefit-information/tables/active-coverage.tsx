/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCaretDown,
  faCaretRight,
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import {
  CellContext,
  ExpandedState,
  VisibilityState,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Form,
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import { TextWithHighlight } from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { Patient } from "../../apis/patients-all";
import CommonLoader from "../common-loader";

// TODO: TEST this after backend changes are fixed - Effective Date and Percentage are not getting added or updated

// TODO: TEST this after backend changes are fixed - Updating one record in active coverage group creates two additional records instead of updating the original record - We could delete the two additional records whereas we couldn't delete the original record

// TODO: TEST this after backend changes are fixed - Updating one record in active coverage group creates two additional records instead of updating the original record

const activeCoverageSchema = z.object({
  serviceType: z.string().optional().nullable(),
  network: z.string().optional().nullable(),
  code: z.string().optional().nullable(),
  effectiveDateFrom: z.string().optional().nullable(),
  planPeriod: z.string().optional().nullable(),
  percent: z.string().optional().nullable(),
  waitingPeriodApplies: z.string().optional().nullable(),
  auth: z.string().optional().nullable(),
  insuranceType: z.string().optional().nullable(),
  coverageLevel: z.string().optional().nullable(),
  planCoverageDescription: z.string().optional().nullable(),
  message: z.string().optional().nullable(),
});

const keyToColumnHeaderMapping = {
  serviceType: "Service Type",
  network: "Network",
  code: "ADA Code",
  effectiveDateFrom: "Effective Date",
  planPeriod: "Plan Period",
  percent: "Percentage",
  waitingPeriodApplies: "Waiting Period Applies",
  auth: "Auth",
  insuranceType: "Insurance Type",
  coverageLevel: "Coverage Level",
  planCoverageDescription: "Plan Coverage Description",
} as Record<string, string>;

export type ActiveCoverageForm = z.infer<typeof activeCoverageSchema>;

const defaultData = [] as any[];

export const ActiveCoverageTable = React.memo(() => {
  const [expanded, setExpanded] = React.useState<ExpandedState>({});
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});

  const { id: patientId } = useParams() as { id: string };

  const [searchParams] = useSearchParams();

  const auth = useAuth();

  const { state } = useLocation() as Location<Patient>;

  const { search } = useLocation();

  const getAll = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAllActiveCoveragefilter${search}`;

    // const url = `${
    //   import.meta.env.VITE_API_HOST ?? ""
    // }/eligibility/getAllActiveCoverage/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      keyVisibility: response?.obj ?? {},
      data: [...(response.data ?? [])].map((data: any) => ({ ...data, data })),
    };
  };

  const eligibilityId =
    searchParams.get("pastHistory") === "undefined" || null
      ? state.eligibilityId
      : searchParams.get("pastHistory");

  const {
    isRefetching,
    data: { data: activeCoverageList, keyVisibility },
  } = useSuspenseQuery({
    queryKey: ["activeCoverage", "getAll", patientId, search],
    queryFn: getAll(
      eligibilityId
        ? search
          ? `${search}&patientId=${patientId}&eligibilityId=${eligibilityId}`
          : `?patientId=${patientId}&eligibilityId=${eligibilityId}`
        : search
        ? `${search}&patientId=${patientId}`
        : `?patientId=${patientId}`
    ),
  });

  React.useEffect(() => {
    setColumnVisibility(
      Object.keys(keyVisibility).reduce((acc, key) => {
        return {
          ...acc,
          [keyToColumnHeaderMapping[key]]: keyVisibility[key],
        };
      }, {})
    );
  }, [keyVisibility]);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    queryClient.invalidateQueries({
      queryKey: ["activeCoverage", "getAll"],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const editMode = searchParams.get("editMode") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<any>();

    const staticColumns = [
      {
        id: "expander",
        header: () => null,
        cell: ({ row }: CellContext<any, unknown>) => {
          return row.getCanExpand() ? (
            <Button
              color="link"
              className="p-0 text-black"
              {...{
                onClick: row.getToggleExpandedHandler(),
                style: {
                  cursor: "pointer",
                },
              }}
            >
              {row.getIsExpanded() ? (
                <FontAwesomeIcon icon={faCaretDown} />
              ) : (
                <FontAwesomeIcon icon={faCaretRight} />
              )}
            </Button>
          ) : null;
        },
      },
      columnHelper.accessor(
        (row) => row?.data?.type ?? row?.data?.serviceType ?? row?.serviceType,
        {
          cell: (info) => (
            <TextWithHighlight>
              {info.row.original?.activeCoverage?.length
                ? textWithDefault(info.getValue())
                : ""}
            </TextWithHighlight>
          ),
          header: "Service Type",
        }
      ),
      columnHelper.accessor((row) => row?.data?.network ?? row?.network, {
        cell: (info) => {
          return (
            <TextWithHighlight>
              {textWithDefault(info.getValue() === "Other Network" ? "In and Out Network": info.getValue())}
            </TextWithHighlight>
          )
        },
        header: "Network",
      }),
      columnHelper.accessor((row) => row?.data?.code ?? row?.code, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "ADA Code",
      }),
      columnHelper.accessor(
        (row) => row?.data?.effectiveDateFrom ?? row?.effectiveDateFrom,
        {
          // TODO: Add effective date from the subscriber data
          cell: (info) => (
            <TextWithHighlight>
              {textWithDefault(info.getValue() as string)}
            </TextWithHighlight>
          ),
          header: "Effective Date",
        }
      ),
      columnHelper.accessor((row) => row?.data?.planPeriod ?? row?.planPeriod, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Plan Period",
      }),
      columnHelper.accessor((row) => row?.data?.percent ?? row?.percent, {
        cell: (info) => {
          const percent = info.getValue()
          const insurancePercent = 100 - Number(percent)
          return(
            <TextWithHighlight>
              {textWithDefault(
                info.getValue() ? `${percent as string}% / ${insurancePercent}%` : ""
              )}
            </TextWithHighlight>
          )
        },
        header: "Percentage PAT% / INS%",
      }),
      columnHelper.accessor(
        (row) => row?.data?.waitingPeriodApplies ?? row?.waitingPeriodApplies,
        {
          cell: (info) => (
            <TextWithHighlight>
              {textWithDefault(info.getValue() as string)}
            </TextWithHighlight>
          ),
          header: "Waiting Period Applies",
        }
      ),
      columnHelper.accessor((row) => row?.data?.auth ?? row?.auth, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Auth",
      }),
      columnHelper.accessor(
        (row) => row?.data?.insuranceType ?? row?.insuranceType,
        {
          cell: (info) => (
            <TextWithHighlight>
              {textWithDefault(info.getValue() as string)}
            </TextWithHighlight>
          ),
          header: "Insurance Type",
        }
      ),
      columnHelper.accessor(
        (row) => row?.data?.coverageLevel ?? row?.coverageLevel,
        {
          cell: (info) => (
            <TextWithHighlight>
              {textWithDefault(info.getValue() as string)}
            </TextWithHighlight>
          ),
          header: "Coverage Level",
        }
      ),
      columnHelper.accessor(
        (row) =>
          row?.data?.planCoverageDescription ?? row?.planCoverageDescription,
        {
          cell: (info) => (
            <TextWithHighlight>
              {textWithDefault(info.getValue() as string)}
            </TextWithHighlight>
          ),
          header: "Plan Coverage",
        }
      ),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="gap-3 hstack">
                  <RouterLink
                    to={`active-coverage-edit${search}`}
                    state={{
                      activeCoverageId: info.row.original.id,
                    }}
                  >
                    <Button color="link" className={`rounded-circle p-0`}>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </Button>
                  </RouterLink>

                  <DeleteModal activeCoverageId={info.row.original.id} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode, search]);

  const table = useReactTable({
    columns: (columns as any) ?? defaultData,
    data: (activeCoverageList as any) ?? defaultData,
    debugTable: import.meta.env.DEV ? true : false,
    state: {
      columnVisibility,
      expanded,
    },
    onColumnVisibilityChange: setColumnVisibility,
    onExpandedChange: setExpanded,
    getSubRows: (row: any) => row?.activeCoverage,
    getRowCanExpand: (row) =>
      (row.original as any).data?.message ??
      (row.original as any).data?.activeCoverage
        ? true
        : false,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
  });

  const renderSubComponent = ({ row }: any) => (
    <div>{row.original?.data?.message}</div>
  );

  return (
    <>
      {isRefetching ? (
        <CommonLoader label="Active Coverage" />
      ) : (
        <Card className="mt-3">
          <CardBody>
            {import.meta.env.DEV ? (
              <ReactTableDevtools initialIsOpen table={table} />
            ) : null}

            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Active Coverage</h6>

                {editMode ? <AddActiveCoverageForm /> : null}
              </div>
            </CardTitle>

            <table className="table mb-0 table-hover">
              <thead>
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        colSpan={header.colSpan}
                        className="border-bottom"
                      >
                        {header.isPlaceholder ? null : (
                          <div
                            {...{
                              className: "hstack align-items-center",
                              style: header.column.getCanSort()
                                ? {
                                    cursor: "pointer",
                                    userSelect: "none",
                                  }
                                : undefined,
                              onClick: header.column.getToggleSortingHandler(),
                            }}
                          >
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </div>
                        )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>

              <tbody>
                {table.getRowModel().rows.length === 0 ? (
                  <tr>
                    <td colSpan={12}>There are no records to display</td>
                  </tr>
                ) : null}
                {table.getRowModel().rows.map((row) => (
                  <React.Fragment key={row.id}>
                    <tr>
                      {row.getVisibleCells().map((cell) => (
                        <td key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      ))}
                    </tr>

                    {(row.original.data?.message ?? row.original?.message) &&
                    row.getIsExpanded() ? (
                      <tr>
                        {/* 2nd row is a custom 1 cell row */}
                        <td colSpan={row.getVisibleCells().length}>
                          {renderSubComponent({ row })}
                        </td>
                      </tr>
                    ) : null}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>
      )}
    </>
  );
});

export const ActiveCoverageFormFields = () => {
  return (
    <>
      <Field name="serviceType" />
      <Field name="network" />
      <Field name="code" />
      <Field name="effectiveDateFrom" />
      <Field name="planPeriod" />
      <Field name="percent" />
      <Field name="waitingPeriodApplies" />
      <Field name="auth" />
      <Field name="insuranceType" />
      <Field name="coverageLevel" />
      <Field name="planCoverageDescription" />
      <Field name="message" type="textarea" />
    </>
  );
};

export const AddActiveCoverageForm = () => {
  const { state } = useLocation() as Location<Patient>;
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();

  const queryClient = useQueryClient();

  const create = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/createActiveCoverage`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const activeCoverageListCreate = useMutation({
    mutationKey: ["activeCoverage", "create"],
    mutationFn: create,
  });

  const methods = useForm<ActiveCoverageForm>({
    resolver: zodResolver(activeCoverageSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<ActiveCoverageForm> = async (data) => {
    try {
      await activeCoverageListCreate.mutateAsync({
        ...data,
        isScheduled: state?.isScheduled,
        patientId,
      });

      toast.success("Active Coverage added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["activeCoverage", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <div>
      <Button outline size="sm" color="primary" onClick={toggle}>
        <FontAwesomeIcon icon={faPlus} />
      </Button>

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Add Active Coverage
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <ActiveCoverageFormFields />

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EditActiveCoverageFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath:
      "eligibility/patient-benefit-information/:id/active-coverage-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<ActiveCoverageForm>({
    resolver: zodResolver(activeCoverageSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Active Coverage
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditActiveCoverageForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditActiveCoverageFormProps = {
  methods: UseFormReturn<ActiveCoverageForm>;
  toggle: () => void;
};

export const EditActiveCoverageForm = ({
  methods,
  toggle,
}: EditActiveCoverageFormProps) => {
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();

  const {
    state: { activeCoverageId },
  } = useLocation() as Location<{ activeCoverageId: string }>;

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/updateActiveCoverageById/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getById = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getActiveCoverageById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const activeCoverageUtils = useSuspenseQuery({
    queryKey: ["activeCoverage", "get", activeCoverageId],
    queryFn: getById(activeCoverageId),
  });

  const activeCoverageListUpdate = useMutation({
    mutationKey: ["activeCoverage", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    methods.reset(
      (activeCoverageUtils?.data as any)?.data?.[0]?.activeCoverage
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeCoverageUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<ActiveCoverageForm> = async (data) => {
    try {
      await activeCoverageListUpdate.mutateAsync({
        ...data,
        id: activeCoverageId,
      });

      toast.success("Active Coverage updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["activeCoverage", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <ActiveCoverageFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};

export type DeleteModalProps = {
  activeCoverageId: number;
};

export const DeleteModal = ({ activeCoverageId }: DeleteModalProps) => {
  const { id: patientId } = useParams() as { id: string };

  const [open, setOpen] = React.useState(false);

  const auth = useAuth();

  const toggle = () => setOpen(!open);

  const remove = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/deleteActiveCoverageById/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const eligibilityListRemove = useMutation({
    mutationKey: ["activeCoverage", "remove"],
    mutationFn: remove,
  });

  const queryClient = useQueryClient();

  const deleteRow = async () => {
    try {
      await eligibilityListRemove.mutateAsync(String(activeCoverageId));

      toast.success("Active Coverage deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["activeCoverage", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default ActiveCoverageTable;
