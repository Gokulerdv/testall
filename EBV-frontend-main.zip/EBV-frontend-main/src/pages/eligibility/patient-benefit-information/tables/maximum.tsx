/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCaretDown,
  faCaretRight,
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import {
  CellContext,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Form,
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import { TextWithHighlight } from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import Config from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { Patient } from "../../apis/patients-all";

const getAll = (search: string) => async (): Promise<any> => {
  const url = `${
    import.meta.env.VITE_API_HOST ?? ""
  }/eligibility/getAllMaximumfilter${search}`;

  // const url = `${
  //   import.meta.env.VITE_API_HOST ?? ""
  // }/eligibility/getAllMaximum/${patientId}`;

  const response = await (await fetch(url)).json();

  return [...(response.data ?? [])].map((data: any) => ({ ...data, data }));
};

const create = async (data: any): Promise<any> => {
  const url = `${
    import.meta.env.VITE_API_HOST ?? ""
  }/eligibility/createMaximum`;

  const response = await (
    await fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
  ).json();

  return response;
};

const remove = async (id: string): Promise<any> => {
  const auth = useAuth();
  const url = `${
    import.meta.env.VITE_API_HOST ?? ""
  }/eligibility/deleteMaximumById/${id}`;

  const response = await (
    await fetch(url, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    })
  ).json();

  return response;
};

const getById = (patientId: string) => async (): Promise<any> => {
  const url = `${
    import.meta.env.VITE_API_HOST ?? ""
  }/eligibility/getMaximumById/${patientId}`;

  const response = await (await fetch(url)).json();

  return response;
};

const maximumSchema = z.object({
  serviceType: z.string().optional(),
  code: z.string().optional(),
  planPeriod: z.string().optional(),
  frequency: z.string().optional(),
  ageRestriction: z.string().optional(),
  lastVisit: z.string().optional(),
  message: z.string().optional(),
});

export type MaximumForm = z.infer<typeof maximumSchema>;

const defaultData = [] as any[];

export const MaximumTable = React.memo(() => {
  const { id: patientId } = useParams() as { id: string };

  const [searchParams] = useSearchParams();

  const { state } = useLocation() as Location<Patient>;

  const { search } = useLocation();

  const eligibilityId =
    searchParams.get("pastHistory") === "undefined" ||
    searchParams.get("pastHistory") === "null"
      ? state.eligibilityId
      : searchParams.get("pastHistory");

  const { data: maximumList } = useSuspenseQuery({
    queryKey: ["maximum", "getAll", patientId, search],
    queryFn: getAll(
      eligibilityId
        ? search
          ? `${search}&patientId=${patientId}&eligibilityId=${eligibilityId}`
          : `?patientId=${patientId}&eligibilityId=${eligibilityId}`
        : search
        ? `${search}&patientId=${patientId}`
        : `?patientId=${patientId}`
    ),
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    queryClient.invalidateQueries({
      queryKey: ["maximum", "getAll"],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const editMode = searchParams.get("editMode") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<any>();

    const staticColumns = [
      {
        id: "expander",
        header: () => null,
        cell: ({ row }: CellContext<any, unknown>) => {
          return row.getCanExpand() ? (
            <Button
              color="link"
              className="p-0 text-black"
              {...{
                onClick: row.getToggleExpandedHandler(),
                style: {
                  cursor: "pointer",
                },
              }}
            >
              {row.getIsExpanded() ? (
                <FontAwesomeIcon icon={faCaretDown} />
              ) : (
                <FontAwesomeIcon icon={faCaretRight} />
              )}
            </Button>
          ) : null;
        },
      },
      columnHelper.accessor((row) => row?.data?.serviceType, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue())}
          </TextWithHighlight>
        ),
        header: "Service Type",
      }),
      columnHelper.accessor((row) => row?.data?.code, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "ADA Code",
      }),
      columnHelper.accessor((row) => row?.data?.planPeriod, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Plan Period",
      }),
      columnHelper.accessor((row) => row?.data?.frequency, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Frequency",
      }),
      columnHelper.accessor((row) => row?.data?.ageRestriction, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Age Restriction",
      }),
      columnHelper.accessor((row) => row?.data?.lastVisit, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Last Visit",
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="gap-3 hstack">
                  <RouterLink
                    to={`maximum-edit${search}`}
                    state={{
                      maximumId: info.row.original.id,
                    }}
                  >
                    <Button color="link" className={`rounded-circle p-0`}>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </Button>
                  </RouterLink>

                  <DeleteModal maximumId={info.row.original.id} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode, search]);

  const table = useReactTable({
    columns: (columns as any) ?? defaultData,
    data: maximumList as any,
    // TODO: Add the filters logic to the table filters
    // .filter((maximum: any) =>
    //   adaCodeFilter === "true" && maximum?.data?.code
    //     ? // TODO: Get the procedure code from eligibility
    //       "D0140, D0123".includes(maximum?.data?.code)
    //     : true
    // )
    // .filter((maximum: any) =>
    //   networkFilters.length > 0 && maximum?.network
    //     ? networkFilters.includes(maximum.network)
    //     : true
    // ) ?? defaultData,
    getRowCanExpand: (row) =>
      (row.original as any).data?.message ? true : false,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    debugTable: import.meta.env.DEV ? true : false,
  });

  const renderSubComponent = ({ row }: any) => (
    <div>{row.original?.data?.message}</div>
  );

  return (
    <Card className="mt-3">
      <CardBody>
        {import.meta.env.DEV ? (
          <ReactTableDevtools initialIsOpen table={table} />
        ) : null}

        <CardTitle tag="h6">
          <div className="hstack justify-content-between align-items-center">
            <h6>Maximum</h6>

            {editMode ? <AddMaximumForm /> : null}
          </div>
        </CardTitle>

        <table className="table mb-0 table-hover">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    className="border-bottom"
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        {...{
                          className: "hstack align-items-center",
                          style: header.column.getCanSort()
                            ? {
                                cursor: "pointer",
                                userSelect: "none",
                              }
                            : undefined,
                          onClick: header.column.getToggleSortingHandler(),
                        }}
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>

          <tbody>
            {table.getRowModel().rows.map((row) => (
              <React.Fragment key={row.id}>
                <tr>
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </td>
                  ))}
                </tr>

                {row.getIsExpanded() ? (
                  <tr>
                    {/* 2nd row is a custom 1 cell row */}
                    <td colSpan={row.getVisibleCells().length}>
                      {renderSubComponent({ row })}
                    </td>
                  </tr>
                ) : null}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </CardBody>
    </Card>
  );
});

export const MaximumFormFields = () => {
  return (
    <>
      <Field name="serviceType" />
      <Field name="code" />
      <Field name="planPeriod" />
      <Field name="frequency" />
      <Field name="ageRestriction" />
      <Field name="lastVisit" />
      <Field name="message" type="textarea" />
    </>
  );
};

export const AddMaximumForm = () => {
  const { id: patientId } = useParams() as { id: string };
  const { state } = useLocation() as Location<Patient>;
  const maximumListCreate = useMutation({
    mutationKey: ["maximum", "create"],
    mutationFn: create,
  });

  const queryClient = useQueryClient();

  const methods = useForm<MaximumForm>({
    resolver: zodResolver(maximumSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<MaximumForm> = async (data) => {
    try {
      await maximumListCreate.mutateAsync({
        ...data,
        isScheduled: state?.isScheduled,
        patientId,
      });

      toast.success("Maximum added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["maximum", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <div>
      <Button outline size="sm" color="primary" onClick={toggle}>
        <FontAwesomeIcon icon={faPlus} />
      </Button>

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Add Maximum
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <MaximumFormFields />

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EditMaximumFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id/maximum-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<MaximumForm>({
    resolver: zodResolver(maximumSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Maximum
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditMaximumForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditMaximumFormProps = {
  methods: UseFormReturn<MaximumForm>;
  toggle: () => void;
};

export const EditMaximumForm = ({ methods, toggle }: EditMaximumFormProps) => {
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();
  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/updateMaximumById/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };
  const {
    state: { maximumId },
  } = useLocation() as Location<{ maximumId: string }>;

  const maximumUtils = useSuspenseQuery({
    queryKey: ["maximum", "get", maximumId],
    queryFn: getById(maximumId),
  });

  const maximumListUpdate = useMutation({
    mutationKey: ["maximum", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    methods.reset((maximumUtils?.data as any)?.data);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [maximumUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<MaximumForm> = async (data) => {
    try {
      await maximumListUpdate.mutateAsync({
        ...data,
        id: maximumId,
      });

      toast.success("Maximum updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["maximum", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <MaximumFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};

export type DeleteModalProps = {
  maximumId: number;
};

export const DeleteModal = ({ maximumId }: DeleteModalProps) => {
  const { id: patientId } = useParams() as { id: string };

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const maximumListRemove = useMutation({
    mutationKey: ["maximum", "remove"],
    mutationFn: remove,
  });

  const queryClient = useQueryClient();

  const deleteRow = async () => {
    try {
      await maximumListRemove.mutateAsync(String(maximumId));

      toast.success("Maximum deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["maximum", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default MaximumTable;
