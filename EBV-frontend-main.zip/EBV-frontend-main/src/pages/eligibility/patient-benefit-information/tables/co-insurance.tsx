/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCaretDown,
  faCaretRight,
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import {
  CellContext,
  VisibilityState,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Form,
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import { TextWithHighlight } from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { Patient } from "../../apis/patients-all";
import CommonLoader from "../common-loader";

// TODO: TEST this after backend changes are fixed - Plan Period, Type and Message are not getting added or updated

const coInsuranceSchema = z.object({
  serviceType: z.string().optional().nullable(),
  code: z.string().optional().nullable(),
  planPeriod: z.string().optional().nullable(),
  network: z.string().optional().nullable(),
  coverageLevel: z.string().optional().nullable(),
  percent: z.string().optional().nullable(),
  amount: z.string().optional().nullable(),
  message: z.string().optional().nullable(),
  planCoverageDescription: z.string().optional().nullable(),
  insuranceType: z.string().optional().nullable(),
  type: z.string().optional().nullable(),
});

export type CoInsuranceForm = z.infer<typeof coInsuranceSchema>;

const defaultData = [] as any[];

const keyToColumnHeaderMapping = {
  serviceType: "Service Type",
  code: "ADA Code",
  planPeriod: "Plan Period",
  network: "Network",
  coverageLevel: "Coverage Level",
  percent: "Percentage",
  amount: "Amount",
  planCoverageDescription: "Plan Coverage",
  insuranceType: "Insurance Type",
  type: "Type",
} as Record<string, string>;

export const CoInsuranceTable = React.memo(() => {
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});

  const { id: patientId } = useParams() as { id: string };

  const { state } = useLocation() as Location<Patient>;

  const [searchParams] = useSearchParams();

  const eligibilityId =
    searchParams.get("pastHistory") === "undefined" ||
    searchParams.get("pastHistory") === "null"
      ? state.eligibilityId
      : searchParams.get("pastHistory");

  const { search } = useLocation();
  const auth = useAuth();

  const getAll = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAllcoinsfilter${search}`;

    // const url = `${
    //   import.meta.env.VITE_API_HOST ?? ""
    // }/eligibility/getallcoins/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      keyVisibility: response?.obj ?? {},
      data: [...(response.data ?? [])].map((data: any) => ({ ...data, data })),
    };
  };

  const {
    isRefetching,
    data: { data: coInsuranceList, keyVisibility },
  } = useSuspenseQuery({
    queryKey: ["coInsurance", "getAll", patientId, search],
    queryFn: getAll(
      eligibilityId
        ? search
          ? `${search}&patientId=${patientId}&eligibilityId=${eligibilityId}`
          : `?patientId=${patientId}&eligibilityId=${eligibilityId}`
        : search
        ? `${search}&patientId=${patientId}`
        : `?patientId=${patientId}`
    ),
  });

  React.useEffect(() => {
    setColumnVisibility(
      Object.keys(keyVisibility).reduce((acc, key) => {
        return {
          ...acc,
          [keyToColumnHeaderMapping[key]]: keyVisibility[key],
        };
      }, {})
    );
  }, [keyVisibility]);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    queryClient.invalidateQueries({
      queryKey: ["coInsurance", "getAll"],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const editMode = searchParams.get("editMode") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<any>();

    const staticColumns = [
      {
        id: "expander",
        header: () => null,
        cell: ({ row }: CellContext<any, unknown>) => {
          return row.getCanExpand() ? (
            <Button
              color="link"
              className="p-0 text-black"
              {...{
                onClick: row.getToggleExpandedHandler(),
                style: {
                  cursor: "pointer",
                },
              }}
            >
              {row.getIsExpanded() ? (
                <FontAwesomeIcon icon={faCaretDown} />
              ) : (
                <FontAwesomeIcon icon={faCaretRight} />
              )}
            </Button>
          ) : null;
        },
      },
      columnHelper.accessor((row) => row?.data?.serviceType, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue())}
          </TextWithHighlight>
        ),
        header: "Service Type",
      }),
      columnHelper.accessor((row) => row?.data?.code, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "ADA Code",
      }),
      columnHelper.accessor((row) => row?.data?.planPeriod, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Plan Period",
      }),
      columnHelper.accessor((row) => row?.data?.network, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() === "Other Network" ? "In and Out Network": info.getValue())}
          </TextWithHighlight>
        ),
        header: "Network",
      }),
      columnHelper.accessor((row) => row?.data?.coverageLevel, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Coverage Level",
      }),
      columnHelper.accessor((row) => row?.data?.percent, {
        cell: (info) => {
          const percent = info.getValue()
          const insurancePercent = 100 - Number(percent)
          return(
            <TextWithHighlight>
              {textWithDefault(
                info.getValue() ? `${percent as string}% / ${insurancePercent}%` : ""
              )}
            </TextWithHighlight>
          )
        },
        header: "Percentage PAT% / INS%",
      }),
      columnHelper.accessor((row) => row?.data?.amount, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Amount",
      }),
      columnHelper.accessor((row) => row?.data?.planCoverageDescription, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Plan Coverage",
      }),
      columnHelper.accessor((row) => row?.data?.insuranceType, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Insurance Type",
      }),
      columnHelper.accessor((row) => row?.data?.type, {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: "Type",
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="gap-3 hstack">
                  <RouterLink
                    to={`co-insurance-edit${search}`}
                    state={{
                      coInsuranceId: info.row.original.id,
                    }}
                  >
                    <Button color="link" className={`rounded-circle p-0`}>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </Button>
                  </RouterLink>

                  <DeleteModal coInsuranceId={info.row.original.id} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode, search]);

  const table = useReactTable({
    columns: (columns as any) ?? defaultData,
    data: (coInsuranceList as any) ?? defaultData,
    getRowCanExpand: (row) =>
      (row.original as any).data?.message ? true : false,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    debugTable: import.meta.env.DEV ? true : false,
    state: {
      columnVisibility,
    },
    onColumnVisibilityChange: setColumnVisibility,
  });

  const renderSubComponent = ({ row }: any) => (
    <div>{row.original?.data?.message}</div>
  );

  return (
    <>
      {isRefetching ? (
        <CommonLoader label="Co Insurance" />
      ) : (
        <Card className="mt-3">
          <CardBody>
            {import.meta.env.DEV ? (
              <ReactTableDevtools initialIsOpen table={table} />
            ) : null}

            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Co Insurance</h6>

                {editMode ? <AddCoInsuranceForm /> : null}
              </div>
            </CardTitle>

            <table className="table mb-0 table-hover">
              <thead>
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        colSpan={header.colSpan}
                        className="border-bottom"
                      >
                        {header.isPlaceholder ? null : (
                          <div
                            {...{
                              className: "hstack align-items-center",
                              style: header.column.getCanSort()
                                ? {
                                    cursor: "pointer",
                                    userSelect: "none",
                                  }
                                : undefined,
                              onClick: header.column.getToggleSortingHandler(),
                            }}
                          >
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </div>
                        )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>

              <tbody>
                {table.getRowModel().rows.length === 0 ? (
                  <tr>
                    <td colSpan={12}>There are no records to display</td>
                  </tr>
                ) : null}
                {table.getRowModel().rows.map((row) => (
                  <React.Fragment key={row.id}>
                    <tr>
                      {row.getVisibleCells().map((cell) => (
                        <td key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      ))}
                    </tr>

                    {row.getIsExpanded() ? (
                      <tr>
                        {/* 2nd row is a custom 1 cell row */}
                        <td colSpan={row.getVisibleCells().length}>
                          {renderSubComponent({ row })}
                        </td>
                      </tr>
                    ) : null}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>
      )}
    </>
  );
});

export const CoInsuranceFormFields = () => {
  return (
    <>
      <Field name="serviceType" />
      <Field name="code" />
      <Field name="planPeriod" />
      <Field name="network" />
      <Field name="coverageLevel" />
      <Field name="percent" />
      <Field name="amount" />
      <Field name="planCoverageDescription" />
      <Field name="insuranceType" />
      <Field name="type" />
      <Field name="message" type="textarea" />
    </>
  );
};

export const AddCoInsuranceForm = () => {
  const { id: patientId } = useParams() as { id: string };
  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const create = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/createcoins`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const coInsuranceListCreate = useMutation({
    mutationKey: ["coInsurance", "create"],
    mutationFn: create,
  });

  const queryClient = useQueryClient();

  const methods = useForm<CoInsuranceForm>({
    resolver: zodResolver(coInsuranceSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<CoInsuranceForm> = async (data) => {
    try {
      await coInsuranceListCreate.mutateAsync({
        ...data,
        isScheduled: state?.isScheduled,
        patientId,
      });

      toast.success("Co Insurance added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["coInsurance", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <div>
      <Button outline size="sm" color="primary" onClick={toggle}>
        <FontAwesomeIcon icon={faPlus} />
      </Button>

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Add Co Insurance
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <CoInsuranceFormFields />

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EditCoInsuranceFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id/co-insurance-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<CoInsuranceForm>({
    resolver: zodResolver(coInsuranceSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Co Insurance
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditCoInsuranceForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditCoInsuranceFormProps = {
  methods: UseFormReturn<CoInsuranceForm>;
  toggle: () => void;
};

export const EditCoInsuranceForm = ({
  methods,
  toggle,
}: EditCoInsuranceFormProps) => {
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();
  const {
    state: { coInsuranceId },
  } = useLocation() as Location<{ coInsuranceId: string }>;

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/updatecoinsbyid/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getById = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getcoinsbyid/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const coInsuranceUtils = useSuspenseQuery({
    queryKey: ["coInsurance", "get", coInsuranceId],
    queryFn: getById(coInsuranceId),
  });

  const coInsuranceListUpdate = useMutation({
    mutationKey: ["coInsurance", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    methods.reset((coInsuranceUtils?.data as any)?.data);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coInsuranceUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<CoInsuranceForm> = async (data) => {
    try {
      await coInsuranceListUpdate.mutateAsync({
        ...data,
        id: coInsuranceId,
      });

      toast.success("Co Insurance updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["coInsurance", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <CoInsuranceFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};

export type DeleteModalProps = {
  coInsuranceId: number;
};

export const DeleteModal = ({ coInsuranceId }: DeleteModalProps) => {
  const { id: patientId } = useParams() as { id: string };

  const [open, setOpen] = React.useState(false);

  const auth = useAuth();

  const toggle = () => setOpen(!open);

  const remove = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/deletecoinbyid/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const coInsuranceListRemove = useMutation({
    mutationKey: ["coInsurance", "remove"],
    mutationFn: remove,
  });

  const queryClient = useQueryClient();

  const deleteRow = async () => {
    try {
      await coInsuranceListRemove.mutateAsync(String(coInsuranceId));

      toast.success("Co Insurance deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["coInsurance", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default CoInsuranceTable;
