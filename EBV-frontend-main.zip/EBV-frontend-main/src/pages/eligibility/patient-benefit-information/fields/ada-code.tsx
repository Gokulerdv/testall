import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
} from "reactstrap";

export type AdaCodeFilterProps = InputProps & {
  help?: React.ReactNode;
  name: string;
};

export const AdaCodeSwitch = (props: AdaCodeFilterProps) => {
  const { control } = useFormContext();

  const key = props.name;

  return (
    <>
      <Controller
        key={key}
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <FormGroup switch>
              <Input
                {...field}
                id={key}
                type="switch"
                invalid={Boolean(fieldState.error?.message)}
                {...props}
              />
              {fieldState.error?.message ? (
                <FormFeedback>{fieldState.error.message}</FormFeedback>
              ) : null}
              {props.help ? <FormText>{props.help}</FormText> : null}
            </FormGroup>
          </>
        )}
      />
    </>
  );
};

export default AdaCodeSwitch;
