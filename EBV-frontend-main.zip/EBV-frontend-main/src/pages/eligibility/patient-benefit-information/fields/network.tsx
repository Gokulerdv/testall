import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";

export type NetworkProps = Omit<InputProps, "name"> & {
  help?: React.ReactNode;
  name: string[];
};

export const Network = ({ name, ...props }: NetworkProps) => {
  const { control } = useFormContext();

  const keys = name;

  return (
    <>
      {keys.map((key) => (
        <Controller
          key={key}
          name={key}
          control={control}
          render={({ field, fieldState }) => (
            <>
              <FormGroup check>
                <Label for={key} check>
                  {props.required ? (
                    <span className="text-danger">*&nbsp;</span>
                  ) : null}
                  {capitalCase(key)}
                </Label>

                <Input
                  {...field}
                  id={key}
                  type="checkbox"
                  invalid={Boolean(fieldState.error?.message)}
                  {...props}
                />
                {fieldState.error?.message ? (
                  <FormFeedback>{fieldState.error.message}</FormFeedback>
                ) : null}
                {props.help ? <FormText>{props.help}</FormText> : null}
              </FormGroup>
            </>
          )}
        />
      ))}
    </>
  );
};

export default Network;
