/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSuspenseQuery } from "@tanstack/react-query";
import { Controller, useFormContext } from "react-hook-form";
import { Location, useLocation, useParams } from "react-router-dom";
import { FormGroup, Input, InputProps, Label } from "reactstrap";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { dateFormat } from "../../../../utils/date-format";
import { Config } from "../../../../utils/headers-config";
import { Patient } from "../../apis/patients-all";

export type PastHistoryFilterProps = InputProps & {
  help?: React.ReactNode;
  name: string;
};

export const PastHistory = (props: PastHistoryFilterProps) => {
  const { state } = useLocation() as Location<Patient>;
  const { id: patientId } = useParams() as { id: string };
  const { control } = useFormContext();
  const key = "pastHistory";
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;

  const getSettings =
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (adminId: string) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/generalSettings/get/${adminId}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return response;
    };

  const get =
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (patientId: string, eligibilityId: string) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/eligibility/gethistory?patientId=${patientId}&currentEligibilityId=${eligibilityId}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return [...(response.data ?? [])].map((data: any) => ({ ...data, data }));
    };

  const { data: pastHistory } = useSuspenseQuery({
    queryKey: ["pastHistory", "get", patientId],
    queryFn: get(patientId, `${state.eligibilityId}`),
  });

  const { data: settings } = useSuspenseQuery({
    queryKey: ["generalSettings", "get", "adminId"],
    queryFn: getSettings(`${userId}`),
  });
  const isHistory: boolean = settings?.data?.ishistory;
  return (
    <>
      <Controller
        key={key}
        name={key}
        control={control}
        disabled={!isHistory}
        render={({ field }) => (
          <>
            <FormGroup switch className="p-0">
              <Label>Past Benefit History</Label>
              <Input {...field} id={key} type="select" {...props}>
                <option disabled selected>
                  Benefit Summary On
                </option>
                {pastHistory.map((history: any) => (
                  <option value={history.eligibilityId}>
                    {dateFormat(new Date(history.createdAt))}
                  </option>
                ))}
              </Input>
            </FormGroup>
          </>
        )}
      />
    </>
  );
};
