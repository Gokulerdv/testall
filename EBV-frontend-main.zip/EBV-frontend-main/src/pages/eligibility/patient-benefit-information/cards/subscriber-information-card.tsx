/* eslint-disable @typescript-eslint/no-explicit-any */
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Location,
  NavLink as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import TextWithHighlight from "../../../../components/text-with-highlight";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateFormat } from "../../../../utils/date-format";
import textWithDefault from "../../../../utils/text-with-default";

import { faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { toast } from "react-toastify";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";
import { Patient } from "../../apis/patients-all";

export const SubscriberInformationCard = () => {
  const { id: patientId } = useParams() as { id: string };

  const { state, search } = useLocation() as Location<Patient>;
  const [searchParams] = useSearchParams();
  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const auth = useAuth();

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const { data: patient } = useSuspenseQuery({
    queryKey: ["patient", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  return (
    <Card className="border-2 border-primary bg-primary-subtle">
      <CardBody>
        <Row>
          <Col xs={12} md={6} lg={5}>
            <Row className="g-3">
              <Col xs={12}>
                <h5 className="mb-3">Subscriber Information</h5>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">First Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.firstName ?? undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Last Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.lastName ?? undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">DOB</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.dateOfBirth
                          ? dateFormat(new Date(patient?.data?.dateOfBirth))
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Gender</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.gender ??
                          // eslint-disable-next-line @typescript-eslint/no-explicit-any
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Relationship</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.relationship)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">
                    Member ID/Medicaid ID
                  </Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.memberId ?? undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>

          <Col xs={12} md={6} lg={7}>
            <Row className="g-3">
              <Col xs={12}>
                <div className="hstack justify-content-between w-100">
                  <h5 className="mb-3">Coverage</h5>
                  <div className="d-flex align-items-center">
                    <h5 className="mb-0 mr-3 subscriber-span">
                      Primary Insurance
                    </h5>
                    <div style={{ marginLeft: "10px" }}>
                      {download || mode ? (
                        <Button
                          className="p-0 d-flex align-items-center justify-content-center"
                          color="link"
                          style={{
                            width: "60px",
                            height: "30px",
                            border: "1px solid",
                            padding: "0 5px",
                            position: "relative",
                            textDecoration: "none",
                          }}
                          disabled={download || mode ? true : false}
                        >
                          <span
                            style={{
                              fontSize: "10px",
                              whiteSpace: "nowrap",
                              display: "flex",
                              alignItems: "center",
                              // Align icon and text vertically
                            }}
                          >
                            <FontAwesomeIcon
                              icon={faPenToSquare}
                              style={{
                                fontSize: "10px",
                                marginRight: "5px",
                              }}
                            />
                            <b
                              style={{
                                fontSize: "12px",
                              }}
                            >
                              Edit
                            </b>
                          </span>
                        </Button>
                      ) : (
                        <RouterLink
                          to={`subscriberinformation-edit${search}`}
                          state={state}
                          className="text-decoration-none"
                        >
                          <Button
                            className="p-0 d-flex align-items-center justify-content-center"
                            color="link"
                            style={{
                              width: "60px",
                              height: "30px",
                              border: "1px solid",
                              padding: "0 5px",
                              position: "relative",
                              textDecoration: "none",
                            }}
                            disabled={download || mode ? true : false}
                          >
                            <span
                              style={{
                                fontSize: "10px",
                                whiteSpace: "nowrap",
                                display: "flex",
                                alignItems: "center",
                                // Align icon and text vertically
                              }}
                            >
                              <FontAwesomeIcon
                                icon={faPenToSquare}
                                style={{
                                  fontSize: "10px",
                                  marginRight: "5px",
                                }}
                              />
                              <b
                                style={{
                                  fontSize: "12px",
                                }}
                              >
                                Edit
                              </b>
                            </span>
                          </Button>
                        </RouterLink>
                      )}
                    </div>
                  </div>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Effective Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.effectiveDateFrom
                          ? dateFormat(
                              new Date(patient?.data?.effectiveDateFrom)
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">End Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.effectiveEndDate
                          ? dateFormat(
                              new Date(patient?.data?.effectiveEndDate)
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">statusflag</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.effectiveDateFrom ? "Active" : "Inactive"
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Coverage Type</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Insurance Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.insurancePayer ?? undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
          <Row />
        </Row>
      </CardBody>
    </Card>
  );
};

export default SubscriberInformationCard;

const subscriberinformationFormSchema = z.object({
  firstName: z.string({ required_error: `firstname is required.` }),
  lastName: z.string({ required_error: `lastname is required.` }),
  dateOfBirth: z.string({ required_error: `dob is required.` }),
  gender: z.string({ required_error: `gender is required.` }),
  relationship: z.string({ required_error: `relationship is required.` }),
  memberId: z.string({ required_error: `memberid is required.` }),
  effectiveDateFrom: z.string({ required_error: `effectivedate is required.` }),
  effectiveEndDate: z.string({
    required_error: `effectiveEndDate is required.`,
  }),
  statusflag: z.string({ required_error: `statusflag is required.` }),
  coveragetype: z
    .string({ required_error: `coveragetype is required.` })
    .optional(),
  insurancePayer: z.string({ required_error: `insurancename is required.` }),
});

export type subscriberinformationForm = z.infer<
  typeof subscriberinformationFormSchema
>;

export const SubscriberInformationFormFields = () => {
  return (
    <>
      <h4>Subscriber Information</h4>
      <Row>
        <Col xs={12} md={4}>
          <Field name="firstName" required />
        </Col>
        <Col xs={12} md={4}>
          <Field name="lastName" required />
        </Col>
        <Col xs={12} md={4}>
          <Field name="dateOfBirth" required />
        </Col>
      </Row>
      <Row>
        <Col xs={12} md={4}>
          <Field name="gender" required />
        </Col>
        <Col xs={12} md={4}>
          <Field name="relationship" required />
        </Col>
        <Col xs={12} md={4}>
          <Field name="memberId" required />
        </Col>
      </Row>

      <h4>Coverage</h4>
      <Row>
        <Col xs={12} md={4}>
          <Field name="effectiveDateFrom" required />
        </Col>
        <Col xs={12} md={4}>
          <Field name="effectiveEndDate" />
        </Col>
        <Col xs={12} md={4}>
          <Field name="statusflag" required />
        </Col>
      </Row>
      <Row>
        <Col xs={12} md={4}>
          <Field name="coveragetype" />
        </Col>
        <Col xs={12} md={4}>
          <Field name="insurancePayer" required />
        </Col>
      </Row>
    </>
  );
};

export const EditSubscriberInformationFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath:
      "eligibility/patient-benefit-information/:id/subscriberinformation-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<subscriberinformationForm>({
    resolver: zodResolver(subscriberinformationFormSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Subscriber Information
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditSubscriberInformationForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditSubscriberInformationFormProps = {
  methods: UseFormReturn<subscriberinformationForm>;
  toggle: () => void;
};

export const EditSubscriberInformationForm = ({
  methods,
  toggle,
}: EditSubscriberInformationFormProps) => {
  const { id: patientId } = useParams() as { id: string };

  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();
  // const subscriberinformationUtils = useSuspenseQuery({
  //   queryKey: ["subscriberinformation", "get"],
  //   queryFn: getById(miscellaneousId),
  // });

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const update = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/update`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const { data: patient } = useSuspenseQuery({
    queryKey: ["patient", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  const subscriberinformationListUpdate = useMutation({
    mutationKey: ["subscriberinformation", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const data = patient?.data;
    methods.reset({
      firstName: data.firstName,
      lastName: data.lastName,
      dateOfBirth: data.dateOfBirth,
      gender: data.gender,
      relationship: data.relationship,
      memberId: data.memberId,
      effectiveDateFrom: data.effectiveDateFrom,
      effectiveEndDate: data.effectiveEndDate,
      statusflag: data.statusflag,
      coveragetype: data.coverageType,
      insurancePayer: data.insurancePayer,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patient.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<subscriberinformationForm> = async (data) => {
    try {
      await subscriberinformationListUpdate.mutateAsync({
        uniqueId: state.uniqueId,
        isScheduled: state.isScheduled,
        firstName: data.firstName,
        lastName: data.lastName,
        dateOfBirth: data.dateOfBirth,
        gender: data.gender,
        relationship: data.relationship,
        memberId: data.memberId,
        effectiveDateFrom: data.effectiveDateFrom,
        effectiveEndDate: data.effectiveEndDate,
        statusflag: data.statusflag,
        insurancePayer: data.insurancePayer,
      });

      toast.success("Subscriber Information updated successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patient", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <SubscriberInformationFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};
