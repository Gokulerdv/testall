/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Location,
  // useSearchParams,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Col,
  Form,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";
import { Patient } from "../../apis/patients-all";

export const Miscellaneous = () => {
  const { id: patientId } = useParams() as { id: string };
  const { search, state } = useLocation();
  const [searchParams] = useSearchParams();
  const auth = useAuth();

  const get =
    (patientId: string, eligibilityId: string) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/eligibility/miscellaneous/${patientId}?eligibilityId=${eligibilityId}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return [...(response.data ?? [])].map((data: any) => ({ ...data, data }));
    };

  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const eligibilityId: any = state.eligibilityId;
  const miscellaneous = useSuspenseQuery({
    queryKey: ["miscellaneous", "getAll", patientId],
    queryFn: get(patientId, eligibilityId),
  });

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          <h5 className="mb-3">Miscellaneous</h5>
          <div className="hstack gap-3 align-items-baseline">
            <p className="fw-bold mb-4">Caveat Question</p>

            <AddMiscellaneous />
          </div>
          <Row className="g-3">
            {[
              ...miscellaneous.data.map(
                (miscellaneous: any) => miscellaneous?.data
              ),
            ].map((question) => (
              <Col xs={12} md={6} key={question.question}>
                <Card>
                  <CardHeader className="bg-transparent hstack justify-content-between">
                    <p className="fw-bold mb-0 mt-1">Q. {question.question}</p>
                    <div className="gap-3">
                      {mode || download ? (
                        <Button
                          color="link"
                          disabled
                          className={`rounded-circle p-0 me-2`}
                        >
                          <FontAwesomeIcon icon={faPenToSquare} />
                        </Button>
                      ) : (
                        <RouterLink
                          to={`miscellaneous-edit${search}`}
                          state={{
                            ...state,
                            miscellaneousId: question.id,
                          }}
                        >
                          <Button
                            color="link"
                            className={`rounded-circle p-0 me-2`}
                          >
                            <FontAwesomeIcon icon={faPenToSquare} />
                          </Button>
                        </RouterLink>
                      )}

                      {question?.id &&
                        (mode || download ? (
                          <Button
                            color="link"
                            className={`rounded-circle p-0`}
                            disabled
                          >
                            <FontAwesomeIcon icon={faTrash} />
                          </Button>
                        ) : (
                          <DeleteModal miscellaneousId={question?.id} />
                        ))}
                    </div>
                  </CardHeader>
                  <CardBody>A: {question.answer}</CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        </CardBody>
      </Card>
    </>
  );
};

const miscellaneousFormSchema = z.object({
  question: z.string({ required_error: `Question is required.` }),
  answer: z.string({ required_error: `Answer is required.` }),
});

export type MiscellaneousForm = z.infer<typeof miscellaneousFormSchema>;

export const MiscellaneousFormFields = () => {
  return (
    <>
      <Field name="question" required />
      <Field name="answer" type="textarea" required />
    </>
  );
};

export const AddMiscellaneous = () => {
  const { id: patientId } = useParams() as { id: string };
  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const create = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/miscellaneous`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const miscellaneousListCreate = useMutation({
    mutationKey: ["miscellaneous", "create"],
    mutationFn: create,
  });

  const queryClient = useQueryClient();

  const [searchParams] = useSearchParams();

  const download = searchParams.get("download");
  const mode = searchParams.get("mode");

  const methods = useForm<MiscellaneousForm>({
    resolver: zodResolver(miscellaneousFormSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<MiscellaneousForm> = async (data) => {
    const isScheduled = state.isScheduled;

    try {
      await miscellaneousListCreate.mutateAsync({
        ...data,
        patientId,
        isScheduled,
        eligibilityId: state.eligibilityId,
      });

      toast.success("Miscellaneous added successfully");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["miscellaneous", "getAll"],
      });
      toggle();
    }
  };

  return (
    <div>
      <Button
        color="primary"
        style={{ borderRadius: 40 }}
        onClick={toggle}
        disabled={Boolean(download || mode)}
      >
        <FontAwesomeIcon icon={faPlus} className="text-white" />
      </Button>

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Patient Benefit Information
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack gap-3">
                <MiscellaneousFormFields />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary">
                    Cancel
                  </Button>

                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EditMiscellaneousFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id/miscellaneous-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<MiscellaneousForm>({
    resolver: zodResolver(miscellaneousFormSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Miscellaneous
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditMiscellaneousForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditMiscellaneousFormProps = {
  methods: UseFormReturn<MiscellaneousForm>;
  toggle: () => void;
};

export const EditMiscellaneousForm = ({
  methods,
  toggle,
}: EditMiscellaneousFormProps) => {
  const { id: patientId } = useParams() as { id: string };

  const {
    state: { miscellaneousId },
  } = useLocation() as Location<{ miscellaneousId: string }>;

  const auth = useAuth();

  const getById = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/miscellaneous/getbyid/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/miscellaneous/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const miscellaneousUtils = useSuspenseQuery({
    queryKey: ["miscellaneous", "get", miscellaneousId],
    queryFn: getById(miscellaneousId),
  });

  const miscellaneousListUpdate = useMutation({
    mutationKey: ["miscellaneous", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    methods.reset((miscellaneousUtils?.data as any)?.data);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [miscellaneousUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<MiscellaneousForm> = async (data) => {
    try {
      await miscellaneousListUpdate.mutateAsync({
        ...data,
        id: miscellaneousId,
      });

      toast.success("Miscellaneous updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["miscellaneous", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <MiscellaneousFormFields />

          <div className="hstack gap-2 ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};

export type DeleteModalProps = {
  miscellaneousId: number;
};

export const DeleteModal = ({ miscellaneousId }: DeleteModalProps) => {
  const { id: patientId } = useParams() as { id: string };

  const [open, setOpen] = React.useState(false);

  const auth = useAuth();

  const remove = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/miscellaneous/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const toggle = () => setOpen(!open);

  const miscellaneousListRemove = useMutation({
    mutationKey: ["miscellaneous", "remove"],
    mutationFn: remove,
  });

  const queryClient = useQueryClient();

  const deleteRow = async () => {
    try {
      await miscellaneousListRemove.mutateAsync(String(miscellaneousId));

      toast.success("Miscellaneous deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["miscellaneous", "getAll", patientId],
      });
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default AddMiscellaneous;
