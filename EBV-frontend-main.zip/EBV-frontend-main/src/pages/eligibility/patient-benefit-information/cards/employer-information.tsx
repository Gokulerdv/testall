/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Button,
  Card,
  Col,
  Form,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";

import { faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import { z } from "zod";
import { Field } from "../../../../components/field";
import TextWithHighlight from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { PatientsAddBody } from "../../apis/patients-add";
import { Patient } from "../../apis/patients-all";

export type EmployerInformationEditBody = Partial<PatientsAddBody> & {
  uniqueId?: string;
  EmpName?: string;
  empenrollmentstatus?: string;
  empAddress?: string;
  empAddress2?: string;
  empState?: string;
  empCity?: string;
  empZip?: string;
  empWirelessPhone?: string;
  empWebSite?: string;
  isScheduled?: boolean;
};

const employerInformationFormSchema = z.object({
  employerName: z.string().optional(),
  enrollmentStatus: z.string().optional(),
  addressLine1: z.string().optional(),
  addressLine2: z.string().optional(),
  state: z.string().optional(),
  city: z.string().optional(),
  zipCode: z.string().optional(),
  insuranceLink: z.string().optional(),
  phoneNumber: z.string().optional(),
});

export type EmployerInformationForm = z.infer<
  typeof employerInformationFormSchema
>;

export const EmployerInformationFormFields = () => {
  return (
    <>
      <Row className="mt-3">
        <Col xs={6}>
          <Field name="employerName" />
        </Col>
        <Col>
          <Field name="enrollmentStatus" />
        </Col>
      </Row>
      <Row>
        <Col xs={12}>
          <h6 className="mb-4 fw-bold">Contact Details</h6>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="addressLine1" />
          </div>
        </Col>
        <Col xs={12} md={6}>
          <div>
            <Field name="addressLine2" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="state" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="city" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="zipCode" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="insuranceLink" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="phoneNumber" />
          </div>
        </Col>
      </Row>
    </>
  );
};

export const EmployerInformation = () => {
  const { id: patientId } = useParams() as { id: string };

  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const { data: patient } = useSuspenseQuery({
    queryKey: ["getPatient", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  return (
    <>
      <Card className="p-4 mt-3">
        <Row>
          <Col xs={3}>
            <h6 className="mb-4 fw-bold">Employer Information</h6>
          </Col>
          <Col xs={9}>
            <RouterLink
              to={`employer-information-edit`}
              state={{
                ...state,
              }}
            >
              <div className="gap-2 hstack justify-content-start ">
                <Button color="link" className={`rounded-circle p-0`}>
                  <FontAwesomeIcon icon={faPenToSquare} />
                </Button>
              </div>
            </RouterLink>
          </Col>
          <Col xs={12}>
            <Row>
              <Col xs={12} md={6}>
                <Row>
                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Employer Name
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.EmpName)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Enrollment Status
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empenrollmentstatus)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Employer Identification Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.employerId)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Employee Identification Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.employeeId)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>
                </Row>
              </Col>

              <Col xs={12} md={6}>
                <Row>
                  <Col xs={12}>
                    <h6 className="mb-4 fw-bold">Contact Details</h6>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Address Line 1
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empAddress)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">City</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empCity)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Address Line 2
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empAddress2)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">Zip Code</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empZip)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">State</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empState)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Phone Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(patient?.data?.empWirelessPhone)}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">Website</Label>
                      <p>
                        <a href="#">
                          <TextWithHighlight>
                            {textWithDefault(patient?.data?.empWebSite)}
                          </TextWithHighlight>
                        </a>
                      </p>
                    </div>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Col>
        </Row>
      </Card>
    </>
  );
};

export default EmployerInformation;

export const EditEmployerInformationFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath:
      "eligibility/patient-benefit-information/:id/employer-information-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<EmployerInformationForm>({
    resolver: zodResolver(employerInformationFormSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Employer Information
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditEmployerInformationForm methods={methods} toggle={toggle} />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditEmployerInformationFormProps = {
  methods: UseFormReturn<EmployerInformationForm>;
  toggle: () => void;
};

export const EditEmployerInformationForm = ({
  methods,
  toggle,
}: EditEmployerInformationFormProps) => {
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();

  const { state } = useLocation() as Location<Patient>;

  const update = async (data: EmployerInformationEditBody) => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/update`;

    return await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const employerInformationUtils = useSuspenseQuery({
    queryKey: ["getPatient", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  const employerInformationListUpdate = useMutation({
    mutationKey: ["employerInformation", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const data = employerInformationUtils.data?.data;

    methods.reset({
      employerName: data.EmpName,
      enrollmentStatus: data.empenrollmentstatus,
      addressLine1: data.empAddress,
      addressLine2: data.empAddress2,
      city: data.empCity,
      state: data.empState,
      zipCode: data.empZip,
      insuranceLink: data.empWebSite,
      phoneNumber: data.empWirelessPhone,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employerInformationUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<EmployerInformationForm> = async (data) => {
    try {
      await employerInformationListUpdate.mutateAsync({
        uniqueId: state.uniqueId,
        isScheduled: state.isScheduled,
        EmpName: data.employerName,
        empenrollmentstatus: data.enrollmentStatus,
        empAddress: data.addressLine1,
        empAddress2: data.addressLine2,
        empCity: data.city,
        empState: data.state,
        empZip: data.zipCode,
        empWebSite: data.insuranceLink,
        empWirelessPhone: data.phoneNumber,
      });

      toast.success("Employer Information updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["getPatient", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <EmployerInformationFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};
