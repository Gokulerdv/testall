/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSuspenseQuery } from "@tanstack/react-query";
import {
  Location,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { Badge, Button, Card, CardBody, Col, Row } from "reactstrap";
import TextWithHighlight from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { dateFormat } from "../../../../utils/date-format";
import { getRelativeTime } from "../../../../utils/get-relative-time";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { Patient } from "../../apis/patients-all";

export const InsightsCards = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { id: patientId } = useParams() as { id: string };
  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const getAllDeductible = (patientId: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAllDeductiblefilter?patientId=${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      keyVisibility: response?.obj ?? {},
      data: [...(response.data ?? [])].map((data: any) => ({ ...data, data })),
    };
  };

  const getAllLimitation = (patientId: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getAllLimitationfilter?patientId=${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      keyVisibility: response?.obj ?? {},
      data: [...(response.data ?? [])].map((data: any) => ({ ...data, data })),
    };
  };

  // const { data: subscriber } = useSuspenseQuery({
  //   queryKey: ["dxcSubscriber", patientId],
  //   queryFn: getSubscriber(patientId)
  // });

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const { data: patient } = useSuspenseQuery({
    queryKey: ["patient", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  const {
    data: { data: deductibleList },
  } = useSuspenseQuery({
    queryKey: ["deductible", "getAll", patientId],
    queryFn: getAllDeductible(`${patientId}`),
  });

  const {
    data: { data: limitationList },
  } = useSuspenseQuery({
    queryKey: ["limitation", "getAll", patientId],
    queryFn: getAllLimitation(`${patientId}`),
  });

  const deductibleRemainingFiltered = deductibleList.filter(
    (deductible: any) => deductible.planPeriod === "Remaining"
  );

  const deductibleNonRemainingFiltered = deductibleList.filter(
    (deductible: any) =>
      deductible.planPeriod !== "Remaining" && deductible.planPeriod !== null
  );

  const deductibleRemainingNumerator =
    deductibleRemainingFiltered.reduce(
      (acc: any, deductible: any) => acc.add(deductible?.amount as any),
      new Set<string>()
    ).size === 1
      ? `$${deductibleRemainingFiltered[0].amount}`
      : "Varies";

  const deductibleRemainingDenominator =
    deductibleNonRemainingFiltered.reduce(
      (acc: any, deductible: any) => acc.add(deductible?.amount as any),
      new Set<string>()
    ).size === 1
      ? `$${deductibleNonRemainingFiltered[0].amount}`
      : "Varies";

  const limitationRemainingFiltered = limitationList.filter(
    (limitation: any) => limitation.planPeriod === "Remaining"
  );
  const limitationNonRemainingFiltered = limitationList.filter(
    (limitation: any) => limitation.planPeriod !== "Remaining"
  );

  const limitaitonRemainingNumerator =
    limitationRemainingFiltered.reduce(
      (acc: any, limitation: any) => acc.add(limitation?.amount as any),
      new Set<string>()
    ).size === 1
      ? `$${limitationRemainingFiltered[0].amount}`
      : "Varies";

  const limitationRemainingDenominator =
    limitationNonRemainingFiltered.reduce(
      (acc: any, limitation: any) => acc.add(limitation?.amount as any),
      new Set<string>()
    ).size === 1
      ? `$${limitationNonRemainingFiltered[0].amount}`
      : "Varies";

  return (
    <Row lg={2} className="g-3">
      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Dental Coverage</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <Badge
                  className={`border-1 ${
                    patient?.data?.effectiveDateFrom
                      ? "bg-success-subtle border-success text-success"
                      : "bg-danger-subtle border-danger text-danger"
                  }`}
                  style={{ border: "1px solid" }}
                  pill
                >
                  <TextWithHighlight>
                    {textWithDefault(
                      patient?.data?.effectiveDateFrom ? "Active" : "Inactive"
                    )}
                  </TextWithHighlight>
                </Badge>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Remaining Benefits</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <h5 className="fw-semibold">
                  {limitaitonRemainingNumerator !== "Varies" ? (
                    <>
                      <TextWithHighlight>
                        {limitaitonRemainingNumerator}
                      </TextWithHighlight>
                      |
                    </>
                  ) : limitaitonRemainingNumerator === null ? (
                    limitaitonRemainingNumerator
                  ) : (
                    <>
                      <Button
                        color="link"
                        className="p-0"
                        disabled={Boolean(download || mode)}
                        onClick={() => {
                          setSearchParams(
                            {
                              ...Array.from(searchParams.entries()).reduce(
                                (acc, [key, value]) => {
                                  return { ...acc, [key]: value };
                                },
                                {}
                              ),
                              tabId: "6",
                              tableFilter: "",
                            },
                            { state }
                          );
                        }}
                      >
                        <TextWithHighlight>Varies</TextWithHighlight>
                      </Button>
                      |
                    </>
                  )}
                  <h6 className="d-inline text-secondary">
                    {limitationRemainingDenominator !== "Varies" ? (
                      <>
                        <TextWithHighlight>
                          {limitationRemainingDenominator}
                        </TextWithHighlight>
                        |
                      </>
                    ) : limitationRemainingDenominator === null ? (
                      limitationRemainingDenominator
                    ) : (
                      <>
                        <Button
                          color="link"
                          className="p-0"
                          disabled={Boolean(download || mode)}
                          onClick={() => {
                            setSearchParams(
                              {
                                ...Array.from(searchParams.entries()).reduce(
                                  (acc, [key, value]) => {
                                    return { ...acc, [key]: value };
                                  },
                                  {}
                                ),
                                tabId: "6",
                                tableFilter: "!",
                              },
                              { state }
                            );
                          }}
                        >
                          <TextWithHighlight>Varies</TextWithHighlight>
                        </Button>
                      </>
                    )}
                  </h6>
                </h5>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Last Verified</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <p className="mb-0">
                  <TextWithHighlight>
                    {textWithDefault(
                      patient?.data?.lastVerified
                        ? dateFormat(new Date(patient?.data?.lastVerified))
                        : undefined
                    )}
                  </TextWithHighlight>
                </p>
                <p className="mb-0 fw-light text-secondary">
                  <TextWithHighlight>
                    {textWithDefault(
                      patient?.data?.lastVerified
                        ? getRelativeTime(
                            new Date(patient?.data?.lastVerified).getTime()
                          )
                        : undefined
                    )}
                  </TextWithHighlight>
                </p>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Deductible Remaining</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <h5 className="fw-semibold">
                  {deductibleRemainingNumerator !== "Varies" ? (
                    <>
                      <TextWithHighlight>
                        {deductibleRemainingNumerator}
                      </TextWithHighlight>
                      |
                    </>
                  ) : deductibleRemainingNumerator === null ? (
                    deductibleRemainingNumerator
                  ) : (
                    <>
                      <Button
                        color="link"
                        className="p-0"
                        disabled={Boolean(download || mode)}
                        onClick={() => {
                          setSearchParams(
                            {
                              ...Array.from(searchParams.entries()).reduce(
                                (acc, [key, value]) => {
                                  return { ...acc, [key]: value };
                                },
                                {}
                              ),
                              tabId: "5",
                              tableFilter: "Remaining",
                            },
                            { state }
                          );
                        }}
                      >
                        <TextWithHighlight>Varies</TextWithHighlight>
                      </Button>
                      |
                    </>
                  )}
                  <h6 className="d-inline text-secondary">
                    {deductibleRemainingDenominator !== "Varies" ? (
                      <>
                        <TextWithHighlight>
                          {deductibleRemainingDenominator}
                        </TextWithHighlight>
                        |
                      </>
                    ) : deductibleRemainingDenominator === null ? (
                      deductibleRemainingDenominator
                    ) : (
                      <>
                        <Button
                          color="link"
                          className="p-0"
                          disabled={Boolean(download || mode)}
                          onClick={() => {
                            setSearchParams(
                              {
                                ...Array.from(searchParams.entries()).reduce(
                                  (acc, [key, value]) => {
                                    return { ...acc, [key]: value };
                                  },
                                  {}
                                ),
                                tabId: "5",
                                tableFilter: "!Remaining",
                              },
                              { state }
                            );
                          }}
                        >
                          <TextWithHighlight>Varies</TextWithHighlight>
                        </Button>
                      </>
                    )}
                  </h6>
                </h5>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>
    </Row>
  );
};

export default InsightsCards;
