/* eslint-disable @typescript-eslint/no-explicit-any */
import { faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import {
  FormProvider,
  SubmitHandler,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import {
  Location,
  Link as RouterLink,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  Col,
  Form,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import { Field } from "../../../../components/field";
import TextWithHighlight from "../../../../components/text-with-highlight";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../../shared/hooks/use-dialog-with-form-reset";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateFormat } from "../../../../utils/date-format";
import { Config } from "../../../../utils/headers-config";
import textWithDefault from "../../../../utils/text-with-default";
import { PatientsAddBody } from "../../apis/patients-add";
import { Patient } from "../../apis/patients-all";
import { relationshipTypes as relationshipList } from "../../form/fields/relationship";

export type PatientAndPayerInformationEditBody = Partial<PatientsAddBody> & {
  uniqueId?: string;
  isScheduled?: boolean;
  effectiveDateFrom?: string;
  effectiveEndDate?: string;
  status?: string;
  Address?: string;
  Address2?: string;
  State?: string;
  City?: string;
  Zip?: string;
};

const patientAndPayerInformationFormSchema = z.object({
  effectiveDate: z.string().optional(),
  endDate: z.string().optional(),
  status: z.string().optional(),
  address1: z.string().optional(),
  address2: z.string().optional(),
  state: z.string().optional(),
  city: z.string().optional(),
  zipCode: z.string().optional(),
});

export type PatientAndPayerInformationForm = z.infer<
  typeof patientAndPayerInformationFormSchema
>;

export const PatientAndPayerInformationFormFields = () => {
  return (
    <>
      <Row className="mt-3">
        <Col xs={12}>
          <h6 className="mb-4 fw-bold">Coverage</h6>
        </Col>
        <Row>
          <Col xs={6}>
            <Field name="effectiveDate" />
          </Col>
        </Row>
        <Row>
          <Col xs={6}>
            <Field name="endDate" />
          </Col>
        </Row>
        <Row>
          <Col xs={6}>
            <Field name="status" />
          </Col>
        </Row>
      </Row>
      <Row>
        <Col xs={12}>
          <h6 className="mb-4 fw-bold">Contact Details</h6>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="address1" />
          </div>
        </Col>
        <Col xs={12} md={6}>
          <div>
            <Field name="address2" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="state" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="city" />
          </div>
        </Col>

        <Col xs={12} md={6}>
          <div>
            <Field name="zipCode" />
          </div>
        </Col>
      </Row>
    </>
  );
};

export const PatientAndPayerInformation = () => {
  const { state } = useLocation() as Location<Patient>;
  const [searchParams] = useSearchParams();
  const auth = useAuth();

  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const { id: patientId } = useParams() as { id: string };

  const getDxcPatient = (patientId: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/dxcPatient/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getSubscriber = (patientId: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/dxcSubscriber/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getPayer = (patientId: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/dxcPayer/${patientId}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const { data: dxcPatient } = useSuspenseQuery({
    queryKey: ["dxcPatient", patientId],
    queryFn: getDxcPatient(patientId),
  });

  const { data: payer } = useSuspenseQuery({
    queryKey: ["dxcPayer", patientId],
    queryFn: getPayer(patientId),
  });

  const { data: subscriber } = useSuspenseQuery({
    queryKey: ["dxcSubscriber", patientId],
    queryFn: getSubscriber(patientId),
  });

  const { data: patient } = useSuspenseQuery({
    queryKey: ["getPatient", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  return (
    <>
      <Card className="p-4 mt-3">
        <Row>
          <Col xs={12} md={4} lg={2} className="me-5">
            <h6 className="mb-4 fw-bold">Patient Information</h6>
          </Col>
        </Row>

        <Row>
          <Col>
            <Row>
              <h6 className="mb-3 fw-medium ">Subscriber</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">First Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (subscriber as any)?.data?.firstName ??
                          patient?.data?.firstName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Last Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (subscriber as any)?.data?.lastName ??
                          patient?.lastName ??
                          patient?.lastName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">DOB</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (subscriber as any)?.data?.dateOfBirth ??
                          patient?.dateOfBirth ??
                          patient?.dateOfBirth
                          ? dateFormat(
                              new Date(
                                (subscriber as any)?.data?.dateOfBirth ??
                                  patient?.dateOfBirth ??
                                  patient?.dateOfBirth
                              )
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Gender</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (subscriber as any)?.data?.gender ??
                          // eslint-disable-next-line @typescript-eslint/no-explicit-any
                          (patient as any)?.data?.gender ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Relationship</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        dxcPatient?.data?.relationship ??
                          relationshipList.find(
                            (relationship) =>
                              relationship.value === patient?.data?.relationship
                          )?.label ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">
                    Member ID/Medicaid ID
                  </Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (subscriber as any)?.data?.plan?.subscriberId ??
                          patient.memberId ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>

          <Col>
            <Row>
              <Col xs={3}>
                <h6 className="mb-3 fw-medium ">Address</h6>
              </Col>
              <Col>
                {download || mode ? (
                  <Button
                    color="link"
                    className={`rounded-circle p-0`}
                    disabled
                  >
                    <FontAwesomeIcon icon={faPenToSquare} />
                  </Button>
                ) : (
                  <RouterLink
                    to={`patient-and-payer-information-edit`}
                    state={{
                      ...state,
                    }}
                  >
                    <div className="gap-2 hstack justify-content-start ">
                      <Button color="link" className={`rounded-circle p-0`}>
                        <FontAwesomeIcon icon={faPenToSquare} />
                      </Button>
                    </div>
                  </RouterLink>
                )}
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">City</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.City ?? undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">State</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.State ?? undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Address</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.Address)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Zip Code</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(patient?.data?.Zip)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Col>
              <div>
                <Label className="mb-0 text-secondary">Address 2</Label>
                <p>
                  <TextWithHighlight>
                    {textWithDefault(patient?.data?.Address2)}
                  </TextWithHighlight>
                </p>
              </div>
            </Col>
          </Col>
        </Row>

        <hr />

        <Row>
          <Col xs={12} md={4} lg={6}>
            <Row>
              <h6 className="mb-3 fw-medium">Coverage</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Effective Date</Label>
                  <p>
                    {textWithDefault(
                      patient?.data?.effectiveDateFrom
                        ? dateFormat(new Date(patient?.data?.effectiveDateFrom))
                        : undefined
                    )}
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">End Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.effectiveEndDate
                          ? dateFormat(
                              new Date(patient?.data?.effectiveEndDate)
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Status</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        patient?.data?.effectiveDateFrom ? "Active" : "Inactive"
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>

        <Row>
          <Col xs={12} md={4} lg={6}>
            <Row>
              <h6 className="mb-3 fw-medium ">Payer</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">ID</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (payer as any)?.data?.payerId ??
                          patient?.patient?.insurancePayer ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (payer as any)?.data?.name ??
                          patient?.insurancePayer ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>

        <hr />

        <Row>
          <Col xs={12} md={4} lg={6}>
            <Row>
              <h6 className="mb-3 fw-medium ">Plan</h6>
            </Row>

            <Row>
              <h6 className="fw-medium">Basic</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Group Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (dxcPatient as any)?.data?.plan?.groupName ??
                          (patient as any)?.data?.plan?.groupName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Effective Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (subscriber as any)?.data?.plan?.effectiveDateFrom
                          ? dateFormat(
                              new Date(
                                (
                                  subscriber as any
                                )?.data?.plan?.effectiveDateFrom
                              )
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Group Number</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        (dxcPatient as any)?.data?.plan?.groupNumber ??
                          patient.groupId ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">
                    Req Participation
                  </Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </Card>
    </>
  );
};

export default PatientAndPayerInformation;

export const EditPatiendAndPayerInformationFormDrawer = React.memo(() => {
  const drawer = useDrawerFromLocation({
    matchPath:
      "eligibility/patient-benefit-information/:id/patient-and-payer-information-edit",
    togglePath: "../..",
    historyPopInstead: true,
  });

  const methods = useForm<PatientAndPayerInformationForm>({
    resolver: zodResolver(patientAndPayerInformationFormSchema),
    defaultValues: {},
  });

  const { open, toggle } = useDialogWithFormReset(methods, drawer);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit Patient And Payer Information
        </OffcanvasHeader>

        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EditPatientAndPayerInformationForm
              methods={methods}
              toggle={toggle}
            />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

export type EditPatientAndPayerInformationFormProps = {
  methods: UseFormReturn<PatientAndPayerInformationForm>;
  toggle: () => void;
};

export const EditPatientAndPayerInformationForm = ({
  methods,
  toggle,
}: EditPatientAndPayerInformationFormProps) => {
  const { id: patientId } = useParams() as { id: string };

  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const getPatient = (search: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getpatient${search}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const patientAndPayerInformationUtils = useSuspenseQuery({
    queryKey: ["patientAndPayerInformation", "get", patientId],
    queryFn: getPatient(
      `?patientId=${patientId}${state.isScheduled ? "&isScheduled=true" : ""}`
    ),
  });

  const update = async (data: PatientAndPayerInformationEditBody) => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/update`;

    return await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };

  const patientAndPayerInformationListUpdate = useMutation({
    mutationKey: ["patientAndPayerInformation", "update"],
    mutationFn: update,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const data = patientAndPayerInformationUtils.data?.data;

    methods.reset({
      effectiveDate: data.effectiveDateFrom,
      endDate: data.effectiveEndDate,
      address1: data.Address,
      address2: data.Address2,
      city: data.City,
      state: data.State,
      zipCode: data.Zip,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientAndPayerInformationUtils.isFetchedAfterMount]);

  const onSubmit: SubmitHandler<PatientAndPayerInformationForm> = async (
    data
  ) => {
    try {
      await patientAndPayerInformationListUpdate.mutateAsync({
        uniqueId: state.uniqueId,
        isScheduled: state.isScheduled,
        effectiveDateFrom: data.effectiveDate,
        effectiveEndDate: data.endDate,
        Address: data.address1,
        Address2: data.address2,
        City: data.city,
        State: data.state,
        Zip: data.zipCode,
      });

      toast.success("Patient and Payer Information updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["getPatient", patientId],
      });
      toggle();
    }
  };

  return (
    <FormProvider {...methods}>
      <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
        <div className="vstack">
          <PatientAndPayerInformationFormFields />

          <div className="gap-2 hstack ms-auto">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>
            <Button color="primary" className="text-white" type="submit">
              Save
            </Button>
          </div>
        </div>
      </Form>
    </FormProvider>
  );
};
