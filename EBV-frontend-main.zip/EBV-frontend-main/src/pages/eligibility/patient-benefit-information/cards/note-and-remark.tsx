/* eslint-disable @typescript-eslint/no-explicit-any */
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
// import { capitalCase } from "change-case";
import { faPenToSquare, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import {
  Controller,
  FormProvider,
  SubmitHandler,
  useForm,
  useFormContext,
} from "react-hook-form";
import {
  Location,
  useLocation,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
  Spinner,
} from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";
import { Patient } from "../../apis/patients-all";

export const key = "notesandremarks";

const noteAndRemarkSchema = z.object({
  [key]: z.string({
    required_error: `Notes is required.`,
  }),
});

export type NoteAndRemarkForm = z.infer<typeof noteAndRemarkSchema>;

export type NoteAndRemarkFieldProps = InputProps & {
  help?: React.ReactNode;
};

export const NoteAndRemarkField = (props: NoteAndRemarkFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="textarea"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default NoteAndRemarkField;

export const NotesAndRemarks = () => {
  const { id: patientId } = useParams() as { id: string };
  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();

  const get =
    (patientId: string, eligibilityId: string) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/eligibility/notesandremarks/${patientId}?eligibilityId=${eligibilityId}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return response ?? { data: [] };
    };

  const create = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/notesandremarks`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const eligibilityId: any = state.eligibilityId;
  const { data: notesandremarks } = useSuspenseQuery({
    queryKey: ["notesandremarks", "get", patientId],
    queryFn: get(patientId, eligibilityId),
  });

  const notesAndRemarksCreate = useMutation({
    mutationKey: ["notesandremarks", "create"],
    mutationFn: create,
  });

  const queryClient = useQueryClient();

  const [searchParams] = useSearchParams();

  const download = searchParams.get("download");
  const mode = searchParams.get("mode");

  const methods = useForm<NoteAndRemarkForm>({
    resolver: zodResolver(noteAndRemarkSchema),
    defaultValues: {
      notesandremarks: "",
    },
  });

  const onSubmit: SubmitHandler<NoteAndRemarkForm> = async (data) => {
    try {
      await notesAndRemarksCreate.mutateAsync({
        data: data[key] as string,
        patientId: patientId,
        isScheduled: state.isScheduled,
        eligibilityId: state.eligibilityId,
      });
      methods.reset();
      toast.success("Notes and remarks saved successfully");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["notesandremarks", "get"],
      });
    }
  };

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit)}>
              <Row>
                <Col xs={12} lg={6}>
                  <h5 className="mb-3">Notes & Remarks</h5>
                  <p className="text-secondary">Notes</p>
                  <NoteAndRemarkField
                    required
                    placeholder="Type here"
                    disabled={Boolean(download || mode)}
                  />
                </Col>

                <Col xs={12} lg={6}>
                  <div className="gap-2 hstack justify-content-end">
                    <Button
                      outline
                      color="primary"
                      onClick={() => methods.reset()}
                      disabled={Boolean(download || mode)}
                    >
                      Cancel
                    </Button>

                    <Button
                      color="primary"
                      className="text-white"
                      type="submit"
                      disabled={Boolean(download || mode)}
                      // onClick={methods.handleSubmit(onSubmit)}
                    >
                      {notesAndRemarksCreate.isPending ? (
                        <>
                          <Spinner size="sm">Saving...</Spinner>
                          <span className="mb-0">Saving...</span>
                        </>
                      ) : (
                        <span className="mb-0">Save</span>
                      )}
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </FormProvider>
          <>
            {notesandremarks &&
              notesandremarks?.data?.map((notes: any, index: any) => (
                <ANoteAndRemark note={notes} index={index + 1} key={index} />
              ))}
          </>
        </CardBody>
      </Card>
    </>
  );
};

export const ANoteAndRemark = (props: any) => {
  const [editMode, setEditMode] = useState(false);
  const queryClient = useQueryClient();
  const [searchParams] = useSearchParams();
  const auth = useAuth();

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/notesandremarks/${data.noteId.noteId}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const notesAndRemarksUpdate = useMutation({
    mutationKey: ["notesandremarks", "update"],
    mutationFn: update,
  });

  const methods = useForm<NoteAndRemarkForm>({
    resolver: zodResolver(noteAndRemarkSchema),
    defaultValues: {
      notesandremarks: props.note.data,
    },
  });
  const onSubmit: SubmitHandler<NoteAndRemarkForm> = async (data: any) => {
    try {
      await notesAndRemarksUpdate.mutateAsync({
        data: { data: data[key] as string },
        noteId: { noteId: props.note.id as string },
      });
      setEditMode(!editMode);
      toast.success("Notes and remarks saved successfully");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["notesandremarks", "get"],
      });
    }
  };

  return (
    <div className="mb-3">
      {!editMode ? (
        <>
          <Row>
            <Col xs={12} lg={6}>
              <p className="text-secondary">{props.index}. Notes</p>
            </Col>
            <Col xs={6} lg={3}>
              <div className="gap-2 hstack justify-content-end ">
                {mode || download ? (
                  <Button
                    color="link"
                    disabled
                    className={`rounded-circle p-0`}
                  >
                    <FontAwesomeIcon
                      icon={faPenToSquare}
                      onClick={() => {
                        setEditMode(!editMode);
                      }}
                    />
                  </Button>
                ) : (
                  <Button color="link" className={`rounded-circle p-0`}>
                    <FontAwesomeIcon
                      icon={faPenToSquare}
                      onClick={() => {
                        setEditMode(!editMode);
                      }}
                    />
                  </Button>
                )}{" "}
                <DeleteModal note={props.note} />
              </div>
            </Col>
          </Row>
          <Row>
            <Col> {props.note.data}</Col>
          </Row>
        </>
      ) : (
        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit)}>
            <Row>
              <Col xs={12} lg={6}>
                <p className="text-secondary">Notes</p>
                <NoteAndRemarkField />
              </Col>

              <Col xs={12} lg={6}>
                <div className="gap-2 hstack justify-content-end">
                  <Button
                    outline
                    color="primary"
                    onClick={() => setEditMode(!editMode)}
                  >
                    Cancel
                  </Button>

                  <Button color="primary" className="text-white">
                    <span className="mb-0">Save</span>
                  </Button>
                </div>
              </Col>
            </Row>
          </Form>
        </FormProvider>
      )}
    </div>
  );
};

export const DeleteModal = (props: any) => {
  const [open, setOpen] = React.useState(false);
  const queryClient = useQueryClient();
  const [searchParams] = useSearchParams();
  const auth = useAuth();

  const deleteNoteAndRemark = (noteId: any) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/notesandremarks/${noteId}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const toggle = () => setOpen(!open);

  const notesAndRemarksDelete = useMutation({
    mutationKey: ["notesandremarks", "delete"],
    mutationFn: deleteNoteAndRemark(props.note.id),
  });

  const handleDelete = async () => {
    try {
      await notesAndRemarksDelete.mutateAsync();
      toast.success("Notes and remarks deleted successfully");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      toggle();
      await queryClient.invalidateQueries({
        queryKey: ["notesandremarks", "get"],
      });
    }
  };

  return (
    <>
      {mode || download ? (
        <Button
          color="link"
          disabled
          className={`rounded-circle p-0`}
          onClick={toggle}
        >
          <FontAwesomeIcon icon={faTrash} />
        </Button>
      ) : (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faTrash} />
        </Button>
      )}

      <Modal backdrop keyboard size="lg" isOpen={open} toggle={toggle}>
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="primary" onClick={handleDelete}>
              <span>Yes</span>
            </Button>
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
