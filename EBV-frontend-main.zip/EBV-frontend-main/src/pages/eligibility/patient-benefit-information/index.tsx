import {
  faDownload,
  faEye,
  faPenToSquare,
  faSave,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import {
  Location,
  NavLink as RouterNavLink,
  useLocation,
  useSearchParams,
} from "react-router-dom";
import {
  Button,
  Card,
  CardBody,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Form,
  Input,
  Nav,
  NavItem,
  NavLink,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
  Spinner,
  TabContent,
  TabPane,
  UncontrolledDropdown,
} from "reactstrap";
import { z } from "zod";
import useDrawerFromLocation from "../../../shared/hooks/use-drawer-from-location";
import EmployerInformation from "./cards/employer-information";
import InsightsCards from "./cards/insights-cards";
import { NotesAndRemarks } from "./cards/note-and-remark";
import PatientAndPayerInformation from "./cards/patient-and-payer-information";
import SubscriberInformationCard from "./cards/subscriber-information-card";
import AdaCodeSwitch from "./fields/ada-code";
import Network from "./fields/network";
import Search from "./fields/search";
import ActiveCoverageTable from "./tables/active-coverage";
import AdaProcedureTable from "./tables/ada-procedure";
import BenefitHistoryTable from "./tables/benefit-history";
import CoInsuranceTable from "./tables/co-insurance";
import DeductibleTable from "./tables/deductible";
// import LimitationTable from "./tables/limitation";
// import MaximumTable from "./tables/maximum";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import axios from "axios";
import { useAuth } from "../../../shared/hooks/use-auth";
import { Config } from "../../../utils/headers-config";
import { AttachmentTable } from "../../patient-benefit-information/components/attachments-table";
import { Patient } from "../apis/patients-all";
import { Miscellaneous } from "./cards/miscellaneous";
import CommonLoader from "./common-loader";
import { PastHistory } from "./fields/past-history";
import LimitationAndMaximumTable from "./tables/limitation-and-maximum";
import NotCoveredTable from "./tables/not-covered";

const FiltersFormSchema = z.object({
  "In-Network": z.boolean().optional(),
  "Out-Of-Network": z.boolean().optional(),
  "ADA-Code": z.boolean().optional(),
  search: z.string().optional(),
  pastHistory: z.string().optional(),
});

export type FiltersForm = z.infer<typeof FiltersFormSchema>;

export const PatientBenefitInformation = React.memo(() => {
  const { state } = useLocation() as Location<Patient>;
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;

  const fetchReport = async ({
    patientId,
    eligibilityId,
    isScheduled,
    basic,
    document,
    code,
  }: {
    patientId: string;
    eligibilityId: string;
    isScheduled: boolean | undefined;
    basic: boolean;
    document: Document;
    code: string;
  }) => {
    try {
      const fileName = basic
        ? `Patient ${patientId}-basic-report`
        : `Patient ${patientId}-detailed-report`;
      const response = await getPatientReport(
        patientId,
        eligibilityId,
        isScheduled,
        basic,
        code
      );
      const file = new Blob([response.data], { type: "application/pdf" });
      const fileURL = URL.createObjectURL(file);

      const link = document.createElement("a");
      link.href = fileURL;
      link.setAttribute("download", `${fileName}`);
      document.body.appendChild(link);
      link.click();

      URL.revokeObjectURL(fileURL);
      document.body.removeChild(link);
    } catch (error) {
      console.log(error);
    }
  };

  const getPatientReport = async (
    patientId: string,
    eligibilityId: string,
    isScheduled: boolean | undefined,
    basic: boolean,
    code: string
  ) => {
    const body = {
      patientId,
      eligibilityId,
      isScheduled,
      basicReport: basic,
    };
    return await axios({
      method: "POST",
      url: `${
        import.meta.env.VITE_API_HOST ?? ""
      }/eligibility/getreport?code=${code}`,
      data: body,
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
      responseType: "blob",
    });
  };

  const getSettings =
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (adminId: string) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/generalSettings/get/${adminId}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return response;
    };

  const verifypatientUtils = useSuspenseQuery({
    queryKey: ["verifyPatient", "get", `${userId}`],
    queryFn: getSettings(`${userId}`),
  });

  const getReport = useMutation({
    mutationKey: [],
    mutationFn: fetchReport,
  });

  const methods = useForm<FiltersForm>({
    resolver: zodResolver(FiltersFormSchema),
  });

  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id/*",
    togglePath: "../..",
    // historyPopInstead: true,
  });

  const [searchParams, setSearchParams] = useSearchParams();

  const queryClient = useQueryClient();

  const eligibilityId =
    searchParams.get("pastHistory") === "undefined" ||
    searchParams.get("pastHistory") === "null"
      ? state.eligibilityId
      : searchParams.get("pastHistory");

  const [editMode, setEditMode] = React.useState(
    searchParams.get("editMode") ?? ""
  );

  const adaVerificationCodes =
    verifypatientUtils?.data?.data?.verificationcodes?.join(",");

  const onSubmit: SubmitHandler<FiltersForm> = (data) => {
    ({ data });
  };

  const inNetwork = methods.watch("In-Network", false);
  const outNetwork = methods.watch("Out-Of-Network", false);
  const adaCode = methods.watch("ADA-Code", false);
  const search = methods.watch("search", "");
  const pastHistory = methods.watch("pastHistory");

  const network = React.useMemo(
    () => ({
      ["In-Network"]: inNetwork,
      ["Out-Of-Network"]: outNetwork,
      ["ADA-Code"]: adaCode,
      ["search"]: search,
      ["editMode"]: editMode,
      ["pastHistory"]: pastHistory,
    }),
    [inNetwork, outNetwork, adaCode, search, editMode, pastHistory]
  );

  React.useEffect(() => {
    setSearchParams(
      {
        ...(network["ADA-Code"]
          ? {
              code: state?.procedureCode
                ? state.procedureCode
                : adaVerificationCodes,
            }
          : {}),
        network: (
          ["In-Network", "Out-Of-Network"] as (keyof typeof network)[]
        ).filter((key) => network[key]),
        search: String(network["search"]),
        editMode: String(network["editMode"]),
        pastHistory: String(network["pastHistory"]),
      },
      { state }
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [network]);

  const handleClose = React.useCallback(async () => {
    await queryClient.invalidateQueries({
      queryKey: ["patients/all"],
    });
  }, [queryClient]);

  return (
    <div>
      <Offcanvas
        isOpen={open}
        onExit={handleClose}
        toggle={toggle}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Patient Benefit Information -{" "}
          {`${
            state?.relationship === "18"
              ? state?.firstName
              : state?.dependentFirstName
          } ${
            state?.relationship === "18"
              ? state?.lastName
              : state?.dependentLastName
          } (${state?.patientId})`}
        </OffcanvasHeader>

        <OffcanvasBody>
          <>
            <FormProvider {...methods}>
              <Form onSubmit={methods.handleSubmit(onSubmit)}>
                <div className="position-relative">
                  <div
                    className="p-3 bg-white position-fixed z-3 w-100"
                    style={{ margin: "-1rem" }}
                  >
                    <Search
                      name="search"
                      setValue={(value) => methods.setValue("search", value)}
                      style={{ maxWidth: "fit-content" }}
                    />
                  </div>
                  <div className="p-3 pb-0">
                    <Input style={{ visibility: "hidden" }} />
                  </div>
                </div>

                <Card className="mb-4">
                  <CardBody>
                    <Row>
                      <Col xs={12} md={4} lg={2}>
                        <h6>Benefits</h6>
                        <Input type="select">
                          <option>02/24/2023</option>
                        </Input>
                      </Col>

                      <Col xs={12} md={4} lg={2}>
                        <h6>ADA Code Filter</h6>
                        <AdaCodeSwitch name="ADA-Code" />
                      </Col>

                      <Col xs={12} md={4} lg={2}>
                        <h6>Network Filter</h6>
                        <Network name={["In-Network", "Out-Of-Network"]} />
                      </Col>

                      <Col xs={12} md={5} lg={3}>
                        <React.Suspense fallback={""}>
                          <PastHistory name="pastHistory" />
                        </React.Suspense>
                      </Col>

                      <Col>
                        <div className="gap-2 hstack justify-content-end align-items-center h-100">
                          <UncontrolledDropdown>
                            <DropdownToggle data-toggle="dropdown" tag="span">
                              <Button outline color="primary">
                                <FontAwesomeIcon
                                  icon={faDownload}
                                  className="me-2"
                                />
                                PDF
                              </Button>
                            </DropdownToggle>

                            <DropdownMenu>
                              {getReport.isPending &&
                              getReport?.variables?.basic ? (
                                <DropdownItem
                                  style={{
                                    display: "flex",
                                    justifyContent: "center",
                                  }}
                                >
                                  <Spinner size="sm">
                                    Generating report...
                                  </Spinner>
                                </DropdownItem>
                              ) : (
                                <DropdownItem
                                  toggle={false}
                                  onClick={() =>
                                    getReport.mutate({
                                      patientId: state.patientId,
                                      eligibilityId: `${eligibilityId}`,
                                      isScheduled: state?.isScheduled,
                                      basic: true,
                                      document,
                                      code: searchParams.get("code") || "",
                                    })
                                  }
                                >
                                  Basic Report
                                </DropdownItem>
                              )}
                              {getReport.isPending &&
                              !getReport?.variables?.basic ? (
                                <DropdownItem
                                  style={{
                                    display: "flex",
                                    justifyContent: "center",
                                  }}
                                >
                                  <Spinner size="sm">
                                    Generating report...
                                  </Spinner>
                                </DropdownItem>
                              ) : (
                                <DropdownItem
                                  toggle={false}
                                  onClick={() =>
                                    getReport.mutate({
                                      patientId: state.patientId,
                                      eligibilityId: `${eligibilityId}`,
                                      isScheduled: state?.isScheduled,
                                      basic: false,
                                      document,
                                      code: searchParams.get("code") || "",
                                    })
                                  }
                                >
                                  Detailed Report
                                </DropdownItem>
                              )}
                            </DropdownMenu>
                          </UncontrolledDropdown>

                          <UncontrolledDropdown>
                            <DropdownToggle data-toggle="dropdown" tag="span">
                              <Button outline color="primary">
                                <FontAwesomeIcon
                                  icon={faEye}
                                  className="me-2"
                                />
                                Preview
                              </Button>
                            </DropdownToggle>

                            <DropdownMenu>
                              <RouterNavLink
                                to="report?type=basic&mode=preview"
                                state={state}
                                className="text-decoration-none"
                              >
                                <DropdownItem toggle={false}>
                                  Basic Report
                                </DropdownItem>
                              </RouterNavLink>

                              <RouterNavLink
                                to="report?type=detailed&mode=preview"
                                state={state}
                                className="text-decoration-none"
                              >
                                <DropdownItem toggle={false}>
                                  Detailed Report
                                </DropdownItem>
                              </RouterNavLink>
                            </DropdownMenu>
                          </UncontrolledDropdown>

                          {state.isVerifiedManually && (
                            <Button
                              style={{
                                backgroundColor: "#E6F7F3",
                                color: "var(--bs-primary)",
                                borderColor: "#E6F7F3",
                              }}
                              onClick={() =>
                                setEditMode((editMode) =>
                                  editMode === "true" ? "" : "true"
                                )
                              }
                            >
                              {editMode ? (
                                <p className="gap-2 mb-0 hstack">
                                  <FontAwesomeIcon icon={faSave} /> Save
                                </p>
                              ) : (
                                <p className="gap-2 mb-0 hstack">
                                  <FontAwesomeIcon icon={faPenToSquare} /> Edit
                                </p>
                              )}
                            </Button>
                          )}
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Form>
            </FormProvider>

            <Row className="mb-5 g-3">
              <Col lg={8}>
                <React.Suspense fallback={""}>
                  <SubscriberInformationCard />
                </React.Suspense>
              </Col>

              <Col>
                <React.Suspense fallback={""}>
                  <InsightsCards />
                </React.Suspense>
              </Col>
            </Row>

            <PatientBenefitInformationTabs />
          </>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
});

const getTabActiveStyles = (
  activeTab: string,
  tab: string
): React.CSSProperties => {
  return activeTab === tab
    ? {
        backgroundColor: "#EBF2F5",
        color: "var(--bs-text-black)",
        borderRadius: 50,
        boxShadow: "0px 1px 2px 0px rgba(0, 0, 0, 0.20)",
        margin: "0.35rem",
        padding: "0.35rem 0.65rem",
      }
    : {
        backgroundColor: "transparent",
        color: "var(--bs-text-black)",
        borderRadius: 50,
        border: "1px solid black",
        margin: "0.35rem",
        padding: "0.35rem 0.65rem",
      };
};

export const PatientBenefitInformationTabs = React.memo(() => {
  const [searchParams, setSearchParams] = useSearchParams();

  const { state } = useLocation() as Location<Patient>;

  const tabId = searchParams.get("tabId");

  const [activeTab, setActiveTab] = React.useState(tabId || "1");

  React.useEffect(() => {
    if (tabId) setActiveTab(tabId);
  }, [tabId]);

  const toggle = (tab: string) => {
    setSearchParams(
      {
        ...Array.from(searchParams.entries()).reduce((acc, [key, value]) => {
          return { ...acc, [key]: value };
        }, {}),
        tabId: "",
        tableFilter: "",
      },
      { state }
    );
    if (activeTab !== tab) setActiveTab(tab);
  };

  return (
    <>
      <Nav pills>
        <NavItem>
          <NavLink
            style={getTabActiveStyles(activeTab, "1")}
            onClick={() => {
              toggle("1");
            }}
          >
            All
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "2")}
            onClick={() => {
              toggle("2");
            }}
          >
            Active Coverage
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "3")}
            onClick={() => {
              toggle("3");
            }}
          >
            Co Insurance
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "5")}
            onClick={() => {
              toggle("5");
            }}
          >
            Deductible
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "6")}
            onClick={() => {
              toggle("6");
            }}
          >
            Limitation & Maximum
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "7")}
            onClick={() => {
              toggle("7");
            }}
          >
            Not Covered
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "4")}
            onClick={() => {
              toggle("4");
            }}
          >
            ADA Procedure
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "8")}
            onClick={() => {
              toggle("8");
            }}
          >
            Patient & Payer Information
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "9")}
            onClick={() => {
              toggle("9");
            }}
          >
            Benefits History
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "10")}
            onClick={() => {
              toggle("10");
            }}
          >
            Employer Information
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "11")}
            onClick={() => {
              toggle("11");
            }}
          >
            Miscellaneous
          </NavLink>
        </NavItem>
      </Nav>

      <TabContent activeTab={activeTab}>
        <TabPane tabId="1">
          <React.Suspense fallback={<CommonLoader label="Active Coverage" />}>
            <ActiveCoverageTable />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Co-Insurance" />}>
            <CoInsuranceTable />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Deductible" />}>
            <DeductibleTable />
          </React.Suspense>
          <React.Suspense
            fallback={<CommonLoader label="Limitation And Maximum" />}
          >
            <LimitationAndMaximumTable />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Not Covered" />}>
            <NotCoveredTable />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="ADA Procedure" />}>
            <AdaProcedureTable />
          </React.Suspense>
          <React.Suspense
            fallback={<CommonLoader label="Patient and Payer Information" />}
          >
            <PatientAndPayerInformation />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Benefit History" />}>
            <BenefitHistoryTable />
          </React.Suspense>
          <React.Suspense
            fallback={<CommonLoader label="Employer Information" />}
          >
            <EmployerInformation />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Miscellaneous" />}>
            <Miscellaneous />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Notes and Remarks" />}>
            <NotesAndRemarks />
          </React.Suspense>
          <React.Suspense fallback={<CommonLoader label="Attachment" />}>
            <AttachmentTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="2">
          <React.Suspense fallback={<CommonLoader label="Active Coverage" />}>
            <ActiveCoverageTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="3">
          <React.Suspense fallback={<CommonLoader label="Co Insurance" />}>
            <CoInsuranceTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="5">
          <React.Suspense fallback={<CommonLoader label="Deductible" />}>
            <DeductibleTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="6">
          <React.Suspense
            fallback={<CommonLoader label="Limitation and Maximum" />}
          >
            <LimitationAndMaximumTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="7">
          <React.Suspense fallback={<CommonLoader label="Not Covered" />}>
            <NotCoveredTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="4">
          <React.Suspense fallback={<CommonLoader label="ADA Procedure" />}>
            <AdaProcedureTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="8">
          <React.Suspense
            fallback={<CommonLoader label="Patient And Payer Information" />}
          >
            <PatientAndPayerInformation />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="9">
          <React.Suspense fallback={<CommonLoader label="Benefit History" />}>
            <BenefitHistoryTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="10">
          <React.Suspense
            fallback={<CommonLoader label="Employer Information" />}
          >
            <EmployerInformation />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="11">
          <React.Suspense fallback={<CommonLoader label="Miscellaneous" />}>
            <Miscellaneous />
            <NotesAndRemarks />
            <AttachmentTable />
          </React.Suspense>
        </TabPane>
      </TabContent>
    </>
  );
});

export default PatientBenefitInformation;
