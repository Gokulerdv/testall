/* eslint-disable @typescript-eslint/no-explicit-any */
import { Card, Col, Row, Spinner } from "reactstrap";

export type CommonLoaderProps = {
  label: React.ReactNode;
};

export const CommonLoader = ({ label }: CommonLoaderProps) => {
  return (
    <Card className="p-4 mt-3">
      <Row>
        <Col xs={12}>
          <h6 className="mb-4 fw-bold">{label}</h6>
        </Col>
        <Col xs={12} style={{ height: 300 }}>
          <div className="d-flex justify-content-center align-items-center w-100 h-100">
            <Spinner color="success">Loading...</Spinner>
          </div>
        </Col>
      </Row>
    </Card>
  );
};

export default CommonLoader;
