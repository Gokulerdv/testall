/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { Config } from "../../utils/headers-config";

const DownloadAllConfirmation = () => {
  const auth = useAuth();
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/download-all-confirmation",
    togglePath: "../../..",
    historyPopInstead: true,
  });

  const downloadAllPDF = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/eligibility/getallpatientpdf`;

    const response = await (
      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const downloadAll = useMutation({
    mutationKey: ["patients/bulkverifyall"],
    mutationFn: downloadAllPDF,
  });

  const handleDownloadPDF = async () => {
    try {
      const response = await downloadAll.mutateAsync();
      const bufferData = new Uint8Array(response?.data[0]?.data?.pdf.data);
      const blob = await new Blob([bufferData], {
        type: "application/pdf",
      });

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "bulk_pdf.pdf";

      a.click();

      window.URL.revokeObjectURL(url);

      toast.success("Pdf downloaded successfully");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Download all PDF
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to download all the patients?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="primary" onClick={handleDownloadPDF}>
              <span>Yes</span>
            </Button>
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
export default DownloadAllConfirmation;
