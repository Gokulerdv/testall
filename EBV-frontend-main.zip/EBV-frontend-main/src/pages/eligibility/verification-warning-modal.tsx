import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import { useNotificationContext } from "../../shared/hooks/use-notification";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import { Config } from "../../utils/headers-config";
import {
  PatientsVerifyProps,
  PatientsVerifyResponse,
} from "./apis/patients-verify";

type VerificationWarningModalProps = {
  uniqueId: string;
  isScheduled: string;
  lastName: string;
  lastVerified: string;
  firstName: string;
  closeModal: () => void;
  open: boolean;
};
export const VerificationWarningModal = ({
  uniqueId,
  isScheduled,
  lastName,
  lastVerified,
  firstName,
  closeModal,
  open,
}: VerificationWarningModalProps) => {
  const auth = useAuth();

  const userId = auth?.state?.user?.userData?.userId;

  const [, setSearchParams] = useSearchParams();
  const notify = useNotificationContext();

  // const { open, toggle } = useDrawerFromLocation({
  //   matchPath: "eligibility/:id/verify-warning",
  //   togglePath: "../../?refresh=true",
  // });

  const getSettings =
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (adminId: string) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/generalSettings/get/${adminId}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return response;
    };

  const patientsVerify = async ({
    uniqueId,
    isScheduled,
  }: PatientsVerifyProps): Promise<PatientsVerifyResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/verifypatient?uniqueId=${uniqueId}&adminId=${
      auth?.state?.user?.userData?.userId
    }${
      isScheduled && isScheduled !== "undefined"
        ? `&isScheduled=${isScheduled}`
        : ""
    }`;

    const response = (await (
      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsVerifyResponse;

    return response;
  };

  const datetimeString = lastVerified;
  const dateObj = new Date(datetimeString);
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth() + 1;
  const day = dateObj.getDate();
  const hours = dateObj.getHours();
  const minutes = dateObj.getMinutes();
  const seconds = dateObj.getSeconds();

  const formattedMonth = month < 10 ? `0${month}` : month;
  const formattedDay = day < 10 ? `0${day}` : day;

  const date = `${year}-${formattedMonth}-${formattedDay}`;
  const time = `${hours}:${minutes}:${seconds}`;

  const patients = useMutation({
    mutationKey: ["patients/verify"],
    mutationFn: patientsVerify,
  });

  const verifypatientUtils = useSuspenseQuery({
    queryKey: ["verifyPatient", "get", `${userId}`],
    queryFn: getSettings(`${userId}`),
  });

  const warningDays = verifypatientUtils.data.data.warningdays;

  const verifyPatientNew = async () => {
    try {
      const res = await patients.mutateAsync(
        { uniqueId, isScheduled, lastName, lastVerified, firstName },
        defaultMutateOptions
      );
      setSearchParams({ refresh: String(true) });
      res?.notificationData && notify.dispatcher({ type: "increment-count" });
      !res?.error && toast.success("Patient verified Successfully");
      if (res?.error) throw Error;
      res.data?.eligibility && res.data?.eligibility?.errors?.length
        ? toast.error("Patient verification failed!")
        : toast.success("Patient verified Successfully");
      setSearchParams({ refresh: String(true) });
    } catch (error) {
      toast.error("Patient verification failed!");
      console.log(error);
    } finally {
      closeModal();
    }
  };

  return (
    <Modal
      isOpen={open}
      toggle={closeModal}
      backdrop
      keyboard
      size="lg"
      zIndex={1400}
    >
      <ModalHeader toggle={closeModal} className="text-white bg-primary">
        Confirmation
      </ModalHeader>
      <ModalBody className="m-auto">
        <p>
          Below Patient is recently verified in last {warningDays} days. Are you
          sure you want to proceed?
        </p>
        <table className="table payer_table ">
          <thead>
            <tr>
              <th scope="col">Patients</th>
              <th scope="col">LastVerified Date</th>
              <th scope="col">LastVerified Time</th>
            </tr>
          </thead>
          <tbody>
            <tr className="table-secondary scheduled_process_table">
              <td>
                {firstName} {lastName}
              </td>
              <td>{date}</td>
              <td> {time}</td>
            </tr>
          </tbody>
        </table>
        <div className="gap-4 hstack justify-content-center">
          <Button outline color="primary" onClick={verifyPatientNew}>
            {patients.isPending ? (
              <>
                <Spinner size="sm">Verifying...</Spinner>
                <span> Verifying...</span>
              </>
            ) : (
              "Yes"
            )}
          </Button>
          <Button outline color="secondary" onClick={() => closeModal()}>
            No
          </Button>
        </div>
      </ModalBody>
    </Modal>
  );
};

export default VerificationWarningModal;
