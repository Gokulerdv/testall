/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faClose,
  faDownload,
  faPaperclip,
  faPenToSquare,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Dialog, DialogContent, DialogTitle, IconButton } from "@mui/material";
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { createColumnHelper } from "@tanstack/react-table";
import React from "react";
import {
  NavLink as RouterLink,
  useNavigate,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Card, Spinner } from "reactstrap";
import TableComponent from "../../components/table";
import { useAuth } from "../../shared/hooks/use-auth";
import { dateTimeFormat } from "../../utils/date-time-format";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import Config from "../../utils/headers-config";
import {
  PatientAttachment,
  PatientsAttachmentsProps,
  PatientsAttachmentsResponse,
} from "./apis/patients-attachment-all";
import {
  PatientsAttachmentDeleteProps,
  PatientsAttachmentDeleteResponse,
} from "./apis/patients-attachment-delete";
import { AttachmentImageModal } from "./attachment-image-modal";
import { EligibilityModalProps } from "./eligibility-modal";

export type AttachmentDataType = PatientAttachment;

export type AttachmentModalProps = EligibilityModalProps & {
  trigger?: (props: { toggle: () => void }) => React.ReactNode;
  state?: any;
  isOpen?: any;
  onClose?: any;
  type?: "insuranceCard" | "attachment";
};

export const AttachmentModal = (props: AttachmentModalProps) => {
  const [searchParams] = useSearchParams();
  const { state, isOpen, onClose, type } = props;
  const refresh = searchParams.get("refresh");
  const patientId = state?.patientId;

  const auth = useAuth();

  const patientsAttachmentsAll =
    ({ patientId }: PatientsAttachmentsProps) =>
    async (): Promise<PatientsAttachmentsResponse> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/patients/attachments/${patientId}`;

      const response = (await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json()) as PatientsAttachmentsResponse;

      return response;
    };

  const attachments = useSuspenseQuery({
    queryKey: [`patients/${patientId}/attachments`],
    queryFn: patientsAttachmentsAll({ patientId }),
  });

  const data = React.useMemo(() => {
    return attachments.data.data;
  }, [attachments.data.data]);

  const patientsAttachmentDelete = async ({
    uniqueId,
  }: PatientsAttachmentDeleteProps): Promise<PatientsAttachmentDeleteResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/attachments/${uniqueId}`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
        method: "DELETE",
      })
    ).json()) as PatientsAttachmentDeleteResponse;

    return response;
  };

  React.useEffect(() => {
    (async () => {
      if (refresh) await attachments.refetch();
    })();
  }, [attachments, refresh]);

  const patientsAttachment = useMutation({
    mutationKey: [`patients/attachments/${patientId}`],
    mutationFn: patientsAttachmentDelete,
  });

  const deletePatientAttachment = async ({
    uniqueId,
  }: {
    uniqueId: string;
  }) => {
    try {
      if (!patientId) return;

      await patientsAttachment.mutateAsync({ uniqueId }, defaultMutateOptions);
      await attachments.refetch();

      props.onSuccess?.();

      toast.success("Attachment deleted successfully");
      onClose();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };
  const navigate = useNavigate();
  const handleNavigate = (info: any) => {
    onClose();

    navigate(`${patientId}/attachments/${info.uniqueId}/edit`, {
      state: info,
    });
  };

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<AttachmentDataType>();

    const defaultColumns = [
      columnHelper.accessor("fileName", {
        cell: (info) => <AttachmentImageModal {...info} />,
        header: "File",
      }),
      columnHelper.accessor("description", {
        cell: (info) => info.getValue(),
        header: "Description",
      }),
      columnHelper.accessor("updatedAt", {
        cell: (info) => dateTimeFormat(new Date(info.getValue())),
        header: "Attachment Date",
      }),
      columnHelper.display({
        id: "actions",
        header: "Actions",
        cell: (info) => (
          <div className="gap-3 hstack">
            {/* <RouterLink
              to={`${patientId}/attachments/${info.row.original.uniqueId}/edit`}
              state={info.row.original}
            > */}
            <Button
              color="link"
              className={`rounded-circle p-0`}
              onClick={() => handleNavigate(info.row.original)}
            >
              <FontAwesomeIcon icon={faPenToSquare} />
            </Button>

            <RouterLink to={``} state={info.row.original}>
              <Button color="link" className={`rounded-circle p-0`}>
                {attachments.isPending ? (
                  <>
                    <Spinner size="sm">Deleting...</Spinner>
                  </>
                ) : (
                  <FontAwesomeIcon
                    icon={faTrash}
                    onClick={() =>
                      deletePatientAttachment({
                        uniqueId: info.row.original.uniqueId,
                      })
                    }
                  />
                )}
              </Button>
            </RouterLink>

            <a
              href={info.row.original.base64File}
              download={info.row.original.fileName}
              target="__blank"
            >
              <Button color="link" className={`rounded-circle p-0`}>
                <FontAwesomeIcon icon={faDownload} />
              </Button>
            </a>
          </div>
        ),
      }),
    ];

    return defaultColumns;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      {type === "attachment" ? (
        <Button
          color="link"
          className="p-0 text-black rounded-circle me-2"
          onClick={onClose}
        >
          {" "}
          <FontAwesomeIcon icon={faPaperclip} />
        </Button>
      ) : (
        <div>View Insurance Card</div>
      )}
      <Dialog open={isOpen} onClose={onClose} maxWidth="lg">
        <DialogTitle>
          <div className="title">Attachment</div>
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
          }}
        >
          <FontAwesomeIcon icon={faClose} />
        </IconButton>
        <DialogContent style={{ width: "50rem" }}>
          <Card className="p-2">
            <TableComponent data={data} columns={columns} />
          </Card>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AttachmentModal;
