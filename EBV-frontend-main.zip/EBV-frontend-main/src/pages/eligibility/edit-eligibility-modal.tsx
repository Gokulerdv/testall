/* eslint-disable @typescript-eslint/no-explicit-any */
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React, { useState } from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { Button, Col, Input, Row } from "reactstrap";
import { z } from "zod";
import ConfirmationModal from "../../components/confirmation-modal";
import DateOfBirth from "../../shared/forms/fields/date-of-birth";
import FirstName from "../../shared/forms/fields/first-name";
import GroupId from "../../shared/forms/fields/group-id";
import LastName from "../../shared/forms/fields/last-name";
import MemberId from "../../shared/forms/fields/member-id";
import { useAuth } from "../../shared/hooks/use-auth";
import { useNotificationContext } from "../../shared/hooks/use-notification";
import {
  ScanQrEditPermission,
  UploadImagesEditPermission,
} from "../../utils/constant";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import Config from "../../utils/headers-config";
import { RolesPermission } from "../../utils/role-permission";
import {
  Providers,
  ProvidersAllResponse,
} from "../settings/provider/table/columns";
import { PatientsEditBody } from "./apis/patients-edit";
import { AttachmentModalProps } from "./attachment-modal";
import { eligibilityFormSchema } from "./eligibility-modal";
import AppointmentRenderingProvider, {
  appointmentRenderingProviderSchema,
} from "./form/fields/appointment-rendering-provider";
import AppointmentType, {
  appointmentTypeSchema,
} from "./form/fields/appointment-type";
import Gender, { genderSchema } from "./form/fields/gender";
import InsurancePayer, {
  insurancePayerList,
} from "./form/fields/insurance-payer";
import PracticeNameAndLocation, {
  practiceNameAndLocationSchema,
} from "./form/fields/practice-name-and-location";
import ProcedureCode from "./form/fields/procedure-code";
import ProcedureType from "./form/fields/procedure-type";
import Provider from "./form/fields/provider";
import Relationship from "./form/fields/relationship";
import ScheduleAppointment, {
  scheduleAppointmentSchema,
} from "./form/fields/schedule-appointment";
import Specialty, { specialtySchema } from "./form/fields/specialty";
import TypeOfService, {
  typeOfServiceSchema,
} from "./form/fields/type-of-service";
import QRModal from "./qr-modal";
import UploadModal from "./upload-modal";

export const eligibilityEditFormSchema = z.object({
  ...eligibilityFormSchema.shape,
  ...typeOfServiceSchema.shape,
  ...specialtySchema.shape,
  ...practiceNameAndLocationSchema.shape,
  ...appointmentTypeSchema.shape,
  ...scheduleAppointmentSchema.shape,
  ...genderSchema.shape,
  // ...subscriberIdSchema.shape,
  ...appointmentRenderingProviderSchema.shape,
});
eligibilityEditFormSchema.merge(typeOfServiceSchema);
eligibilityEditFormSchema.merge(practiceNameAndLocationSchema);
eligibilityEditFormSchema.merge(appointmentTypeSchema);
eligibilityEditFormSchema.merge(genderSchema);
export type EligibilityEditFormData = z.infer<typeof eligibilityEditFormSchema>;

export type EligibilityEditModalProps = AttachmentModalProps & {
  defaultValues?: Partial<EligibilityEditFormData>;
  state?: any;
  isOpen?: any;
  onClose?: any;
};
export const EligibilityEditModal = (props: EligibilityEditModalProps) => {
  const auth = useAuth();
  const { state, isOpen, onClose } = props;
  // const { state } = useLocation() as Location<Patient>;
  const notify = useNotificationContext();
  const [providerData, setProviderData] = React.useState<Providers>([]);
  const [odProviderData, setOdProviderData] = React.useState<any[]>([]);

  const [category, setCategory] = useState("");
  const [type, setType] = useState("");
  // const [open, setOpen] = React.useState(false);
  // const toggle = () => {
  //   setOpen(!open);
  // };

  // useEffect(() => {

  // }, [state]);

  const methods = useForm<EligibilityEditFormData>({
    resolver: zodResolver(eligibilityFormSchema),
  });

  // const drawer = useDrawerFromLocation({
  //   matchPath: "eligibility/:id/edit",
  //   togglePath: "../../?refresh=true",
  // });

  // const { open, toggle } = useDialogWithFormReset(methods);

  const patientsEdit = async (body: PatientsEditBody) => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/update`;

    return await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(body),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };

  const getById = (id: string) => async (): Promise<any> => {
    const url = state.isScheduled
      ? `${
          import.meta.env.VITE_API_HOST ?? ""
        }/patients/getpatient/?patientId=${id}&isScheduled=true`
      : `${
          import.meta.env.VITE_API_HOST ?? ""
        }/patients/getpatient/?patientId=${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };
  const patientsGetById = useSuspenseQuery({
    queryKey: ["patentId", "get", state?.patientId],
    queryFn: getById(state.patientId),
  });
  const eligibility = useMutation({
    mutationKey: ["patients/edit"],
    mutationFn: patientsEdit,
  });
  React.useEffect(() => {
    if (isOpen === true) {
      methods.reset({
        firstName: patientsGetById.data.data.firstName,
        lastName: patientsGetById.data.data.lastName,
        dateOfBirth: new Date(patientsGetById.data.data.dateOfBirth),
        groupId: patientsGetById.data.data.groupId,
        memberId: patientsGetById.data.data.memberId,
        relationship: patientsGetById.data.data.relationship,
        typeOfService: patientsGetById.data.data.typeOfService,
        practiceNameAndLoc: patientsGetById.data.data.practiceNameAndLoc,
        appointmentType: patientsGetById.data.data.appointmentType,
        scheduleAppointment: new Date(
          patientsGetById.data.data.scheduleAppointment
        ),
        speciality: patientsGetById.data.data.speciality,
        gender: patientsGetById.data.data.gender,
        procedureType: patientsGetById.data.data.procedureType,
        procedureCode: patientsGetById.data.data.procedureCode?.split(",")?.[0],

        insurancePayer: patientsGetById.data.data.insurancePayer,

        dependentDateOfBirth: new Date(
          patientsGetById.data.data.dependentDateOfBirth
        ),

        appointmentRenderingProvider:
          patientsGetById.data.data.appointmentRenderingProvider,
        provider: patientsGetById.data.data.provider,
        dependentFirstName: patientsGetById.data.data.dependentFirstName,
        dependentLastName: patientsGetById.data.data.dependentLastName,
      });
      setCategory(
        patientsGetById.data.data.medical
          ? "medical"
          : patientsGetById.data.data.dental
          ? "dental"
          : "others"
      );
      setType(
        patientsGetById.data.data.primary
          ? "primary"
          : patientsGetById.data.data.secondary
          ? "secondary"
          : "tertiary"
      );
    }
  }, [isOpen]);

  const ProvidersAll = async (): Promise<ProvidersAllResponse> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/provider/getAll/18`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as ProvidersAllResponse;
    return {
      ...response,
      data: response.data.map((e) => {
        return {
          ...e,
          providerOption:
            e.doctorName +
            "-" +
            e.deaNumber +
            "-" +
            e.location +
            "-" +
            e.npiId +
            "-" +
            (String(e.ssn) ? `XXXXX${String(e.ssn).slice(-4)}` : ""),
        };
      }),
    };
  };
  const OdProvidersAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/opendental/provider/getAll`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return {
      ...response,
      data: response.data.map((e: any) => {
        return {
          id: e.id,
          adminId: "",
          deaNumber: "",
          doctorName: e.firstName + " " + e.lastName,
          location: "",
          npiId: e.NationalProvID,
          practiceName: "",
          providerType: "",
          ssn: e.SSN,
          status: true,
          taxId: e.SSN,
          uniqueId: e?.ProvNum,
          updatedAt: e.updatedAt,
          createdAt: e.createdAt,
          providerOption:
            e.firstName +
            " " +
            e.lastName +
            "-" +
            " " +
            "-" +
            " " +
            "-" +
            e.NationalProvID +
            "-" +
            (String(e.SSN) ? `XXXXX${String(e.SSN).slice(-4)}` : ""),
        };
      }),
    };
  };

  const providerdataResp = useSuspenseQuery({
    queryKey: ["provider", "getAll"],
    queryFn: ProvidersAll,
  });
  const odProviderdataResp = useSuspenseQuery({
    queryKey: ["opendental", "provider", "getAll"],
    queryFn: OdProvidersAll,
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    if (isOpen) {
      setOdProviderData(odProviderdataResp.data.data);
    }
  }, [odProviderdataResp.data.data, isOpen]);

  React.useEffect(() => {
    if (isOpen) {
      setProviderData(providerdataResp.data.data);
    }
    //   // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [providerdataResp.data.data, isOpen]);
  const onSubmit: SubmitHandler<EligibilityEditFormData> = async (data) => {
    try {
      const providerDataFiltered = (
        state.isScheduled === true ? odProviderData : providerData
      )?.find((e: any) => {
        return e?.uniqueId === data?.provider;
      });
      const res = await eligibility.mutateAsync(
        {
          uniqueId: state.uniqueId,
          patientId: state.patientId,
          isScheduled: state.isScheduled ?? false,
          firstName: data.firstName,
          lastName: data.lastName,
          adminId: auth?.state?.user?.userData?.userId,
          dateOfBirth: data.dateOfBirth ? data.dateOfBirth.toString() : "",
          groupId: data.groupId,
          memberId: data.memberId,
          relationship: data.relationship,
          procedureType: data.procedureType,
          procedureCode: data.procedureCode,
          provider: providerDataFiltered?.doctorName || "",
          providerNpi: providerDataFiltered?.npiId,
          providerTaxId: providerDataFiltered?.taxId,
          providerFirstName: providerDataFiltered?.doctorName
            ?.split(" ")
            ?.slice(0, 1)
            ?.join(" "),
          providerLastName: providerDataFiltered?.doctorName
            ?.split(" ")
            ?.slice(1)
            ?.join(" "),
          insurancePayer: data.insurancePayer,
          gender: data.gender === null ? "" : data.gender,
          payerIdCode:
            insurancePayerList.find(
              (item) => item.label === data.insurancePayer
            )?.value ?? (state.isScheduled ? state.payerIdCode : ""),
          dependentFirstName:
            data.relationship === "18"
              ? data.firstName
              : data.dependentFirstName,
          dependentLastName:
            data.relationship === "18" ? data.lastName : data.dependentLastName,
          dependentDateOfBirth:
            data.relationship === "18"
              ? data.dateOfBirth
                ? data.dateOfBirth.toString()
                : ""
              : data.dependentDateOfBirth
              ? data.dependentDateOfBirth.toString()
              : "",
          verificationType: "manual",
          typeOfService: data.typeOfService === null ? "" : data.typeOfService,
          practiceNameAndLoc:
            data.practiceNameAndLoc === null ? "" : data.practiceNameAndLoc,
          appointmentType:
            data.appointmentType === null ? "" : data.appointmentType,
          scheduleAppointment: data.scheduleAppointment
            ? data.scheduleAppointment.toString()
            : "",
          speciality: data.speciality,
          medical: category === "medical",
          dental: category === "dental",
          others: category === "others",
          primary: type === "primary",
          secondary: type === "secondary",
          tertiary: type === "tertiary",
          // subscriberId: data["subscriberId"],
          appointmentRenderingProvider: data.appointmentRenderingProvider,
        },
        defaultMutateOptions
      );

      props.onSuccess?.();
      res?.notificationData && notify.dispatcher({ type: "increment-count" });
      toast.success("Patient updated successfully");
      setCategory("");
      setType("");
      onClose();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };

  React.useEffect(() => {
    if (state?.isScheduled === true && isOpen && odProviderData?.length) {
      const providerDataFiltered = odProviderData?.find((e) => {
        return e?.doctorName === patientsGetById.data.data.provider;
      });
      methods.setValue("provider", providerDataFiltered?.uniqueId || "");
    }
    if (!state?.isScheduled && providerData?.length && isOpen) {
      const providerDataFiltered = providerData.find((e) => {
        return e.doctorName === patientsGetById.data.data.provider;
      });
      methods.setValue("provider", providerDataFiltered?.uniqueId || "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [providerData, odProviderData, isOpen]);

  return (
    <>
      <div
        // className="dropdown-item"
        style={{ cursor: "pointer" }}
        // onClick={toggle}
      >
        Edit
      </div>
      <Dialog
        open={isOpen}
        fullWidth
        keepMounted
        sx={{ m: 0, p: 3 }}
        onClose={onClose}
        disableEscapeKeyDown
        // aria-labelledby="customized-dialog-title"

        maxWidth={"md"}
      >
        <DialogTitle sx={{ m: 0, p: 2 }}>
          <div className="title">Edit</div>
        </DialogTitle>

        <DialogActions
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <div className="gap-2 hstack">
            {RolesPermission(ScanQrEditPermission) && (
              <QRModal
                onSuccess={(data) => {
                  const name = data
                    ?.find((singleRecord) =>
                      singleRecord.Key.toLowerCase().includes("name")
                    )
                    ?.Value?.split(" ");
                  const firstName = name?.[0];
                  const lastName = name?.[1];
                  methods.resetField("firstName", {
                    defaultValue: firstName ?? "",
                  });
                  methods.resetField("lastName", {
                    defaultValue: lastName ?? "",
                  });
                  const gender = data
                    ?.find((singleRecord) => singleRecord.Key === "gender")
                    ?.Value.toLowerCase();
                  methods.resetField("gender", {
                    defaultValue: gender ?? "",
                  });
                  const memberId = data?.find(
                    (singleRecord) => singleRecord.Key === "memberId"
                  )?.Value;
                  methods.resetField("memberId", {
                    defaultValue: memberId ?? "",
                  });
                  const groupId = data?.find(
                    (singleRecord) => singleRecord.Key === "groupId"
                  )?.Value;
                  methods.resetField("groupId", {
                    defaultValue: groupId ?? "",
                  });
                  const dateOfBirth = data?.find(
                    (singleRecord) => singleRecord.Key === "dateOfBirth"
                  )?.Value;
                  methods.resetField("dateOfBirth", {
                    defaultValue:
                      dateOfBirth !== undefined ? new Date(dateOfBirth) : null,
                  });
                }}
              />
            )}
            {RolesPermission(UploadImagesEditPermission) && (
              <UploadModal
                onSuccess={(data: any) => {
                  const name = data
                    ?.find((singleRecord: any) =>
                      singleRecord.Key.toLowerCase().includes("name")
                    )
                    ?.Value?.split(" ");

                  const firstName = name?.[0];
                  const lastName = name?.[1];
                  methods.resetField("firstName", {
                    defaultValue: firstName ?? ("" as string),
                  });
                  methods.resetField("lastName", {
                    defaultValue: lastName ?? ("" as string),
                  });
                  const gender = data
                    ?.find((singleRecord: any) => singleRecord.Key === "gender")
                    ?.Value.toLowerCase();
                  methods.resetField("gender", {
                    defaultValue: gender ?? "",
                  });
                  const memberId = data?.find(
                    (singleRecord: any) => singleRecord.Key === "memberId"
                  )?.Value;
                  methods.resetField("memberId", {
                    defaultValue: memberId ?? "",
                  });
                  const groupId = data?.find(
                    (singleRecord: any) => singleRecord.Key === "groupId"
                  )?.Value;
                  methods.resetField("groupId", {
                    defaultValue: groupId ?? "",
                  });
                  const dateOfBirth = data?.find(
                    (singleRecord: any) => singleRecord.Key === "dateOfBirth"
                  )?.Value;
                  methods.resetField("dateOfBirth", {
                    defaultValue:
                      dateOfBirth !== undefined ? new Date(dateOfBirth) : null,
                  });
                }}
              />
            )}

            <Button
              outline
              color="primary"
              onClick={() => {
                onClose();
                setCategory("");
                setType("");
              }}
            >
              Cancel
            </Button>

            <ConfirmationModal
              onClick={methods.handleSubmit(onSubmit)}
              value="Submit"
            />
          </div>
        </DialogActions>
        <FormProvider {...methods}>
          <form onSubmit={methods.handleSubmit(onSubmit, console.log)}>
            <DialogContent dividers>
              {/* <ModalBody> */}
              <h6>Subscriber Information</h6>

              <Row>
                <Col xs={12} md={4}>
                  <FirstName required />
                </Col>
                <Col xs={12} md={4}>
                  <LastName required />
                </Col>
                <Col xs={12} md={4}>
                  <DateOfBirth required />
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <MemberId required disabled />
                  ) : (
                    <MemberId required />
                  )}
                </Col>
                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <GroupId required disabled />
                  ) : (
                    <GroupId required />
                  )}
                </Col>
                <Col xs={12} md={4}>
                  <Relationship required />
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <TypeOfService disabled />
                  ) : (
                    <TypeOfService />
                  )}
                </Col>
                <Col xs={12} md={4}>
                  <React.Suspense
                    fallback={"Fetching Practice Name and Location..."}
                  >
                    {state.isScheduled ? (
                      <PracticeNameAndLocation disabled />
                    ) : (
                      <PracticeNameAndLocation />
                    )}
                  </React.Suspense>
                </Col>
                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <AppointmentType disabled />
                  ) : (
                    <AppointmentType />
                  )}
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <ScheduleAppointment disabled />
                  ) : (
                    <ScheduleAppointment />
                  )}
                </Col>
                <Col xs={12} md={4}>
                  {state.isScheduled ? <Specialty disabled /> : <Specialty />}
                </Col>

                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <Gender type="select" disabled />
                  ) : (
                    <Gender type="select" />
                  )}
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  <AppointmentRenderingProvider
                    odProvider={
                      state.isScheduled === true ? odProviderData : undefined
                    }
                  />
                </Col>
              </Row>

              <hr className="border-bottom" />
              <Row className="mb-3">
                <Col>
                  <Input
                    type="radio"
                    name="insurance-category"
                    checked={category === "medical"}
                    value="medical"
                    className="me-2"
                    onChange={(event: any) => {
                      setCategory(event.target.value);
                    }}
                  />
                  <label>Medical</label>
                </Col>
                <Col>
                  <Input
                    type="radio"
                    name="insurance-category"
                    className="me-2"
                    checked={category === "dental"}
                    value="dental"
                    onChange={(event: any) => {
                      setCategory(event.target.value);
                    }}
                  />
                  <label>Dental</label>
                </Col>
                <Col>
                  <Input
                    type="radio"
                    name="insurance-category"
                    checked={category === "others"}
                    className="me-2"
                    value="others"
                    onChange={(event: any) => {
                      setCategory(event.target.value);
                    }}
                  />
                  <label>Others</label>
                </Col>
                {category && (
                  <>
                    <Col>
                      <Input
                        type="radio"
                        name="insurance-type"
                        value="primary"
                        checked={type === "primary"}
                        className="me-2"
                        onChange={(event: any) => {
                          setType(event.target.value);
                        }}
                      />
                      <label>1</label>
                    </Col>
                    <Col>
                      <Input
                        type="radio"
                        name="insurance-type"
                        value="secondary"
                        checked={type === "secondary"}
                        className="me-2"
                        onChange={(event: any) => {
                          setType(event.target.value);
                        }}
                      />
                      <label>2</label>
                    </Col>
                    <Col>
                      <Input
                        type="radio"
                        name="insurance-type"
                        value="tertiary"
                        checked={type === "tertiary"}
                        className="me-2"
                        onChange={(event: any) => {
                          setType(event.target.value);
                        }}
                      />
                      <label>3</label>
                    </Col>
                  </>
                )}
              </Row>

              <h6>Insurance Details</h6>

              <Row>
                <Col xs={12} md={4}>
                  <ProcedureType required />
                </Col>
                <Col xs={12} md={4}>
                  <ProcedureCode
                    required
                    isScheduled={state.isScheduled}
                    isEdit
                  />
                </Col>

                <Col xs={12} md={4}>
                  <Provider
                    required
                    providerData={
                      state.isScheduled === true ? odProviderData : providerData
                    }
                  />
                </Col>
                <Col xs={12} md={4}>
                  {state.isScheduled ? (
                    <InsurancePayer required disabled />
                  ) : (
                    <InsurancePayer type="select" required />
                  )}
                </Col>
              </Row>

              {state.relationship !== "18" ? (
                <>
                  <hr />

                  <h6>Dependent Details-Patient Details</h6>

                  <Row>
                    <Col xs={12} md={4}>
                      {state.isScheduled ? (
                        <FirstName
                          name={"dependentFirstName"}
                          required
                          disabled
                        />
                      ) : (
                        <FirstName name={"dependentFirstName"} required />
                      )}
                    </Col>
                    <Col xs={12} md={4}>
                      {state.isScheduled ? (
                        <LastName
                          name={"dependentLastName"}
                          required
                          disabled
                        />
                      ) : (
                        <LastName name={"dependentLastName"} required />
                      )}
                    </Col>
                    <Col xs={12} md={4}>
                      {state.isScheduled ? (
                        <DateOfBirth
                          name={"dependentDateOfBirth"}
                          required
                          disabled
                        />
                      ) : (
                        <DateOfBirth name={"dependentDateOfBirth"} required />
                      )}
                    </Col>
                  </Row>
                </>
              ) : null}

              {/* </ModalBody> */}
            </DialogContent>
          </form>
        </FormProvider>
      </Dialog>
    </>
  );
};

export default EligibilityEditModal;
