/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation } from "@tanstack/react-query";

import { toast } from "react-toastify";

import { Button, Spinner } from "reactstrap";

import { useAuth } from "../../shared/hooks/use-auth";

import { useNotificationContext } from "../../shared/hooks/use-notification";

import { defaultMutateOptions } from "../../utils/default-mutate-options";

import Config from "../../utils/headers-config";

import {
  PatientsDeleteProps,
  PatientsDeleteResponse,
} from "./apis/patients-delete";

import { faClose } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Dialog, DialogContent, DialogTitle, IconButton } from "@mui/material";

export type DeleteModalProps = {
  onSuccess?: (() => Promise<void>) | undefined;
  state?: any;
  isOpen?: any;
  onClose?: any;
};

export const DeleteModal = (props: DeleteModalProps) => {
  const { state, isOpen, onClose, onSuccess } = props;

  const notify = useNotificationContext();

  const uniqueId = state.uniqueId;

  const auth = useAuth();
  const patientsDelete = async ({
    uniqueId,
  }: PatientsDeleteProps): Promise<PatientsDeleteResponse> => {
    const url = state.isScheduled
      ? `${
          import.meta.env.VITE_API_HOST ?? ""
        }/patients/delete?uniqueId=${uniqueId}&isScheduled=true
    `
      : `${
          import.meta.env.VITE_API_HOST ?? ""
        }/patients/delete?uniqueId=${uniqueId}
    `;

    const response = (await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsDeleteResponse;

    return response;
  };

  // const { open, toggle } = useDrawerFromLocation({
  //   matchPath: "eligibility/:id/delete",
  //   togglePath: "../../?refresh=true",
  // });

  const patients = useMutation({
    mutationKey: ["patients/delete"],
    mutationFn: patientsDelete,
  });

  const deletePatient = async () => {
    try {
      if (!uniqueId) return;

      const res = await patients.mutateAsync(
        { uniqueId, isScheduled: state.isScheduled },
        defaultMutateOptions
      );

      onSuccess?.();

      res?.notificationData && notify.dispatcher({ type: "increment-count" });

      toast.success("Patient deleted successfully");
      onClose();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <div>Delete</div>{" "}
      <Dialog open={isOpen} onClose={onClose} maxWidth="md">
        <DialogTitle className="text-white bg-primary">Delete</DialogTitle>
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
          }}
          className="text-white"
        >
          <FontAwesomeIcon icon={faClose} />
        </IconButton>
        <DialogContent className="m-auto" style={{ width: "35rem" }}>
          <p style={{ textAlign: "center" }}>
            Are you sure want to delete the details?
          </p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="primary" onClick={deletePatient}>
              {patients.isPending ? (
                <>
                  <Spinner size="sm">Deleting...</Spinner>

                  <span> Deleting...</span>
                </>
              ) : (
                <span>Yes</span>
              )}
            </Button>

            <Button outline color="secondary" onClick={onClose}>
              No
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DeleteModal;
