/* eslint-disable @typescript-eslint/no-explicit-any */
import { faAws, faGoogleDrive } from "@fortawesome/free-brands-svg-icons";
import {
  faArrowRotateRight,
  faTrash,
  faUpload,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import {
  Button,
  Card,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Form,
  Input,
  InputGroup,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
} from "reactstrap";
import { useDialogWithFormReset } from "../../shared/hooks/use-dialog-with-form-reset";
import { EligibilityModalProps } from "./eligibility-modal";
// import { Response } from "../../apis/mocks/response";
// import { faCircleCheck } from "@fortawesome/free-regular-svg-icons";
import axios from "axios";
import CSVFileValidator from "csv-file-validator";
import { isEmpty } from "lodash";
import moment from "moment";
import { useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import "./eligibility.module.scss";

export type ImportResponseData = {
  msg: string;
  addedPatients: Array<unknown>;
};
interface CsvErrorItem {
  message?: string;
}

interface AxiosError {
  response?: {
    data?: {
      error?: Array<unknown>;
      msg?: string;
    };
  };
}

export const ImportModal = (props: EligibilityModalProps) => {
  const [file, setFile] = React.useState<File | undefined | null>();
  // const [error, setError] = React.useState<Error>();
  const [csvError, setcsvError] = React.useState<unknown[]>([]);
  const [csvUploadData, setCsvUploadData] = React.useState<any[]>([]);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // const [successfulImport, setSuccessfulImport] =
  //   React.useState<ImportResponseData>();

  // const methods = useForm<ImportForm>({
  //   resolver: zodResolver(importFormSchema),
  // });

  const methods = useForm();

  const { open, toggle } = useDialogWithFormReset(methods);

  const [storageDropdown, setStorageDropdown] = React.useState(false);

  const toggleStorageDropdown = () => setStorageDropdown(!storageDropdown);

  const { state } = useLocation();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onSubmit: SubmitHandler<any> = async () => {
    try {
      if (!file) return;
      const url = import.meta.env.VITE_API_HOST;
      const response = await axios.post(
        url + "/patients/csv/upload",

        {
          patientsData: csvUploadData,
        }
      );
      toast.success(response.data.msg);
      setFile(null);
      props.onSuccess?.();
      toggle();
    } catch (error: unknown) {
      toast.error((error as AxiosError)?.response?.data?.msg);
      setcsvError((error as AxiosError)?.response?.data?.error || []);
    }
  };

  const downloadSampleCsv = async () => {
    const fileName = "Patient_upload_template";
    const url = import.meta.env.VITE_API_HOST;
    const response = await axios.get(url + "/patients/downloadsamplecsv");

    const file = new Blob([response.data], { type: "text/csv" });
    const fileURL = URL.createObjectURL(file);

    const link = document.createElement("a");
    link.href = fileURL;
    link.setAttribute("download", `${fileName}`);
    document.body.appendChild(link);
    link.click();

    URL.revokeObjectURL(fileURL);
    document.body.removeChild(link);
  };

  const templateCSVHeader = [
    { label: "First name*", key: "subscriberFirstName" },
    { label: "Last name*", key: "subscriberLastName" },
    { label: "Date of Birth*", key: "subscriberDateOfBirth" },
    { label: "Member ID/Medicaid ID*", key: "memberId" },
    { label: "Group ID*", key: "groupId" },
    { label: "Relationship*", key: "relationship" },
    { label: "Type Of Service", key: "typeOfService" },
    { label: "Practice name & Location", key: "practiceNameAndLoc" },
    { label: "Appointment Type", key: "appointmentType" },
    { label: "Appointment Date", key: "scheduleAppointment" },
    { label: "Specialty", key: "speciality" },
    { label: "Gender*", key: "gender" },
    {
      label: "Appointment Rendering Provider",
      key: "appointmentRenderingProvider",
    },
    { label: "Type of Insurance*", key: "insuranceType" },
    { label: "Procedure Type*", key: "procedureType" },
    { label: "Procedure Code*", key: "procedureCode" },
    { label: "Primary Provider", key: "provider" },
    { label: "Provider NPI ID*", key: "providerNpi" },
    { label: "Insurance Payer*", key: "insurancePayer" },
    { label: "Payer ID*", key: "payerIdCode" },
    { label: "First Name*", key: "dependentFirstName" },
    { label: "Last Name*", key: "dependentLastName" },
    { label: "Date of Birth*", key: "dependentDateOfBirth" },
  ];

  const headerConfig = () => {
    const resultArr: {
      name: string;
      inputName: string;
      required: boolean;
      requiredError: (
        headerName: any,
        rowNumber: any,
        columnNumber: any
      ) => string;
    }[] = [];
    templateCSVHeader.forEach((item) => {
      const obj = {
        name: item.label,
        inputName: item.key,
        required: [
          "groupId",
          "memberId",
          "subscriberFirstName",
          "subscriberLastName",
          "subscriberDateOfBirth",
          "relationship",
          "gender",
          "insurancePayer",
          "providerNpi",
          "payerIdCode",
          "dependentFirstName",
          "dependentLastName",
          "dependentDateOfBirth",
          "insuranceType",
          "procedureCode",
          "procedureType",
        ].includes(item.key),
        validate: function (value: any) {
          if (
            [
              "scheduleAppointment",
              "subscriberDateOfBirth",
              "dependentDateOfBirth",
            ].includes(item.key)
          ) {
            const date = value.trimEnd();
            const isValidDate = moment(date, "MM-DD-YYYY", true).isValid();
            return isValidDate;
          } else return true;
        },
        validateError: function (
          headerName: any,
          rowNumber: any,
          columnNumber: any
        ) {
          return `${headerName} in row ${rowNumber} / column ${columnNumber} should be "MM-DD-YYYY" format.`;
        },
        requiredError: function (
          headerName: any,
          rowNumber: any,
          columnNumber: any
        ) {
          return `${headerName} is required in the row ${rowNumber} / column ${columnNumber} `;
        },
      };
      resultArr.push(obj);
    });
    return resultArr;
  };

  const csvHeaderConfig = headerConfig();

  const handleCsvValidation = (file: File | undefined) => {
    const config = {
      headers: csvHeaderConfig, // required
      isHeaderNameOptional: false, // default (optional)
    };

    if (file) {
      const reader = new FileReader();
      reader.onload = async (e: ProgressEvent<FileReader>) => {
        let text = "";
        if (e.target) {
          text = e.target.result as string;
        }

        let rows = text.split(/\r?\n/);

        rows = rows.slice(1);

        rows = rows.filter((row) =>
          row.split(",").some((cell) => cell.trim() !== "")
        );

        const notesIndex = rows.findIndex((row) =>
          row.trim().includes("Notes")
        );

        const csvData =
          notesIndex !== -1
            ? rows.slice(0, notesIndex).join("\n")
            : rows.join("\n");

        try {
          const res = await CSVFileValidator(csvData, config);
          setCsvUploadData(res.data);
          setcsvError(res.inValidData);
        } catch (error) {
          console.log(error);
        }
      };
      reader.readAsText(file);
    }
  };

  const errorContent = () => {
    if (!isEmpty(csvError)) {
      return (
        <>
          <h6 className="text-center warning">
            {csvError.length} Errors Found
          </h6>{" "}
          <br />
          <div className="upload-patient-error-container">
            {file?.type === "text/csv" ? (
              <>
                {csvError.map((item, index) => {
                  const errorItem = item as CsvErrorItem;
                  return (
                    <>
                      <span key={index} className="warning">
                        {index + 1}. *{errorItem?.message ?? ""}
                      </span>
                      <br />
                      <br />
                    </>
                  );
                })}
              </>
            ) : (
              <span className="warning">
                *Invalid format!, Please upload .csv file
              </span>
            )}
          </div>
        </>
      );
    }
  };

  return (
    <>
      {!state?.isHistory && (
        <Button
          outline
          color="primary"
          onClick={() => {
            toggle();
            setFile(null);
          }}
        >
          Import
        </Button>
      )}

      <Modal
        isOpen={open}
        toggle={() => {
          toggle();
          setFile(null);
        }}
        backdrop
        keyboard
        size="lg"
      >
        <ModalHeader
          toggle={() => {
            toggle();
            setFile(null);
          }}
        >
          <div className="title">Import</div>
        </ModalHeader>

        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
            {file ? (
              <ModalBody>
                {file && (
                  <>
                    <div className="import-modal-confirmation d-flex justify-content-between">
                      <div>
                        <h6>{file?.name}</h6>
                        <p>{file?.size} bytes</p>
                        {csvUploadData.length > 0 && !(csvError?.length > 0) ? (
                          <p className="text-success">
                            {csvUploadData.length} Data(s) is ready for upload
                            !!!
                          </p>
                        ) : (
                          <p className="text-danger">
                            *Csv file is either empty or has invalid data
                          </p>
                        )}
                      </div>
                      <div>
                        <span
                          className="text-success"
                          onClick={() => setFile(null)}
                        >
                          <FontAwesomeIcon
                            icon={faArrowRotateRight}
                            fontSize={14}
                          />{" "}
                          Reupload
                        </span>{" "}
                        <span
                          className="text-danger"
                          onClick={() => setFile(null)}
                        >
                          {" "}
                          <FontAwesomeIcon icon={faTrash} fontSize={14} />{" "}
                          Delete
                        </span>
                      </div>
                    </div>
                    <div className="import-modal-error">
                      {!isEmpty(csvError) && errorContent()}
                    </div>
                  </>
                )}
              </ModalBody>
            ) : (
              <ModalBody>
                <div className="vstack gap-3">
                  <div className="ms-auto">
                    <a href="#" onClick={() => downloadSampleCsv()}>
                      Download sample template
                    </a>
                  </div>

                  <label className="w-100">
                    <Card
                      className="bg-primary-subtle"
                      style={{
                        border: `2px dashed #06AB89`,
                      }}
                    >
                      <div className="hstack justify-content-center m-5 gap-2">
                        <FontAwesomeIcon icon={faUpload} />
                        <div>Upload CSV</div>
                      </div>
                    </Card>

                    <input
                      type="file"
                      className="d-none"
                      onChange={(event) => {
                        const acceptedFile = event.target.files?.[0];
                        setFile(acceptedFile);
                        handleCsvValidation(acceptedFile);
                      }}
                      accept=".csv"
                    />
                  </label>

                  <InputGroup className="w-100">
                    <Dropdown
                      isOpen={storageDropdown}
                      toggle={toggleStorageDropdown}
                      direction={"down"}
                    >
                      <DropdownToggle outline caret>
                        <FontAwesomeIcon
                          icon={faGoogleDrive}
                          className="me-2"
                        />
                        Gdrive
                      </DropdownToggle>
                      <DropdownMenu>
                        <DropdownItem>
                          <FontAwesomeIcon icon={faAws} className="me-2" />
                          AWS S3 Bucket
                        </DropdownItem>
                      </DropdownMenu>
                    </Dropdown>

                    <Input placeholder="Ex: https://drive.google.com/drive/u/0/my-drive" />
                  </InputGroup>
                </div>
              </ModalBody>
            )}
          </Form>
        </FormProvider>

        {/* {successfulImport ? (
          <div className="w-100 text-center">
            <FontAwesomeIcon
              icon={faCircleCheck}
              className="text-success"
              fontSize={32}
            />
            <h5>Successfully Imported</h5>
            <p>Your file has successfully imported</p>
            <Button onClick={toggle}>Got it</Button>
          </div>
        ) : (
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              {file ? (
                <ModalBody>
                  {file && (
                    <>
                      <div className="import-modal-confirmation d-flex justify-content-between">
                        <div>
                          <h6>{file?.name}</h6>
                          <p>{file?.size} bytes</p>
                        </div>
                        <div>
                          <span
                            className="text-success"
                            onClick={() => setFile(null)}
                          >
                            <FontAwesomeIcon
                              icon={faArrowRotateRight}
                              fontSize={14}
                            />{" "}
                            Reupload
                          </span>{" "}
                          <span
                            className="text-danger"
                            onClick={() => setFile(null)}
                          >
                            {" "}
                            <FontAwesomeIcon
                              icon={faTrash}
                              fontSize={14}
                            />{" "}
                            Delete
                          </span>
                        </div>
                      </div>
                      <div className="import-modal-error">
                        {!isEmpty(csvError) && errorContent()}
                      </div>
                    </>
                  )}
                </ModalBody>
              ) : (
                <ModalBody>
                  <div className="vstack gap-3">
                    <div className="ms-auto">
                      <a href="" target="_blank">
                        Download sample template
                      </a>
                    </div>

                    <label className="w-100">
                      <Card
                        className="bg-primary-subtle"
                        style={{
                          border: `2px dashed #06AB89`
                        }}
                      >
                        <div className="hstack justify-content-center m-5 gap-2">
                          <FontAwesomeIcon icon={faUpload} />
                          <div>Upload CSV</div>
                        </div>
                      </Card>

                      <input
                        type="file"
                        className="d-none"
                        onChange={(event) => {
                          const acceptedFile = event.target.files?.[0];
                          setFile(acceptedFile);
                          handleCsvValidation(acceptedFile);
                        }}
                        accept=".csv"
                      />
                    </label>

                    <InputGroup className="w-100">
                      <Dropdown
                        isOpen={storageDropdown}
                        toggle={toggleStorageDropdown}
                        direction={"down"}
                      >
                        <DropdownToggle outline caret>
                          <FontAwesomeIcon
                            icon={faGoogleDrive}
                            className="me-2"
                          />
                          Gdrive
                        </DropdownToggle>
                        <DropdownMenu>
                          <DropdownItem>
                            <FontAwesomeIcon icon={faAws} className="me-2" />
                            AWS S3 Bucket
                          </DropdownItem>
                        </DropdownMenu>
                      </Dropdown>

                      <Input placeholder="Ex: https://drive.google.com/drive/u/0/my-drive" />
                    </InputGroup>
                  </div>
                </ModalBody>
              )}
            </Form>
          </FormProvider>
        )} */}

        <ModalFooter>
          <div className="hstack gap-2">
            <Button
              outline
              color="primary"
              onClick={() => {
                toggle();
                setFile(null);
              }}
            >
              Cancel
            </Button>

            <Button
              color="primary"
              className="text-white"
              onClick={methods.handleSubmit(onSubmit)}
              disabled={csvError.length > 0 || csvUploadData.length === 0}
            >
              Upload
            </Button>
          </div>
        </ModalFooter>
      </Modal>
    </>
  );
};

export default ImportModal;
