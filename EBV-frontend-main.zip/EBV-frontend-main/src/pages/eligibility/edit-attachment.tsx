import { faTrash, faUpload } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form, Location, useLocation, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Spinner,
} from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { base64ToFile } from "../../utils/base64-file-format";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import Config from "../../utils/headers-config";
import { AttachmentForm, attachmentFormSchema } from "./add-attachment";
import {
  PatientAttachment,
  PatientsAttachmentsResponse,
} from "./apis/patients-attachment-all";
import {
  PatientsAttachmentDeleteProps,
  PatientsAttachmentDeleteResponse,
} from "./apis/patients-attachment-delete";
import { PatientsAttachmentsUpdateProps } from "./apis/patients-attachment-update";
import {
  PatientsAttachmentsAddProps,
  convertBase64,
} from "./apis/patients-attachments-add";
import Description from "./form/fields/description";
import FileName from "./form/fields/file-name";

export const EditAttachment = () => {
  const { state } = useLocation() as Location<
    PatientAttachment & { onSuccess?: () => Promise<void> }
  >;
  const auth = useAuth();
  const [file, setFile] = React.useState<File | undefined>(
    base64ToFile(
      state.base64File,
      state.fileName +
        "." +
        state.base64File?.split(";")[0].replace("data:", "")?.split("/")[1],
      state.base64File?.split(";")[0].replace("data:", "")
    )
  );

  const patientsAttachmentDelete = async ({
    uniqueId,
  }: PatientsAttachmentDeleteProps): Promise<PatientsAttachmentDeleteResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/attachments/${uniqueId}`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
        method: "DELETE",
      })
    ).json()) as PatientsAttachmentDeleteResponse;

    return response;
  };

  const patientsAttachmentsAdd = async (
    props: PatientsAttachmentsAddProps
  ): Promise<PatientsAttachmentsResponse> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/attachments/${
      props.body.patientId
    }`;

    const bodyData = {
      patientId: props.body.patientId,
      fileName: props.body.fileName,
      description: props.body.description,
      isPatientCard: props.body.isPatientCard,
      base64File: await convertBase64(props.body.files),
    };

    const response = (await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(bodyData),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsAttachmentsResponse;

    return response;
  };

  const patientsAttachmentsUpdate = async (
    props: PatientsAttachmentsUpdateProps
  ): Promise<PatientsAttachmentsResponse> => {
    await patientsAttachmentDelete({ uniqueId: props.uniqueId });
    return patientsAttachmentsAdd({ body: props.body });
  };

  const [error, setError] = React.useState<Error>();

  const methods = useForm<AttachmentForm>({
    resolver: zodResolver(attachmentFormSchema),
    defaultValues: { fileName: state.fileName, description: state.description },
  });

  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/:id/attachments/:attachmentId/edit",
    togglePath: "../..",
  });

  const attachments = useMutation({
    mutationKey: ["attachment", "update"],
    mutationFn: patientsAttachmentsUpdate,
  });

  const queryClient = useQueryClient();

  const { id: patientId, attachmentId: uniqueId } = useParams() as {
    id: string;
    attachmentId: string;
  };

  const onSubmit: SubmitHandler<AttachmentForm> = async (data) => {
    try {
      if (!file) throw new Error("No file selected");

      await attachments.mutateAsync(
        {
          body: {
            description: data.description,
            fileName: data.fileName,
            files: file,
            patientId,
            isPatientCard: true,
          },
          uniqueId,
        },
        defaultMutateOptions
      );

      state.onSuccess?.();

      toast.success("Attachment updated successfully");
      toggle();
      await queryClient.invalidateQueries({
        queryKey: [`patients/${patientId}/attachments`],
      });
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
      setError(error as Error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["attachment", "getAll"],
      });
    }
  };

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "40%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Edit
        </OffcanvasHeader>
        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="gap-3 vstack">
                <FileName required />

                <Description required />

                <label className="mb-3 w-100">
                  <Card
                    className="bg-primary-subtle"
                    style={{
                      border: `2px dashed #06AB89`,
                    }}
                  >
                    <div className="gap-2 m-5 d-flex justify-content-center center ">
                      <FontAwesomeIcon icon={faUpload} /> Drag & Drop here
                      <div>or</div>
                      <div style={{ color: "blue" }}>Browse File</div>
                    </div>
                  </Card>

                  <input
                    type="file"
                    multiple
                    className="d-none"
                    onChange={(event) => {
                      if (event.target.files?.[0])
                        setFile(event.target.files?.[0]);
                    }}
                  />
                  {error && <p>Error uploading file: {error.message}</p>}
                </label>

                <div className="gap-3 vstack">
                  {file
                    ? [file].map((file) => (
                        <Card key={file.name}>
                          <CardBody>
                            <div className="hstack justify-content-between">
                              <div>
                                <div>{file.name}</div>
                                <div className="text-secondary">
                                  {file.size} bytes
                                </div>
                              </div>

                              <div>
                                <Button
                                  color="link"
                                  className="p-0 rounded-circle text-danger"
                                  onClick={() => setFile(undefined)}
                                >
                                  <FontAwesomeIcon icon={faTrash} />
                                </Button>
                              </div>
                            </div>
                          </CardBody>
                        </Card>
                      ))
                    : null}
                </div>

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>

                  <Button color="primary" className="text-white" type="submit">
                    {attachments.isPending ? (
                      <>
                        <Spinner size="sm">Uploading...</Spinner>
                        <span> Uploading...</span>
                      </>
                    ) : (
                      <span>Save</span>
                    )}
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export default EditAttachment;
