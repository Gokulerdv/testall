/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCalendarDays,
  faChevronDown,
  faRefresh,
  faSearch,
  faSortDown,
  faSortUp,
  faTableColumns,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import {
  ColumnFiltersState,
  FilterFn,
  PaginationState,
  RowSelectionState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import { capitalCase } from "change-case";
import React, { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { usePDF } from "react-to-pdf";
import { toast } from "react-toastify";
import {
  Button,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  FormGroup,
  Input,
  InputGroupText,
  Label,
  Spinner,
  UncontrolledDropdown,
} from "reactstrap";
import Filter, { convertDateToDDMMYYYY } from "../../../components/filter";
import LoadingIndicator from "../../../components/loading-indicator";
import { useAuth } from "../../../shared/hooks/use-auth";
import {
  BulkActionViewPermission,
  ExcelVerificationCreatePermission,
  ManualVerificationCreateermission,
  ScheduleVerificationCreatePermission,
  ScheduleVerificationDeletePermission,
} from "../../../utils/constant";
import { dateStringFormat } from "../../../utils/date-string-format";
import { Config } from "../../../utils/headers-config";
import { RolesPermission } from "../../../utils/role-permission";
import {
  Deductible,
  LimitationAndMaximum,
} from "../../patient-benefit-information/apis/eligibility-get";
import { Patient, PatientsAllResponse } from "../apis/patients-all";
import EligibilityModal from "../eligibility-modal";
import ImportModal from "../import-modal";
import {
  appointmentRenderingProviderColumnHeader,
  dateOfBirthColumnHeader,
  defaultColumns,
  insurancePayerCodeColumnHeader,
  procedureCodeColumnHeader,
  procedureTypeColumnHeader,
  specialtyColumnHeader,
  subscriberIdColumnHeader,
} from "./columns";
import Pagination from "./pagination";

const defaultColumnVisibility = {
  [specialtyColumnHeader]: false,
  [dateOfBirthColumnHeader]: false,
  [subscriberIdColumnHeader]: false,
  [appointmentRenderingProviderColumnHeader]: false,
  [insurancePayerCodeColumnHeader]: false,
  [procedureCodeColumnHeader]: false,
  [procedureTypeColumnHeader]: false,
} as VisibilityState;

export const Table = () => {
  const [columnVisibility, setColumnVisibility] = React.useState({
    ...defaultColumnVisibility,
  });
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [rowSelection, setRowSelection] = React.useState<RowSelectionState>({});
  const [globalFilter, setGlobalFilter] = React.useState("");
  const [selectedDate, setSelectedDate] = React.useState<Date | null>(
    new Date()
  );
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [pagination, setPagination] = React.useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const refresh = searchParams.get("refresh");
  const download = searchParams.get("download");
  const { toPDF, targetRef } = usePDF({ filename: "page.pdf" });
  const isFirstLoad = React.useRef(true);
  const { state } = useLocation();
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;

  const patientsAll = async (search: string): Promise<PatientsAllResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/getallpatients${search}&adminId=${userId}`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsAllResponse;

    return {
      ...response,
      data: response.data.map((eligibility: any) => {
        const dentalXchangeResponse = eligibility.remainingBenefits;

        const actualResponseData = {
          ...eligibility,
          dentalXchangeResponse,
        };

        const processedDeductible = [
          ...(actualResponseData?.remainingBenefits?.deductible
            ? typeof actualResponseData?.remainingBenefits?.deductible ===
              "string"
              ? (JSON.parse(
                  actualResponseData.remainingBenefits
                    .deductible as unknown as string
                ) as Deductible[])
              : (actualResponseData?.remainingBenefits
                  ?.deductible as Deductible[])
            : []),
        ].reduce(
          (acc, deductible) => acc.add(deductible?.amount as string),
          new Set<string>()
        );

        const processedLimitationsAndMaximum = [
          ...(actualResponseData.remainingBenefits?.limitationAndMaximum
            ? typeof actualResponseData?.remainingBenefits
                ?.limitationAndMaximum === "string"
              ? (JSON.parse(
                  actualResponseData.remainingBenefits
                    .limitationAndMaximum as unknown as string
                ) as LimitationAndMaximum[])
              : (actualResponseData?.remainingBenefits
                  ?.limitationAndMaximum as LimitationAndMaximum[])
            : []),
        ].reduce(
          (acc, deductible) => acc.add(deductible?.amount as string),
          new Set<string>()
        );

        return {
          ...eligibility,
          deductible:
            processedDeductible.size === 1
              ? parseFloat(Array.from(processedDeductible?.values())[0])
              : processedDeductible.size === 0
              ? null
              : "5",
          insuranceStatus: eligibility?.effectiveDateFrom
            ? "active"
            : "inactive",
          limitationsAndMaximum:
            processedLimitationsAndMaximum.size === 1
              ? parseFloat(
                  Array.from(processedLimitationsAndMaximum?.values())[0]
                )
              : processedLimitationsAndMaximum.size === 0
              ? null
              : "6",
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } as any;
      }),
    };
  };

  const eligibilities = useSuspenseQuery({
    queryKey: ["patients/all", state, userId],
    queryFn: async () =>
      await patientsAll(
        `${
          state
            ? `?isHistory=${state.isHistory}&adminId=${userId}`
            : `?adminId=${userId}`
        }`
      ),
  });

  const bulkVerify = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/bulkverify`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const cronODPatients = async (): Promise<void> => {
    await Promise.all(
      [
        "/opendental/appointment/all",
        "/opendental/patient/all",
        "/opendental/appointmenttypes/all",
        "/opendental/clinics/all",
        "/opendental/patplans/all",
        "/opendental/inssubs/all",
        "/opendental/procedurecode/all",
        "/opendental/familymodules/all",
        "/opendental/providers/all",
        "/opendental/carriers/all",
        "/opendental/insplans/all",
        "/opendental/procedurelogs/all",
      ].map((url) => fetch(`${import.meta.env.VITE_API_HOST ?? ""}${url}`))
    );

    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/schedulepatient/create?adminId=${userId}`;

    await (
      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return;
  };

  const odPatients = useMutation({
    mutationKey: ["cron", "od", "patients"],
    mutationFn: cronODPatients,
  });

  const queryClient = useQueryClient();

  const handleRefreshOdPatients = React.useCallback(async () => {
    try {
      await odPatients.mutateAsync();

      toast.success("OpenDental patients successfully fetched");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  }, [odPatients, queryClient]);

  React.useEffect(() => {
    if (download === "pdf" && isFirstLoad.current) {
      toPDF();
      isFirstLoad.current = false;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [download]);

  useEffect(() => {
    (async () => {
      if (refresh) {
        await eligibilities.refetch();
        setSearchParams({});
      }
    })();
  }, [eligibilities, refresh, setSearchParams]);

  const onSuccess = React.useCallback(async () => {
    await eligibilities.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const data = React.useMemo(() => {
    // return z.array(eligibilitySchema).parse(eligibilities.data.data);
    return eligibilities.data.data;
  }, [eligibilities.data.data]);

  const customGlobalFilterFn: FilterFn<Patient> = (
    row,
    columnIds,
    filterValue
  ) => {
    const nonSearchColumnsIds = [
      ...Object.entries(columnVisibility)
        .filter(([, value]) => value === false)
        .map(([key]) => key),
      "payerLogo",
      "lastVerified",
    ];
    if (nonSearchColumnsIds.includes(columnIds)) {
      return false;
    } else {
      const value = row.getValue(columnIds);
      return (
        value !== undefined &&
        String(value).toLowerCase().includes(filterValue.toLowerCase())
      );
    }
  };

  const table = useReactTable({
    columns: defaultColumns,
    enableRowSelection: true,
    onRowSelectionChange: setRowSelection,
    getRowId: (row) => row.uniqueId,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: data as any,
    state: {
      columnVisibility,
      columnFilters,
      sorting,
      pagination,
      globalFilter,
      rowSelection,
    },
    globalFilterFn: customGlobalFilterFn,
    onColumnVisibilityChange: setColumnVisibility,
    onColumnFiltersChange: setColumnFilters,
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),

    debugTable: true,
  });

  const settingsGetById = (adminid: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/generalSettings/get/${adminid}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const patientBulkVerify = useMutation({
    mutationKey: ["patients/bulkverify"],
    mutationFn: bulkVerify,
  });

  const verifypatientUtils = useSuspenseQuery({
    queryKey: ["verifyPatient", "get", `${userId}`],
    queryFn: settingsGetById(`${userId}`),
  });

  const selectedRows = table
    .getSelectedRowModel()
    .rows.map((data) => data.original);

  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);

  useEffect(() => {
    const verifiedPatients = selectedRows.filter(
      (data: any) =>
        data.lastVerified &&
        new Date().getTime() <
          new Date(
            new Date().setFullYear(
              new Date(data.lastVerified).getFullYear(),
              new Date(data.lastVerified).getMonth(),
              new Date(data.lastVerified).getDate() +
                verifypatientUtils?.data?.data?.warningdays
            )
          ).getTime()
    );
    setFilteredPatients(verifiedPatients);
  }, [table.getSelectedRowModel().rows]);

  const handleBulkPdf = () => {
    navigate(`20/bulk-pdf-warning`, {
      state: selectedRows,
    });
  };
  const handleBulkCsv = () => {
    navigate(`20/bulk-csv-warning`, {
      state: selectedRows,
    });
  };
  const handleBulkExclude = () => {
    navigate(`20/bulk-exclude-warning`, {
      state: selectedRows,
    });
  };
  const handleBulkVerify = () => {
    if (filteredPatients.length >= 0) {
      navigate(`20/bulk-verify-warning`, {
        state: selectedRows,
      });
    } else {
      try {
        patientBulkVerify.mutateAsync({
          ids: filteredPatients.map((data: any) => ({
            uniqueId: data.uniqueId,
            isScheduled: data.isScheduled,
            adminId: auth?.state?.user?.userData?.userId,
          })),
        });

        toast.success("Patients verified Successfully");

        setSearchParams({ refresh: String(true) });
      } catch (error) {
        toast.error("Patient verification failed!");
        console.log(error);
      }
    }
  };

  const handleClearGlobalFilter = () => {
    setGlobalFilter("");
    setSelectedDate(null);
  };

  return (
    <div className="table-responsive" ref={targetRef}>
      {import.meta.env.DEV || false ? (
        <ReactTableDevtools initialIsOpen table={table} />
      ) : null}
      <table className="table mb-0 table-striped table-hover table-borderless">
        <thead>
          <tr>
            <th colSpan={table.getVisibleLeafColumns().length} className="p-0">
              <div className="p-3 hstack justify-content-between border-bottom">
                <div className="gap-2 hstack " style={{ width: "40%" }}>
                  <div className="input-group ">
                    <div className="input-group-text">
                      <FontAwesomeIcon icon={faSearch} />
                    </div>

                    <Input
                      value={globalFilter ?? ""}
                      onChange={(e) => setGlobalFilter(e.target.value)}
                      placeholder="Search content"
                      style={{ width: "100px !important" }}
                    />
                    {globalFilter && (
                      <InputGroupText>
                        <FontAwesomeIcon
                          icon={faXmark}
                          onClick={handleClearGlobalFilter}
                        />
                      </InputGroupText>
                    )}
                  </div>
                  <UncontrolledDropdown direction="end">
                    <DropdownToggle data-toggle="dropdown" tag="span">
                      <Button
                        outline={table.getState().columnFilters.length === 0}
                        color="primary"
                      >
                        Filters
                      </Button>
                    </DropdownToggle>

                    <DropdownMenu style={{ minWidth: "18.5625rem" }}>
                      <DropdownItem toggle={false} text className="m-0">
                        Filters
                      </DropdownItem>

                      <DropdownItem divider />
                      {/* I have hide the appointment,lastVerified,dateOfBirth filter value in here */}
                      {table.getHeaderGroups().map((headerGroup) => (
                        <React.Fragment key={headerGroup.id}>
                          {headerGroup.headers.map((header) => (
                            <React.Fragment key={header.id}>
                              {header.isPlaceholder ? null : (
                                <>
                                  {header.column.getCanFilter() ? (
                                    header.id === "scheduleAppointment" ||
                                    header.id === "lastVerified" ||
                                    header.id === "Date of Birth" ||
                                    header.id === "payerLogo" ? null : (
                                      <DropdownItem toggle={false}>
                                        <div className="mb-1 d-flex flex-column">
                                          <Label>
                                            {header.column.columnDef.header &&
                                            typeof header.column.columnDef
                                              .header === "string"
                                              ? header.column.columnDef.header
                                              : capitalCase(header.column.id)}
                                          </Label>
                                          <Filter
                                            column={header.column}
                                            table={table}
                                          />
                                        </div>
                                      </DropdownItem>
                                    )
                                  ) : null}
                                </>
                              )}
                            </React.Fragment>
                          ))}
                        </React.Fragment>
                      ))}
                    </DropdownMenu>
                  </UncontrolledDropdown>

                  <DatePicker
                    className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom"
                    selected={selectedDate}
                    showIcon
                    icon={<FontAwesomeIcon icon={faCalendarDays} />}
                    calendarIconClassname="text-primary"
                    isClearable
                    onChange={(event: any) => {
                      if (!event) {
                        setSelectedDate(null);
                        setGlobalFilter("");
                      } else {
                        setSelectedDate(event);
                        setGlobalFilter(
                          `${convertDateToDDMMYYYY(dateStringFormat(event))}`
                        );
                      }
                    }}
                  />

                  <Button
                    color="#E6F7F3"
                    style={{
                      backgroundColor: "#E6F7F3",
                      color: "var(--bs-primary)",
                      borderColor: "#E6F7F3",
                    }}
                    disabled={odPatients.isPending}
                    onClick={handleRefreshOdPatients}
                  >
                    {odPatients.isPending ? (
                      <Spinner size="sm">Refetching...</Spinner>
                    ) : (
                      <FontAwesomeIcon icon={faRefresh} />
                    )}
                  </Button>
                </div>

                <div className="gap-2 hstack">
                  <UncontrolledDropdown direction="start">
                    <DropdownToggle data-toggle="dropdown" tag="span">
                      <Button
                        style={{
                          backgroundColor: "#E6F7F3",
                          color: "var(--bs-primary)",
                          borderColor: "#E6F7F3",
                        }}
                      >
                        <p className="gap-2 mb-0 hstack">
                          <FontAwesomeIcon icon={faTableColumns} />

                          <span className="mb-0">Columns</span>
                        </p>
                      </Button>
                    </DropdownToggle>

                    <DropdownMenu>
                      <DropdownItem toggle={false} text className="m-0">
                        Edit Columns
                      </DropdownItem>

                      <DropdownItem divider className="" />

                      <DropdownItem
                        toggle={false}
                        onClick={table.getToggleAllColumnsVisibilityHandler()}
                      >
                        <FormGroup check>
                          <Input
                            type="checkbox"
                            checked={table.getIsAllColumnsVisible()}
                            onChange={table.getToggleAllColumnsVisibilityHandler()}
                          />
                          <Label check>Toggle All</Label>
                        </FormGroup>
                      </DropdownItem>

                      {table.getAllLeafColumns().map((column) => {
                        return (
                          <React.Fragment key={column.id}>
                            {column.id === "lastVerifiedDate" ||
                            column.id === "scheduleAppointmentDate" ||
                            column.id === "dateOfBirthDate" ? null : (
                              <>
                                <DropdownItem divider className="m-0" />

                                <DropdownItem
                                  toggle={false}
                                  onClick={column.getToggleVisibilityHandler()}
                                >
                                  <FormGroup check>
                                    <Input
                                      type="checkbox"
                                      checked={column.getIsVisible()}
                                      onChange={column.getToggleVisibilityHandler()}
                                    />
                                    <Label check>
                                      {column.columnDef.header &&
                                      typeof column.columnDef.header ===
                                        "string"
                                        ? column.columnDef.header
                                        : capitalCase(column.id)}
                                    </Label>
                                  </FormGroup>
                                </DropdownItem>
                              </>
                            )}
                          </React.Fragment>
                        );
                      })}
                    </DropdownMenu>
                  </UncontrolledDropdown>
                  {RolesPermission(BulkActionViewPermission) &&
                  selectedRows.length < 2 ? (
                    <Button
                      color="primary"
                      outline
                      disabled
                      style={{ textWrap: "nowrap" }}
                    >
                      Bulk Action
                    </Button>
                  ) : (
                    <UncontrolledDropdown>
                      <DropdownToggle data-toggle="dropdown" tag="span">
                        <Button
                          color="primary"
                          outline
                          style={{ textWrap: "nowrap" }}
                        >
                          Bulk Action <FontAwesomeIcon icon={faChevronDown} />
                        </Button>
                      </DropdownToggle>

                      <DropdownMenu>
                        <DropdownItem onClick={handleBulkCsv}>CSV</DropdownItem>

                        <DropdownItem onClick={handleBulkPdf}>PDF</DropdownItem>
                        {RolesPermission(
                          ScheduleVerificationCreatePermission
                        ) && (
                          <DropdownItem onClick={handleBulkVerify}>
                            Verify Now
                          </DropdownItem>
                        )}
                        {RolesPermission(
                          ScheduleVerificationDeletePermission
                        ) && (
                          <DropdownItem onClick={handleBulkExclude}>
                            Exclude
                          </DropdownItem>
                        )}
                      </DropdownMenu>
                    </UncontrolledDropdown>
                  )}
                  {RolesPermission(ExcelVerificationCreatePermission) && (
                    <ImportModal onSuccess={onSuccess} />
                  )}

                  {RolesPermission(ManualVerificationCreateermission) && (
                    <EligibilityModal onSuccess={onSuccess} />
                  )}
                </div>
              </div>
            </th>
          </tr>

          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) =>
                header.id === "lastVerifiedDate" ||
                header.id === "dateOfBirthDate" ||
                header.id === "scheduleAppointmentDate" ? null : (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    className="border-bottom"
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        {...{
                          className: "hstack align-items-center",
                          style: header.column.getCanSort()
                            ? {
                                cursor: "pointer",
                                userSelect: "none",
                              }
                            : undefined,
                          onClick: header.column.getToggleSortingHandler(),
                        }}
                      >
                        <span style={{ maxWidth: "fit-content" }}>
                          {flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                        </span>

                        {header.column.getCanSort() ? (
                          <span
                            className="vstack justify-content-center align-items-center ms-2"
                            style={{
                              maxWidth: "min-content",
                            }}
                          >
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "asc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortUp}
                              style={{ marginBottom: "-1rem" }}
                            />
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "desc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortDown}
                            />
                          </span>
                        ) : null}
                      </div>
                    )}
                  </th>
                )
              )}
            </tr>
          ))}
        </thead>

        <tbody>
          {table.getRowModel().rows.length === 0 ? (
            <tr>
              <td colSpan={24} style={{ textAlign: "center" }}>
                There are no records to display
              </td>
            </tr>
          ) : null}
          {!eligibilities.isRefetching
            ? table.getRowModel().rows.map((row) => (
                <tr key={row.id}>
                  {row.getVisibleCells().map((cell) => {
                    return cell.column.id === "dateOfBirthDate" ||
                      cell.column.id === "lastVerifiedDate" ||
                      cell.column.id === "scheduleAppointmentDate" ? null : (
                      <td
                        key={cell.id}
                        style={{
                          backgroundColor:
                            row.original.statusflag === "I"
                              ? "rgba(0, 0, 0, 0.2)"
                              : "initial",
                        }}
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))
            : null}

          <tr>
            <td
              colSpan={table.getVisibleLeafColumns().length || 1}
              scope="row"
              className="p-0"
              style={{
                height: eligibilities.isRefetching
                  ? `${10 * 2.65}rem`
                  : table.getVisibleLeafColumns().length
                  ? `${(10 - table.getRowModel().rows.length) * 2.65}rem`
                  : `${11 * 2.65}rem`,
              }}
            >
              {eligibilities.isRefetching ? <LoadingIndicator /> : null}
            </td>
          </tr>
        </tbody>

        <Pagination table={table} />
      </table>
    </div>
  );
};
