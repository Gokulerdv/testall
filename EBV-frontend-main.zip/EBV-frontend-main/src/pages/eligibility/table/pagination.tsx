import usePagination from "@mui/material/usePagination";
import { Table as ReactTable } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import { Button, FormGroup, Input, Label } from "reactstrap";
import styles from "../eligibility.module.scss";

export type PaginationProps = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  table: ReactTable<any>;
};

export const Pagination = ({ table }: PaginationProps) => {
  const { items } = usePagination({
    count: table.getPageCount(),
  });

  return (
    <tfoot>
      <td colSpan={table.getVisibleLeafColumns().length} scope="row">
        <div className="border-top p-3">
          <nav className="hstack justify-content-between">
            <FormGroup className="w-100">
              <Label for="items-per-page">Items per page</Label>

              <Input
                id="items-per-page"
                name="select"
                type="select"
                className="d-inline-block w-auto mx-2"
                onChange={(event) =>
                  table.setPageSize(parseInt(event.target.value, 10))
                }
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={30}>30</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
                <option value={500}>500</option>
                <option value={1000}>1000</option>
              </Input>

              <span>to 1000</span>
            </FormGroup>

            <ul className={styles["pagination-list"]}>
              {items.map(({ page, type, selected, ...item }, index) => {
                let children = null;

                if (type === "start-ellipsis" || type === "end-ellipsis") {
                  children = "…";
                } else if (type === "page") {
                  children = (
                    <Button
                      color={selected ? "primary" : "secondary"}
                      outline
                      className={selected ? "" : "border-0"}
                      type="button"
                      {...item}
                      onClick={(args) => {
                        item.onClick(args);
                        if (!page) return table.setPageIndex(0);
                        return table.setPageIndex(page - 1);
                      }}
                    >
                      {page}
                    </Button>
                  );
                } else {
                  if (type === "next")
                    children = table.getCanNextPage() ? (
                      <Button
                        type="button"
                        outline
                        color="primary"
                        className="border-0"
                        {...item}
                        onClick={(event) => {
                          item.onClick(event);
                          table.nextPage();
                        }}
                      >
                        {capitalCase(type)}
                      </Button>
                    ) : null;
                  else if (type === "previous")
                    children = table.getCanPreviousPage() ? (
                      <Button
                        type="button"
                        outline
                        color="primary"
                        className="border-0"
                        {...item}
                        onClick={(event) => {
                          item.onClick(event);
                          table.previousPage();
                        }}
                      >
                        {capitalCase(type)}
                      </Button>
                    ) : null;
                  else
                    children = (
                      <Button type="button" {...item}>
                        {type}
                      </Button>
                    );
                }

                return (
                  <li key={index} className="px-1">
                    {children}
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>
      </td>
    </tfoot>
  );
};

export default Pagination;
