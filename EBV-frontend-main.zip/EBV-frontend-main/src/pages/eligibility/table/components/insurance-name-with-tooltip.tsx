// import React from "react";
// import { Tooltip } from "reactstrap";
// import { TempEligibilityData } from "../columns";
import { Patient } from "../../apis/patients-all";

export type InsuranceNameWithTooltipProps = {
  row: Patient;
};

export const InsuranceNameWithTooltip = ({
  row,
}: InsuranceNameWithTooltipProps) => {
  // const [tooltipOpen, setTooltipOpen] = React.useState(false);
  // const toggle = () => setTooltipOpen(!tooltipOpen);

  return (
    <>
      {row?.insurancePayer}
      {/* <p id="insurance-name">
        {row.PriProv ? `${row.PriProv},` : ""}{" "}
        {row.priProvAbbr ? `(${row.priProvAbbr})` : ""}
      </p>
      <Tooltip
        target={"insurance-name"}
        isOpen={tooltipOpen}
        toggle={toggle}
        placement="bottom"
      >
        {row?.insurancePayer
          ? row.insurancePayer.split(" ").splice(1).join(" ")
          : ""}
      </Tooltip> */}
    </>
  );
};

export default InsuranceNameWithTooltip;
