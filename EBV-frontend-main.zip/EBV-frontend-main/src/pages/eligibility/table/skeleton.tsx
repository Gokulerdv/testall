import usePagination from "@mui/material/usePagination";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { Placeholder } from "reactstrap";
import styles from "../eligibility.module.scss";
import { defaultColumns } from "./columns";

export const TableSkeleton = () => {
  const table = useReactTable({
    columns: defaultColumns,
    data: new Array(100).fill(undefined),
    getCoreRowModel: getCoreRowModel(),
  });

  const { items } = usePagination({
    count: table.getPageCount(),
  });

  return (
    <div className="table-responsive">
      <table className="table table-striped table-hover table-borderless mb-0">
        <thead>
          <tr>
            <th colSpan={table.getVisibleLeafColumns().length} className="p-0">
              <div className="hstack justify-content-between p-3 border-bottom">
                <div className="hstack gap-2 placeholder-glow">
                  <Placeholder style={{ width: 200 }} />
                  <Placeholder style={{ width: 100 }} />
                </div>

                <div className="hstack gap-2 placeholder-glow">
                  <Placeholder style={{ width: 100 }} />
                  <Placeholder style={{ width: 100 }} />
                  <Placeholder style={{ width: 100 }} />
                </div>
              </div>
            </th>
          </tr>

          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id} className="sticky-top">
              {headerGroup.headers.map((header) => (
                <th
                  key={header.id}
                  colSpan={header.colSpan}
                  className="border-bottom"
                >
                  {header.isPlaceholder ? null : (
                    <div
                      {...{
                        className: "hstack align-items-center placeholder-glow",
                        style: header.column.getCanSort()
                          ? {
                              cursor: "pointer",
                              userSelect: "none",
                            }
                          : undefined,
                      }}
                    >
                      <Placeholder style={{ width: 100 }} />
                    </div>
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody>
          {table
            .getRowModel()
            .rows.slice(0, 10)
            .map((row) => (
              <tr key={row.id}>
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id} className="placeholder-glow">
                    <Placeholder style={{ width: 100 }} />
                  </td>
                ))}
              </tr>
            ))}
        </tbody>

        <tfoot>
          <td colSpan={table.getVisibleLeafColumns().length} scope="row">
            <div className="border-top p-3">
              <nav className="hstack justify-content-between placeholder-glow">
                <Placeholder style={{ width: 200 }} />

                <ul className={styles["pagination-list"]}>
                  {items.map(({ type }, index) => {
                    let children = null;

                    if (type === "start-ellipsis" || type === "end-ellipsis") {
                      children = "…";
                    } else if (type === "page") {
                      children = (
                        <>
                          <Placeholder style={{ width: 20 }} />
                        </>
                      );
                    } else {
                      if (type === "next")
                        children = table.getCanNextPage() ? (
                          <>
                            <Placeholder style={{ width: 100 }} />
                          </>
                        ) : null;
                      else if (type === "previous")
                        children = table.getCanPreviousPage() ? (
                          <>
                            <Placeholder style={{ width: 100 }} />
                          </>
                        ) : null;
                      else
                        children = (
                          <>
                            <Placeholder style={{ width: 100 }} />
                          </>
                        );
                    }

                    return (
                      <li key={index} className="px-1 placeholder-glow">
                        {children}
                      </li>
                    );
                  })}
                </ul>
              </nav>
            </div>
          </td>
        </tfoot>
      </table>
    </div>
  );
};

export default TableSkeleton;
