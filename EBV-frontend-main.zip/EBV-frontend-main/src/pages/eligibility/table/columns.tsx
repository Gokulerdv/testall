/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faEllipsisVertical,
  faFile,
  faFileExcel,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { CellContext, createColumnHelper } from "@tanstack/react-table";
import React, { useState } from "react";
import { DeepPartial } from "react-hook-form";
import {
  NavLink as RouterLink,
  useLocation,
  useNavigate,
  useSearchParams,
} from "react-router-dom";
import {
  Badge,
  Button,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  Spinner,
  UncontrolledDropdown,
} from "reactstrap";
import { Eligibility as EligibilityData } from "../../../apis/mocks/eligibility/data";
import {
  DentalXchangeResponse,
  EligibilityList,
} from "../../../apis/mocks/patients/data";
// import { dateTimeFormat } from "../../../utils/date-time-format";
import { Patient } from "../apis/patients-all";
import {
  PatientsExcludeProps,
  PatientsExcludeResponse,
} from "../apis/patients-exclude";
import {
  PatientsVerifyProps,
  PatientsVerifyResponse,
} from "../apis/patients-verify";
// import { currencyFormat } from "../../../utils/currency-format";
import { Box, Menu, MenuItem } from "@mui/material";
import axios from "axios";
import { capitalCase } from "change-case";
import { toast } from "react-toastify";
import { useAuth } from "../../../shared/hooks/use-auth";
import { useNotificationContext } from "../../../shared/hooks/use-notification";
import {
  BenefitSummaryViewPermission,
  EligibilityTableDeletePermission,
  ScheduleVerificationCreatePermission,
  ScheduleVerificationDeletePermission,
} from "../../../utils/constant";
import { currencyFormat } from "../../../utils/currency-format";
import { dateFormat } from "../../../utils/date-format";
import { dateTimeFormat } from "../../../utils/date-time-format";
import { defaultMutateOptions } from "../../../utils/default-mutate-options";
import { Config } from "../../../utils/headers-config";
import { RolesPermission } from "../../../utils/role-permission";
import AttachmentModal from "../attachment-modal";
import DeleteModal from "../delete-modal";
import DemographicsErrorModal from "../demographics-error-modal";
import EligibilityEditModal from "../edit-eligibility-modal";
import InsurancePayerModal from "../insurance-payer-modal";
import TechnicalErrorModal from "../technical-error-modal";
import VerificationWarningModal from "../verification-warning-modal";

export type TempEligibilityData = EligibilityData & {
  actualResponseData: Omit<EligibilityList[0], "dentalXchangeResponse"> & {
    dentalXchangeResponse: DeepPartial<DentalXchangeResponse>;
  };
} & { row: Patient };

const columnHelper = createColumnHelper<Patient>();

export const specialtyColumnHeader = "Specialty";
export const dateOfBirthColumnHeader = "Date of Birth";
export const subscriberIdColumnHeader = "Subscriber ID";
export const appointmentRenderingProviderColumnHeader =
  "Appointment Rendering Provider";
export const insurancePayerCodeColumnHeader = "Insurance Payer Code";
export const insurancePayerNameColumnHeader = "Insurance Name/Plan";
export const procedureCodeColumnHeader = "Procedure Code";
export const procedureTypeColumnHeader = "Procedure Type";

export const defaultColumns = [
  columnHelper.display({
    id: "select-col",
    header: ({ table }) => (
      <Input
        type="checkbox"
        checked={table.getIsAllRowsSelected()}
        indeterminate={table.getIsSomeRowsSelected()}
        onChange={table.getToggleAllRowsSelectedHandler()} //or getToggleAllPageRowsSelectedHandler
      />
    ),
    cell: ({ row }) => (
      <Input
        type="checkbox"
        checked={row.getIsSelected()}
        disabled={!row.getCanSelect()}
        onChange={row.getToggleSelectedHandler()}
      />
    ),
  }),
  columnHelper.accessor("patientId", {
    cell: (info) => (
      <>
        {/* <RouterLink
          to={`${info.row.original.patientId}/attachments`}
          state={info.row.original}
          className="text-decoration-none"
        >
          <Button color="link" className="p-0 text-black rounded-circle me-2">
            <FontAwesomeIcon icon={faPaperclip} />
          </Button>
        </RouterLink> */}
        <ViewAttachment info={info.row.original} />
        <Button
          color="link"
          // style={{
          //   color: "blue",
          // }}
          className="p-0 me-2"
        >
          {info.getValue()}
        </Button>
      </>
    ),
    header: "Patient Id",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor((row) => `${row.firstName} ${row.lastName}`, {
    cell: (info) => (
      <>
        <RouterLink
          to={`patient-information/${info.row.original.patientId}`}
          state={info.row.original}
        >
          <Button color="link" className="p-0" style={{ textAlign: "left" }}>
            {info.row.original.relationship === "18" ? (
              <>
                {info.row.original.firstName} {info.row.original.lastName}
              </>
            ) : (
              <>
                {info.row.original.dependentFirstName}{" "}
                {info.row.original.dependentLastName}
                {""}
              </>
            )}
          </Button>
        </RouterLink>
      </>
    ),
    header: "Patient Name",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),

  columnHelper.accessor("typeOfService", {
    cell: (info) => info.getValue(),
    header: "Type of Service",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("practiceNameAndLoc", {
    cell: (info) => info.getValue(),
    header: "Practice Name & Location",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("appointmentType", {
    cell: (info) => info.getValue(),
    header: "Appointment Type",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("payerLogo", {
    cell: (info) => (
      <>
        <img src={info.getValue()} />
      </>
    ),
    header: "Insurance Name",
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor("insurancePayer", {
    cell: (info) => info.getValue(),
    filterFn: (row, id, value) => {
      return row.getUniqueValues(id).includes(value);
    },
    getUniqueValues: (row) => [row?.insurancePayer && row.insurancePayer],
    // getUniqueValues: (row) => [
    //   `${row.PriProv ? `${row.PriProv},` : ""} ${
    //     row.priProvAbbr ? `(${row.priProvAbbr})` : ""
    //   }`.trim(),
    // ],
    header: insurancePayerNameColumnHeader,
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor((row) => <RemainingBenefitsNavigation row={row} />, {
    cell: (info) => info.getValue(),
    header: "Remaining Benefits/Deductible",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("scheduleAppointment", {
    cell: (info) =>
      `${
        typeof info.getValue() === "string" && info.getValue()
          ? dateTimeFormat(new Date(info.getValue()))
          : ""
      }`,
    header: "Appointment",
    filterFn: (row, id, value) => {
      return row.getUniqueValues(id).includes(value);
    },
    getUniqueValues: (row) => [
      `${
        typeof row.scheduleAppointment === "string" && row.scheduleAppointment
          ? dateTimeFormat(new Date(row.scheduleAppointment))
          : ""
      }`,
    ],
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor("lastVerified", {
    cell: (info) =>
      !info.row.original.isVerified &&
      info.row.original.lastVerified === null ? (
        <>
          <div className="p-0" style={{ textAlign: "left" }}>
            {"-"}
          </div>
        </>
      ) : (
        `${
          typeof info.getValue() === "string" && info.getValue()
            ? dateTimeFormat(new Date(info.getValue()))
            : ""
        }`
      ),

    filterFn: (row, id, value) => {
      return row.getUniqueValues(id).includes(value);
    },
    getUniqueValues: (row) => [
      `${
        typeof row.lastVerified === "string" && row.lastVerified
          ? dateTimeFormat(new Date(row.lastVerified))
          : ""
      }`,
    ],
    meta: { filterVariant: "range" },
    header: "Last Verified",
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor("insuranceStatus", {
    cell: (info) =>
      !info.row.original.isVerified &&
      info.row.original.lastVerified === null ? (
        <>
          <div className="p-0" style={{ textAlign: "left" }}>
            {"-"}
          </div>
        </>
      ) : (
        <Badge
          className={`fw-normal border-1 ${
            info.getValue() === "active"
              ? "bg-success-subtle border-success text-success"
              : "bg-danger-subtle border-danger text-danger"
          }`}
          style={{ border: "1px solid" }}
          pill
        >
          {capitalCase((info.getValue() as string) ?? "")}
        </Badge>
      ),
    filterFn: "equals",
    header: "Status",
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor((row) => row?.payerIdCode, {
    cell: (info) => info.getValue(),
    header: insurancePayerCodeColumnHeader,
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor("status", {
    cell: (info) =>
      !info.row.original.isVerified &&
      info.row.original.lastVerified === null ? (
        <>
          <div className="p-0" style={{ textAlign: "left" }}>
            {"-"}
          </div>
        </>
      ) : (
        <BenefitStatus {...info} />
      ),
    filterFn: (row, id, value) => {
      return row.getUniqueValues(id).includes(value);
    },
    getUniqueValues: (row) => {
      const notLinkedErrorCodes = ["110", "120", "130", "140", "150"];

      const success =
        row.isVerified &&
        row.verificationErrMessages === null &&
        row.verificationErrCode === null &&
        row.verificationError === null;

      const demographics =
        !row.isVerified &&
        row.verificationErrCode === "2001" &&
        row.verificationErrMessages !== null;

      const technicalError =
        !row.isVerified &&
        row.verificationErrCode !== null &&
        row.verificationErrCode === "2001";

      const notLinked =
        !row.isVerified &&
        !row.isVerifiedManually &&
        row.verificationErrCode !== null &&
        notLinkedErrorCodes.includes(row.verificationErrCode);

      const manual =
        row.isVerified &&
        row.isVerifiedManually &&
        row.verificationErrCode !== null &&
        row.verificationErrCode === "2002";

      switch (true) {
        case success:
          // green green
          return ["Success"];

        case demographics:
          // yellow green
          return ["Demographics"];

        case technicalError:
          // red green
          return ["Technical Error"];

        case notLinked:
          // red red will change to blue blue after verfication via call
          return ["Not Linked"];

        case manual:
          // blue blue
          return ["Manual"];
        default:
          return ["Unknown"];
      }
    },
    header: "Benefits Details",
    footer: (props) => props.column.id,
  }),

  columnHelper.accessor("scheduleAppointmentDate", {
    cell: (info) => info.getValue(),
    header: "Appointment",
    footer: (props) => props.column.id,
    enableHiding: true,
  }),
  columnHelper.accessor("lastVerifiedDate", {
    cell: (info) => info.getValue(),
    header: "Last Verified",
    footer: (props) => props.column.id,
    enableHiding: true,
  }),
  columnHelper.accessor("dateOfBirthDate", {
    cell: (info) => info.getValue(),
    header: "Date Of Birth",
    footer: (props) => props.column.id,
    enableHiding: true,
  }),
  columnHelper.accessor((row) => row?.speciality, {
    cell: (info) => info.getValue(),
    header: specialtyColumnHeader,
    footer: (props) => props.column.id,
    enableHiding: true,
  }),
  columnHelper.accessor((row) => row?.dependentDateOfBirth, {
    cell: (info) => info.getValue() && dateFormat(new Date(info.getValue())),
    header: dateOfBirthColumnHeader,
    meta: { filterVariant: "range" },

    footer: (props) => props.column.id,
  }),
  columnHelper.accessor((row) => row.memberId, {
    cell: (info) => info.getValue(),
    header: subscriberIdColumnHeader,
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor((row) => row.appointmentRenderingProvider, {
    cell: (info) => info.getValue(),
    header: appointmentRenderingProviderColumnHeader,
    footer: (props) => props.column.id,
  }),
  columnHelper.accessor((row) => row.procedureType, {
    cell: (info) => info.getValue(),
    header: procedureTypeColumnHeader,
    footer: (props) => props.column.id,
    // enableColumnFilter: false,
  }),
  columnHelper.accessor((row) => row.procedureCode, {
    cell: (info) => info.getValue(),
    header: procedureCodeColumnHeader,
    footer: (props) => props.column.id,
    // enableColumnFilter: false,
  }),
  // Display Column
  columnHelper.display({
    id: "actions",
    header: () => <Actions />,
    cell: (info) => (
      <>
        <DropDownWrapper info={info.row.original} />
      </>
    ),
  }),
];

export type VerificationWarningModalProps = {
  uniqueId: string;
  isScheduled: string;
  lastName: string;
  lastVerified: string;
  firstName: string;
};
const DropDownWrapper = (props: { info: any }) => {
  const [verifyPatientModal, setVerifyPatientModal] = useState<{
    data: null | VerificationWarningModalProps;
  }>({
    data: null,
  });
  return (
    <>
      <DropDown
        info={props.info}
        setVerifyPatientModal={(x: VerificationWarningModalProps) => {
          setVerifyPatientModal({ data: x });
        }}
      />
      {verifyPatientModal?.data && (
        <VerificationWarningModal
          {...verifyPatientModal?.data}
          closeModal={() => {
            setVerifyPatientModal({ data: null });
          }}
          open={verifyPatientModal?.data ? true : false}
        />
      )}
    </>
  );
};

const Actions = () => {
  const { state } = useLocation();
  return (
    <>
      {!state?.isHistory && (
        <UncontrolledDropdown direction="start">
          <DropdownToggle nav>
            <Button color="link" className="p-0 text-black rounded-circle">
              <FontAwesomeIcon icon={faEllipsisVertical} />
            </Button>
          </DropdownToggle>
          <DropdownMenu>
            {/* <RouterLink
              to={`download-all-confirmation`}
              className="text-decoration-none"
            >
              <DropdownItem>Download All PDF</DropdownItem>
            </RouterLink> */}
            {RolesPermission(ScheduleVerificationCreatePermission) && (
              <RouterLink
                to={`verify-all-confirmation`}
                className="text-decoration-none"
              >
                <DropdownItem>Verify All</DropdownItem>
              </RouterLink>
            )}
            {RolesPermission(ScheduleVerificationCreatePermission) && (
              <RouterLink
                to={`verify-primary-confirmation`}
                className="text-decoration-none"
              >
                <DropdownItem>Verify Primary</DropdownItem>
              </RouterLink>
            )}
            {RolesPermission(ScheduleVerificationCreatePermission) && (
              <RouterLink
                to={`verify-secondary-confirmation`}
                className="text-decoration-none"
              >
                <DropdownItem>Verify Secondary</DropdownItem>
              </RouterLink>
            )}
          </DropdownMenu>
        </UncontrolledDropdown>
      )}
    </>
  );
};

// export const EditField = (props: { info: any }) => {
//   const { state } = useLocation();
//   const { info } = props;
//   // const auth=
//   return <>{!state?.isHistory && <EligibilityEditModal state={info} />}</>;
// };

export const DropDown = (props: {
  info: any;
  setVerifyPatientModal: (x: VerificationWarningModalProps) => void;
}) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [open, setOpen] = React.useState(false);
  const { info, setVerifyPatientModal } = props;
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    event.stopPropagation(); // Stop event propagation
    setAnchorEl(event.currentTarget);
    setOpen(true);
  };
  const handleClose = () => {
    setAnchorEl(null);
    setOpen(false);
  };
  const [openDialog, setOpenDialog] = React.useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = React.useState(false);
  const [openInsuranceDialog, setOpenInsuranceDialog] = React.useState(false);

  const handleDialogOpen = () => {
    setOpenDialog(!openDialog);
    handleClose(); // Close the menu when dialog opens
  };
  const handleDeleteOpen = () => {
    setOpenDeleteDialog(!openDeleteDialog);
    handleClose(); // Close the menu when dialog opens
  };
  const handleInsuranceOpen = () => {
    setOpenInsuranceDialog(!openInsuranceDialog);
    handleClose(); // Close the menu when dialog opens
  };
  const handleDialogClose = () => {
    setOpenDialog(!openDialog);
  };
  const handleDeleteClose = () => {
    setOpenDeleteDialog(!openDeleteDialog);
  };
  const handleInsuranceClose = () => {
    setOpenInsuranceDialog(!openInsuranceDialog);
  };
  return (
    <div>
      <div style={{ display: "none" }}>
        <EditField
          info={info}
          isOpen={openDialog}
          onClose={handleDialogClose}
        />
        <DeleteField
          isOpen={openDeleteDialog}
          onClose={handleDeleteClose}
          info={info}
        />
        <ViewInsuranceCard
          isOpen={openInsuranceDialog}
          onClose={handleInsuranceClose}
          info={info}
        />
      </div>
      <Box
        id="demo-positioned-button"
        aria-controls={open ? "demo-positioned-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        style={{ cursor: "pointer" }}
      >
        <FontAwesomeIcon icon={faEllipsisVertical} />
      </Box>
      <Menu
        id="demo-positioned-menu"
        aria-labelledby="demo-positioned-button"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "top",
          horizontal: "left",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left",
        }}
      >
        <MenuItem onClick={handleClose}>
          <DownloadPDF info={info} />{" "}
        </MenuItem>

        {/* */}

        <MenuItem style={{ padding: "1px" }}>
          <Button
            color="transparent"
            style={{
              width: "100%",
              textAlign: "left",
            }}
          >
            <VerifyPatient
              lastName={info.lastName}
              lastVerified={info.lastVerified}
              firstName={info.firstName}
              isVerified={info.isVerified}
              uniqueId={info.uniqueId}
              isScheduled={String(info.isScheduled)}
              handleClose={handleClose}
              setVerifyPatientModal={setVerifyPatientModal}
            />
          </Button>
        </MenuItem>

        <MenuItem onClick={handleClose}>
          <ExcludePatient
            uniqueId={info.uniqueId}
            isVerified={info.isVerified}
            isScheduled={String(info.isScheduled)}
          />
        </MenuItem>

        <MenuItem onClick={handleDialogOpen}>
          <EditField
            isOpen={openDialog}
            onClose={handleDialogClose}
            info={info}
          />
        </MenuItem>
        {/* <MenuItem onClick={handleClose}>
          <DownloadCSV />
        </MenuItem>
        <MenuItem onClick={handleClose}>
          <DownloadExcel />
        </MenuItem> */}

        {RolesPermission(EligibilityTableDeletePermission) && (
          // <RouterLink
          //   to={`${info.uniqueId}/delete`}
          //   state={info}
          //   className="text-decoration-none text-dark-emphasis"
          // >
          <MenuItem onClick={handleDeleteOpen}>
            <DeleteField
              isOpen={openDeleteDialog}
              onClose={handleDeleteClose}
              info={info}
            />{" "}
          </MenuItem>
          // </RouterLink>
        )}

        <MenuItem onClick={handleInsuranceOpen}>
          {/* <RouterLink
            to={`${info.patientId}/attachments`}
            state={info}
            className="text-decoration-none text-dark-emphasis"
          > */}
          <ViewInsuranceCard
            isOpen={openInsuranceDialog}
            onClose={handleInsuranceClose}
            info={info}
          />
          {/* </RouterLink> */}
        </MenuItem>
      </Menu>
    </div>
  );
};
export const EditField = (props: { info: any; isOpen: any; onClose: any }) => {
  const { state } = useLocation();
  const { info, isOpen, onClose } = props;
  // const auth=
  return (
    <>
      {!state?.isHistory && (
        <EligibilityEditModal state={info} isOpen={isOpen} onClose={onClose} />
      )}
    </>
  );
};
export const DeleteField = (props: {
  info: any;
  isOpen: any;
  onClose: any;
}) => {
  // const { state } = useLocation();
  const { info, isOpen, onClose } = props;
  const [, setSearchParams] = useSearchParams();
  const refreshTable = () => {
    return setSearchParams({ refresh: String(true) });
  };
  return (
    <>
      <DeleteModal
        state={info}
        isOpen={isOpen}
        onClose={onClose}
        onSuccess={async () => refreshTable()}
      />
    </>
  );
};
// export const ViewInsuranceCard = () => {
//   const { state } = useLocation();
//   return (
//     <>{!state?.isHistory && <DropdownItem>View Insurance Card</DropdownItem>}</>
//   );
// };

export const ViewAttachment = (props: { info: any }) => {
  const { info } = props;
  const [openAttachment, setOpenAttachment] = React.useState(false);

  const openAttachmentModal = () => {
    setOpenAttachment((prevState) => !prevState);
  };

  return (
    <>
      <AttachmentModal
        state={info}
        isOpen={openAttachment}
        onClose={openAttachmentModal}
        type="attachment"
      />
    </>
  );
};
export const ViewInsuranceCard = (props: {
  info: any;
  isOpen: any;
  onClose: any;
}) => {
  const { state } = useLocation();
  const { info, isOpen, onClose } = props;
  // const auth=
  return (
    <>
      {!state?.isHistory && (
        <AttachmentModal
          state={info}
          isOpen={isOpen}
          onClose={onClose}
          type="insuranceCard"
        />
      )}
    </>
  );
};
export const DownloadCSV = () => {
  const { state } = useLocation();
  return <>{state?.isHistory && <DropdownItem>Download CSV</DropdownItem>}</>;
};
export const DownloadExcel = () => {
  const { state } = useLocation();
  return <>{state?.isHistory && <DropdownItem>Download Excel</DropdownItem>}</>;
};

export const DownloadPDF = (props: { info: any }) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const { info } = props;
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    event.stopPropagation(); // Stop event propagation
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const auth = useAuth();

  const fetchReport = async ({
    patientId,
    eligibilityId,
    isScheduled,
    basic,
    document,
    code,
  }: {
    patientId: string;
    eligibilityId: string;
    isScheduled: boolean | undefined;
    basic: boolean;
    document: Document;
    code: string;
  }) => {
    try {
      const fileName = basic
        ? `Patient ${patientId}-basic-report`
        : `Patient ${patientId}-detailed-report`;
      const response = await getPatientReport(
        patientId,
        eligibilityId,
        isScheduled,
        basic,
        code
      );
      const file = new Blob([response.data], { type: "application/pdf" });
      const fileURL = URL.createObjectURL(file);

      const link = document.createElement("a");
      link.href = fileURL;
      link.setAttribute("download", `${fileName}`);
      document.body.appendChild(link);
      link.click();

      URL.revokeObjectURL(fileURL);
      document.body.removeChild(link);
    } catch (error) {
      console.log(error);
    }
  };
  const getPatientReport = async (
    patientId: string,
    eligibilityId: string,
    isScheduled: boolean | undefined,
    basic: boolean,
    code: string
  ) => {
    const body = {
      patientId,
      eligibilityId,
      isScheduled,
      basicReport: basic,
    };
    return await axios({
      method: "POST",
      url: `${
        import.meta.env.VITE_API_HOST ?? ""
      }/eligibility/getreport?code=${code}`,
      data: body,
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
      responseType: "blob",
    });
  };

  const getReport = useMutation({
    mutationKey: [],
    mutationFn: fetchReport,
  });

  return (
    <>
      <Box
        id="demo-positioned-button"
        aria-controls={open ? "demo-positioned-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        style={{ cursor: "pointer" }}
      >
        Download PDF
      </Box>
      <Menu
        id="demo-positioned-menu"
        aria-labelledby="demo-positioned-button"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        {(() => {
          if (
            !info.isVerified &&
            info.verificationErrCode !== null &&
            info.verificationErrCode === "2001"
          )
            return (
              <>
                <MenuItem onClick={handleClose} disabled>
                  Basic Report
                </MenuItem>

                <MenuItem onClick={handleClose} disabled>
                  Detailed Report
                </MenuItem>
              </>
            );

          if (info.isVerified && info.verificationErrMessages !== null)
            return (
              <>
                <MenuItem onClick={handleClose} disabled>
                  Basic Report
                </MenuItem>

                <MenuItem onClick={handleClose} disabled>
                  Detailed Report
                </MenuItem>
              </>
            );

          if (
            !info.isVerified &&
            info.verificationErrCode !== null &&
            info.verificationErrCode === "2002"
          )
            return (
              <>
                <MenuItem onClick={handleClose} disabled>
                  Basic Report
                </MenuItem>

                <MenuItem onClick={handleClose} disabled>
                  Detailed Report
                </MenuItem>
              </>
            );

          if (
            info.isVerified &&
            info.verificationErrMessages === null &&
            info.verificationErrCode === null &&
            info.verificationError === null
          )
            return (
              <>
                {getReport.isPending && getReport?.variables?.basic ? (
                  <MenuItem
                    style={{
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <Spinner size="sm">Generating report...</Spinner>
                  </MenuItem>
                ) : (
                  <MenuItem
                    // toggle={false}
                    onClick={() =>
                      getReport.mutate({
                        patientId: info?.patientId,
                        eligibilityId: `${info?.eligibilityId}`,
                        isScheduled: info?.isScheduled,
                        basic: true,
                        document,
                        code: "",
                      })
                    }
                  >
                    Basic Report
                  </MenuItem>
                )}
                {getReport.isPending && !getReport?.variables?.basic ? (
                  <MenuItem
                    style={{
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <Spinner size="sm">Generating report...</Spinner>
                  </MenuItem>
                ) : (
                  <MenuItem
                    // toggle={false}
                    onClick={() => {
                      getReport.mutate({
                        patientId: info?.patientId,
                        eligibilityId: `${info?.eligibilityId}`,
                        isScheduled: info?.isScheduled,
                        basic: false,
                        document,
                        code: "",
                      });
                    }}
                  >
                    Detailed Report
                  </MenuItem>
                )}
              </>
            );

          return (
            <>
              <MenuItem onClick={handleClose} disabled>
                Basic Report
              </MenuItem>

              <MenuItem onClick={handleClose} disabled>
                Detailed Report
              </MenuItem>
            </>
          );
        })()}
      </Menu>
    </>
  );
};

export type VerifyPatientProps = PatientsVerifyProps &
  Pick<Patient, "isVerified"> & {
    handleClose: () => void;
    setVerifyPatientModal: (x: VerificationWarningModalProps) => void;
  };

export const VerifyPatient = (props: VerifyPatientProps) => {
  const {
    uniqueId,
    isScheduled,
    lastName,
    lastVerified,
    firstName,
    handleClose,
    setVerifyPatientModal,
  } = props;
  const notify = useNotificationContext();
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;
  const patientsVerify = async ({
    uniqueId,
    isScheduled,
  }: PatientsVerifyProps): Promise<PatientsVerifyResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/verifypatient?uniqueId=${uniqueId}&adminId=${
      auth?.state?.user?.userData?.userId
    }${
      isScheduled && isScheduled !== "undefined"
        ? `&isScheduled=${isScheduled}`
        : ""
    }`;

    const response = (await (
      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsVerifyResponse;

    return response;
  };

  const settingsGetById = (adminid: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/generalSettings/get/${adminid}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const patients = useMutation({
    mutationKey: ["patients/verify"],
    mutationFn: patientsVerify,
  });

  const verifypatientUtils = useSuspenseQuery({
    queryKey: ["verifyPatient", "get", `${userId}`],
    queryFn: settingsGetById(`${userId}`),
  });

  const [, setSearchParams] = useSearchParams();
  const { state } = useLocation();

  // const navigate = useNavigate();

  const verifyPatient: React.MouseEventHandler<HTMLElement> = async (event) => {
    try {
      event.preventDefault();
      event.stopPropagation();

      if (
        lastVerified &&
        new Date().getTime() <
          new Date(
            new Date().setFullYear(
              new Date(lastVerified).getFullYear(),
              new Date(lastVerified).getMonth(),
              new Date(lastVerified).getDate() +
                verifypatientUtils.data.data.warningdays
            )
          ).getTime()
      ) {
        handleClose();
        setVerifyPatientModal({ ...props });
        // navigate(`${uniqueId}/verify-warning`, {
        //   state: { ...props, handleClose: null, warningDays },
        // });

        // setShowWarning(true);
        return;
      }

      const res = await patients.mutateAsync(
        { uniqueId, isScheduled, lastName, lastVerified, firstName },
        defaultMutateOptions
      );
      setSearchParams({ refresh: String(true) });
      res?.notificationData && notify.dispatcher({ type: "increment-count" });
      !res?.error && toast.success("Patient verified Successfully");
      if (res?.error) throw Error;
      res.data?.eligibility && res.data?.eligibility?.errors?.length
        ? toast.error("Patient verification failed!")
        : toast.success("Patient verified Successfully");
      setSearchParams({ refresh: String(true) });
    } catch (error) {
      toast.error("Patient verification failed!");
      console.log(error);
    }
  };

  return (
    <>
      {RolesPermission(ScheduleVerificationCreatePermission) &&
        !state?.isHistory && (
          <DropdownItem
            onClick={verifyPatient}
            toggle={false}
            disabled={patients.isPending}
          >
            {patients.isPending ? (
              <>
                <Spinner size="sm">Verifying...</Spinner>
                <span> Verifying...</span>
              </>
            ) : (
              "Verify Now"
            )}
          </DropdownItem>
        )}
    </>
  );
};

export type ExcludePatientProps = PatientsExcludeProps &
  Pick<Patient, "isVerified">;

export const ExcludePatient = ({
  uniqueId,
  isVerified,
  isScheduled,
}: ExcludePatientProps) => {
  const [, setSearchParams] = useSearchParams();

  const { state } = useLocation();
  const auth = useAuth();

  const patientsExclude = async ({
    uniqueId,
    body,
  }: any): Promise<PatientsExcludeResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/exclude/${uniqueId}`;

    const response = (await (
      await fetch(url, {
        body: JSON.stringify(body),
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsExcludeResponse;
    return response;
  };

  const patients = useMutation({
    mutationKey: ["patients/exclude"],
    mutationFn: patientsExclude,
  });

  const excludePatient = async () => {
    try {
      await patients.mutateAsync(
        { uniqueId, body: { isScheduled: isScheduled } },
        defaultMutateOptions
      );
      setSearchParams({ refresh: String(true) });

      toast.success("Patient excluded successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      {RolesPermission(ScheduleVerificationDeletePermission) &&
        !state?.isHistory && (
          <DropdownItem disabled={isVerified} onClick={excludePatient}>
            {patients.isPending ? (
              <>
                <Spinner size="sm">Excluding...</Spinner>
                <span> Excluding...</span>
              </>
            ) : (
              "Exclude"
            )}
          </DropdownItem>
        )}
    </>
  );
};

export const BenefitStatus = (info: CellContext<Patient, unknown>) => {
  const patientId = info.row.original.patientId;

  const navigate = useNavigate();

  const handleNavigate = async () => {
    try {
      if (
        info.row.original.isVerified === false &&
        info.row.original.isScheduled === true
      )
        return;

      const state = {
        ...info.row.original,
        row: info.row.original,
        patientId: info.row.original.patientId,
      };

      navigate(`patient-benefit-information/${patientId}`, {
        state,
      });
    } catch (error) {
      console.log(error);
    }
  };

  const colorCheck = () => {
    let fileIcon1: string, fileIcon2: string;
    // (isVerified === true && VerificationError === []) // - YELLOW GREEN
    const demographicsErrorCodes = [
      "90",
      "2001",
      "2002",
      "2003",
      "2005",
      "2007",
      "2009",
      "2012",
    ];
    const technicalErrorCodes = [
      "100",
      "101",
      "160",
      "170",
      "1000",
      "2004",
      "2010",
      "1",
    ];
    const notLinkedErrorCodes = ["110", "120", "130", "140", "150"];

    const verificationErrorCode = info.row.original.verificationErrCode || "";

    const successColor =
      info.row.original.isVerified &&
      info.row.original.verificationErrMessages === null &&
      info.row.original.verificationErrCode === null &&
      info.row.original.verificationError === null;

    const demographicsColor =
      !info.row.original.isVerified &&
      demographicsErrorCodes.includes(verificationErrorCode);

    const technicalColor =
      !info.row.original.isVerified &&
      info.row.original.verificationErrCode !== null &&
      technicalErrorCodes.includes(verificationErrorCode);

    const notLinkedColor =
      !info.row.original.isVerified &&
      !info.row.original.isVerifiedManually &&
      info.row.original.verificationErrCode !== null &&
      notLinkedErrorCodes.includes(verificationErrorCode);

    const manualColor =
      info.row.original.isVerifiedManually &&
      info.row.original.isVerified &&
      info.row.original.verificationErrCode !== null;

    switch (true) {
      case successColor: // SUCCESS
        fileIcon1 = "var(--bs-success)"; // GREEN
        fileIcon2 = "var(--bs-success)"; // GREEN
        break;

      case demographicsColor: // DEMOGRAPHICS
        fileIcon1 = "var(--bs-warning)"; // YELLOW
        fileIcon2 = "var(--bs-danger)"; // RED
        break;

      case technicalColor: // TECHNICAL ERROR
        fileIcon1 = "var(--bs-danger)"; // RED
        fileIcon2 = "var(--bs-success)"; // GREEN
        break;

      case notLinkedColor: // NOT-LINKED
        fileIcon1 = "var(--bs-danger)"; // RED
        fileIcon2 = "var(--bs-danger)"; // RED
        break;

      case manualColor: // MANUAL
        fileIcon1 = "#067492"; // BLUE
        fileIcon2 = "#067492"; // BLUE
        break;

      default:
        fileIcon1 = "var(--bs-warning)"; // YELLOW
        fileIcon2 = "var(--bs-danger)"; // RED
        break;
    }

    return (
      <>
        {(() => {
          if (demographicsColor)
            return (
              <DemographicsErrorModal
                uniqueId={info.row.original.uniqueId}
                info={info}
              />
            );

          if (technicalColor)
            return (
              <TechnicalErrorModal
                uniqueId={info.row.original.uniqueId}
                info={info}
              />
            );

          if (notLinkedColor)
            return (
              <InsurancePayerModal
                uniqueId={info.row.original.uniqueId}
                info={info}
              />
            );

          return RolesPermission(BenefitSummaryViewPermission) ? (
            <Button
              color="link"
              className={`rounded-circle p-0`}
              style={{ color: fileIcon1 }}
              onClick={() => {
                handleNavigate();
              }}
            >
              <FontAwesomeIcon icon={faFile} />
            </Button>
          ) : (
            <Button
              color="link"
              className={`rounded-circle p-0`}
              style={{ color: fileIcon1 }}
            >
              <FontAwesomeIcon icon={faFile} />
            </Button>
          );
        })()}
        <Button
          color="link"
          className={`rounded-circle p-0 ms-2`}
          style={{ color: fileIcon2 }}
        >
          <FontAwesomeIcon icon={faFileExcel} />
        </Button>
      </>
    );
  };

  return <>{colorCheck()}</>;
};

export type RemainingBenefitsNavigationProps = {
  row: Patient;
};

export const RemainingBenefitsNavigation = ({
  row,
}: RemainingBenefitsNavigationProps) => {
  const navigate = useNavigate();

  const handleNavigate = (to: string) => async () => {
    try {
      if (row.isVerified === false) return;

      const state = {
        ...row,
        row: row,
        patientId: row.patientId,
      };

      navigate(to, {
        state,
      });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      {typeof row.limitationsAndMaximum === "number" ? (
        <>{currencyFormat(row.limitationsAndMaximum)}|</>
      ) : row.limitationsAndMaximum === null ? (
        row.limitationsAndMaximum
      ) : (
        <>
          <Button
            color="link"
            className="p-0"
            onClick={handleNavigate(
              `patient-benefit-information/${row.patientId}?tabId=${row.limitationsAndMaximum}`
            )}
          >
            Varies
          </Button>
          |
        </>
      )}
      {typeof row.deductible === "number" ? (
        currencyFormat(row.deductible)
      ) : row.deductible === null ? (
        row.deductible
      ) : (
        <>
          <Button
            color="link"
            className="p-0"
            onClick={handleNavigate(
              `patient-benefit-information/${row.patientId}?tabId=${row.deductible}`
            )}
          >
            Varies
          </Button>
        </>
      )}
    </>
  );
};
