import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientAttachmentAddSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type PatientAttachmentAdd = z.infer<typeof patientAttachmentAddSchema>;
export type PatientsAttachmentsResponse = Response<PatientAttachmentAdd>;

export type PatientsAttachmentsAddBody = {
  patientId: string;
  fileName: string;
  description: string;
  files: File;
  isPatientCard: boolean;
};

export type PatientsAttachmentsAddProps = {
  body: PatientsAttachmentsAddBody;
};

export const convertBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const fileReader = new FileReader();
    fileReader.readAsDataURL(file);

    fileReader.onload = () => {
      resolve(fileReader.result as string);
    };

    fileReader.onerror = (error) => {
      reject(error);
    };
  });
};

export const convertBase64ToFileURL = (base64: string, fileType: string) => {
  return new Promise((resolve) => {
    const byteString = atob(base64.split(",")[1]);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uint8Array = new Uint8Array(arrayBuffer);

    for (let i = 0; i < byteString.length; i++) {
      uint8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([uint8Array], { type: fileType });
    const fileURL = URL.createObjectURL(blob);

    resolve(fileURL);
  });
};
