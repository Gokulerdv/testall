import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientVerifySchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type PatientVerify = z.infer<typeof patientVerifySchema>;
export type PatientsVerifyResponse = Response<
  PatientVerify & { eligibility: { errors: unknown[] } }
> & {
  error: unknown;
};

export type PatientsVerifyProps = {
  uniqueId: string;
  isScheduled: string;
  lastName: string;
  firstName: string;
  lastVerified: string;
};

// TODO: Verify if it is working properly
