import { z } from "zod";
import { Response } from "../../../apis/mocks/response";
import { PatientsAttachmentsAddBody } from "./patients-attachments-add";

export const patientAttachmentUpdateSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type PatientAttachmentUpdate = z.infer<
  typeof patientAttachmentUpdateSchema
>;
export type PatientsAttachmentsResponse = Response<PatientAttachmentUpdate>;

export type PatientsAttachmentsUpdateBody = PatientsAttachmentsAddBody;

export type PatientsAttachmentsUpdateProps = {
  body: PatientsAttachmentsUpdateBody;
  uniqueId: string;
};
