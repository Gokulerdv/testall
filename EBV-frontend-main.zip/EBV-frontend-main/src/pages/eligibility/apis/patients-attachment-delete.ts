import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientAttachmentDeleteSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type PatientAttachmentDelete = z.infer<
  typeof patientAttachmentDeleteSchema
>;
export type PatientsAttachmentDeleteResponse =
  Response<PatientAttachmentDelete>;

export type PatientsAttachmentDeleteProps = {
  uniqueId: string;
};
