import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientDeleteSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type PatientDelete = z.infer<typeof patientDeleteSchema>;
export type PatientsDeleteResponse = Response<PatientDelete>;

export type PatientsDeleteProps = {
  uniqueId: string;
  isScheduled?: boolean;
};
