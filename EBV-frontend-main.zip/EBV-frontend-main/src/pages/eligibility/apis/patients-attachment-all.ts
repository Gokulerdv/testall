import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientAttachmentSchema = z.object({
  patientId: z.string(),
  fileName: z.string(),
  isPatientCard: z.string().optional(),
  uniqueId: z.string(),
  statusflag: z.string(),
  base64File: z.string(),
  description: z.string(),
  updatedAt: z.date(),
});

export type PatientAttachment = z.infer<typeof patientAttachmentSchema>;
export type PatientsAttachments = PatientAttachment[];
export type PatientsAttachmentsResponse = Response<PatientsAttachments>;

export type PatientsAttachmentsProps = {
  patientId: string;
};
