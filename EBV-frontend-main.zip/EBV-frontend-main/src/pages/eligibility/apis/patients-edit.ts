import { PatientsAddBody } from "./patients-add";

export type PatientsEditBody = Partial<PatientsAddBody> & {
  uniqueId: string;
  patientId: string;
  isScheduled: boolean;
};
