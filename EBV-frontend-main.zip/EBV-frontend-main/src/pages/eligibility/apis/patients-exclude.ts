import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

import { patientDeleteSchema } from "./patients-delete";

export const patientExcludeSchema = patientDeleteSchema;

export type PatientExclude = z.infer<typeof patientExcludeSchema>;
export type PatientsExcludeResponse = Response<PatientExclude>;

export type PatientsExcludeProps = {
  uniqueId: string;
  isScheduled: string;
};
