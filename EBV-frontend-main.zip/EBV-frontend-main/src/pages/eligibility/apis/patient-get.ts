import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientSchema = z.object({
  payerIdCode: z.string(),
  lastName: z.string(),
  groupId: z.string(),
  firstName: z.string(),
  verificationType: z.string(),
  patientId: z.string(),
  insurancePayer: z.string(),
  providerLastName: z.string(),
  providerTaxId: z.string(),
  providerNpi: z.string(),
  appointmentRenderingProvider: z.string(),
  memberId: z.string(),
  adminId: z.string(),
  dependentFirstName: z.string(),
  provider: z.string(),
  dateOfBirth: z.string(),
  relationship: z.string(),
  practiceNameAndLoc: z.string(),
  lastVerified: z.string(),
  createdAt: z.string(),
  subscriberId: z.string(),
  statusflag: z.string(),
  providerFirstName: z.string(),
  typeOfService: z.string(),
  isVerified: z.boolean(),
  dependentLastName: z.string(),
  addedFrom: z.string(),
  appointmentType: z.string(),
  scheduleAppointment: z.string(),
  dependentDateOfBirth: z.string(),
  uniqueId: z.string(),
  procedureCode: z.string(),
  speciality: z.string(),
});

export type PatientInfo = z.infer<typeof patientSchema> & {
  [key: string]: unknown;
};
export type PatientGetResponse = Response<PatientInfo>;

export type PatientGetProps = {
  patientId: string;
  isScheduled: string;
};

// TODO: Verify if this is working or not
// export const patientGet =
//   ({ patientId, isScheduled }: PatientGetProps) =>
//   async (): Promise<PatientGetResponse> => {
//     const url = `${
//       import.meta.env.VITE_API_HOST ?? ""
//     }/patients/?patientId=${patientId}&isScheduled=${isScheduled}`;

//     const response = (await (
//       await fetch(url, { headers: Config() })
//     ).json()) as PatientGetResponse;

//     return response;
//   };
