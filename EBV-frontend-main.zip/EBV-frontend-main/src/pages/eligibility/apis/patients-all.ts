import { DeepPartial } from "react-hook-form";
import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const patientSchema = z.object({
  verificationErrMessages: z.string().nullable(),
  verificationError: z.string().nullable(),
  verificationErrCode: z.string().nullable(),
  isVerifiedManually: z.string().nullable(),
  verificationType: z.string().nullable(),
  isVerified: z.boolean(),
  lastVerified: z.string(),
  payerIdCode: z.string(),
  lastName: z.string(),
  groupId: z.string(),
  firstName: z.string(),
  patientId: z.string(),
  insurancePayer: z.string(),
  providerLastName: z.string(),
  providerTaxId: z.string(),
  providerNpi: z.string(),
  appointmentRenderingProvider: z.string(),
  memberId: z.string(),
  adminId: z.string(),
  dependentFirstName: z.string(),
  provider: z.string(),
  dateOfBirth: z.string(),
  relationship: z.string(),
  practiceNameAndLoc: z.string(),
  createdAt: z.string(),
  subscriberId: z.string(),
  statusflag: z.string(),
  providerFirstName: z.string(),
  typeOfService: z.string(),
  dependentLastName: z.string(),
  addedFrom: z.string(),
  appointmentType: z.string(),
  scheduleAppointment: z.string(),
  dependentDateOfBirth: z.string(),
  uniqueId: z.string(),
  procedureCode: z.string(),
  procedureType: z.string(),
  speciality: z.string(),
  isScheduled: z.boolean().optional(),
  remainingBenefits: z
    .object({
      limitationAndMaximum: z.array(
        z.object({
          serviceType: z.string(),
          planPeriod: z.string(),
          amount: z.string(),
          insuranceType: z.string(),
          network: z.string(),
          coverageLevel: z.string(),
        })
      ),
      deductible: z.array(
        z.object({
          serviceType: z.string(),
          planPeriod: z.string(),
          amount: z.string(),
          insuranceType: z.string(),
          network: z.string(),
          coverageLevel: z.string(),
          message: z.string().optional(),
        })
      ),
    })
    .optional(),
  effectiveDateFrom: z.string().optional(),
  payerLogo: z.string(),
});

export type Patient = z.infer<typeof patientSchema> & {
  [key: string]: unknown;
};
export type Patients = DeepPartial<Patient>[];
export type PatientsAllResponse = Response<Patients>;
