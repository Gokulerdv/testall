import { CellContext } from "@tanstack/react-table";
import { useForm } from "react-hook-form";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import { useDialogWithFormReset } from "../../shared/hooks/use-dialog-with-form-reset";
import { PatientAttachment } from "./apis/patients-attachment-all";

export type AttachmentImageModalProps = CellContext<PatientAttachment, unknown>;

export const AttachmentImageModal = (props: AttachmentImageModalProps) => {
  const methods = useForm();
  const { open, toggle } = useDialogWithFormReset(methods);

  const src = props.row.original.base64File;

  return (
    <>
      <Button color="link" onClick={toggle}>
        {props.row.original.fileName}
      </Button>

      <Modal
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size="lg"
        zIndex={1400}
      >
        <ModalHeader toggle={toggle}>
          <div className="title">{props.row.original.fileName}</div>
        </ModalHeader>

        <ModalBody>
          <label className="w-100 mb-3"></label>

          {src ? <img height={300} src={src} alt="" className="w-100" /> : null}
        </ModalBody>
      </Modal>
    </>
  );
};
export default AttachmentImageModal;
