import React from "react";
import { Card } from "reactstrap";
import { Table } from "./table";

export const Eligibility = React.memo(() => {
  return (
    <>
      <Card>
        <Table />
      </Card>
    </>
  );
});

export default Eligibility;
