/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { dateFormat } from "../../utils/date-format";
import { Config } from "../../utils/headers-config";
export const BulkVerificationWarningModal = () => {
  const { state } = useLocation();
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;
  const [, setSearchParams] = useSearchParams();

  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/:id/bulk-verify-warning",
    togglePath: "../../?refresh=true",
  });
  const timeFormat = (lastVerified: Date) => {
    const datetimeString = lastVerified;
    const dateObj = new Date(datetimeString);

    const hours = dateObj.getHours();
    const minutes = dateObj.getMinutes();
    const seconds = dateObj.getSeconds();

    return `${hours}:${minutes}:${seconds}`;
  };

  const settingsGetById = (adminid: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/generalSettings/get/${adminid}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const bulkVerify = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/bulkverify`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const patientBulkVerify = useMutation({
    mutationKey: ["patients/bulkverify"],
    mutationFn: bulkVerify,
  });
  const patientBulkExclude = useMutation({
    mutationKey: ["patients/bulkverify"],
    mutationFn: bulkVerify,
  });
  const verifypatientUtils = useSuspenseQuery({
    queryKey: ["verifyPatient", "get", `${userId}`],
    queryFn: settingsGetById(`${userId}`),
  });

  const verifyPatientNew = async () => {
    try {
      await patientBulkVerify.mutateAsync({
        ids: state.map((data: any) => ({
          uniqueId: data.uniqueId,
          isScheduled: !!data.isScheduled,
          adminId: auth?.state?.user?.userData?.userId
        })),
      });

      toast.success("Patient verified Successfully");

      setSearchParams({ refresh: String(true) });
    } catch (error) {
      toast.error("Patient verification failed!");
      console.log(error);
    } finally {
      toggle();
    }
  };
  const excludePatientNew = async () => {
    const last3Days = new Date();
    last3Days.setDate(last3Days.getDate() - 3);
    const filteredData = state.filter((item: any) => {
      if (!item.lastVerifiedDate) {
        return true;
      }
      const [day, month, year] = item.lastVerifiedDate.split("-");
      const verifiedDate = new Date(`${year}-${month}-${day}`);
      return verifiedDate < last3Days;
    });

    try {
      await patientBulkExclude.mutateAsync({
        ids: filteredData?.map((data: any) => ({
          uniqueId: data.uniqueId,
          isScheduled: !!data.isScheduled,
          adminId: auth?.state?.user?.userData?.userId
        })),
      });
      toast.success("Patient verified Successfully");

      setSearchParams({ refresh: String(true) });
    } catch (error) {
      toast.error("Patient verification failed!");
      console.log(error);
    } finally {
      toggle();
    }
  };
  return (
    <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
      <ModalHeader toggle={toggle} className="text-white bg-primary">
        Confirmation
      </ModalHeader>
      <ModalBody className="m-auto">
        <p>
          Below Patient is recently verified in last{" "}
          {`${verifypatientUtils.data.data.warningdays}`} days. Are you sure you
          want to proceed?
        </p>
        <table className="table payer_table ">
          <thead>
            <tr>
              <th scope="col">Patients</th>
              <th scope="col">LastVerified Date</th>
              <th scope="col">LastVerified Time</th>
            </tr>
          </thead>
          <tbody>
            {state?.map((data: any) => (
              <tr className="table-secondary scheduled_process_table">
                <td>
                  {data.firstName} {data.lastName}
                </td>
                <td>{dateFormat(new Date(data.lastVerified))}</td>
                <td>{timeFormat(data.lastVerified)} </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="gap-4 hstack justify-content-center">
          <Button outline color="primary" onClick={verifyPatientNew}>
            {patientBulkVerify.isPending ? (
              <>
                <Spinner size="sm">loading...</Spinner>
                <span> loading...</span>
              </>
            ) : (
              <span>Include last verified</span>
            )}
          </Button>
          <Button color="primary" onClick={excludePatientNew}>
            {patientBulkExclude.isPending ? (
              <>
                <Spinner size="sm">loading...</Spinner>
                <span> loading...</span>
              </>
            ) : (
              <span>Exclude last verified</span>
            )}
          </Button>
        </div>
      </ModalBody>
    </Modal>
  );
};

export default BulkVerificationWarningModal;
