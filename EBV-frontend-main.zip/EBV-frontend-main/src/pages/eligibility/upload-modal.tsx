import { faImage } from "@fortawesome/free-regular-svg-icons";
import { faClose, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
} from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { Alert, Button, Card, CardBody, Form, Spinner } from "reactstrap";
import { z } from "zod";

const extractedItemSchema = z.object({
  Key: z.string(),
  Value: z.string(),
});

export type ExtractedItem = z.infer<typeof extractedItemSchema>;

const extractedItemsSchema = z.array(extractedItemSchema);

export type ExtractedItems = z.infer<typeof extractedItemsSchema>;

export type UploadModalProps = {
  onSuccess: (data: ExtractedItems) => void;
};

export const UploadModal = (props: UploadModalProps) => {
  const [files, setFiles] = React.useState<FileList>();
  const [error, setError] = React.useState<Error>();

  const [open, setOpen] = React.useState(false);
  const toggle = () => {
    setOpen(!open);
    methods.reset();
    setFiles(undefined);
  };

  const ocrFile = async (formData: FormData) => {
    const response = await fetch(`${import.meta.env.VITE_API_HOST ?? ""}/ocr`, {
      method: "POST",
      body: formData,
    });

    return await response.json();
  };
  const ocrFileMutation = useMutation({
    mutationKey: ["ocr-file"],
    mutationFn: ocrFile,
  });

  const methods = useForm();

  // const { open, toggle } = useDialogWithFormReset(methods);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onSubmit: SubmitHandler<any> = async () => {
    try {
      if (!files) return;

      if (files.length === 0) return;

      const [file] = files;

      // const [file] = event.target.files;
      const fileSize = file.size;
      const fileMb = fileSize / 1024 ** 2;

      if (fileMb <= 5) {
        const formData = new FormData();
        formData.append("image", file);

        const data = await ocrFileMutation.mutateAsync(formData);

        props.onSuccess?.(data as ExtractedItems);
        toast.success("Text successfully extracted from document!");
        setFiles(undefined);
        toggle();
      } else {
        toast.error("File size should not exceed 5MB");
      }
    } catch (error) {
      console.log(error);
      toast.error("Document upload failed!");
      setError(error as Error);
    }
  };

  const supportedFileFormats = ["image/jpeg", "image/png"];

  function formatBytes(a: number, b = 2) {
    if (!+a) return "0 Bytes";
    const c = 0 > b ? 0 : b,
      d = Math.floor(Math.log(a) / Math.log(1024));
    return `${parseFloat((a / Math.pow(1024, d)).toFixed(c))} ${
      ["Bytes", "KB", "MB", "GB", "TiB", "PiB", "EiB", "ZiB", "YiB"][d]
    }`;
  }

  return (
    <>
      <Button outline color="primary" onClick={toggle}>
        Upload
      </Button>

      <Dialog open={open} onClose={toggle} maxWidth="lg" sx={{ p: 4 }}>
        <DialogTitle>
          <div className="title">Upload</div>
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={toggle}
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
          }}
        >
          <FontAwesomeIcon icon={faClose} />
        </IconButton>
        <DialogContent style={{ width: "50rem" }}>
          {ocrFileMutation.isPending ? (
            <Alert color="info">
              <div className="gap-3 hstack justify-content-center align-items-center">
                <Spinner>Extracting...</Spinner>
                <p className="mb-0">Extracting text from the document...</p>
              </div>
            </Alert>
          ) : (
            <FormProvider {...methods}>
              <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
                {files ? (
                  <>
                    <label className="mb-3 w-100">
                      <Card
                        className="bg-primary-subtle"
                        style={{
                          border: `2px dashed #06AB89`,
                          height: "300px",
                        }}
                      >
                        <img
                          src={URL.createObjectURL(files?.[0])}
                          style={{
                            height: "inherit",
                          }}
                        />
                      </Card>
                    </label>
                  </>
                ) : (
                  <label className="mb-3 w-100">
                    <Card
                      className="bg-primary-subtle"
                      style={{
                        border: `2px dashed #06AB89`,
                      }}
                    >
                      <div className="gap-2 m-5 hstack justify-content-center">
                        <FontAwesomeIcon icon={faImage} />
                        <div>Upload Images</div>
                      </div>
                    </Card>

                    <input
                      type="file"
                      // multiple
                      accept="image/*"
                      className="d-none"
                      onChange={(event) => {
                        if (event.target.files) setFiles(event.target.files);
                      }}
                      disabled={ocrFileMutation.isPending ? true : false}
                    />
                    {error && <p>Error uploading file: {error.message}</p>}
                  </label>
                )}
              </Form>
            </FormProvider>
          )}
          <div className="gap-3 vstack">
            {files
              ? Array.from(files).map((file) => {
                  return (
                    <Card key={file.name}>
                      <CardBody>
                        <div className="hstack justify-content-between">
                          {supportedFileFormats.includes(file?.type) ? (
                            <div>
                              <div>{file.name}</div>
                              <div className="text-secondary">
                                {formatBytes(file.size)}
                              </div>
                            </div>
                          ) : (
                            <span className="warning">
                              *Invalid format!, Please upload only image files !
                            </span>
                          )}

                          <div>
                            <Button
                              color="link"
                              className="p-0 rounded-circle text-danger"
                              onClick={() => setFiles(undefined)}
                              disabled={ocrFileMutation.isPending}
                            >
                              <FontAwesomeIcon icon={faTrash} />
                            </Button>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  );
                })
              : null}
          </div>
        </DialogContent>

        <DialogActions>
          <div className="gap-2 hstack">
            <Button outline color="primary" onClick={toggle}>
              Cancel
            </Button>

            {!files ||
            (files && !supportedFileFormats.includes(files?.[0]?.type)) ? (
              <Button color="primary" className="text-white" disabled>
                Upload
              </Button>
            ) : (
              <>
                <Button
                  color="primary"
                  className="text-white"
                  disabled={ocrFileMutation.isPending ? true : false}
                  onClick={methods.handleSubmit(onSubmit)}
                >
                  {ocrFileMutation.isPending ? (
                    <Spinner size="sm"> Uploading...</Spinner>
                  ) : null}
                  {ocrFileMutation.isPending ? "Uploading..." : "Upload"}
                </Button>
              </>
            )}
          </div>
        </DialogActions>
      </Dialog>
    </>
  );
};
export default UploadModal;
