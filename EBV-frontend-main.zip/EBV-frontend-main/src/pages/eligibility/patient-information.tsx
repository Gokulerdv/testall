import { Offcanvas, OffcanvasBody } from "reactstrap";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import PatientInformationCanvas from "../patient-information";
export const PatientInformation = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/patient-information/:id",
    togglePath: "../..",
  });

  const close = () => {
    toggle();
  };
  return (
    <Offcanvas
      isOpen={open}
      toggle={toggle}
      direction="end"
      style={{ width: "80%" }}
    >
      <OffcanvasBody>
        <PatientInformationCanvas toggle={close} />
      </OffcanvasBody>
    </Offcanvas>
  );
};

export default PatientInformation;
