import { Offcanvas, OffcanvasBody, OffcanvasHeader } from "reactstrap";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import PatientBenefitInformationPage from "../patient-benefit-information";

export const PatientBenefitInformation = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/patient-benefit-information/:id",
    togglePath: "../..",
  });

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Patient Benefit Information
        </OffcanvasHeader>
        <OffcanvasBody>
          <PatientBenefitInformationPage />
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export default PatientBenefitInformation;
