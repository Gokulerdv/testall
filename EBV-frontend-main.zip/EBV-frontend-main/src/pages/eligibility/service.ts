/* eslint-disable @typescript-eslint/no-explicit-any */
import { faker } from "@faker-js/faker";
import axios from "axios";
import { Eligibility } from "../../apis/mocks/eligibility/data";
import {
  BenefitHistory,
  generateBenefitHistory,
} from "../../apis/mocks/eligibility/manual/benefits-history/data";
import { Response } from "../../apis/mocks/response";
import Config from "../../utils/headers-config";

export const eligibilityManualAll = async (): Promise<
  Response<Eligibility[]>
> => {
  return await (await fetch("/eligibility/manual/all")).json();
};

export const eligibilityManualBenefitsHistoryAll =
  (eligibilityId: string): (() => Promise<Response<BenefitHistory[]>>) =>
  async () => {
    try {
      return await (
        await fetch(`/eligibility/manual/${eligibilityId}/benefits-history/all`)
      ).json();
    } catch (error) {
      return {
        status: true,
        message: "TODO: Implement this API, this is a dummy response.",
        data: faker.helpers.multiple(generateBenefitHistory, {
          count: 2,
        }),
      } as Response<BenefitHistory[]>;
    }
  };

// export const patientEligibilityList = async (): Promise<
//   Response<
//     (Eligibility & {
//       actualResponseData: Omit<EligibilityList[0], "dentalXchangeResponse"> & {
//         dentalXchangeResponse: DeepPartial<DentalXchangeResponse>;
//       };
//     })[]
//   >
// > => {
//   const url = `${import.meta.env.VITE_API_HOST ?? ""}/patient/eligibility-list`;

//   const response = (await (
//     await fetch(url, { headers: Config() })
//   ).json()) as Response<EligibilityList>;

//   return {
//     ...response,
//     data: response.data.map((eligibility, index) => {
//       const dentalXchangeResponse =
//         eligibility.dentalXchangeResponse as DeepPartial<DentalXchangeResponse>;

//       const actualResponseData = {
//         ...eligibility,
//         dentalXchangeResponse,
//       };

//       const processedDeductible = [
//         ...(actualResponseData.dentalXchangeResponse.response?.deductible
//           ? actualResponseData.dentalXchangeResponse.response.deductible
//           : []),
//       ].reduce(
//         (acc, deductible) => acc.add(deductible?.amount as string),
//         new Set<string>()
//       );

//       const processedLimitationsAndMaximum = [
//         ...(actualResponseData.dentalXchangeResponse.response
//           ?.limitationAndMaximum
//           ? actualResponseData.dentalXchangeResponse.response
//               .limitationAndMaximum
//           : []),
//       ].reduce(
//         (acc, deductible) => acc.add(deductible?.amount as string),
//         new Set<string>()
//       );

//       return {
//         appointmentOn: "" as unknown as Date,
//         deductible:
//           processedDeductible.size === 1
//             ? parseFloat(Array.from(processedDeductible?.values())[0])
//             : processedDeductible.size === 0
//             ? null
//             : "4",
//         id: faker.string.nanoid(4),
//         insurancePlan: "",
//         insuranceStatus:
//           actualResponseData.dentalXchangeResponse.status?.code === 0
//             ? "active"
//             : "inactive",
//         lastVerifiedOn: actualResponseData.lastverified
//           ? new Date(actualResponseData.lastverified)
//           : "",
//         patientId: actualResponseData.patientid || `M${index + 1}`,
//         patientName: `${actualResponseData.dentalXchangeResponse.response?.patient?.firstName} ${actualResponseData.dentalXchangeResponse.response?.patient?.lastName}`,
//         remainingBenefits:
//           processedLimitationsAndMaximum.size === 1
//             ? parseFloat(
//                 Array.from(processedLimitationsAndMaximum?.values())[0]
//               )
//             : processedLimitationsAndMaximum.size === 0
//             ? null
//             : "5",
//         status: faker.helpers.arrayElement(["approved"]),
//         actualResponseData,
//       };
//     }),
//   };
// };

export type AddPatientBody = {
  adminId: string;
  verificationType: "manual";
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  relationship: string;
  memberId: string;
  groupId?: string;
  procedureCode?: string;
  provider: string;
  providerTaxId?: string;
  insurancePayer: string;
  payerIdCode: string;
  dependentFirstName: string;
  dependentLastName: string;
  dependentDateOfBirth: string;
  insuranceLastName?: string;
  insuranceDateOfBirth?: string;
  providerNpi?: string;
  providerFirstName?: string;
  providerLastName?: string;
  medical?: boolean;
  dental?: boolean;
  others?: boolean;
  primary?: boolean;
  secondary?: boolean;
  tertiary?: boolean;
};

// export const addPatient = async (
//   body: AddPatientBody
// ): Promise<Response<DentalXchangeResponse>> => {
//   const overwrittenBody: AddPatientBody = {
//     ...body,
//     providerNpi: body.providerNpi || "",
//     providerTaxId: body.providerTaxId || "",
//     providerFirstName: body.providerFirstName || "",
//     providerLastName: body.providerLastName || "",
//     insuranceLastName: "",
//     insuranceDateOfBirth: "",
//   };

//   const url = `${import.meta.env.VITE_API_HOST ?? ""}/patient`;

//   return await (
//     await fetch(url, urlEncodedRequestOptions(overwrittenBody))
//   ).json();
// };

export const getPatientReport = async (
  patientId: string,
  eligibilityId: string,
  auth: any,
  isScheduled: boolean | undefined,
  basic: boolean
) => {
  const body = {
    patientId,
    eligibilityId,
    isScheduled,
    basicReport: basic,
  };
  return await axios({
    method: "POST",
    url: `${import.meta.env.VITE_API_HOST ?? ""}/eligibility/getreport`,
    data: body,
    headers: {
      "Content-Type": "application/json",
      ...Config(auth),
    },
    responseType: "blob",
  });
};
