/* eslint-disable react-refresh/only-export-components */
import { faPlus, faTrash, faUpload } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  Form,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Spinner,
} from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../shared/hooks/use-auth";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import Config from "../../utils/headers-config";
import {
  PatientsAttachmentsAddProps,
  PatientsAttachmentsResponse,
  convertBase64,
} from "./apis/patients-attachments-add";
import Description, { descriptionSchema } from "./form/fields/description";
import FileName, { fileNameSchema } from "./form/fields/file-name";

export const attachmentFormSchema = fileNameSchema.merge(descriptionSchema);

export type AttachmentForm = z.infer<typeof attachmentFormSchema>;
export const addAttachmentSchema = z.object({
  id: z.string().optional(),
});
export type AddAttachmentProps = z.infer<typeof addAttachmentSchema>;

export const AddAttachment = (props: AddAttachmentProps) => {
  const [file, setFile] = React.useState<File>();
  const [error, setError] = React.useState<Error>();
  const { id } = props;
  const auth = useAuth();
  const methods = useForm<AttachmentForm>({
    resolver: zodResolver(attachmentFormSchema),
  });
  const [open, setOpen] = React.useState(false);
  const toggle = () => {
    setOpen(!open);
    setFile(undefined);
    methods.reset();
  };

  const patientsAttachmentsAdd = async (
    props: PatientsAttachmentsAddProps
  ): Promise<PatientsAttachmentsResponse> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/attachments/${
      props.body.patientId
    }`;

    const bodyData = {
      patientId: props.body.patientId,
      fileName: props.body.fileName,
      description: props.body.description,
      isPatientCard: props.body.isPatientCard,
      base64File: await convertBase64(props.body.files),
    };

    const response = (await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(bodyData),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as PatientsAttachmentsResponse;

    return response;
  };

  // const { open, toggle } = useDrawerFromLocation({
  //   matchPath:
  //     "eligibility/patient-benefit-information/:patientId/attachments/add",
  //   togglePath: "../../..",
  //   historyPopInstead: true,
  // });

  const attachmentsCreate = useMutation({
    mutationKey: ["attachment", "create"],
    mutationFn: patientsAttachmentsAdd,
  });

  const queryClient = useQueryClient();

  const onSubmit: SubmitHandler<AttachmentForm> = async (data) => {
    try {
      if (!file) {
        toast.error("Attachment is not added");
        return;
      }

      await attachmentsCreate.mutateAsync(
        {
          body: {
            description: data.description,
            fileName: data.fileName,
            files: file,
            patientId: id !== undefined ? id : "",
            isPatientCard: true,
          },
        },
        defaultMutateOptions
      );

      toggle();
      toast.success("Attachment added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
      setError(error as Error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["attachment", "getAll"],
      });
    }
  };

  const supportedFileFormats = [
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/bmp",
    "image/svg+xml",
    "application/pdf",
  ];

  return (
    <div>
      <Button color="primary" style={{ borderRadius: 40 }} onClick={toggle}>
        <FontAwesomeIcon icon={faPlus} className="text-white" />
      </Button>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "40%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Upload
        </OffcanvasHeader>
        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="gap-3 vstack">
                <FileName required />

                <Description required />

                <label className="mb-3 w-100">
                  <Card
                    className="bg-primary-subtle"
                    style={{
                      border: `2px dashed #06AB89`,
                    }}
                  >
                    <div className="gap-2 m-5 d-flex justify-content-center center ">
                      <FontAwesomeIcon icon={faUpload} /> Drag & Drop here
                      <div>or</div>
                      <div style={{ color: "blue" }}>Browse File</div>
                    </div>
                  </Card>

                  <input
                    type="file"
                    multiple
                    className="d-none"
                    accept="image/*"
                    onChange={(event) => {
                      if (event.target.files?.[0])
                        setFile(event.target.files?.[0]);
                    }}
                  />
                  {error && <p>Error uploading file: {error.message}</p>}
                </label>

                <div className="gap-3 vstack">
                  {file
                    ? [file].map((file) => (
                        <Card key={file.name}>
                          <CardBody>
                            <div className="hstack justify-content-between">
                              {supportedFileFormats.includes(file?.type) ? (
                                <div>
                                  <div>{file.name}</div>
                                  <div className="text-secondary">
                                    {file.size} bytes
                                  </div>
                                </div>
                              ) : (
                                <span className="warning">
                                  *Invalid format!, Please upload only image
                                  files !
                                </span>
                              )}

                              <div>
                                <Button
                                  color="link"
                                  className="p-0 rounded-circle text-danger"
                                  onClick={() => setFile(undefined)}
                                >
                                  <FontAwesomeIcon icon={faTrash} />
                                </Button>
                              </div>
                            </div>
                          </CardBody>
                        </Card>
                      ))
                    : null}
                </div>

                <div className="gap-2 hstack ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>

                  <Button
                    color="primary"
                    className="text-white"
                    type="submit"
                    disabled={
                      !(file && supportedFileFormats.includes(file?.type))
                    }
                  >
                    {attachmentsCreate.isPending ? (
                      <>
                        <Spinner size="sm">Uploading...</Spinner>
                        <span> Uploading...</span>
                      </>
                    ) : (
                      <span>Save</span>
                    )}
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export default AddAttachment;
