/* eslint-disable @typescript-eslint/no-explicit-any */
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { capitalCase } from "change-case";
import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";
export const key = "scheduleAppointment";

export const scheduleAppointmentSchema = z.object({
  [key]: z
    .date({ required_error: `${capitalCase(key)} is required.` })
    .optional()
    .nullable(),
});

export type ScheduleAppointmentSchema = z.infer<
  typeof scheduleAppointmentSchema
>;

export type ScheduleAppointmentProps = InputProps & {
  help?: React.ReactNode;
};

export const ScheduleAppointment = (props: ScheduleAppointmentProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={props.name || key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <DatePicker
              className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom date-of-birth"
              selected={field.value}
              minDate={new Date()}
              showTimeSelect
              timeIntervals={10}
              timeCaption="Time"
              dateFormat={"MM/d/yyyy h:mm aa"}
              showIcon
              icon={<FontAwesomeIcon icon={faCalendarDays} />}
              calendarIconClassname="text-primary"
              isClearable
              onChange={(event: any) => {
                if (event) field.onChange(event);
                else field.onChange(null);
              }}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default ScheduleAppointment;
