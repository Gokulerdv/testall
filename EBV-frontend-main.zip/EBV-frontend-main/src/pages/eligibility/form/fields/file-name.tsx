import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  Label,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";

export const key = "fileName";

export const fileNameSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} should contain at least 1 character.`),
});

export type FileNameSchema = z.infer<typeof fileNameSchema>;

export type FileNameProps = InputProps & {
  help?: React.ReactNode;
};

export const FileName = (props: FileNameProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default FileName;
