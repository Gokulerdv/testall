/* eslint-disable @typescript-eslint/no-explicit-any */
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext, useWatch } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";

export const relationshipTypes = [
  { value: "01", label: "Spouse" },
  { value: "18", label: "Self" },
  { value: "19", label: "Child" },
  { value: "20", label: "Employee" },
  { value: "21", label: "Unknown" },
  { value: "22", label: "Handicapped Dependent" },
  { value: "29", label: "Signifcant Other" },
  { value: "34", label: "Other Adult" },
  { value: "41", label: "Injured Plaintiff" },
  { value: "53", label: "Life Partner" },
  { value: "76", label: "Dependent" },
  { value: "99", label: "Other" },
];

export const key = "procedureCode";

export const procedureCodeSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`),
});

export type ProcedureCodeSchema = z.infer<typeof procedureCodeSchema>;

export type ProcedureCodeProps = InputProps & {
  help?: React.ReactNode;
};

export const ProcedureCode = (props: ProcedureCodeProps) => {
  const queryClient = useQueryClient();
  const { control } = useFormContext();
  const auth = useAuth();
  const procedureType = useWatch({ name: "procedureType" });
  const [procedureCodeData, setProcedureCodeData] = React.useState<
    any[] | undefined
  >(undefined);
  // const [procedureTypeData, setProcedureTypeData] = React.useState<
  //   string | undefined
  // >(undefined);
  const getAll = (type: string | undefined) => async (): Promise<any> => {
    const url =
      props?.isScheduled && props?.isEdit
        ? `${
            import.meta.env.VITE_API_HOST ?? ""
          }/opendental/procedurecode/getAll?procedureType=${encodeURIComponent(
            type ?? ""
          )}`
        : `${import.meta.env.VITE_API_HOST ?? ""}/procedurecodes/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: procedureCode } = useSuspenseQuery({
    queryKey: ["procedureCode", "getAll"],
    queryFn: getAll(procedureType),
  });

  React.useEffect(() => {
    (async () => {
      if (props?.isEdit) {
        await queryClient.invalidateQueries({
          queryKey: ["procedureCode", "getAll"],
        });
      }
    })();
  }, [procedureType, props?.isEdit]);
  React.useEffect(() => {
    setProcedureCodeData(procedureCode.data);
  }, [procedureCode]);
  return (
    <FormGroup>
      <Label for={key}>
        <span className="text-danger">*&nbsp;</span>
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              <option value="">Select procedure code</option>
              {procedureCodeData?.map((data: any) => (
                <option value={data.ProcCode || data.procedureCode}>
                  {data.ProcCode || data.procedureCode}
                </option>
              ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default ProcedureCode;
