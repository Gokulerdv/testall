import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";
import { Providers } from "../../../settings/provider/table/columns";

export const key = "provider";

export const providerSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`),
});

export type ProviderSchema = z.infer<typeof providerSchema>;

export type ProviderProps = InputProps & {
  help?: React.ReactNode;
  providerData: Providers;
};

export const Provider = (props: ProviderProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase("primary provider")}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              <option value="">Select provider</option>
              {props.providerData.map((provider) => (
                <option value={provider.uniqueId} key={provider.providerOption}>
                  {provider.providerOption}
                </option>
              ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default Provider;
