import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  Label,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";

export const specialties = [{ value: "Unspecified", label: "Unspecified" }];

export const key = "speciality";

export const specialtySchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`)
    .optional(),
});

export type SpecialtySchema = z.infer<typeof specialtySchema>;

export type SpecialtyProps = InputProps & {
  help?: React.ReactNode;
};

export const Specialty = (props: SpecialtyProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              {props.type === "select" ? (
                <>
                  <option value="">Select Specialty</option>
                  {specialties.map((type) => (
                    <option value={type.value} key={type.value}>
                      {type.label}
                    </option>
                  ))}
                </>
              ) : null}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default Specialty;
