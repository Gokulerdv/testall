import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";

export const key = "appointmentRenderingProvider";

export const appointmentRenderingProviders = [
  "Dr. Kumar Vadivel",
  "Dr. Archana Venkataraman",
  "Dr. Manali Tanna Madhavani",
];

export const appointmentRenderingProviderSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} ` })
    .min(1, `${capitalCase(key)} `)
    .optional(),
});

export type AppointmentRenderingProviderSchema = z.infer<
  typeof appointmentRenderingProviderSchema
>;

export type AppointmentRenderingProviderProps = InputProps & {
  help?: React.ReactNode;
  odProvider?: any;
};

export const AppointmentRenderingProvider = (
  props: AppointmentRenderingProviderProps
) => {
  const { control } = useFormContext();
  const { odProvider } = props;
  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              <option value="">-</option>
              {odProvider
                ? odProvider.map((provider: any) => (
                    <option
                      value={provider.doctorName}
                      key={provider.doctorName}
                    >
                      {provider.doctorName}
                    </option>
                  ))
                : appointmentRenderingProviders.map((provider) => (
                    <option value={provider} key={provider}>
                      {provider}
                    </option>
                  ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default AppointmentRenderingProvider;
