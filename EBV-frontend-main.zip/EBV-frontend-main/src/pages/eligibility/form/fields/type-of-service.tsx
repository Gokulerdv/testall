import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";

// export const typesOfServices = [
//   { value: "DIAGNOSTIC-PREVENTIVE", label: "DIAGNOSTIC-PREVENTIVE" },
//   { value: "SEALANT", label: "SEALANT" },
//   { value: "RESTORATIVE", label: "RESTORATIVE" },
//   { value: "ENDODONTICS", label: "ENDODONTICS" },
//   { value: "PERIODONTICS", label: "PERIODONTICS" },
//   { value: "POST & CORE", label: "POST & CORE" },
//   { value: "SINGLE CROWN", label: "SINGLE CROWN" },
//   { value: "DENTURE", label: "DENTURE" },
//   { value: "DENTURE REPAIR", label: "DENTURE REPAIR" },
//   { value: "BRIDGE", label: "BRIDGE" },
//   { value: "SIMPLE EXTRACTION", label: "SIMPLE EXTRACTION" },
//   { value: "ORAL SURGERY", label: "ORAL SURGERY" },
//   { value: "ANESTHESIA-I.V.", label: "ANESTHESIA-I.V." },
//   { value: "ANESTHESIA-NITROS", label: "ANESTHESIA-NITROS" },
//   { value: "IMPLANT", label: "IMPLANT" },
//   { value: "ORTHODONTICS", label: "ORTHODONTICS" },
//   { value: "ADJUNCTIVE GENERAL", label: "ADJUNCTIVE GENERAL" },
//   { value: "NIGHT-GUARD", label: "NIGHT-GUARD" },
//   { value: "LABIAL VEENERS - D2962", label: "LABIAL VEENERS - D2962" },
//   {
//     value: "INLAY-ONLAY-PORCELAIN/CERAMIC",
//     label: "INLAY-ONLAY-PORCELAIN/CERAMIC",
//   },
//   { value: "ORTHO COVERED", label: "ORTHO COVERED" },
//   { value: "EXAMS AND XRAY", label: "EXAMS AND XRAY" },
// ];

export const key = "typeOfService";

export const typeOfServiceSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`)
    .optional()
    .nullable(),
});

export type TypeOfServiceSchema = z.infer<typeof typeOfServiceSchema>;

export type TypeOfServiceProps = InputProps & {
  help?: React.ReactNode;
};

export const TypeOfService = (props: TypeOfServiceProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              {/* <option value="">Select Type of Service</option>
              {typesOfServices.map((type) => (
                <option value={type.value} key={type.value}>
                  {type.label}
                </option>
              ))} */}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default TypeOfService;
