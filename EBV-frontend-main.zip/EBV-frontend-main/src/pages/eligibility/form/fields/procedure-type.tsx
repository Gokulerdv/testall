/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSuspenseQuery } from "@tanstack/react-query";
import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";

export const relationshipTypes = [
  { value: "01", label: "Spouse" },
  { value: "18", label: "Self" },
  { value: "19", label: "Child" },
  { value: "20", label: "Employee" },
  { value: "21", label: "Unknown" },
  { value: "22", label: "Handicapped Dependent" },
  { value: "29", label: "Signifcant Other" },
  { value: "34", label: "Other Adult" },
  { value: "41", label: "Injured Plaintiff" },
  { value: "53", label: "Life Partner" },
  { value: "76", label: "Dependent" },
  { value: "99", label: "Other" },
];

export const key = "procedureType";

export const procedureTypeSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`),
});

export type ProcedureTypeSchema = z.infer<typeof procedureTypeSchema>;

export type ProcedureTypeProps = InputProps & {
  help?: React.ReactNode;
};

export const ProcedureType = (props: ProcedureTypeProps) => {
  const { control } = useFormContext();
  const auth = useAuth();

  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/opendental/procedurecode/getTypes`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: procedureCode } = useSuspenseQuery({
    queryKey: ["procedureCode", "getTypes"],
    queryFn: getAll,
  });

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              <option value="">Select procedure type</option>
              {procedureCode?.data?.map((type: any) => (
                <option value={type} key={type}>
                  {type}
                </option>
              ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default ProcedureType;
