/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";
import { useAuth } from "../../../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateFormat } from "../../../../utils/date-format";
import { Config } from "../../../../utils/headers-config";
export const BulkExcludeWarningModal = () => {
  const { state } = useLocation();
  const auth = useAuth();
  const [, setSearchParams] = useSearchParams();
  const queryClient = useQueryClient();

  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/:id/bulk-exclude-warning",
    togglePath: "../../?refresh=true",
  });
  const timeFormat = (lastVerified: Date) => {
    const datetimeString = lastVerified;
    const dateObj = new Date(datetimeString);

    const hours = dateObj.getHours();
    const minutes = dateObj.getMinutes();
    const seconds = dateObj.getSeconds();

    return `${hours}:${minutes}:${seconds}`;
  };

  const bulkexclude = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/bulkexclude`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const patientBulkExclude = useMutation({
    mutationKey: ["patients/bulkexclude"],
    mutationFn: bulkexclude,
  });
  const handleBulkExclude = async () => {
    try {
      await patientBulkExclude.mutateAsync({
        ids: state.map((data: any) => ({
          uniqueId: data.uniqueId,
          isScheduled: data.isScheduled,
        })),
      });
      toggle();
      toast.success("Patients excluded successfully");
      setSearchParams({ refresh: String(true) });
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };
  // const verifypatientUtils = useSuspenseQuery({
  //   queryKey: ["verifyPatient", "get", "18"],
  //   queryFn: settingsGetById("18"),
  // });

  return (
    <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
      <ModalHeader toggle={toggle} className="text-white bg-primary">
        Confirmation
      </ModalHeader>
      <ModalBody className="m-auto">
        <p>
          {/* Below Patient is recently verified in last{" "}
          {`${verifypatientUtils.data.data.warningdays}`} days. Are you sure you
          want to proceed? */}
          Are you sure you want to exclude the selected{" "}
          {`${state.length + " "}`}
          patients?
        </p>
        <table className="table payer_table ">
          <thead>
            <tr>
              <th scope="col">Patients</th>
              <th scope="col">LastVerified Date</th>
              <th scope="col">LastVerified Time</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
            {state?.map((data: any) => (
              <tr className="table-secondary scheduled_process_table">
                <td>
                  {data.firstName} {data.lastName}
                </td>
                <td>{dateFormat(new Date(data.lastVerified))}</td>
                <td>{timeFormat(data.lastVerified)} </td>
                <td>{data.isexclude === true ? "Exclude" : "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="gap-4 hstack justify-content-center">
          <Button outline color="primary" onClick={toggle}>
            Cancel
          </Button>
          <Button color="primary" onClick={handleBulkExclude}>
            {patientBulkExclude.isPending ? (
              <>
                <Spinner size="sm">loading...</Spinner>
                <span> loading...</span>
              </>
            ) : (
              <span>Proceed</span>
            )}
          </Button>
        </div>
      </ModalBody>
    </Modal>
  );
};

export default BulkExcludeWarningModal;
