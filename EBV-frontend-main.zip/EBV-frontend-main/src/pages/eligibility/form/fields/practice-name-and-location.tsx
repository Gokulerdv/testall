/* eslint-disable @typescript-eslint/no-explicit-any */
import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";
// import { useSuspenseQuery } from "@tanstack/react-query";
// import textWithDefault from "../../../../utils/text-with-default";

export const keyFirst = "practiceName";

export const keyLast = "Location";

export const key = `practiceNameAndLoc`;

export const practiceNameAndLocationSchema = z.object({
  [key]: z
    .string({
      required_error: `${capitalCase(keyFirst)} & ${capitalCase(
        keyLast
      )} is required.`,
    })
    .min(1, `${capitalCase(keyFirst)} & ${capitalCase(keyLast)} is required.`)
    .nullable()
    .optional(),
});

export type PracticeNameAndLocationSchema = z.infer<
  typeof practiceNameAndLocationSchema
>;

export type PracticeNameAndLocationProps = InputProps & {
  help?: React.ReactNode;
};

// const getAllClinics = () => async (): Promise<any> => {
//   const url = `${import.meta.env.VITE_API_HOST ?? ""}/opendental/clinics/all`;

//   const response = (await (await fetch(url)).json()) as any;

//   return response;
// };

export const PracticeNameAndLocation = (
  props: PracticeNameAndLocationProps
) => {
  const { control } = useFormContext();

  // const clinics = useSuspenseQuery({
  //   queryKey: [`opendental/clinics/all`],
  //   queryFn: getAllClinics(),
  // });

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {`${capitalCase(keyFirst)} & ${capitalCase(keyLast)}`}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              {/* <option value="">
                Select {`${capitalCase(keyFirst)} & ${capitalCase(keyLast)}`}
              </option> */}
              {/* {clinics.data.data.map((clinic: any) => (
                <option value={clinic.ClinicNum} key={clinic.ClinicNum}>
                  {textWithDefault(
                    clinic.city && clinic.state
                      ? `${clinic.City}, ${clinic.State}`
                      : clinic.city ?? clinic.state
                  )}
                </option>
              ))} */}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default PracticeNameAndLocation;
