import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";

export const appointmentTypes = [
  {
    value: "WebSched New Patient Default",
    label: "WebSched New Patient Default",
  },
  { value: "New Patient", label: "New Patient" },
  { value: "Ortho", label: "Ortho" },
  { value: "Restorative", label: "Restorative" },
  { value: "Emergency", label: "Emergency" },
  { value: "Pre-Selection", label: "Pre-Selection" },
];

export const key = "appointmentType";

export const appointmentTypeSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`)
    .optional()
    .nullable(),
});

export type AppointmentTypeSchema = z.infer<typeof appointmentTypeSchema>;

export type AppointmentTypeProps = InputProps & {
  help?: React.ReactNode;
};

export const AppointmentType = (props: AppointmentTypeProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              {/* <option value="">Select Appointment Type</option>
              {appointmentTypes.map((type) => (
                <option value={type.value} key={type.value}>
                  {type.label}
                </option>
              ))} */}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default AppointmentType;
