/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSuspenseQuery } from "@tanstack/react-query";
import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";

export const insurancePayerList = [
  { value: "11198", label: "32 BJ" },
  { value: "7000", label: "3M Dental Services" },
  { value: "AARP1", label: "AARP Dental Insurance Plan" },
  { value: "CX076", label: "Administrative Services Only (ASO)" },
  { value: "43168", label: "Advantica" },
  { value: "SCION", label: "Aetna Better Health of Kansas" },
  { value: "SCION", label: "Aetna Better Health of Pennsylvania" },
  { value: "60054", label: "Aetna Dental Plans" },
  { value: "68246", label: "Aetna DMO" },
  { value: "18014", label: "Aetna Medicare" },
  { value: "CX014", label: "Affinity Health Plan" },
  { value: "R7003", label: "Alan Sturm & Associates" },
  { value: "ALH01", label: "Aliera Health Care" },
  { value: "81040", label: "Allegiance Benefit Plan Management, Inc." },
  { value: "50503", label: "Altus Dental" },
  { value: "GP133", label: "AmeriChoice of New York" },
  { value: "CX014", label: "Amerigroup - WA Medicare" },
  { value: "CX083", label: "Amerigroup Family Care NJ" },
  { value: "GP133", label: "Amerigroup of Florida" },
  { value: "CX014", label: "Amerigroup of Georgia" },
  { value: "47009", label: "Ameritas Life Insurance Corp." },
  { value: "72630", label: "Ameritas Life Insurance Corp. of New York" },
  { value: "84105", label: "Anthem" },
  { value: "GP133", label: "APIPA (United Healthcare)" },
  { value: "ARCMS", label: "Arkansas Medicare Advantage" },
  { value: "CX076", label: "ASONET" },
  { value: "93221", label: "Asuris Northwest Health" },
  { value: "73289", label: "Author by Humana" },
  { value: "62308", label: "Banner Health and Dental" },
  { value: "60054", label: "Bell Atlantic" },
  { value: "R7003", label: "Benefits, Inc. (Sturm and Associates)" },
  { value: "TLY26", label: "Blue Advantage" },
  { value: "AD060", label: "Blue Care Family Plan" },
  { value: "CBAL1", label: "Blue Cross Blue Shield of Alabama" },
  { value: "53589", label: "Blue Cross Blue Shield of Arizona" },
  { value: "CBAR1", label: "Blue Cross Blue Shield of Arkansas" },
  { value: "AD050", label: "Blue Cross Blue Shield of Colorado - Anthem" },
  { value: "AD060", label: "Blue Cross Blue Shield of Connecticut - Anthem" },
  { value: "89070", label: "Blue Cross Blue Shield of Delaware (UCCI)" },
  { value: "CBGA1", label: "Blue Cross Blue Shield of Georgia - Anthem" },
  { value: "CBGA1", label: "Blue Cross Blue Shield of Georgia - Federal" },
  { value: "HMSA1", label: "Blue Cross Blue Shield of Hawaii" },
  { value: "621", label: "Blue Cross Blue Shield of Illinois" },
  { value: "AD130", label: "Blue Cross Blue Shield of Indiana - Anthem" },
  { value: "CBKS1", label: "Blue Cross Blue Shield of Kansas" },
  { value: "DX067", label: "Blue Cross Blue Shield of Kansas City (MO)" },
  { value: "AD160", label: "Blue Cross Blue Shield of Kentucky - Anthem" },
  {
    value: "UCCAP",
    label: "Blue Cross Blue Shield of Louisiana Advantage Plus Network",
  },
  { value: "AD180", label: "Blue Cross Blue Shield of Maine - Anthem" },
  { value: "580", label: "Blue Cross Blue Shield of Maryland - CareFirst" },
  { value: "CBMA1", label: "Blue Cross Blue Shield of Massachusetts" },
  { value: "BBMDQ", label: "Blue Cross Blue Shield of Michigan" },
  { value: "AD241", label: "Blue Cross Blue Shield of Missouri - Anthem" },
  { value: "CBMT1", label: "Blue Cross Blue Shield of Montana" },
  { value: "AD265", label: "Blue Cross Blue Shield of Nevada - Anthem" },
  { value: "AD270", label: "Blue Cross Blue Shield of New Hampshire - Anthem" },
  { value: "84100", label: "Blue Cross Blue Shield of New Mexico" },
  { value: "CX004", label: "Blue Cross Blue Shield of North Dakota" },
  { value: "89070", label: "Blue Cross Blue Shield of North Dakota (UCCI)" },
  {
    value: "89070",
    label: "Blue Cross Blue Shield of North Dakota FEP (UCCI)",
  },
  { value: "AD332", label: "Blue Cross Blue Shield of Ohio - Anthem" },
  { value: "BCSOK", label: "Blue Cross Blue Shield of Oklahoma" },
  { value: "851", label: "Blue Cross Blue Shield of Oregon/ Regence" },
  { value: "53473", label: "Blue Cross Blue Shield of Rhode Island" },
  { value: "BCSSC", label: "Blue Cross Blue Shield of South Carolina" },
  { value: "DXSCF", label: "Blue Cross Blue Shield of South Carolina (FEP)" },
  { value: "CBTN1", label: "Blue Cross Blue Shield of Tennessee" },
  { value: "84980", label: "Blue Cross Blue Shield of Texas" },
  { value: "AD423", label: "Blue Cross Blue Shield of Virginia - Anthem" },
  { value: "89070", label: "Blue Cross Blue Shield of Western New York" },
  {
    value: "AD450",
    label: "Blue Cross Blue Shield of Wisconsin (United of Wisconsin)",
  },
  { value: "AD450", label: "Blue Cross Blue Shield of Wisconsin FEP - Anthem" },
  { value: "53767", label: "Blue Cross Blue Shield of Wyoming" },
  { value: "53767", label: "Blue Cross Blue Shield of Wyoming FEP (UCCI)" },
  { value: "84103", label: "Blue Cross of California - Anthem" },
  { value: "621", label: "Blue Cross of Illinois (IL)" },
  { value: "47570", label: "Blue Cross of Washington" },
  { value: "7000", label: "Blue Plus Public Programs" },
  { value: "BSCA2", label: "Blue Shield of California Federal Plan" },
  { value: "611", label: "Blue Shield of Idaho / Regence" },
  { value: "89070", label: "Blue Shield of Northeastern New York (UCCI)" },
  {
    value: "932",
    label: "Blue Shield of Washington / Regence of Washington Health",
  },
  { value: "CX028", label: "Bridgeport Dental Service" },
  { value: "SDCOM", label: "BrightBenefits" },
  { value: "47009", label: "Brokers National" },
  { value: "11198", label: "Buffalo Teachers Federation" },
  { value: "11198", label: "Building Service 32BJ Health Fund" },
  { value: "CX014", label: "California Dental Network (DentaQuest)" },
  { value: "80705", label: "Canada Life Assurance Company" },
  { value: "GP133", label: "Care Improvement Plus" },
  { value: "580", label: "CareFirst - Blue Cross Blue Shield of Maryland" },
  { value: "GACS1", label: "CareSource Georgia" },
  { value: "INCS1", label: "CareSource Indiana" },
  { value: "31114", label: "CareSource OH MyCare Medicaid & Medicare" },
  { value: "CX021", label: "Chicago Transit Authority (CompBenefits)" },
  { value: "60054", label: "Choice Plus" },
  { value: "62308", label: "CIGNA" },
  { value: "62308", label: "Cigna DHMO" },
  { value: "CX014", label: "Cigna Health Springs Medicare Advantage" },
  { value: "CIGN1", label: "CIGNA International" },
  { value: "80705", label: "Cigna Select (Formerly known as Great West)" },
  { value: "CX021", label: "City of Chicago (CompBenefits)" },
  { value: "CX021", label: "CompBenefits" },
  { value: "CX021", label: "CompBenefits and Humana Specialty Benefits" },
  { value: "62308", label: "Connecticut General (CIGNA)" },
  { value: "62308", label: "Continental Dental" },
  { value: "CX076", label: "Correction Captains (Active and Retired)" },
  { value: "CX076", label: "Council of Supervisors and Administrators" },
  { value: "60054", label: "CustomCare (Southwestern Bell - Exec)" },
  { value: "7000", label: "DCASI" },
  { value: "94276", label: "DDIC" },
  { value: "89070", label: "DE (Delaware) Adult Medicaid" },
  { value: "2027", label: "Delta Dental (Northeast - ME, NH, and VT)" },
  {
    value: "94275",
    label: "Delta Dental Health Svcs for Children with Spec Needs (HSCSN)",
  },
  { value: "DDAL1", label: "Delta Dental Ins. Co. - Alabama" },
  { value: "DDFL1", label: "Delta Dental Ins. Co. - Florida" },
  { value: "DDGA1", label: "Delta Dental Ins. Co. - Georgia" },
  { value: "DDLA1", label: "Delta Dental Ins. Co. - Louisiana" },
  { value: "DDMS1", label: "Delta Dental Ins. Co. - Mississippi" },
  { value: "DDMT1", label: "Delta Dental Ins. Co. - Montana" },
  { value: "DDNV1", label: "Delta Dental Ins. Co. - Nevada" },
  { value: "DDTX1", label: "Delta Dental Ins. Co. - Texas" },
  { value: "DDUT1", label: "Delta Dental Ins. Co. - Utah" },
  { value: "86027", label: "Delta Dental of Arizona" },
  { value: "CDAR1", label: "Delta Dental of Arkansas" },
  { value: "77777", label: "Delta Dental of California" },
  { value: "DDPCO", label: "Delta Dental of Colorado" },
  { value: "22189", label: "Delta Dental of Connecticut" },
  { value: "51022", label: "Delta Dental of Delaware" },
  { value: "5030", label: "Delta Dental of Illinois" },
  { value: "DDPI", label: "Delta Dental of Indiana" },
  { value: "CDIA1", label: "Delta Dental of Iowa" },
  { value: "CDIAM", label: "Delta Dental of Iowa - Government Programs" },
  { value: "CDKY1", label: "Delta Dental of Kentucky" },
  { value: "DDMD1", label: "Delta Dental of Maryland" },
  { value: "DDPM", label: "Delta Dental of Michigan" },
  { value: "7000", label: "Delta Dental of Minnesota" },
  { value: "43090", label: "Delta Dental of Missouri" },
  { value: "7027", label: "Delta Dental of Nebraska" },
  { value: "22189", label: "Delta Dental of New Jersey" },
  { value: "DDPNM", label: "Delta Dental of New Mexico" },
  { value: "11198", label: "Delta Dental of New York" },
  { value: "56101", label: "Delta Dental of North Carolina" },
  { value: "7029", label: "Delta Dental of North Dakota" },
  { value: "DDPO", label: "Delta Dental of Ohio" },
  { value: "DDPOK", label: "Delta Dental of Oklahoma" },
  { value: "23166", label: "Delta Dental of Pennsylvania" },
  { value: "66043", label: "Delta Dental of Puerto Rico" },
  { value: "5029", label: "Delta Dental of Rhode Island" },
  { value: "43091", label: "Delta Dental of South Carolina" },
  { value: "DDPTN", label: "Delta Dental of Tennessee" },
  { value: "54084", label: "Delta Dental of Virginia" },
  { value: "91062", label: "Delta Dental of Washington" },
  { value: "52147", label: "Delta Dental of Washington DC" },
  { value: "31096", label: "Delta Dental of West Virginia" },
  { value: "7000", label: "Delta Minnesota Capitation" },
  { value: "7000", label: "Delta Minnesota DeltaCare Claims" },
  { value: "7031", label: "Delta Minnesota M.A./Public Programs" },
  { value: "7000", label: "Delta Minnesota National Claims" },
  { value: "7000", label: "Delta Minnesota/Wells Fargo Claims" },
  { value: "7000", label: "Delta USA Dental Claims-Plan 005 MN" },
  { value: "DDCA2", label: "DeltaCare USA - Claims" },
  { value: "DDCA3", label: "DeltaCare USA - Encounters" },
  { value: "52133", label: "Dental Benefit Providers" },
  { value: "64246", label: "Dental Guard Preferred" },
  { value: "CX014", label: "DentaQuest - Government" },
  { value: "DX214", label: "Deseret Mutual Benefit Administrators (DMBA)" },
  { value: "SDCOM", label: "Direct Dental Administrators, Inc." },
  {
    value: "11198",
    label: "District Council 37 Health and Security Plan [DOS after 9/1/20]",
  },
  { value: "CX076", label: "Doctors Council Benefit Fund" },
  { value: "73288", label: "EHI, EHIC" },
  { value: "73288", label: "Emphesys" },
  {
    value: "81039",
    label: "Employee Benefit Management Services, Inc. (EBMS)",
  },
  { value: "73288", label: "Employers Health Insurance of Wisconsin" },
  { value: "62308", label: "Equicor / Equitable" },
  { value: "GP133", label: "EVERCARE of New Mexico / United HealthCare" },
  { value: "54771", label: "Federal Employees Program" },
  { value: "64246", label: "First Commonwealth HMO Dental Plan" },
  { value: "13317", label: "First Reliance Standard" },
  { value: "R7004", label: "Flex Compensation" },
  { value: "60054", label: "FlexCare" },
  { value: "76031", label: "Florida Combined Life (Dental)" },
  { value: "60054", label: "Florida Power & Light" },
  { value: "96938", label: "Gateway Health Plan" },
  { value: "44054", label: "GEHA" },
  { value: "GHP22", label: "Geisinger Health Plan" },
  { value: "CX014", label: "Georgia Medicaid, Grady Healthcare,Inc" },
  { value: "80314D", label: "GIC" },
  { value: "GWD01", label: "Golden West Dental" },
  { value: "44054", label: "Government Employee Hospital Association, Inc." },
  { value: "64246", label: "Guardian Life Insurance Co. of America" },
  { value: "99010", label: "Hawaii Dental Service" },
  { value: "621", label: "HCSC (Blue Cross Blue Shield of Illinois)" },
  { value: "HDSMH", label: "HDS Medicaid" },
  { value: "52133", label: "Health Net - Commercial" },
  { value: "CX083", label: "Health Net - Government Program" },
  { value: "CX083", label: "Health Net 21 - LA & Sacramento (LIBERTY Dental)" },
  { value: "CX083", label: "Health Net Los Angeles PHP (LIBERTY Dental)" },
  { value: "CX083", label: "Health Net Sacramento GMC (LIBERTY Dental)" },
  { value: "HCH01", label: "Healthcare Highways (Lubbock, TX)" },
  { value: "71064", label: "HealthChoice Oklahoma" },
  { value: "89070", label: "HealthNow Federal (UCCI)" },
  { value: "71063", label: "HealthScope Benefits" },
  { value: "31118", label: "HealthScope Benefits (Tribute Health Plan)" },
  { value: "52429", label: "HealthScope Benefits / EHC Repricing" },
  { value: "35092", label: "HealthScope Benefits/ Morris Associates" },
  { value: "71084", label: "HealthScope Benefits/ACPMO" },
  { value: "62308", label: "Healthsource Provident" },
  { value: "CKSC1", label: "Healthy Connections (Medicaid of South Carolina)" },
  { value: "GP133", label: "Healthy Michigan Dental (UHC)" },
  { value: "CX013", label: "Hershey Healthsmile" },
  { value: "89070", label: "Highmark West Virginia (UCCI)" },
  { value: "HMSA1", label: "HMSA (BCBS of Hawaii)" },
  { value: "73288", label: "Humana" },
  { value: "CX021", label: "Humana CompBenefits Federal Plan Dental" },
  { value: "73288", label: "Humana Specialty Benefits Claim" },
  {
    value: "CX021",
    label: "Humana Specialty Benefits Florida Healthy Kids Dental",
  },
  {
    value: "CX021",
    label: "Humana Specialty Benefits State of Florida Dental",
  },
  { value: "CX014", label: "Idaho Smiles" },
  { value: "65030", label: "Idaho Smiles Medicaid" },
  {
    value: "DDPI",
    label: "Indiana/Kentucky/Ohio Regional Council of Carpenters Welfare Fund",
  },
  {
    value: "DDPO",
    label:
      "International Brotherhood of Electrical Workers (IBEW), Local 38 Health & Welfare Fund",
  },
  { value: "61271", label: "J. F. Molloy and Associates" },
  { value: "R7001", label: "Laborers Union of Minnesota" },
  { value: "CX083", label: "Liberty Dental - Medicaid of Nevada" },
  { value: "CX083", label: "Liberty Dental Plan" },
  { value: "RLH01", label: "LifeMap" },
  { value: "47009", label: "LifeRe" },
  { value: "LWHOR", label: "LifeWise Health Plan of Oregon" },
  { value: "47570", label: "LifeWise Health Plan of Washington" },
  { value: "52133", label: "Lincoln Financial Group (Salt Lake City)" },
  { value: "CKPA1", label: "MA Service Program" },
  { value: "65030", label: "Managed Care of North America, Inc. (MCNA)" },
  { value: "64246", label: "Managed Dental Care Network" },
  { value: "CX014", label: "Managed Health Services - WI State Employees" },
  { value: "CX014", label: "Maricopa Health Plan (DentaQuest)" },
  { value: "60054", label: "Marriott" },
  { value: "2027", label: "Martin’s Point Generation Advantage Claims" },
  { value: "CX014", label: "Maryland Physicians Care MCO" },
  { value: "7031", label: "MEDICA of Minnesota" },
  { value: "CKAL1", label: "Medicaid of Alabama" },
  { value: "65030", label: "Medicaid of Arkansas (MCNA)" },
  { value: "CX014", label: "Medicaid of Colorado - DentaQuest" },
  { value: "CKCT1", label: "Medicaid of Connecticut" },
  { value: "CX014", label: "Medicaid of Georgia, Grady Healthcare, Inc" },
  { value: "CKID1", label: "Medicaid of Idaho" },
  { value: "CKIL1", label: "Medicaid of Illinois" },
  { value: "CKIN1", label: "Medicaid of Indiana" },
  { value: "65030", label: "Medicaid of Iowa - MCNA" },
  { value: "CKKY3", label: "Medicaid of Kentucky - DentaQuest" },
  { value: "CX014", label: "Medicaid of Maryland, PhysiciansCare MCO" },
  { value: "CKMI1", label: "Medicaid of Michigan" },
  { value: "CKMN1", label: "Medicaid of Minnesota" },
  { value: "GP133", label: "Medicaid of Mississippi (UHC Community Plan)" },
  { value: "CX014", label: "Medicaid of Missouri, Blue Advantage" },
  {
    value: "CX014",
    label: "Medicaid of Missouri, Community Care Plus - St. Louis",
  },
  { value: "CX014", label: "Medicaid of Missouri, Community Health Plan" },
  { value: "CX014", label: "Medicaid of Missouri, FirstGuard Health Plan" },
  { value: "CX014", label: "Medicaid of Missouri, HealthCare USA - St. Louis" },
  {
    value: "CX014",
    label: "Medicaid of Missouri, TrumanCare - Family Health Partners",
  },
  { value: "65030", label: "Medicaid of Nebraska - MCNA" },
  {
    value: "CX014",
    label: "Medicaid of Nebraska, United HealthCare of the Midlands",
  },
  { value: "GP133", label: "Medicaid of New Jersey (UHC Community Plan - NJ)" },
  { value: "CX014", label: "Medicaid of New Mexico, Cimmaron Health Plan" },
  {
    value: "CX014",
    label: "Medicaid of New Mexico, Lovelace Community Health Plan",
  },
  { value: "CX014", label: "Medicaid of New Mexico, Presbyterian Salud" },
  { value: "CKNY1", label: "Medicaid of New York" },
  { value: "GP133", label: "Medicaid of New York (UHC Community Plan)" },
  { value: "CKNC1", label: "Medicaid of North Carolina" },
  { value: "CKOH1", label: "Medicaid of Ohio" },
  { value: "CX014", label: "Medicaid of Ohio (CareSource)" },
  { value: "CX014", label: "Medicaid of Ohio, Emerald HMO and Medicare, Inc." },
  { value: "CX014", label: "Medicaid of Ohio, Health Power HMO, Cincinnati" },
  {
    value: "CX014",
    label: "Medicaid of Ohio, Personal Physicians Care, Cleveland",
  },
  {
    value: "CX014",
    label: "Medicaid of Ohio, United HealthCare, Inc. Medicare Complete",
  },
  { value: "CX014", label: "Medicaid of Oklahoma, Community Care" },
  { value: "CX014", label: "Medicaid of Oklahoma, Heartland Health Plan" },
  { value: "CX014", label: "Medicaid of Oklahoma, Unicare Health Plan" },
  { value: "CKPA1", label: "Medicaid of Pennsylvania" },
  { value: "GP133", label: "Medicaid of Pennsylvania (UHC Community Plan)" },
  {
    value: "CX014",
    label: "Medicaid of Pennsylvania, Gateway Health Plan, Pittsburgh",
  },
  {
    value: "CX014",
    label: "Medicaid of Pennsylvania, Health Partners, Philadelphia",
  },
  { value: "CX014", label: "Medicaid of Pennsylvania, Oaktree" },
  { value: "GP133", label: "Medicaid of Rhode Island (UHC Community Plan)" },
  { value: "GP133", label: "Medicaid of Tennessee (UHC Community Plan)" },
  { value: "CX014", label: "Medicaid of Tennessee, BlueCare" },
  { value: "CX014", label: "Medicaid of Texas - DentaQuest" },
  { value: "MCNA1", label: "Medicaid of Texas - MCNA" },
  { value: "GP133", label: "Medicaid of Texas (UHC Community Plan)" },
  { value: "CKUT1", label: "Medicaid of Utah" },
  { value: "CX014", label: "Medicaid of Virginia, HealthKeepers Plus" },
  { value: "CKWA1", label: "Medicaid of Washington" },
  { value: "CX014", label: "Medicaid of Wisconsin - DentaQuest" },
  { value: "CX014", label: "Medicaid of Wisconsin, Humana / TDC" },
  { value: "CX014", label: "Medicaid of Wisconsin, PrimeCare" },
  { value: "CX014", label: "Mercy Care Plans (DentaQuest)" },
  { value: "65978", label: "MetLife" },
  { value: "89070", label: "MetLife Tricare" },
  {
    value: "5030",
    label: "Midwest Operating Engineers (MOE) Welfare Fund Local 150",
  },
  { value: "89070", label: "Minnesota Blue Cross Dental (UCCI)" },
  { value: "SKYGN", label: "Molina Healthcare of Michigan" },
  { value: "SKYGN", label: "Molina Healthcare of Mississippi" },
  { value: "SKYGN", label: "Molina Healthcare of Wisconsin" },
  { value: "SKYGN", label: "Molina Ohio" },
  { value: "52133", label: "National Pacific Dental (CA)" },
  { value: "52133", label: "National Pacific Dental (TX)" },
  { value: "52133", label: "Nevada Pacific Dental" },
  { value: "CX076", label: "New York City Retirees" },
  { value: "CX004", label: "North Dakota Dental Service" },
  { value: "2027", label: "Northeast Delta Dental" },
  { value: "7000", label: "NWA Claims" },
  { value: "CX076", label: "NYC Municipal Plumber/Pipefitters" },
  { value: "71065", label: "Oklahoma DRS Doc" },
  { value: "80705", label: "ONE Health Plan Inc." },
  { value: "CX076", label: "Organization of Staff Analysts Welfare Fund" },
  { value: "52133", label: "Pacific Union Dental (CA)" },
  { value: "CX076", label: "Painter Local 155 Welfare" },
  { value: "CX076", label: "Painting Insurance Fund DC9" },
  { value: "CX014", label: "Phoenix Health Plans (DentaQuest)" },
  { value: "CX068", label: "Physicians Mutual (Dental)" },
  {
    value: "CX014",
    label: "Physicians Plus Insurance, Co., Wisconsin State Employees",
  },
  { value: "621", label: "PreDent" },
  { value: "60054", label: "Preferred Dental Organization (PDO)" },
  { value: "DX102", label: "Premera BlueCross (AK)" },
  { value: "47570", label: "Premera BlueCross (WA" },
  {
    value: "CX014",
    label: "PrimeCare, Wisconsin State and Federal Employees and Medicaid",
  },
  { value: "LX049", label: "PrimeWest" },
  { value: "61271", label: "Principal Financial Group" },
  { value: "61271", label: "Principal Mutual Life Insurance Co." },
  { value: "62308", label: "Provident Life & Casualty Ins. Co." },
  { value: "62308", label: "Provident Life and Accident Ins. Co." },
  { value: "62308", label: "Provident Preferred Network" },
  { value: "60054", label: "Prudential Administered by Aetna" },
  { value: "81039", label: "Public Education Health Trust" },
  {
    value: "851",
    label: "Regence Blue Cross/Blue Shield of Oregon (out of State Providers)",
  },
  {
    value: "611",
    label: "Regence Blue Shield of Idaho (out of State Providers)",
  },
  { value: "932", label: "Regence Blue Shield, Regence Washington Health" },
  { value: "36088", label: "Reliance Standard Life" },
  { value: "CX076", label: "Sanitation Officers Local 444" },
  { value: "SCION", label: "Scion Dental, LLC" },
  { value: "47009", label: "Security Life Insurance" },
  { value: "CX107", label: "SelectHealth" },
  { value: "CX076", label: "SIDS (Self Insured Dental Services)" },
  { value: "SKYGN", label: "Skygen USA" },
  { value: "7000", label: "South Country Health Alliance" },
  { value: "60054", label: "Southwestern Bell" },
  { value: "60054", label: "Southwestern Bell Exec. - Custom Care" },
  { value: "60054", label: "Southwestern Bell Exec. - Southwest Bell" },
  { value: "93024", label: "Standard Insurance" },
  { value: "13411", label: "Standard Insurance Co. of New York" },
  { value: "R7003", label: "Sturm & Associates" },
  { value: "CX076", label: "Suffolk County Municipal Employees Benefit Fund" },
  {
    value: "89070",
    label: "Sun Life Financial (United Concordia) DOS Prior to 1/1/2018",
  },
  { value: "CX014", label: "Sunflower State Health" },
  { value: "7000", label: "Target Dental Services" },
  { value: "73288", label: "TDC (The Dental Companies)" },
  { value: "81040", label: "Teachers Health Trust" },
  { value: "84105", label: "Teamsters Joint Council #83 Of VA" },
  { value: "CX014", label: "TennCare" },
  { value: "DXTAS", label: "Tricare Active Reservists" },
  { value: "89070", label: "TRICARE Dental Program (TDP)" },
  { value: "84103", label: "Trigon - Blue Cross/Blue Shield of Colorado" },
  { value: "84103", label: "Trigon - Blue Cross/Blue Shield of Virginia" },
  { value: "60054", label: "TRW" },
  { value: "DXTAS", label: "TSRDP Dental Claims" },
  { value: "84105", label: "UFCW Local 655 Health and Welfare Fund" },
  { value: "62308", label: "UFT Welfare Fund" },
  { value: "80314D", label: "UniCare" },
  { value: "80314D", label: "UniCare of Texas - HMO" },
  { value: "UCCDP", label: "United Concordia - Dental Plus - PA Blue Shield" },
  { value: "54771", label: "United Concordia - Federal Employees Program" },
  { value: "UCCTR", label: "United Concordia - Tricare Dental Plan" },
  { value: "UCCEN", label: "United Concordia (Encounters)" },
  { value: "89070", label: "United Concordia Companies, Inc." },
  {
    value: "DDPO",
    label:
      "United Food & Commercial Workers Union of Central Ohio (UFCW of Central Ohio)",
  },
  { value: "52133", label: "United Healthcare" },
  { value: "GP133", label: "United Healthcare Arizona Physicians IPA" },
  { value: "GP133", label: "United Healthcare Community Plan" },
  { value: "GP133", label: "United Healthcare Community Plan - MS" },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - New Mexico EverCare",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - NJ (Formerly Americhoice)",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - NY (Formerly Americhoice)",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - PA (Formerly Americhoice)",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - RI (Formerly Americhoice)",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - TN (Formerly Americhoice)",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan - TX (Formerly Americhoice)",
  },
  { value: "GP133", label: "United Healthcare Community Plan (AHCCCS)" },
  { value: "GP133", label: "United Healthcare Community Plan (AZ Healthnet)" },
  { value: "GP133", label: "United Healthcare Community Plan (FL)" },
  { value: "GP133", label: "United Healthcare Community Plan (GA Medicare)" },
  { value: "GP133", label: "United Healthcare Community Plan (HI Medicare)" },
  { value: "GP133", label: "United Healthcare Community Plan (KS)" },
  { value: "GP133", label: "United Healthcare Community Plan (MA)" },
  { value: "GP133", label: "United Healthcare Community Plan (MI Medicare)" },
  {
    value: "GP133",
    label: "United Healthcare Community Plan (Special Handling)",
  },
  {
    value: "GP133",
    label: "United Healthcare Community Plan (Unison Health Plan)",
  },
  { value: "GP133", label: "United Healthcare Community Plan (WA Medicare)" },
  {
    value: "GP133",
    label: "United Healthcare Community Plan (Wash. DC Medicare)",
  },
  { value: "GP133", label: "United healthcare Community Plan (WI)" },
  { value: "GP133", label: "United Healthcare Community Plan AZ-Evercare" },
  {
    value: "GP133",
    label:
      "United Healthcare Community Plan Louisiana-Medicaid (Healthy Louisiana)",
  },
  { value: "52133", label: "United Healthcare Global (Inside U.S.)" },
  { value: "GP133", label: "United Healthcare MI Dental" },
  { value: "GP133", label: "United Healthcare of the Midwest" },
  { value: "CX014", label: "University of Arizona Health Plans (DentaQuest)" },
  { value: "60054", label: "Varian Health Care Plan" },
  {
    value: "91062",
    label: "Washington Dental Service (Delta Dental of Washington)",
  },
  { value: "CX083", label: "Wellcare (LIBERTY Dental)" },
  { value: "CX014", label: "WI State Employees - Managed Health Services" },
  {
    value: "CX014",
    label: "WI State Employees - Physicians Plus Insurance Company",
  },
  { value: "R7002", label: "Wilson McShane" },
  { value: "R7001", label: "Zenith Administrators (MN)" },
];

export const key = "insurancePayer";

export const insurancePayerSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`),
});

export type InsurancePayerSchema = z.infer<typeof insurancePayerSchema>;

export type InsurancePayerProps = InputProps & {
  help?: React.ReactNode;
};

export const InsurancePayer = (props: InsurancePayerProps) => {
  const { control } = useFormContext();
  const auth = useAuth();

  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/settings/credentialgetall`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: myInsurancePayerData } = useSuspenseQuery({
    queryKey: ["insurancePayer", "getAll"],
    queryFn: getAll,
  });

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              {props.type === "select" ? (
                <>
                  <option value="">Select Insurance Payer</option>
                  {insurancePayerList.map((type) => (
                    <option value={type.label} key={type.value}>
                      {type.label}
                    </option>
                  ))}
                </>
              ) : null}
              {props.type === "select" ? (
                <option disabled>Others</option>
              ) : null}
              {props.type === "select" ? (
                <>
                  {myInsurancePayerData?.data?.map((type: any) => (
                    <option value={type.payer} key={type.payer}>
                      {type.payer}
                    </option>
                  ))}
                </>
              ) : null}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default InsurancePayer;
