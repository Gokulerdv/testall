/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";
import { useAuth } from "../../../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { Config } from "../../../../utils/headers-config";

export const ConfirmationPdfModal = () => {
  // const { onClick } = props;
  const queryClient = useQueryClient();
  const { state } = useLocation();
  const auth = useAuth();
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/:id/bulk-pdf-warning",
    togglePath: "../../?refresh=true",
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const bulkPdf = async (data: any): Promise<void> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/bulkpdf`;

    const response = await fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    if (response.ok) {
      const blob = await response.blob();

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "bulk_pdf.pdf";

      a.click();

      window.URL.revokeObjectURL(url);
    } else {
      console.error("Failed to fetch PDF:", response.statusText);
    }
  };

  const patientBulkPdf = useMutation({
    mutationKey: ["patients/bulkpdf", "create"],
    mutationFn: bulkPdf,
  });
  const handleBulkPdf = async () => {
    try {
      await patientBulkPdf.mutateAsync({
        manualPatientsIds: state.map(
          (data: { uniqueId: any }) => data.uniqueId
        ),
        schedulePatientIds: state.map(
          (data: { uniqueId: any }) => data.uniqueId
        ),
      });
      toggle();
      toast.success("Pdf downloaded successfully", { toastId: "pdfSuccess" });
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };
  return (
    <>
      {/* <Button color="light" className="text-white" onClick={toggle}>
        Download PDF
      </Button> */}

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md" centered>
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Confirmation
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>
            Are you sure you want to export the selected patient in PDF format?
          </p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" onClick={handleBulkPdf}>
              {patientBulkPdf.isPending ? (
                <>
                  <Spinner size="sm">loading...</Spinner>
                  <span> loading...</span>
                </>
              ) : (
                <span>Yes</span>
              )}
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default ConfirmationPdfModal;
