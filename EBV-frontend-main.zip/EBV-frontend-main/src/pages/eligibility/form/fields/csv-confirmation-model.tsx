/* eslint-disable @typescript-eslint/no-explicit-any */
import { useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import XLSX from "xlsx";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateTimeFormat } from "../../../../utils/date-time-format";

export const ConfirmationCsvModal = () => {
  // const { onClick } = props;
  const { state } = useLocation();
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "eligibility/:id/bulk-csv-warning",
    togglePath: "../../?refresh=true",
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any

  const exportAsCSV = () => {
    try {
      const rows = state.map((cell: any) => ({
        "Patient Id": cell.patientId,
        "Patient Name": cell.firstName + " " + cell.lastName,
        "Type Of Service": cell.typeOfService,
        "Practice Name & Location": cell.practiceNameAndLoc,
        "Appointment Type": cell.appointmentType,
        "Insurance Name/Plan":
          cell.providerFirstName + "" + cell.providerLastName,
        Appointment: cell.scheduleAppointment
          ? dateTimeFormat(new Date(cell.scheduleAppointment))
          : null,
        "Last Verified": cell.lastVerified
          ? dateTimeFormat(new Date(cell.lastVerified))
          : null,
        Status: cell.insuranceStatus,
        "Insurance Payer Code": cell.payerIdCode,
        Speciality: cell.speciality,
        "Date Of Birth": cell.dateOfBirth
          ? dateTimeFormat(new Date(cell.dateOfBirth))
          : null,
        "Subscriber ID": cell.subscriberId,
        "Appointment Rendering Provider": cell.appointmentRenderingProvider,
      }));
      const worksheet = XLSX.utils.json_to_sheet(rows);

      const workBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workBook, worksheet, "data");
      XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      toggle();
      toast.success("CSV downloaded successfully", { toastId: "csvSuccess" });
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    }
  };
  return (
    <>
      {/* <Button color="light" className="text-white" onClick={toggle}>
        Download PDF
      </Button> */}

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md" centered>
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Confirmation
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>
            Are you sure you want to export the selected patient in CSV format?
          </p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" onClick={exportAsCSV}>
              <span>Yes</span>
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default ConfirmationCsvModal;
