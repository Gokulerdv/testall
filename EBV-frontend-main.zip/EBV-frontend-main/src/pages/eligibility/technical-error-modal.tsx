import { faFile } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { CellContext } from "@tanstack/react-table";
import React from "react";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import { Patient } from "./apis/patients-all";

export type TechnicalErrorModalProps = {
  uniqueId: string;
  info: CellContext<Patient, unknown>;
};

export const TechnicalErrorModal = ({ info }: TechnicalErrorModalProps) => {
  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  return (
    <>
      <Button
        color="link"
        className={`rounded-circle p-0`}
        style={{ color: "var(--bs-danger)" }}
        onClick={toggle}
      >
        <FontAwesomeIcon icon={faFile} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md">
        <ModalHeader toggle={toggle}>
          <div className="title">Technical Error</div>
        </ModalHeader>

        <ModalBody>
          Error occurred. Please check logs.
          <div className="m-2">
            <p>
              {" "}
              <b> Error Code: </b>
              {info.row.original.verificationErrCode}
            </p>
            <p>
              <b>Error Message:</b> {info.row.original.verificationError}
            </p>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default TechnicalErrorModal;
