import { faClose } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Dialog, DialogContent, DialogTitle, IconButton } from "@mui/material";
import React, { useEffect } from "react";
import QRCode from "react-qr-code";
import { Button } from "reactstrap";
import { v4 as uuidv4 } from "uuid";
import { z } from "zod";

// Define the schema for a single data item
const extractedItemSchema = z.object({
  Key: z.string(),
  Value: z.string(),
});

// Define the schema for an array of data items
const extractedItemsSchema = z.array(extractedItemSchema);

// Define the types for a single data item and an array of data items
export type ExtractedItem = z.infer<typeof extractedItemSchema>;
export type ExtractedItems = z.infer<typeof extractedItemsSchema>;

// Define the props type for the UploadModal component
export type UploadModalProps = {
  onSuccess: (data: ExtractedItems) => void;
};

export const QRModal = (props: UploadModalProps) => {
  const [open, setOpen] = React.useState(false);
  const uniqueId = React.useRef(uuidv4());

  const clientId = uniqueId.current;

  const link = React.useRef(
    `${
      import.meta.env.VITE_LOCAL_APP_URL_FOR_TESTING || window.location.origin
    }/scan-document?clientId=${clientId}`
  );

  const toggle = () => setOpen(!open);

  useEffect(() => {
    try {
      const eventSource = new EventSource(
        `${import.meta.env.VITE_API_HOST ?? ""}/events?clientId=${clientId}`
      );

      eventSource.onmessage = (event: { data: string }) => {
        const data = JSON.parse(event.data) as ExtractedItems;

        props.onSuccess?.(data as ExtractedItems);
        setOpen(false);
        eventSource.close();
      };

      return () => {
        if (eventSource) {
          eventSource.close();
        }
      };
    } catch (error) {
      console.log(error);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Button outline color="primary" onClick={toggle}>
        Scan QR
      </Button>

      <Dialog open={open} onClose={toggle} maxWidth="lg">
        <DialogTitle>
          <div className="title">Scan QR Code</div>
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={toggle}
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
          }}
        >
          <FontAwesomeIcon icon={faClose} />
        </IconButton>
        <DialogContent dividers style={{ width: "50rem" }}>
          <div className="hstack justify-content-center align-items-center my-5">
            <QRCode value={link.current} />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default QRModal;
