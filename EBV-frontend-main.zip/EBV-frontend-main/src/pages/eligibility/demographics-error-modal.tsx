import { faFile } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { CellContext } from "@tanstack/react-table";
import React from "react";
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import { Patient } from "./apis/patients-all";

export type DemographicsErrorModalProps = {
  uniqueId: string;
  info: CellContext<Patient, unknown>;
};

export const DemographicsErrorModal = ({
  info
}: DemographicsErrorModalProps) => {
  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);
  const modalData = info.row.original.verificationErrMessages || [];

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function isArrayObjects(array: any) {
    if (array.length === 0) return null;
    return typeof array[0] === "object" && array[0] !== null;
  }

  const isArrayObject = isArrayObjects(
    info.row.original.verificationErrMessages
  );

  return (
    <>
      <Button
        color="link"
        className={`rounded-circle p-0`}
        style={{ color: "var(--bs-warning)" }}
        onClick={toggle}
      >
        <FontAwesomeIcon icon={faFile} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md">
        <ModalHeader toggle={toggle}>
          <div className="title">Invalid Demographic Info</div>
        </ModalHeader>

        {modalData.length > 0 && isArrayObject ? (
          Array.isArray(modalData) &&
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          modalData.map((data: any) => {
            return (
              <ModalBody>
                {" "}
                <div className="m-1">
                  <p>
                    {" "}
                    <b> Error Code: </b>
                    {data.errorCode}
                  </p>
                  <p>
                    <b>Error Message:</b> {data.errorMessage}
                  </p>
                </div>{" "}
              </ModalBody>
            );
          })
        ) : (
          <ModalBody>
            <div className="m-1">
              <p>
                {" "}
                <b> Error Code: </b>
                {info.row.original.verificationErrCode}
              </p>
              <p>
                <b>Error Message:</b> {info.row.original.verificationError}
              </p>
            </div>
            {[...(info.row.original.verificationErrMessages ?? [])].length >
              0 && <b>Additional Error Details:</b>}
            {[...(info.row.original.verificationErrMessages ?? [])].map(
              (error, index) => (
                <div key={error} className="m-2">
                  {/* // need to move this to scss */}
                  <p key={error} style={{ color: "#D24545" }}>
                    {index + 1}. {error}
                  </p>
                </div>
              )
            )}
          </ModalBody>
        )}

        <ModalFooter>
          <div className="hstack gap-2">
            <Button color="link">Connect to PMS</Button>
          </div>
        </ModalFooter>
      </Modal>
    </>
  );
};

export default DemographicsErrorModal;
