/* eslint-disable @typescript-eslint/no-explicit-any */
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { Button, Col, Form, Input, Row } from "reactstrap";
import { z } from "zod";
import DateOfBirth, {
  dateOfBirthSchema,
  getDateOfBirthValidator,
} from "../../shared/forms/fields/date-of-birth";
import FirstName, {
  firstNameSchema,
  getFirstNameValidator,
} from "../../shared/forms/fields/first-name";
import GroupId, { groupIdSchema } from "../../shared/forms/fields/group-id";
import LastName, {
  getLastNameValidator,
  lastNameSchema,
} from "../../shared/forms/fields/last-name";
import MemberId, { memberIdSchema } from "../../shared/forms/fields/member-id";

import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { useLocation } from "react-router-dom";
import ConfirmationModal from "../../components/confirmation-modal";
import { useAuth } from "../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../shared/hooks/use-dialog-with-form-reset";
import {
  ScanQrCreatePermission,
  UploadImagesCreatePermission,
} from "../../utils/constant";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import { Config } from "../../utils/headers-config";
import { RolesPermission } from "../../utils/role-permission";
import { urlEncodedRequestOptions } from "../../utils/url-encoded-request-options";
import {
  Providers,
  ProvidersAllResponse,
} from "../settings/provider/table/columns";
import { PatientsAddBody } from "./apis/patients-add";
import AppointmentRenderingProvider, {
  appointmentRenderingProviderSchema,
} from "./form/fields/appointment-rendering-provider";
import AppointmentType, {
  appointmentTypeSchema,
} from "./form/fields/appointment-type";
import Gender, { genderSchema } from "./form/fields/gender";
import InsurancePayer, {
  insurancePayerList,
  insurancePayerSchema,
} from "./form/fields/insurance-payer";
import PracticeNameAndLocation, {
  practiceNameAndLocationSchema,
} from "./form/fields/practice-name-and-location";
import ProcedureCode, {
  procedureCodeSchema,
} from "./form/fields/procedure-code";
import ProcedureType, {
  procedureTypeSchema,
} from "./form/fields/procedure-type";
import Provider, { providerSchema } from "./form/fields/provider";
import Relationship, { relationshipSchema } from "./form/fields/relationship";
import ScheduleAppointment, {
  scheduleAppointmentSchema,
} from "./form/fields/schedule-appointment";
import Specialty, { specialtySchema } from "./form/fields/specialty";
import TypeOfService, {
  typeOfServiceSchema,
} from "./form/fields/type-of-service";
import QRModal from "./qr-modal";
import UploadModal from "./upload-modal";

export const dependentFirstNameKey = "dependentFirstName";
export const dependentLastNameKey = "dependentLastName";
export const dependentDateOfBirthKey = "dependentDateOfBirth";

export const dependentSchema = z.object({
  [dependentFirstNameKey]: getFirstNameValidator(dependentFirstNameKey),
  [dependentLastNameKey]: getLastNameValidator(dependentLastNameKey),
  [dependentDateOfBirthKey]: getDateOfBirthValidator(dependentDateOfBirthKey),
});

export const eligibilityFormSchema = z.object({
  ...dependentSchema.shape,
  ...firstNameSchema.shape,
  ...lastNameSchema.shape,
  ...dateOfBirthSchema.shape,
  ...memberIdSchema.shape,
  ...groupIdSchema.shape,
  ...relationshipSchema.shape,
  ...procedureTypeSchema.shape,
  ...procedureCodeSchema.shape,
  ...providerSchema.shape,
  ...insurancePayerSchema.shape,
  ...typeOfServiceSchema.shape,
  ...specialtySchema.shape,
  ...practiceNameAndLocationSchema.shape,
  ...appointmentTypeSchema.shape,
  ...scheduleAppointmentSchema.shape,
  ...genderSchema.shape,
  // ...subscriberIdSchema.shape,
  ...appointmentRenderingProviderSchema.shape,

  // Merge other schemas incrementally here
});

eligibilityFormSchema.merge(firstNameSchema);
eligibilityFormSchema.merge(lastNameSchema);
eligibilityFormSchema.merge(dateOfBirthSchema);
eligibilityFormSchema.merge(memberIdSchema);
eligibilityFormSchema.merge(groupIdSchema);
eligibilityFormSchema.merge(dependentSchema);
eligibilityFormSchema.merge(relationshipSchema);
eligibilityFormSchema.merge(procedureTypeSchema);
eligibilityFormSchema.merge(procedureCodeSchema.partial());
eligibilityFormSchema.merge(providerSchema);
eligibilityFormSchema.merge(insurancePayerSchema);
eligibilityFormSchema.merge(genderSchema);
eligibilityFormSchema.merge(dependentSchema);
eligibilityFormSchema.merge(typeOfServiceSchema);
eligibilityFormSchema.merge(appointmentTypeSchema);
eligibilityFormSchema.merge(scheduleAppointmentSchema);
eligibilityFormSchema.merge(specialtySchema);
eligibilityFormSchema.merge(appointmentRenderingProviderSchema);
eligibilityFormSchema.merge(practiceNameAndLocationSchema);

export type EligibilityFormData = z.infer<typeof eligibilityFormSchema>;

export type EligibilityModalProps = {
  onSuccess?: () => Promise<void>;
};

export const convertDOBToDDMMYYYY = (dateString: string): string => {
  const [month, day, year] = dateString.split("/");
  return `${year}-${month}-${day}`;
};

export const EligibilityModal = (props: EligibilityModalProps) => {
  const auth = useAuth();
  const [providerData, setProviderData] = React.useState<Providers>([]);

  const methods = useForm<EligibilityFormData>({
    resolver: zodResolver(eligibilityFormSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const { state } = useLocation();

  const patientsAdd = async (body: PatientsAddBody) => {
    const overwrittenBody: PatientsAddBody = {
      ...body,
      providerNpi: body.providerNpi || "",
      providerTaxId: body.providerTaxId || "",
      providerFirstName: body.providerFirstName || "",
      providerLastName: body.providerLastName || "",
      insuranceLastName: "",
      insuranceDateOfBirth: "",
      verificationType: body.verificationType || "manual",
      typeOfService: body.typeOfService || "dental",
      practiceNameAndLoc: body.practiceNameAndLoc || "",
      appointmentType: body.appointmentType || "",
      scheduleAppointment: body.scheduleAppointment || "",
      speciality: body.speciality || "",
      subscriberId: body.subscriberId || "",
      appointmentRenderingProvider: body.appointmentRenderingProvider || "",
      medical: body.medical || false,
      dental: body.dental || false,
      others: body.others || false,
      primary: body.primary || false,
      secondary: body.secondary || false,
      tertiary: body.tertiary || false,
    } as unknown as PatientsAddBody;
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/patients/`;

    return await (
      await fetch(url, urlEncodedRequestOptions(overwrittenBody, auth))
    ).json();
  };

  const eligibility = useMutation({
    mutationKey: ["patients/add"],
    mutationFn: patientsAdd,
  });

  const ProvidersAll = async (): Promise<ProvidersAllResponse> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/provider/getAll/18`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as ProvidersAllResponse;
    return {
      ...response,
      data: response.data.map((e) => {
        return {
          ...e,
          providerOption:
            e.doctorName +
            "-" +
            e.deaNumber +
            "-" +
            e.location +
            "-" +
            e.npiId +
            "-" +
            "XXXXX" +
            String(e.ssn).slice(-4),
        };
      }),
    };
  };

  const providerdataResp = useSuspenseQuery({
    queryKey: ["provider", "getAll"],
    queryFn: ProvidersAll,
  });

  React.useEffect(() => {
    const activeProviders = providerdataResp?.data?.data?.filter(
      (item: any) => item.status
    );
    setProviderData(activeProviders);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [providerdataResp.data.data]);

  const typeOfService = methods.watch("typeOfService");
  const gender = methods.watch("gender");
  const practiceNameAndLoc = methods.watch("practiceNameAndLoc");
  const appointmentType = methods.watch("appointmentType");
  const scheduleAppointment = methods.watch("scheduleAppointment");
  const speciality = methods.watch("speciality");
  const appointmentRenderingProvider = methods.watch(
    "appointmentRenderingProvider"
  );

  const [category, setCategory] = useState("");
  const [type, setType] = useState("");

  const onSubmit: SubmitHandler<EligibilityFormData> = async (data) => {
    try {
      const providerDataFiltered = providerData.find((e) => {
        return e.uniqueId === data.provider;
      });
      await eligibility.mutateAsync(
        {
          firstName: data.firstName,
          lastName: data.lastName,
          adminId: auth?.state?.user?.userData?.userId,
          dateOfBirth: data.dateOfBirth ? data.dateOfBirth.toString() : "",
          gender: gender !== null ? gender : "",
          groupId: data.groupId,
          memberId: data.memberId ?? "",
          relationship: data.relationship,
          procedureType: data.procedureType,
          procedureCode: data.procedureCode,
          provider: providerDataFiltered?.doctorName || "",
          providerNpi: providerDataFiltered?.npiId,
          providerTaxId: providerDataFiltered?.taxId,
          providerFirstName: providerDataFiltered?.doctorName
            ?.split(" ")
            ?.slice(0, 1)
            ?.join(" "),
          providerLastName: providerDataFiltered?.doctorName
            ?.split(" ")
            ?.slice(1)
            ?.join(" "),
          insurancePayer: data.insurancePayer,
          dependentFirstName:
            data.relationship === "18"
              ? data.firstName
              : data.dependentFirstName,
          dependentLastName:
            data.relationship === "18" ? data.lastName : data.dependentLastName,
          dependentDateOfBirth:
            data.relationship === "18"
              ? data.dateOfBirth
                ? data.dateOfBirth.toString()
                : ""
              : data.dependentDateOfBirth
              ? data.dependentDateOfBirth.toString()
              : "",
          verificationType: "manual",
          payerIdCode:
            insurancePayerList.find(
              (item) => item.label === data.insurancePayer
            )?.value ?? "",
          typeOfService: typeOfService !== null ? typeOfService : "",
          practiceNameAndLoc:
            practiceNameAndLoc !== null ? practiceNameAndLoc : "",
          appointmentType: appointmentType !== null ? appointmentType : "",
          scheduleAppointment: scheduleAppointment
            ? scheduleAppointment.toString()
            : "",
          speciality,
          // subscriberId: data["subscriberId"],
          appointmentRenderingProvider,
          medical: category == "medical",
          dental: category == "dental",
          others: category == "others",
          primary: type == "primary",
          secondary: type == "secondary",
          tertiary: type == "tertiary",
        },
        defaultMutateOptions
      );

      props.onSuccess?.();
      toast.success("Patient added successfully");
      setCategory("");
      setType("");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  const relationship = methods.watch("relationship");

  React.useEffect(() => {
    if (relationship === "18") {
      methods.setValue(dependentFirstNameKey, methods.getValues("firstName"));
      methods.setValue(dependentLastNameKey, methods.getValues("lastName"));
      methods.setValue(
        dependentDateOfBirthKey,
        methods.getValues("dateOfBirth")
      );
    } else {
      methods.setValue(dependentFirstNameKey, "");
      methods.setValue(dependentLastNameKey, "");
      methods.setValue(dependentDateOfBirthKey, null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [relationship]);

  return (
    <>
      {!state?.isHistory && (
        <Button color="primary" className="text-white" onClick={toggle}>
          <p className="gap-2 mb-0 hstack">
            <FontAwesomeIcon icon={faPlus} />
            <span className="mb-0">New</span>
          </p>
        </Button>
      )}

      <Dialog
        open={open}
        fullWidth
        keepMounted
        sx={{ m: 0, p: 3 }}
        // onClose={onClose}
        disableEscapeKeyDown
        // aria-labelledby="customized-dialog-title"

        maxWidth={"md"}
      >
        <DialogTitle sx={{ m: 0, p: 2 }}>
          <div className="title">Manual Verification</div>
        </DialogTitle>
        <DialogActions
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <div className="gap-2 hstack">
            {RolesPermission(ScanQrCreatePermission) && (
              <QRModal
                onSuccess={(data) => {
                  const name = data
                    ?.find((singleRecord) =>
                      singleRecord.Key.toLowerCase().includes("name")
                    )
                    ?.Value?.split(" ");

                  const firstName = name?.[0];
                  const lastName = name?.[1];

                  methods.resetField("firstName", {
                    defaultValue: firstName ?? ("" as string),
                  });
                  methods.resetField("lastName", {
                    defaultValue: lastName ?? ("" as string),
                  });
                  const gender = data
                    ?.find((singleRecord) => singleRecord.Key === "gender")
                    ?.Value.toLowerCase();
                  methods.resetField("gender", {
                    defaultValue: gender ?? "",
                  });
                  const memberId = data?.find(
                    (singleRecord) => singleRecord.Key === "memberId"
                  )?.Value;
                  methods.resetField("memberId", {
                    defaultValue: memberId ?? "",
                  });
                  const groupId = data?.find(
                    (singleRecord) => singleRecord.Key === "groupId"
                  )?.Value;
                  methods.resetField("groupId", {
                    defaultValue: groupId ?? "",
                  });
                  const dateOfBirth = data?.find(
                    (singleRecord) => singleRecord.Key === "dateOfBirth"
                  )?.Value;
                  methods.resetField("dateOfBirth", {
                    defaultValue:
                      dateOfBirth !== undefined ? new Date(dateOfBirth) : null,
                  });
                }}
              />
            )}

            {RolesPermission(UploadImagesCreatePermission) && (
              <UploadModal
                onSuccess={(data) => {
                  const name = data
                    ?.find((singleRecord) =>
                      singleRecord.Key.toLowerCase().includes("name")
                    )
                    ?.Value?.split(" ");

                  const firstName = name?.[0];
                  const lastName = name?.[1];
                  methods.resetField("firstName", {
                    defaultValue: firstName ?? "",
                  });
                  methods.resetField("lastName", {
                    defaultValue: lastName ?? "",
                  });

                  const gender = data
                    ?.find((singleRecord) => singleRecord.Key === "gender")
                    ?.Value.toLowerCase();
                  methods.resetField("gender", {
                    defaultValue: gender ?? "",
                  });
                  const memberId = data?.find(
                    (singleRecord) => singleRecord.Key === "memberId"
                  )?.Value;
                  methods.resetField("memberId", {
                    defaultValue: memberId ?? "",
                  });
                  const groupId = data?.find(
                    (singleRecord) => singleRecord.Key === "groupId"
                  )?.Value;
                  methods.resetField("groupId", {
                    defaultValue: groupId ?? "",
                  });
                  const dateOfBirth = data?.find(
                    (singleRecord) => singleRecord.Key === "dateOfBirth"
                  )?.Value;
                  methods.resetField("dateOfBirth", {
                    defaultValue:
                      dateOfBirth !== undefined ? new Date(dateOfBirth) : null,
                  });
                }}
              />
            )}
            <Button
              outline
              color="primary"
              onClick={() => {
                // Reset form fields
                methods.resetField("firstName", {
                  defaultValue: "",
                });
                methods.resetField("lastName", {
                  defaultValue: "",
                });
                methods.resetField("gender", {
                  defaultValue: "",
                });
                methods.resetField("memberId", {
                  defaultValue: "",
                });
                methods.resetField("groupId", {
                  defaultValue: "",
                });
                methods.resetField("dateOfBirth", {
                  defaultValue: null,
                });
                setCategory("");
                setType(""); // Close the modal
                toggle();
              }}
            >
              Cancel
            </Button>
            {/* <Button outline color="primary" onClick={toggle}>
                  Cancel
                </Button> */}
            <ConfirmationModal
              onClick={methods.handleSubmit(onSubmit)}
              value="Submit"
            />
            {/* <Button
                  color="primary"
                  className="text-white"
                  onClick={methods.handleSubmit(onSubmit)}
                >
                  {eligibility.isPending ? (
                    <>
                      <Spinner size="sm">Submitting...</Spinner>
                      <span> Submitting...</span>
                    </>
                  ) : (
                    <span>Submit</span>
                  )}
                </Button> */}
          </div>
        </DialogActions>

        {/* <div className="title">Manual Verification</div> */}
        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
            <DialogContent dividers>
              <h6>Subscriber Information</h6>

              <Row>
                <Col xs={12} md={4}>
                  <FirstName required />
                </Col>
                <Col xs={12} md={4}>
                  <LastName required />
                </Col>
                <Col xs={12} md={4}>
                  <DateOfBirth required />
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  <MemberId required />
                </Col>
                <Col xs={12} md={4}>
                  <GroupId required />
                </Col>
                <Col xs={12} md={4}>
                  <Relationship required />
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  <TypeOfService />
                </Col>
                <Col xs={12} md={4}>
                  <React.Suspense
                    fallback={"Fetching Practice Name and Location..."}
                  >
                    <PracticeNameAndLocation />
                  </React.Suspense>
                </Col>
                <Col xs={12} md={4}>
                  <AppointmentType />
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  <ScheduleAppointment />
                </Col>
                <Col xs={12} md={4}>
                  <Specialty />
                </Col>

                <Col xs={12} md={4}>
                  <Gender type="select" />
                </Col>
              </Row>

              <Row>
                <Col xs={12} md={4}>
                  <AppointmentRenderingProvider />
                </Col>
              </Row>

              <hr className="border-bottom" />
              <Row className="mb-3">
                <Col>
                  <Input
                    type="radio"
                    name="insurance-category"
                    value="medical"
                    className="me-2"
                    onChange={(event: any) => {
                      setCategory(event.target.value);
                    }}
                  />
                  <label>Medical</label>
                </Col>
                <Col>
                  <Input
                    type="radio"
                    name="insurance-category"
                    className="me-2"
                    value="dental"
                    onChange={(event: any) => {
                      setCategory(event.target.value);
                    }}
                  />
                  <label>Dental</label>
                </Col>
                <Col>
                  <Input
                    type="radio"
                    name="insurance-category"
                    className="me-2"
                    value="others"
                    onChange={(event: any) => {
                      setCategory(event.target.value);
                    }}
                  />
                  <label>Others</label>
                </Col>
                {category && (
                  <>
                    <Col>
                      <Input
                        type="radio"
                        name="insurance-type"
                        value="primary"
                        className="me-2"
                        onChange={(event: any) => {
                          setType(event.target.value);
                        }}
                      />
                      <label>1</label>
                    </Col>
                    <Col>
                      <Input
                        type="radio"
                        name="insurance-type"
                        value="secondary"
                        className="me-2"
                        onChange={(event: any) => {
                          setType(event.target.value);
                        }}
                      />
                      <label>2</label>
                    </Col>
                    <Col>
                      <Input
                        type="radio"
                        name="insurance-type"
                        value="tertiary"
                        className="me-2"
                        onChange={(event: any) => {
                          setType(event.target.value);
                        }}
                      />
                      <label>3</label>
                    </Col>
                  </>
                )}
              </Row>

              <h6>Insurance Details</h6>
              <React.Suspense>
                <Row>
                  <Col xs={12} md={3}>
                    <ProcedureType required />
                  </Col>
                  <Col xs={12} md={3}>
                    <ProcedureCode required />
                  </Col>
                  <Col xs={12} md={3}>
                    <Provider required providerData={providerData} />
                  </Col>
                  <Col xs={12} md={3}>
                    <InsurancePayer type="select" required />
                  </Col>
                </Row>
              </React.Suspense>

              {relationship !== "18" ? (
                <>
                  <hr />

                  <h6>Dependent Details-Patient Details</h6>

                  <Row>
                    <Col xs={12} md={4}>
                      <FirstName name={dependentFirstNameKey} required />
                    </Col>
                    <Col xs={12} md={4}>
                      <LastName name={dependentLastNameKey} required />
                    </Col>
                    <Col xs={12} md={4}>
                      <DateOfBirth name={dependentDateOfBirthKey} required />
                    </Col>
                  </Row>
                </>
              ) : null}
            </DialogContent>
          </Form>
        </FormProvider>
      </Dialog>
    </>
  );
};

export default EligibilityModal;
