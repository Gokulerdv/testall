/* eslint-disable @typescript-eslint/no-explicit-any */
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { IconButton, InputAdornment, TextField } from "@mui/material";
import axios from "axios";
import moment from "moment";
import { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Icon } from "react-icons-kit";
import { eye } from "react-icons-kit/feather/eye";
import { eyeOff } from "react-icons-kit/feather/eyeOff";
import { ic_email_outline } from "react-icons-kit/md/ic_email_outline";
import { ic_phone_enabled_outline } from "react-icons-kit/md/ic_phone_enabled_outline";
import {
  Link,
  Location,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";
import { Button, Input, Label } from "reactstrap";
import textWithDefault from "../../utils/text-with-default";
import { Patient } from "../eligibility/apis/patients-all";

const PatientInformationCanvas = ({ toggle }: any) => {
  const params = useParams();
  const [patientData, setPatientData] = useState<any>();
  const [payerData, setPayerData] = useState<any>();
  type Data = {
    INSURANCE_DETAILS: string;
    RESPONSIBLE_PARTY: {
      Name: string;
    };
    TREATMENT_SUMMARY: string;
    SUBSCRIBER_INFORMATION: {
      Surname: string;
      Firstname: string;
      Lastname: string;
      Date_of_Birth: string | null;
      Gender: string;
      Region: string;
      Phone_Number: string;
      Email: string;
      Location: string;
    };
    INSURANCE_INFORMATION: {
      Insurance_Name: string;
      Member_ID: string;
      Username: string;
      Insurances_Phone_Number: string;
      Address: string;
      Address2: string;
      City: string;
      State: string;
      Zip: string;
    };
  };
  const notLinkedErrorCodes = ["110", "120", "130", "140", "150"];

  const [data, setData] = useState<Data>();
  const [myInsurancePayer, setMyInsurancePayer] = useState<any>();
  const patientId: any = params.id;
  const { state } = useLocation() as Location<Patient>;
  const getPayerInfo = async () => {
    const result = await axios.get(
      `${import.meta.env.VITE_API_HOST ?? ""}/settings/credentialgetall`
    );
    setPayerData(result.data.data);
  };

  const getPatientInfo = async () => {
    const res = await axios.get(
      `${
        import.meta.env.VITE_API_HOST ?? ""
      }/patients/getpatient?patientId=${patientId}${
        state?.isScheduled ? `&isScheduled=true` : ""
      }`
    );

    setPatientData(res.data?.data);
    const filteredInsurancePayer = payerData?.find(
      (payer: any) =>
        payer.payer.toLowerCase() ===
        res?.data?.data.insurancePayer.toLowerCase()
    );
    setMyInsurancePayer(filteredInsurancePayer);

    setData({
      INSURANCE_DETAILS: "",
      RESPONSIBLE_PARTY: {
        Name: "Henry Smith",
      },
      TREATMENT_SUMMARY: "No data available",
      SUBSCRIBER_INFORMATION: {
        Surname: res.data?.data?.gender === "female" ? "Mrs" : "Mr",
        Firstname: textWithDefault(
          res.data?.data.subscriberFirstName
            ? res.data?.data.subscriberFirstName
            : res.data?.data.firstName
        ),
        Lastname: textWithDefault(
          res.data?.data.subscriberLastName
            ? res.data?.data.subscriberLastName
            : res.data?.data.lastName
        ),
        Date_of_Birth: textWithDefault(
          res.data?.data.subscriberDateOfBirth
            ? res.data?.data.subscriberDateOfBirth
            : res.data?.data.dateOfBirth
        ),
        Gender: textWithDefault(res.data?.data.gender),
        Region: "+1",
        Phone_Number: textWithDefault(res.data?.data.WirelessPhone),
        Email: textWithDefault(res.data?.data.email),
        Location: textWithDefault(
          [res.data?.data?.subscriberCity, res.data?.data?.subscriberState]
            .filter((value) => value)
            .join(",")
        ),
      },
      INSURANCE_INFORMATION: {
        Insurance_Name: textWithDefault(
          filteredInsurancePayer
            ? filteredInsurancePayer?.payer
            : res.data?.data?.insurancePayer
        ),
        Member_ID: textWithDefault(
          res.data?.data.memberId ? res.data?.data.memberId : "324353"
        ),
        Username: textWithDefault(
          filteredInsurancePayer ? filteredInsurancePayer?.username : ""
        ),
        Insurances_Phone_Number: textWithDefault(
          res?.data?.data?.insurancePhoneNumber
        ),
        Address: textWithDefault(res?.data?.data?.Address),
        Address2: textWithDefault(res?.data?.data?.Address2),
        City: textWithDefault(res?.data?.data?.City),
        State: textWithDefault(res?.data?.data?.State),
        Zip: textWithDefault(res?.data?.data?.Zip),
      },
    });
  };

  useEffect(() => {
    getPayerInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientId]);

  useEffect(() => {
    getPatientInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payerData]);

  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState("");

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handlePassword = (e: any) => setPassword(e.target.value);

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const handleCancel = () => {
    toggle();
  };

  const calculateAge = (birthdate: any) => {
    const age = moment().diff(moment(birthdate, "YYYY-MM-DD"), "years");
    return age;
  };

  return (
    <div className="row ">
      <div className="p-3 col-md-3 patient_info_bg ">
        <h5 className="mb-2">Patient Info</h5>
        <div className="mb-3 row ">
          <div className="col-md-4">
            <img
              className="prof-image w-100 "
              src="/images/patient-info/download.jpeg"
              alt=""
            />
          </div>
          <div className="col-md-8 patient_info ">
            <p className="pat-name">
              {textWithDefault(
                patientData?.dependentFirstName
                  ? patientData?.dependentFirstName
                  : patientData?.firstName
              )}
              <span>{` `}</span>
              {textWithDefault(
                patientData?.dependentLastName
                  ? patientData?.dependentLastName
                  : patientData?.lastName
              )}
            </p>
            <p>
              {`${moment(
                patientData?.dependentDateOfBirth
                  ? patientData?.dependentDateOfBirth
                  : patientData?.dateOfBirth
              ).format("MM/DD/YYYY")}`}{" "}
              ( {calculateAge(patientData && patientData?.dateOfBirth)}, M )
            </p>
            <p className="text-secondary">T088964</p>
          </div>
        </div>
        <div className="mb-3 form_label ">
          <label htmlFor="">Contacts</label>
          <div className="">
            <Icon
              icon={ic_phone_enabled_outline}
              size={"18px"}
              className="me-2"
            />
            <span>{textWithDefault(patientData?.WirelessPhone)}</span>
          </div>
          <div className="">
            <Icon icon={ic_email_outline} size={"18px"} className="me-2" />
            <span>{textWithDefault(patientData?.email)}</span>
          </div>
        </div>
        <div className="form_label">
          <label htmlFor="">Insurance Details</label>
          <p>{textWithDefault(data?.INSURANCE_INFORMATION?.Insurance_Name)}</p>
        </div>
        <div className="form_label">
          <label htmlFor="">Responsible Party</label>
          <p>
            {textWithDefault(
              (data?.INSURANCE_INFORMATION as any)?.Responsible_Party
            )}
          </p>
        </div>
        <div className="form_label">
          <label htmlFor="">Treatment Summary</label>
          <p>
            {textWithDefault(
              (data?.INSURANCE_INFORMATION as any)?.Treatment_Summary
            )}
          </p>
        </div>
      </div>
      <div className="col-md-9 form_label ">
        <div className="d-flex align-items-end justify-content-between ">
          <h5 className="mb-0">Patient Information</h5>
          <div>
            <Button
              className="mx-2"
              color="primary"
              outline
              onClick={handleCancel}
            >
              Cancel
            </Button>
            <Button className="green">Save</Button>
          </div>
        </div>
        <hr />
        <h6>Subscriber Information</h6>
        <div className="mb-4 row info">
          <div className="col-md-6">
            <div className="row ">
              <div className="col-md-4 ">
                <Label className="required">Surname</Label>

                <Input
                  className="field_text"
                  type="select"
                  disabled
                  value={data?.SUBSCRIBER_INFORMATION?.Surname}
                >
                  <option>Mr</option>
                  <option>Mrs</option>
                </Input>
              </div>
              <div className="col-md-8">
                <Label className="required">First Name</Label>
                <Input
                  className="field_text"
                  value={data?.SUBSCRIBER_INFORMATION?.Firstname}
                  placeholder=" "
                  disabled
                />{" "}
              </div>
            </div>
          </div>
          <div className="col-md-6 ">
            <Label className="required">Last Name</Label>
            <Input
              className="field_text"
              value={data?.SUBSCRIBER_INFORMATION?.Lastname}
              placeholder=" "
              disabled
            />{" "}
          </div>
          <div className="col-md-6 mt-3">
            <Label className="required me-5" for="exampleDate">
              Date of Birth
            </Label>
            <DatePicker
              className="field_text ms-1"
              selected={
                data?.SUBSCRIBER_INFORMATION?.Date_of_Birth
                  ? new Date(data.SUBSCRIBER_INFORMATION.Date_of_Birth)
                  : null
              }
              showIcon
              icon={<FontAwesomeIcon icon={faCalendarDays} />}
              calendarIconClassname="text-primary"
              isClearable
              disabled
              onChange={(event: any) => {
                event;
              }}
            />
          </div>
          <div className="col-md-6 ">
            <Label className="required" for="exampleDate">
              Gender
            </Label>
            <div className="d-flex gender">
              <button
                className={`mr-3 ${
                  data?.SUBSCRIBER_INFORMATION?.Gender === "male"
                    ? "gender-bg"
                    : ""
                } field_text`}
                disabled
              >
                Male
              </button>
              <button
                className={`mx-3 ${
                  data?.SUBSCRIBER_INFORMATION?.Gender === "female"
                    ? "gender-bg"
                    : ""
                } field_text`}
                disabled
              >
                Female
              </button>
            </div>
          </div>

          <div className="col-md-6">
            <div className="row">
              <div className="py-2 col-md-4">
                <Label className="required">Region</Label>
                <Input className="field_text" type="select" disabled>
                  <option selected>+1</option>
                  <option>+91</option>
                </Input>
              </div>
              <div className="py-2 col-md-8">
                <Label className="required">Phone Number</Label>
                <Input
                  className="field_text"
                  value={data?.SUBSCRIBER_INFORMATION?.Phone_Number}
                  placeholder=" "
                  disabled
                />{" "}
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="py-2 col-md-12">
              <Label className="required">Email</Label>
              <Input
                className="field_text"
                value={data?.SUBSCRIBER_INFORMATION?.Email}
                placeholder=" "
                disabled
              />{" "}
            </div>
          </div>

          <div className="col-md-6 ">
            <Label className="required" for="exampleDate">
              Location
            </Label>
            <Input
              className="field_text"
              value={data?.SUBSCRIBER_INFORMATION?.Location}
              placeholder=" "
              type="text"
              disabled
            />
          </div>
        </div>
        {/* Insurnace information */}
        <h6 className="mt-5">Insurance Information</h6>
        <div className="row info">
          <div className="col-md-6">
            <div className="row">
              <div className="col-md-12">
                <Label className="required">Insurance Name</Label>
                <Input
                  className="field_text"
                  value={data?.INSURANCE_INFORMATION?.Insurance_Name}
                  placeholder=" "
                  disabled
                />{" "}
              </div>
            </div>
          </div>
          <div className="col-md-6 ">
            <Label>Insurance Link</Label>
            <p>
              <Link to={""}>
                {myInsurancePayer
                  ? myInsurancePayer?.website
                  : "www.dental.com"}
              </Link>
            </p>
          </div>
          <div className="col-md-6 ">
            <Label className="required">Member ID/Medicaid ID</Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.Member_ID}
              placeholder=""
              disabled
            />
          </div>
          <div className="col-md-6 ">
            <Label>User Name</Label>
            <Input
              className="field_text"
              value={myInsurancePayer ? myInsurancePayer.username : ""}
              placeholder=""
              disabled
            />
          </div>
          <div className="col-md-6 ">
            <Label className="required">Insurance Phone Number</Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.Insurances_Phone_Number}
              placeholder=" "
              disabled
            />{" "}
          </div>

          <div className="col-md-6">
            <div className="row">
              <div className="col-md-12">
                <Label for="password">Password</Label>

                <TextField
                  size="small"
                  type={showPassword ? "text" : "password"}
                  value={
                    myInsurancePayer ? myInsurancePayer.password : password
                  }
                  onChange={handlePassword}
                  required={true}
                  disabled
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword}
                          edge="end"
                        >
                          <Icon icon={showPassword ? eye : eyeOff} size={20} />
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                />
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <Label className="required" for="exampleDate py-2">
              Address
            </Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.Address}
              placeholder=" "
              type="text"
              disabled
            />
          </div>

          <div className="col-md-6">
            <Label className="required" for="exampleDate py-2">
              Address 2
            </Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.Address2}
              placeholder=" "
              type="text"
              disabled
            />
          </div>

          <div className="col-md-6">
            <Label className="required" for="exampleDate py-2">
              City
            </Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.City}
              placeholder=" "
              type="text"
              disabled
            />
          </div>

          <div className="col-md-6">
            <Label className="required" for="exampleDate py-2">
              State
            </Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.State}
              placeholder=" "
              type="text"
              disabled
            />
          </div>

          <div className="col-md-6">
            <Label className="required" for="exampleDate py-2">
              Zip
            </Label>
            <Input
              className="field_text"
              value={data?.INSURANCE_INFORMATION?.Zip}
              placeholder=" "
              type="text"
              disabled
            />
          </div>

          <div className="col-12">
            {(state.isVerified ||
              notLinkedErrorCodes.includes(
                state.verificationErrCode || ""
              )) && <PatientBenefitInformationLink />}
          </div>
        </div>
      </div>
    </div>
  );
};

export const PatientBenefitInformationLink = () => {
  const { id: patientId } = useParams() as { id: string };
  const { state: patient } = useLocation() as Location<Patient>;
  const notLinkedErrorCodes = ["110", "120", "130", "140", "150"];

  const isNotlinked = patient.verificationErrCode
    ? notLinkedErrorCodes.includes(patient.verificationErrCode)
    : false;

  const navigate = useNavigate();

  const handleNavigate = async () => {
    try {
      const state = {
        ...patient,
        row: patient,
        patientId,
      };

      navigate(
        `/eligibility/patient-benefit-information/${patientId}?${
          isNotlinked && "editMode=true"
        }`,
        {
          state,
        }
      );
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Button color="link" onClick={handleNavigate}>
      Patient Benefit Information
    </Button>
  );
};

export default PatientInformationCanvas;
