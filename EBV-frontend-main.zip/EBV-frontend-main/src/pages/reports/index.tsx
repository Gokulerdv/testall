/* eslint-disable @typescript-eslint/no-explicit-any */
import { faStar as faStarOutlined } from "@fortawesome/free-regular-svg-icons";
import {
  faDownload,
  faEllipsisVertical,
  faFileUpload,
  faStar,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React, { useState } from "react";
import { NavLink as RouterLink, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  AccordionBody,
  AccordionHeader,
  AccordionItem,
  Button,
  Card,
  CardBody,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Row,
  Table,
  UncontrolledAccordion,
  UncontrolledDropdown,
} from "reactstrap";
import XLSX from "xlsx";
import { useAuth } from "../../shared/hooks/use-auth";
import {
  NewPatientCreatePermission,
  NewPatientDeletePermission,
  NewPatientEditPermission,
  NewPatientViewPermission,
  PendingEligibilityCreatePermission,
  PendingEligibilityDeletePermission,
  PendingEligibilityEditPermission,
  PendingEligibilityViewPermission,
  TransactionCreatePermission,
  TransactionDeletePermission,
  TransactionEditPermission,
  TransactionViewPermission,
} from "../../utils/constant";
import { dateFormat } from "../../utils/date-format";
import { dateTimeFormat } from "../../utils/date-time-format";
import { Config } from "../../utils/headers-config";
import { RolesPermission } from "../../utils/role-permission";

export const Report = () => {
  const [open, setOpen] = useState("1");
  const queryClient = useQueryClient();
  const auth = useAuth();

  const [reportId, setReportId] = React.useState<number>(0);
  React.useState<any>({});
  const [newPatientReportId, setNewPatientReportId] = React.useState<number>(0);
  const [newTranscationReportId, setTranscationPatientReportId] =
    React.useState<number>(0);

  const toggle = (id: any) => {
    if (open === id) {
      setOpen("");
    } else {
      setOpen(id);
    }
  };

  const getAllPendingEligibilityFilters = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const getAllNewPatientFilters = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/newpatient/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const getAllTransactionFilters = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const PendingEligibilityFilterUpdate = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/update/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const NewPatientFilterUpdate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/newpatient/update/${
      data.id
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const TransactionFilterUpdate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/update/${
      data.id
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const handleAccordion = React.useCallback(async () => {
    queryClient.invalidateQueries({
      queryKey: ["newPatientFilters", "getAll"],
    });
    queryClient.invalidateQueries({
      queryKey: ["transactionFilters", "getAll"],
    });
    queryClient.invalidateQueries({
      queryKey: ["pendingEligibilityFilters", "getAll"],
    });
  }, [queryClient]);

  const { data: pendingEligibilityFilters } = useSuspenseQuery({
    queryKey: ["pendingEligibilityFilters", "getAll"],
    queryFn: getAllPendingEligibilityFilters,
  });

  const { data: newPatientFilters } = useSuspenseQuery({
    queryKey: ["newPatientFilters", "getAll"],
    queryFn: getAllNewPatientFilters,
  });

  const { data: transactionFilters } = useSuspenseQuery({
    queryKey: ["transactionFilters", "getAll"],
    queryFn: getAllTransactionFilters,
  });

  const pendingEligibilityUpdate = useMutation({
    mutationKey: ["pendingEligibility", "update"],
    mutationFn: PendingEligibilityFilterUpdate,
  });

  const NewPatientUpdate = useMutation({
    mutationKey: ["newPatient", "update"],
    mutationFn: NewPatientFilterUpdate,
  });

  const TransactionUpdate = useMutation({
    mutationKey: ["transaction", "update"],
    mutationFn: TransactionFilterUpdate,
  });

  const toggleFavorite = async (item: any, key: string) => {
    if (key === "pending-eligibility") {
      try {
        await pendingEligibilityUpdate.mutateAsync({
          id: item.id,
          data: { isFavorite: !item.isFavorite },
        });
        queryClient.invalidateQueries({
          queryKey: ["pendingEligibilityFilters", "getAll"],
        });
      } catch (error) {
        console.log(error);
      }
    } else if (key === "new-patients") {
      try {
        await NewPatientUpdate.mutateAsync({
          id: item.id,
          data: { isFavorite: !item.isFavorite },
        });
        queryClient.invalidateQueries({
          queryKey: ["newPatientsUpdate", "getAll"],
        });
      } catch (error) {
        console.log(error);
      }
    } else {
      try {
        await TransactionUpdate.mutateAsync({
          id: item.id,
          data: { isFavorite: !item.isFavorite },
        });
        queryClient.invalidateQueries({
          queryKey: ["transactionFilters", "getAll"],
        });
      } catch (error) {
        console.log(error);
      }
    }
  };

  const pdfPendingEligibilityDownload =
    (id: number) => async (): Promise<any> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/pendingeligibility/getById/${id}`;

      const response = await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return response;
    };

  const patientBulkPdf = useSuspenseQuery({
    queryKey: ["pendingeligibility", "getById", reportId],
    queryFn: pdfPendingEligibilityDownload(reportId),
  });
  const pdfNewPatientDownload = (id: number) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/newpatient/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const newPatientBulkPdf = useSuspenseQuery({
    queryKey: ["new-pateint", "getById", newPatientReportId],
    queryFn: pdfNewPatientDownload(newPatientReportId),
  });

  const getByIdPendingEligibility = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getByIdNewPatient = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/newpatient/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getByIdTransaction = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/transaction/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const fetchPendingEligibilityData = async (filterId: any) => {
    try {
      const response = getByIdPendingEligibility(filterId);
      const result = await response();
      return result;
    } catch (error) {
      console.log(error);
    }
  };

  const fetchNewPatientData = async (filterId: any) => {
    try {
      const response = getByIdNewPatient(filterId);
      const result = await response();
      return result;
    } catch (error) {
      console.log(error);
    }
  };

  const fetchTransactionData = async (filterId: any) => {
    try {
      const response = getByIdTransaction(filterId);
      const result = await response();
      return result;
    } catch (error) {
      console.log(error);
    }
  };

  const navigate = useNavigate();

  const pdfTransactionDownload = (id: number) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/transaction/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const transactionBulkPdf = useSuspenseQuery({
    queryKey: ["transaction", "getById", newTranscationReportId],
    queryFn: pdfTransactionDownload(newTranscationReportId),
  });

  const handlePdf = async (reportId: number) => {
    try {
      setReportId(reportId);
      // Check if patientBulkPdf.data exists and has the expected structure
      if (
        patientBulkPdf.data &&
        patientBulkPdf.data.pendingEligibility &&
        patientBulkPdf.data.pendingEligibility.pdf &&
        patientBulkPdf.data.pendingEligibility.pdf.data
      ) {
        const bufferData = new Uint8Array(
          patientBulkPdf.data.pendingEligibility.pdf.data
        );

        const blob = new Blob([bufferData], {
          type: "application/pdf",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "message.pdf";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } else {
        toast.error("PDF data is missing or in unexpected format");
      }
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };
  const handleNewPatientPdf = async (reportId: number) => {
    try {
      setNewPatientReportId(reportId);
      // Check if patientBulkPdf.data exists and has the expected structure
      if (
        newPatientBulkPdf.data.data &&
        newPatientBulkPdf.data.data.newPatients &&
        newPatientBulkPdf.data.data.newPatients.pdf &&
        newPatientBulkPdf.data.data.newPatients.pdf.data
      ) {
        const bufferData = new Uint8Array(
          newPatientBulkPdf.data.data.newPatients.pdf.data
        );

        const blob = new Blob([bufferData], {
          type: "application/pdf",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "message.pdf";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        toast.success("Pdf downloaded successfully");
      } else {
        toast.error("PDF data is missing or in unexpected format");
      }
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };
  const handleTransactionPdf = async (reportId: number) => {
    try {
      setTranscationPatientReportId(reportId);
      // Check if patientBulkPdf.data exists and has the expected structure
      if (
        transactionBulkPdf.data.data &&
        transactionBulkPdf.data.data.transaction &&
        transactionBulkPdf.data.data.transaction.pdf &&
        transactionBulkPdf.data.data.transaction.pdf.data
      ) {
        const bufferData = new Uint8Array(
          transactionBulkPdf.data.data.transaction.pdf.data
        );

        const blob = new Blob([bufferData], {
          type: "application/pdf",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "message.pdf";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        toast.success("Pdf downloaded successfully");
      } else {
        toast.error("PDF data is missing or in unexpected format");
      }
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };
  // const exportAsCSV = (reportId: number) => {
  //   setReportId(reportId);

  //   const rows = patientBulkPdf.data.patientDetails.map((cell: any) => ({
  //     "Patient Id": cell.patientId,
  //     "Patient Name": cell.firstName + " " + cell.lastName,
  //     "Type Of Service": cell.typeOfService,
  //     "Practice Name & Location": cell.practiceNameAndLoc,
  //     "Appointment Type": cell.appointmentType,
  //     "Insurance Name/Plan":
  //       cell.providerFirstName + "" + cell.providerLastName,
  //     // Appointment: cell.scheduleAppointment
  //     // ? dateTimeFormat(new Date(cell.scheduleAppointment))
  //     // : null,
  //     // "Last Verified": cell.lastVerified
  //     // ? dateTimeFormat(new Date(cell.lastVerified))
  //     // : null,
  //     Status: cell.insuranceStatus,
  //     "Insurance Payer Code": cell.payerIdCode,
  //     Speciality: cell.speciality,
  //     // "Date Of Birth": cell.dateOfBirth
  //     // ? dateTimeFormat(new Date(cell.dateOfBirth))
  //     // : null,
  //     "Subscriber ID": cell.subscriberId,
  //     "Appointment Rendering Provider": cell.appointmentRenderingProvider,
  //   }));
  //   const worksheet = XLSX.utils.json_to_sheet(rows);

  //   const workBook = XLSX.utils.book_new();
  //   XLSX.utils.book_append_sheet(workBook, worksheet, "data");
  //   XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
  // };

  const exportPendingEligibilityAsCSV = (reportId: number) => {
    setReportId(reportId);
    const rows = patientBulkPdf.data.patientDetails.map((cell: any) => ({
      "Patient Id": cell.patientId,
      "Patient Name": cell.firstName + " " + cell.lastName,
      "Type Of Service": cell.typeOfService,
      "Practice Name & Location": cell.practiceNameAndLoc,
      "Appointment Type": cell.appointmentType,
      "Insurance Name/Plan":
        cell.providerFirstName + " " + cell.providerLastName,
      Appointment: cell.scheduleAppointment
        ? dateTimeFormat(new Date(cell.scheduleAppointment))
        : null,
      "Last Verified": cell.lastVerified
        ? dateTimeFormat(new Date(cell.lastVerified))
        : null,
      Status: cell.insuranceStatus,
      "Insurance Payer Code": cell.payerIdCode,
      Speciality: cell.speciality,
      "Date Of Birth": cell.dateOfBirth
        ? dateTimeFormat(new Date(cell.dateOfBirth))
        : null,
      "Subscriber ID": cell.subscriberId,
      "Appointment Rendering Provider": cell.appointmentRenderingProvider,
    }));

    // Define the column headers
    const columnHeaders = {
      "Patient Id": "",
      "Patient Name": "",
      "Type Of Service": "",
      "Practice Name & Location": "",
      "Appointment Type": "",
      "Insurance Name/Plan": "",
      Appointment: "",
      "Last Verified": "",
      Status: "",
      "Insurance Payer Code": "",
      Speciality: "",
      "Date Of Birth": "",
      "Subscriber ID": "",
      "Appointment Rendering Provider": "",
    };

    // If rows are empty, add an empty row to ensure headers are included
    if (rows.length === 0) {
      rows.push(columnHeaders);
    }

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, worksheet, "data");
    XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
  };

  const exportNewPatientAsCSV = (reportId: number) => {
    setNewPatientReportId(reportId);

    const rows = newPatientBulkPdf.data.data.patientDetails?.map(
      (cell: any) => ({
        "Patient Id": cell.patientId,
        "Patient Name": cell.firstName + " " + cell.lastName,
        "Type Of Service": cell.typeOfService,
        "Practice Name & Location": cell.practiceNameAndLoc,
        "Appointment Type": cell.appointmentType,
        "Insurance Name/Plan":
          cell.providerFirstName + " " + cell.providerLastName,
        Appointment: cell.scheduleAppointment
          ? dateTimeFormat(new Date(cell.scheduleAppointment))
          : null,
        "Last Verified": cell.lastVerified
          ? dateTimeFormat(new Date(cell.lastVerified))
          : null,
        Status: cell.insuranceStatus,
        "Insurance Payer Code": cell.payerIdCode,
        Speciality: cell.speciality,
        "Date Of Birth": cell.dateOfBirth
          ? dateTimeFormat(new Date(cell.dateOfBirth))
          : null,
        "Subscriber ID": cell.subscriberId,
        "Appointment Rendering Provider": cell.appointmentRenderingProvider,
      })
    );

    // Define the column headers
    const columnHeaders = {
      "Patient Id": "",
      "Patient Name": "",
      "Type Of Service": "",
      "Practice Name & Location": "",
      "Appointment Type": "",
      "Insurance Name/Plan": "",
      Appointment: "",
      "Last Verified": "",
      Status: "",
      "Insurance Payer Code": "",
      Speciality: "",
      "Date Of Birth": "",
      "Subscriber ID": "",
      "Appointment Rendering Provider": "",
    };

    // If rows are empty, add an empty row to ensure headers are included
    if (rows.length === 0) {
      rows.push(columnHeaders);
    }

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, worksheet, "data");
    XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
  };
  const exportTransactionAsCSV = (reportId: number) => {
    setTranscationPatientReportId(reportId);
    const rows = transactionBulkPdf.data.data.patientDetails?.map(
      (cell: any) => ({
        "Patient Id": cell.patientId,
        "Patient Name": cell.firstName + " " + cell.lastName,
        "Type Of Service": cell.typeOfService,
        "Practice Name & Location": cell.practiceNameAndLoc,
        "Appointment Type": cell.appointmentType,
        "Insurance Name/Plan":
          cell.providerFirstName + " " + cell.providerLastName,
        Appointment: cell.scheduleAppointment
          ? dateTimeFormat(new Date(cell.scheduleAppointment))
          : null,
        "Last Verified": cell.lastVerified
          ? dateTimeFormat(new Date(cell.lastVerified))
          : null,
        Status: cell.insuranceStatus,
        "Insurance Payer Code": cell.payerIdCode,
        Speciality: cell.speciality,
        "Date Of Birth": cell.dateOfBirth
          ? dateTimeFormat(new Date(cell.dateOfBirth))
          : null,
        "Subscriber ID": cell.subscriberId,
        "Appointment Rendering Provider": cell.appointmentRenderingProvider,
      })
    );

    // Define the column headers
    const columnHeaders = {
      "Patient Id": "",
      "Patient Name": "",
      "Type Of Service": "",
      "Practice Name & Location": "",
      "Appointment Type": "",
      "Insurance Name/Plan": "",
      Appointment: "",
      "Last Verified": "",
      Status: "",
      "Insurance Payer Code": "",
      Speciality: "",
      "Date Of Birth": "",
      "Subscriber ID": "",
      "Appointment Rendering Provider": "",
    };

    // If rows are empty, add an empty row to ensure headers are included
    if (rows.length === 0) {
      rows.push(columnHeaders);
    }

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, worksheet, "data");
    XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
  };
  return (
    <>
      <Row>
        <Col md="4">
          <Row>
            <Col md="12">
              <Card className="mb-2">
                <CardBody className="d-flex justify-content-between align-items-center">
                  <p className="fw-bold">Pending Eligibility</p>
                  {RolesPermission(PendingEligibilityCreatePermission) && (
                    <RouterLink
                      to={`pending-eligibility-report`}
                      className="text-decoration-none"
                    >
                      <Button color="primary" outline>
                        Create New Report
                      </Button>
                    </RouterLink>
                  )}
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card className="mb-2">
                <CardBody className="d-flex justify-content-between align-items-center">
                  <p className="fw-bold">New Patients</p>
                  {RolesPermission(NewPatientCreatePermission) && (
                    <RouterLink
                      to={`new-patient-report`}
                      className="text-decoration-none"
                    >
                      <Button color="primary" outline>
                        Create New Report
                      </Button>
                    </RouterLink>
                  )}
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col sm="12">
              <Card className="mb-3">
                <CardBody className="d-flex justify-content-between align-items-center">
                  <p className="fw-bold">Transaction </p>
                  {RolesPermission(TransactionCreatePermission) && (
                    <RouterLink
                      to={`transaction-report`}
                      className="text-decoration-none"
                    >
                      <Button color="primary" outline>
                        Create New Report
                      </Button>
                    </RouterLink>
                  )}
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Col>
        <Col sm="8">
          <Card body>
            <UncontrolledAccordion toggle={toggle} onClick={handleAccordion}>
              {RolesPermission(PendingEligibilityViewPermission) && (
                <AccordionItem>
                  <AccordionHeader targetId="1">
                    <strong>Pending Eligibility</strong>
                  </AccordionHeader>
                  <AccordionBody accordionId="1">
                    <Table striped>
                      <thead>
                        <tr>
                          <th>Favorite</th>
                          <th>Filter Name</th>
                          <th>Date Range</th>
                          <th>Last Generated</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pendingEligibilityFilters?.data?.map(
                          (item: any, index: any) => (
                            <>
                              <tr key={index}>
                                <td>
                                  {item.isFavorite === true ? (
                                    <FontAwesomeIcon
                                      icon={faStar}
                                      color="primary"
                                      style={{
                                        color: "#824ed3",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        toggleFavorite(
                                          item,
                                          "pending-eligibility"
                                        );
                                      }}
                                    ></FontAwesomeIcon>
                                  ) : (
                                    <FontAwesomeIcon
                                      icon={faStarOutlined}
                                      color="primary"
                                      style={{
                                        color: "#824ed3",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        toggleFavorite(
                                          item,
                                          "pending-eligibility"
                                        );
                                      }}
                                    ></FontAwesomeIcon>
                                  )}
                                </td>
                                <td>{item.filterName}</td>
                                <td>{dateFormat(new Date(item.fromDate))}</td>
                                <td>{dateFormat(new Date(item.toDate))}</td>
                                <td>
                                  <div className="gap-3 hstack">
                                    <FontAwesomeIcon
                                      icon={faFileUpload}
                                      style={{ color: "#824ed3" }}
                                      onClick={async () => {
                                        navigate(
                                          `/reports/generate-pending-eligibility`,
                                          {
                                            state:
                                              await fetchPendingEligibilityData(
                                                item.id
                                              ),
                                          }
                                        );
                                      }}
                                    ></FontAwesomeIcon>
                                    <UncontrolledDropdown className="flex-wrap">
                                      <DropdownToggle
                                        data-toggle="dropdown"
                                        tag="span"
                                      >
                                        <FontAwesomeIcon
                                          icon={faDownload}
                                          style={{ color: "#824ed3" }}
                                        ></FontAwesomeIcon>
                                      </DropdownToggle>
                                      <DropdownMenu className="mt-3">
                                        <DropdownItem
                                          onClick={() => handlePdf(item.id)}
                                        >
                                          PDF
                                        </DropdownItem>
                                        <DropdownItem
                                          onClick={() =>
                                            exportPendingEligibilityAsCSV(
                                              item.id
                                            )
                                          }
                                        >
                                          CSV
                                        </DropdownItem>
                                      </DropdownMenu>
                                    </UncontrolledDropdown>
                                  </div>
                                </td>
                                <td>
                                  <>
                                    <UncontrolledDropdown direction="start">
                                      <DropdownToggle nav>
                                        <Button
                                          color="link"
                                          className="p-0 text-black rounded-circle"
                                        >
                                          <FontAwesomeIcon
                                            icon={faEllipsisVertical}
                                          />
                                        </Button>
                                      </DropdownToggle>
                                      <DropdownMenu>
                                        {RolesPermission(
                                          PendingEligibilityEditPermission
                                        ) && (
                                          <RouterLink
                                            to={`pending-eligibility-report`}
                                            state={item}
                                            style={{ textDecoration: "none" }}
                                          >
                                            <DropdownItem>Edit</DropdownItem>
                                          </RouterLink>
                                        )}
                                        {RolesPermission(
                                          PendingEligibilityDeletePermission
                                        ) && (
                                          <RouterLink
                                            to={`pending-eligibility-report/delete-confirmation/${item.id}`}
                                            style={{ textDecoration: "none" }}
                                            state={item.id}
                                          >
                                            <DropdownItem>Delete</DropdownItem>
                                          </RouterLink>
                                        )}
                                      </DropdownMenu>
                                    </UncontrolledDropdown>
                                  </>
                                </td>
                              </tr>
                            </>
                          )
                        )}
                      </tbody>
                    </Table>
                  </AccordionBody>
                </AccordionItem>
              )}
              {RolesPermission(NewPatientViewPermission) && (
                <AccordionItem>
                  <AccordionHeader targetId="2">
                    <strong>New Patient</strong>
                  </AccordionHeader>
                  <AccordionBody accordionId="2">
                    <Table striped>
                      <thead>
                        <tr>
                          <th>Favorite</th>
                          <th>Filter Name</th>
                          <th>Date Range</th>
                          <th>Last Generated</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {newPatientFilters?.data?.map(
                          (item: any, index: any) => (
                            <>
                              <tr key={index}>
                                <td>
                                  {item.isFavorite === true ? (
                                    <FontAwesomeIcon
                                      icon={faStar}
                                      color="primary"
                                      style={{
                                        color: "#824ed3",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        toggleFavorite(item, "new-patients");
                                      }}
                                    ></FontAwesomeIcon>
                                  ) : (
                                    <FontAwesomeIcon
                                      icon={faStarOutlined}
                                      color="primary"
                                      style={{
                                        color: "#824ed3",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        toggleFavorite(item, "new-patients");
                                      }}
                                    ></FontAwesomeIcon>
                                  )}
                                </td>
                                <td>{item.filtername}</td>
                                <td>{dateFormat(new Date(item.fromDate))}</td>
                                <td>{dateFormat(new Date(item.toDate))}</td>
                                <td>
                                  <div className="gap-3 hstack">
                                    <FontAwesomeIcon
                                      icon={faFileUpload}
                                      style={{ color: "#824ed3" }}
                                      onClick={async () => {
                                        navigate(
                                          `/reports/generate-new-patient`,
                                          {
                                            state: await fetchNewPatientData(
                                              item.id
                                            ),
                                          }
                                        );
                                      }}
                                    ></FontAwesomeIcon>

                                    <UncontrolledDropdown className="flex-wrap">
                                      <DropdownToggle
                                        data-toggle="dropdown"
                                        tag="span"
                                      >
                                        <FontAwesomeIcon
                                          icon={faDownload}
                                          style={{ color: "#824ed3" }}
                                        ></FontAwesomeIcon>
                                      </DropdownToggle>
                                      <DropdownMenu className="mt-3">
                                        <DropdownItem
                                          onClick={() =>
                                            handleNewPatientPdf(item.id)
                                          }
                                        >
                                          PDF
                                        </DropdownItem>
                                        <DropdownItem
                                          onClick={() =>
                                            exportNewPatientAsCSV(item.id)
                                          }
                                        >
                                          CSV
                                        </DropdownItem>
                                      </DropdownMenu>
                                    </UncontrolledDropdown>
                                  </div>
                                </td>
                                <td>
                                  <>
                                    <UncontrolledDropdown direction="start">
                                      <DropdownToggle nav>
                                        <Button
                                          color="link"
                                          className="p-0 text-black rounded-circle"
                                        >
                                          <FontAwesomeIcon
                                            icon={faEllipsisVertical}
                                          />
                                        </Button>
                                      </DropdownToggle>
                                      <DropdownMenu>
                                        {RolesPermission(
                                          NewPatientEditPermission
                                        ) && (
                                          <RouterLink
                                            to={`new-patient-report`}
                                            state={item}
                                            style={{ textDecoration: "none" }}
                                          >
                                            <DropdownItem>Edit</DropdownItem>
                                          </RouterLink>
                                        )}

                                        {RolesPermission(
                                          NewPatientDeletePermission
                                        ) && (
                                          <RouterLink
                                            to={`new-patient-report/delete-confirmation/${item.id}`}
                                            style={{ textDecoration: "none" }}
                                            state={item.id}
                                          >
                                            <DropdownItem>Delete</DropdownItem>
                                          </RouterLink>
                                        )}
                                      </DropdownMenu>
                                    </UncontrolledDropdown>
                                  </>
                                </td>
                              </tr>
                            </>
                          )
                        )}
                      </tbody>
                    </Table>
                  </AccordionBody>
                </AccordionItem>
              )}
              {RolesPermission(TransactionViewPermission) && (
                <AccordionItem>
                  <AccordionHeader targetId="3">
                    <strong>Transaction</strong>
                  </AccordionHeader>
                  <AccordionBody accordionId="3">
                    <Table striped>
                      <thead>
                        <tr>
                          <th>Favorite</th>
                          <th>Filter Name</th>
                          <th>Date Range</th>
                          <th>Last Generated</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactionFilters?.data?.map(
                          (item: any, index: any) => (
                            <>
                              <tr key={index}>
                                <td>
                                  {item.isFavorite === true ? (
                                    <FontAwesomeIcon
                                      icon={faStar}
                                      color="primary"
                                      style={{
                                        color: "#824ed3",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        toggleFavorite(item, "transaction");
                                      }}
                                    ></FontAwesomeIcon>
                                  ) : (
                                    <FontAwesomeIcon
                                      icon={faStarOutlined}
                                      color="primary"
                                      style={{
                                        color: "#824ed3",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        toggleFavorite(item, "transaction");
                                      }}
                                    ></FontAwesomeIcon>
                                  )}
                                </td>
                                <td>{item.filterName}</td>
                                <td>{dateFormat(new Date(item.fromDate))}</td>
                                <td>{dateFormat(new Date(item.toDate))}</td>
                                <td>
                                  <div className="gap-3 hstack">
                                    <FontAwesomeIcon
                                      icon={faFileUpload}
                                      style={{ color: "#824ed3" }}
                                      onClick={async () => {
                                        navigate(
                                          `/reports/generate-transaction`,
                                          {
                                            state: await fetchTransactionData(
                                              item.id
                                            ),
                                          }
                                        );
                                      }}
                                    ></FontAwesomeIcon>
                                    <UncontrolledDropdown className="flex-wrap">
                                      <DropdownToggle
                                        data-toggle="dropdown"
                                        tag="span"
                                      >
                                        <FontAwesomeIcon
                                          icon={faDownload}
                                          style={{ color: "#824ed3" }}
                                        ></FontAwesomeIcon>
                                      </DropdownToggle>
                                      <DropdownMenu className="mt-3">
                                        <DropdownItem
                                          onClick={() =>
                                            handleTransactionPdf(item.id)
                                          }
                                        >
                                          PDF
                                        </DropdownItem>
                                        <DropdownItem
                                          onClick={() =>
                                            exportTransactionAsCSV(item.id)
                                          }
                                        >
                                          CSV
                                        </DropdownItem>
                                      </DropdownMenu>
                                    </UncontrolledDropdown>
                                  </div>
                                </td>
                                <td>
                                  <>
                                    <UncontrolledDropdown direction="start">
                                      <DropdownToggle nav>
                                        <Button
                                          color="link"
                                          className="p-0 text-black rounded-circle"
                                        >
                                          <FontAwesomeIcon
                                            icon={faEllipsisVertical}
                                          />
                                        </Button>
                                      </DropdownToggle>
                                      <DropdownMenu>
                                        {RolesPermission(
                                          TransactionEditPermission
                                        ) && (
                                          <RouterLink
                                            to={`transaction-report`}
                                            state={item}
                                            style={{ textDecoration: "none" }}
                                          >
                                            <DropdownItem>Edit</DropdownItem>
                                          </RouterLink>
                                        )}

                                        {RolesPermission(
                                          TransactionDeletePermission
                                        ) && (
                                          <RouterLink
                                            to={`transaction-report/delete-confirmation/${item.id}`}
                                            style={{ textDecoration: "none" }}
                                            state={item.id}
                                          >
                                            <DropdownItem>Delete</DropdownItem>
                                          </RouterLink>
                                        )}
                                      </DropdownMenu>
                                    </UncontrolledDropdown>
                                  </>
                                </td>
                              </tr>
                            </>
                          )
                        )}
                      </tbody>
                    </Table>
                  </AccordionBody>
                </AccordionItem>
              )}
            </UncontrolledAccordion>
          </Card>
        </Col>
      </Row>
    </>
  );
};

export default Report;
