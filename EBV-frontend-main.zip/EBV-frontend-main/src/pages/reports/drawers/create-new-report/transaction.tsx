/* eslint-disable @typescript-eslint/no-explicit-any */
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
  UncontrolledDropdown,
} from "reactstrap";
import XLSX from "xlsx";

import { useAuth } from "../../../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateTimeFormat } from "../../../../utils/date-time-format";
import Config from "../../../../utils/headers-config";
import CommonLoader from "../../../eligibility/patient-benefit-information/common-loader";
import FilterNameTransaction from "../../fields/filter-name-transaction";
import FromDate from "../../fields/from-date";
import MultipleSelectCheckMarks from "../../fields/multiple-select";
import ToDate from "../../fields/to-date";
import SaveConfirmation from "../../modals/save-confirmation";
import { patientTypeOptions } from "./new-patient";

export const TransactionReport = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "reports/transaction-report",
    togglePath: "../",
  });
  const location = useLocation();
  const { state } = location;

  const navigate = useNavigate();

  const [formValues, setFormValues] = useState({
    filterName: "",
    fromDate: "",
    toDate: "",
    location: [],
    patients: [],
    provider: [],
    patientType: [],
    typeOfBenefitStatus: [],
    appStatus: [],
    isFavorite: false,
    isSaveFilter: false,
    filterId: "",
  });

  const [selectedOption, setSelectedOption] = React.useState("new");
  const [saveConfirmationOpen, setSaveConfirmationOpen] = React.useState(false);
  const [buttonClicked, setButtonClicked] = React.useState("");
  const [, setGenerateResponse] = React.useState({});
  const auth = useAuth();

  const handleGenerateConfirmation = (key: any) => {
    if (formValues.isSaveFilter) {
      setSaveConfirmationOpen(!saveConfirmationOpen);
      setButtonClicked(key);
    } else {
      if (key !== "pdf" && key !== "csv") {
        if (selectedOption === "new") submitForm();
        else if (selectedOption === "existing") updateForm();
      }
    }
  };

  const TransactionFilterCreate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/create`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const TransactionFilterUpdate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/update/${
      data.id
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const FilterCreate = useMutation({
    mutationKey: ["transaction", "create"],
    mutationFn: TransactionFilterCreate,
  });
  const FilterUpdate = useMutation({
    mutationKey: ["transaction", "update"],
    mutationFn: TransactionFilterUpdate,
  });

  const remodify = (passedParam: any) => {
    const remodifiedArray: any = [];
    passedParam.map((item: any) => remodifiedArray.push(item.value));
    return remodifiedArray;
  };

  const submitForm = async () => {
    try {
      const response = await FilterCreate.mutateAsync({
        filterName: formValues?.filterName,
        fromDate: formValues?.fromDate,
        toDate: formValues?.toDate,
        location: remodify(formValues?.location),
        patients: remodify(formValues?.patients),
        provider: remodify(formValues?.provider),
        patientType: remodify(formValues?.patientType),
        benefitsTypes: remodify(formValues?.typeOfBenefitStatus),
        appStatus: "",
        isFavorite: formValues.isFavorite,
        isSave: formValues.isSaveFilter,
      });

      setGenerateResponse(response?.data?.transaction);
      navigate(`/reports/generate-transaction`, {
        state: response?.data,
      });
    } catch (error) {
      console.log(error);
    }
  };
  const submitDownloadPdfForm = async () => {
    try {
      const response =
        selectedOption === "existing" && formValues.filterId
          ? await FilterUpdate.mutateAsync({
              id: formValues?.filterId,
              data: {
                filterName: formValues?.filterName,
                fromDate: formValues?.fromDate,
                toDate: formValues?.toDate,
                location: remodify(formValues?.location),
                patients: remodify(formValues?.patients),
                provider: remodify(formValues?.provider),
                patientType: remodify(formValues?.patientType),
                benefitsTypes: remodify(formValues?.typeOfBenefitStatus),
                appStatus: "",
                isFavorite: formValues.isFavorite,
                isSave: formValues.isSaveFilter,
              },
            })
          : await FilterCreate.mutateAsync({
              filterName: formValues?.filterName,
              fromDate: formValues?.fromDate,
              toDate: formValues?.toDate,
              location: remodify(formValues?.location),
              patients: remodify(formValues?.patients),
              provider: remodify(formValues?.provider),
              patientType: remodify(formValues?.patientType),
              benefitsTypes: remodify(formValues?.typeOfBenefitStatus),
              appStatus: "",
              isFavorite: formValues.isFavorite,
              isSave: formValues.isSaveFilter,
            });
      const bufferData = new Uint8Array(
        selectedOption === "existing" && formValues.filterId
          ? response.data.pdfBuffer.data
          : response.data.pdf.data
      );
      const blob = await new Blob([bufferData], {
        type: "application/pdf",
      });

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "bulk_pdf.pdf";

      a.click();

      window.URL.revokeObjectURL(url);

      toast.success("Pdf downloaded successfully");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    }
  };

  const submitDownloadCsvForm = async () => {
    try {
      const response =
        selectedOption === "existing" && formValues.filterId
          ? await FilterUpdate.mutateAsync({
              id: formValues?.filterId,
              data: {
                filterName: formValues?.filterName,
                fromDate: formValues?.fromDate,
                toDate: formValues?.toDate,
                location: remodify(formValues?.location),
                patients: remodify(formValues?.patients),
                provider: remodify(formValues?.provider),
                patientType: remodify(formValues?.patientType),
                benefitsTypes: remodify(formValues?.typeOfBenefitStatus),
                appStatus: "",
                isFavorite: formValues.isFavorite,
                isSave: formValues.isSaveFilter,
              },
            })
          : await FilterCreate.mutateAsync({
              filterName: formValues?.filterName,
              fromDate: formValues?.fromDate,
              toDate: formValues?.toDate,
              location: remodify(formValues?.location),
              patients: remodify(formValues?.patients),
              provider: remodify(formValues?.provider),
              patientType: remodify(formValues?.patientType),
              benefitsTypes: remodify(formValues?.typeOfBenefitStatus),
              appStatus: "",
              isFavorite: formValues.isFavorite,
              isSave: formValues.isSaveFilter,
            });
      const rows = response.data.patientDetails.map((cell: any) => ({
        "Patient Id": cell.patientId,
        "Patient Name": cell.firstName + " " + cell.lastName,
        "Type Of Service": cell.typeOfService,
        "Practice Name & Location": cell.practiceNameAndLoc,
        "Appointment Type": cell.appointmentType,
        "Insurance Name/Plan":
          cell.providerFirstName + " " + cell.providerLastName,
        Appointment: cell.scheduleAppointment
          ? dateTimeFormat(new Date(cell.scheduleAppointment))
          : null,
        "Last Verified": cell.lastVerified
          ? dateTimeFormat(new Date(cell.lastVerified))
          : null,
        Status: cell.insuranceStatus,
        "Insurance Payer Code": cell.payerIdCode,
        Speciality: cell.speciality,
        "Date Of Birth": cell.dateOfBirth
          ? dateTimeFormat(new Date(cell.dateOfBirth))
          : null,
        "Subscriber ID": cell.subscriberId,
        "Appointment Rendering Provider": cell.appointmentRenderingProvider,
      }));

      // Define the column headers
      const columnHeaders = {
        "Patient Id": "",
        "Patient Name": "",
        "Type Of Service": "",
        "Practice Name & Location": "",
        "Appointment Type": "",
        "Insurance Name/Plan": "",
        Appointment: "",
        "Last Verified": "",
        Status: "",
        "Insurance Payer Code": "",
        Speciality: "",
        "Date Of Birth": "",
        "Subscriber ID": "",
        "Appointment Rendering Provider": "",
      };

      // If rows are empty, add an empty row to ensure headers are included
      if (rows.length === 0) {
        rows.push(columnHeaders);
      }

      const worksheet = XLSX.utils.json_to_sheet(rows);
      const workBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workBook, worksheet, "data");
      XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    }
  };
  const updateForm = async () => {
    try {
      const response = await FilterUpdate.mutateAsync({
        id: formValues?.filterId,
        data: {
          filterName: formValues?.filterName,
          fromDate: formValues?.fromDate,
          toDate: formValues?.toDate,
          location: remodify(formValues?.location),
          patients: remodify(formValues?.patients),
          provider: remodify(formValues?.provider),
          patientType: remodify(formValues?.patientType),
          benefitsTypes: remodify(formValues?.typeOfBenefitStatus),
          appStatus: "",
          isFavorite: formValues.isFavorite,
          isSave: formValues.isSaveFilter,
        },
      });
      setGenerateResponse(formValues.filterId);
      navigate(`/reports/generate-transaction`, {
        state: response?.data,
      });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size={{ xs: "100%", sm: "100%", md: "100%", lg: "100%" }}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader
          toggle={toggle}
          className=" bg-data-tertiary hstack"
          close={
            <>
              <div className="flex-wrap gap-3 hstack">
                <Label check>
                  <Input
                    type="checkbox"
                    name="saveFilter"
                    checked={formValues.isSaveFilter}
                    onChange={() =>
                      setFormValues({
                        ...formValues,
                        isSaveFilter: !formValues?.isSaveFilter,
                      })
                    }
                  />
                  <span className="fs-6">
                    {" "}
                    {selectedOption === "existing"
                      ? "Update / Save as New Filter"
                      : "Save Filter"}
                  </span>
                </Label>
                <Button outline color="primary" onClick={toggle}>
                  Cancel
                </Button>

                <UncontrolledDropdown className="flex-wrap">
                  <DropdownToggle data-toggle="dropdown" tag="span">
                    <Button outline color="primary">
                      Download As Report
                      <FontAwesomeIcon icon={faChevronDown} />
                    </Button>
                  </DropdownToggle>

                  <DropdownMenu className="mt-3">
                    <DropdownItem onClick={submitDownloadPdfForm}>
                      PDF
                    </DropdownItem>

                    <DropdownItem onClick={submitDownloadCsvForm}>
                      CSV
                    </DropdownItem>
                  </DropdownMenu>
                </UncontrolledDropdown>
                <Button
                  color="primary"
                  className="flex-wrap"
                  onClick={() => handleGenerateConfirmation("generate")}
                >
                  Generate
                </Button>
              </div>
            </>
          }
        >
          <div className="title">Transaction </div>
        </OffcanvasHeader>

        <OffcanvasBody className="mt-2">
          <TransactionReportForm
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            setFormValues={setFormValues}
            formValues={formValues}
            stateValues={state}
          />
        </OffcanvasBody>
      </Offcanvas>
      <SaveConfirmation
        saveConfirmationOpen={saveConfirmationOpen}
        setSaveConfirmationOpen={setSaveConfirmationOpen}
        buttonClicked={buttonClicked}
        selectedOption={selectedOption}
        formValues={formValues}
        setFormValues={setFormValues}
        currentForm="transaction"
      />
    </>
  );
};

export default TransactionReport;

export const typeOfBenefitStatusOptions = [
  "Success",
  "Technical",
  "Not Verified",
  "Demographic",
];

const TransactionReportForm = (props: any) => {
  const [selectedFilter, setSelectedFilter] = useState("1");
  const [, setFilteredData] = useState<any>({});
  const auth = useAuth();

  const getAllFormData = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/getallpatients`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
    return response.json();
  };

  const { data: formData } = useSuspenseQuery({
    queryKey: ["transactionFilters", "getAll"],
    queryFn: getAllFormData,
  });

  const patientNameList: any = [];
  formData?.patients?.map((patient: any) => {
    patientNameList.push(`${patient.firstName + " " + patient.lastName}`);
  });

  const modifyOptions: any = (nonModifiedOptions: any) => {
    const modifiedOptions: any = [];
    nonModifiedOptions?.map((item: any) => {
      modifiedOptions.push({ value: item, label: item });
    });
    return modifiedOptions;
  };

  const modifyPatientList = (patientsArray: any) => {
    const modifiedPatientsList: any = [];

    patientsArray?.map((item: any) => {
      modifiedPatientsList.push({
        value: item,
        label: `${item.firstName + " " + item.lastName}`,
      });
    });
    return modifiedPatientsList;
  };

  useEffect(() => {
    if (props.stateValues) {
      props.setSelectedOption("existing");
      setSelectedFilter(props.stateValues?.id);
      props.setFormValues({
        ...props.formValues,
        filterId: props.stateValues?.id,
      });
    }
  }, [props.stateValues]);

  const getByIdTransaction = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/transaction/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  useEffect(() => {
    const fetchData = async (selectedFilter: any) => {
      if (selectedFilter !== "0") {
        try {
          const response = getByIdTransaction(selectedFilter);
          const result = await response();
          props.setFormValues({
            ...props.formValues,
            filterName: result?.data?.transaction?.filterName,
            isFavorite: result?.data?.transaction?.isFavorite,
            fromDate: result?.data?.transaction?.fromDate,
            toDate: result?.data?.transaction?.toDate,
            patients: modifyPatientList(result?.data?.transaction?.patients),
            location: modifyOptions(result?.data?.transaction?.location),
            provider: modifyOptions(result?.data?.transaction?.provider),
            patientType: modifyOptions(result?.data?.transaction?.patientType),
            appStatus: result?.data?.transaction?.appStatus,
            typeOfBenefitStatus: modifyOptions(
              result?.data?.transaction?.benefitsTypes
            ),
            filterId: selectedFilter,
          });
          setFilteredData(result?.transaction);
        } catch (error) {
          console.error("Error fetching data:", error);
          throw error;
        }
      }
    };
    fetchData(selectedFilter);
  }, [selectedFilter]);

  const handleSelect = (val: any, key: string) => {
    props.setFormValues({
      ...props.formValues,
      [key]: val,
    });
  };

  return (
    <React.Suspense fallback={<CommonLoader label="Transaction" />}>
      <Row>
        <Col>
          <span className="mt-2 fs-6 fw-light">Filter Criteria</span>
        </Col>
      </Row>
      <Row className="gap-3 mb-1 hstack">
        <Col xs={12} md={12} lg={12}>
          <Row className="mb-2">
            <Col xs={12} md={4}>
              <Label check>
                <Input
                  type="radio"
                  name="new"
                  value="new"
                  checked={props.selectedOption === "new"}
                  onChange={(e) => {
                    props.setSelectedOption(e.target.value);
                    props.setFormValues({
                      filterName: "",
                      fromDate: "",
                      toDate: "",
                      location: [],
                      patients: [],
                      provider: [],
                      patientType: [],
                      typeOfBenefitStatus: [],
                      appStatus: [],
                      isFavorite: false,
                      isSaveFilter: false,
                      filterId: "",
                    });
                  }}
                />{" "}
                <span className="m-2 fs-6 fw-normal">Create New</span>
              </Label>
            </Col>
            <Col xs={12} md={6}>
              <Label check>
                <Input
                  type="radio"
                  name="existing"
                  value="existing"
                  checked={props.selectedOption === "existing"}
                  onChange={(e) => {
                    props.setSelectedOption(e.target.value);
                  }}
                />
                <span className="m-2 fs-6 fw-normal">Select Existing</span>
              </Label>
            </Col>
          </Row>

          {props.selectedOption === "existing" && (
            <Row className="mt-2">
              <Col xs={12} md={6} lg={6}>
                <FilterNameTransaction
                  name="filterName"
                  label="Filter Name"
                  value={selectedFilter}
                  onChange={(e) => {
                    setSelectedFilter(e.target.value);
                  }}
                />
              </Col>
            </Row>
          )}
          <Row>
            <Col>
              <p className="mb-2 fs-5 fw-normal">Select Filter Criteria</p>
            </Col>
          </Row>
          <Row>
            <Col xs={6} md={3} lg={3}>
              <FromDate
                required
                value={props?.formValues?.fromDate}
                onChange={(event: any) => {
                  if (event) {
                    props.setFormValues({
                      ...props.formValues,
                      fromDate: event.toString(),
                    });
                  } else {
                    props.setFormValues({
                      ...props.formValues,
                      fromDate: null,
                    });
                  }
                }}
              />
            </Col>
            <Col xs={6} md={3} lg={3}>
              <ToDate
                required
                value={props?.formValues?.toDate}
                onChange={(event: any) => {
                  if (event) {
                    props.setFormValues({
                      ...props.formValues,
                      toDate: event.toString(),
                    });
                  } else {
                    props.setFormValues({
                      ...props.formValues,
                      toDate: null,
                    });
                  }
                }}
              />
            </Col>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="typeOfBenefitStatus"
                label="Type of Benefit status"
                options={modifyOptions(typeOfBenefitStatusOptions)}
                value={props?.formValues?.typeOfBenefitStatus}
                onChange={(event) => {
                  handleSelect(event, "typeOfBenefitStatus");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="location"
                label="Location"
                options={modifyOptions(formData?.locations)}
                value={props?.formValues?.location}
                onChange={(event) => {
                  handleSelect(event, "location");
                }}
              />
            </Col>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="typeOfPatient"
                label="Type of Patient"
                options={modifyOptions(patientTypeOptions)}
                value={props?.formValues?.patientType}
                onChange={(event) => {
                  handleSelect(event, "patientType");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="Provider"
                label="Provider"
                options={modifyOptions(formData?.providers)}
                value={props?.formValues?.provider}
                onChange={(event) => {
                  handleSelect(event, "provider");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="App Status"
                label="App Status"
                options={[]}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="patient"
                label="Patient"
                options={modifyPatientList(formData?.patients)}
                value={props?.formValues?.patients}
                onChange={(event) => {
                  handleSelect(event, "patients");
                }}
              />
            </Col>
          </Row>
        </Col>
      </Row>
    </React.Suspense>
  );
};
