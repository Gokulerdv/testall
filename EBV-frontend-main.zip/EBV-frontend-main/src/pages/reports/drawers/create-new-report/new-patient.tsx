/* eslint-disable @typescript-eslint/no-explicit-any */
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
  UncontrolledDropdown,
} from "reactstrap";
import XLSX from "xlsx";
import FromDate from "../../fields/from-date";
import ToDate from "../../fields/to-date";

// import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useAuth } from "../../../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateTimeFormat } from "../../../../utils/date-time-format";
import Config from "../../../../utils/headers-config";
import CommonLoader from "../../../eligibility/patient-benefit-information/common-loader";
import FilterNameNewPatient from "../../fields/filter-name-new-patient";
import MultipleSelectCheckMarks from "../../fields/multiple-select";
import SaveConfirmation from "../../modals/save-confirmation";
import { columnsOptions } from "./pending-eligibility";

export const NewPatientsReport = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "reports/new-patient-report",
    togglePath: "../",
  });

  const location = useLocation();
  const { state } = location;

  const navigate = useNavigate();

  const [formValues, setFormValues] = useState({
    filterName: "",
    appointmentDate: "",
    fromDate: "",
    toDate: "",
    location: "",
    provider: [],
    patientType: [],
    patients: [],
    columns: [],
    isFavorite: false,
    isSaveFilter: false,
    filterId: "",
  });

  const [selectedOption, setSelectedOption] = React.useState("new");
  const [saveConfirmationOpen, setSaveConfirmationOpen] = React.useState(false);
  const [buttonClicked, setButtonClicked] = React.useState("");
  const auth = useAuth();
  const [, setGenerateResponse] = React.useState({});

  const handleGenerateConfirmation = (key: any) => {
    if (formValues.isSaveFilter) {
      setSaveConfirmationOpen(!saveConfirmationOpen);
      setButtonClicked(key);
    } else {
      if (key !== "pdf" && key !== "csv") {
        if (selectedOption === "new") submitForm();
        else if (selectedOption === "existing") updateForm();
      }
    }
  };

  const NewPatientFilterCreate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/newpatient/create`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const NewPatientFilterUpdate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/newpatient/update/${
      data.id
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const FilterCreate = useMutation({
    mutationKey: ["newPatient", "create"],
    mutationFn: NewPatientFilterCreate,
  });

  const FilterUpdate = useMutation({
    mutationKey: ["newPatient", "update"],
    mutationFn: NewPatientFilterUpdate,
  });

  const remodify = (passedParam: any) => {
    const remodifiedArray: any = [];
    passedParam.map((item: any) => remodifiedArray.push(item.value));
    return remodifiedArray;
  };

  // const remodifyPatients = (passedParam: any) => {
  //   const remodifiedPatientsArray: any = [];
  //   passedParam.map((item: any) =>
  //     remodifiedPatientsArray.push({
  //       patientId: item.value.patientId,
  //       isSchedule: item.value.isSchedule,
  //     })
  //   );
  //   return remodifiedPatientsArray;
  // };

  const submitForm = async () => {
    try {
      const response = await FilterCreate.mutateAsync({
        filterName: formValues?.filterName,
        fromDate: formValues?.fromDate,
        appointmentDate: formValues?.appointmentDate,
        toDate: formValues?.toDate,
        location: remodify(formValues?.location),
        patients: remodify(formValues?.patients),
        provider: remodify(formValues?.provider),
        patientType: remodify(formValues?.patientType),
        columns: remodify(formValues?.columns),
        isFavorite: formValues.isFavorite,
        isSave: formValues.isSaveFilter,
      });
      setGenerateResponse(response?.data?.newPatient);
      navigate(`/reports/generate-new-patient`, {
        state: response?.data,
      });
    } catch (error) {
      console.log(error);
    }
  };
  const submitDownloadPdfForm = async () => {
    try {
      const response =
        selectedOption === "existing" && formValues.filterId
          ? await FilterUpdate.mutateAsync({
              id: formValues?.filterId,
              data: {
                filterName: formValues?.filterName,
                fromDate: formValues?.fromDate,
                appointmentDate: formValues?.appointmentDate,
                toDate: formValues?.toDate,
                location: remodify(formValues?.location),
                patientType: remodify(formValues?.patientType),
                patients: remodify(formValues?.patients),
                provider: remodify(formValues?.provider),
                columns: remodify(formValues?.columns),
                isFavorite: formValues?.isFavorite,
                isSave: formValues?.isSaveFilter,
              },
            })
          : await FilterCreate.mutateAsync({
              filterName: formValues?.filterName,
              fromDate: formValues?.fromDate,
              appointmentDate: formValues?.appointmentDate,
              toDate: formValues?.toDate,
              location: remodify(formValues?.location),
              patients: remodify(formValues?.patients),
              provider: remodify(formValues?.provider),
              patientType: remodify(formValues?.patientType),
              columns: remodify(formValues?.columns),
              isFavorite: formValues.isFavorite,
              isSave: formValues.isSaveFilter,
            });
      const bufferData = new Uint8Array(
        selectedOption === "existing" && formValues.filterId
          ? response.data.pdfBuffer.data
          : response.data.pdf.data
      );
      const blob = await new Blob([bufferData], {
        type: "application/pdf",
      });

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "bulk_pdf.pdf";

      a.click();

      window.URL.revokeObjectURL(url);

      toast.success("Pdf downloaded successfully");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    }
  };
  const updateForm = async () => {
    try {
      const response = await FilterUpdate.mutateAsync({
        id: formValues?.filterId,
        data: {
          filterName: formValues?.filterName,
          fromDate: formValues?.fromDate,
          appointmentDate: formValues?.appointmentDate,
          toDate: formValues?.toDate,
          location: remodify(formValues?.location),
          patientType: remodify(formValues?.patientType),
          patients: remodify(formValues?.patients),
          provider: remodify(formValues?.provider),
          columns: remodify(formValues?.columns),
          isFavorite: formValues?.isFavorite,
          isSave: formValues?.isSaveFilter,
        },
      });
      navigate(`/reports/generate-new-patient`, {
        state: response?.data,
      });
      setGenerateResponse(response?.data);
    } catch (error) {
      console.log(error);
    }
  };

  const submitDownloadCsvForm = async () => {
    try {
      const response =
        selectedOption === "existing" && formValues.filterId
          ? await FilterUpdate.mutateAsync({
              id: formValues?.filterId,
              data: {
                filterName: formValues?.filterName,
                fromDate: formValues?.fromDate,
                appointmentDate: formValues?.appointmentDate,
                toDate: formValues?.toDate,
                location: remodify(formValues?.location),
                patientType: remodify(formValues?.patientType),
                patients: remodify(formValues?.patients),
                provider: remodify(formValues?.provider),
                columns: remodify(formValues?.columns),
                isFavorite: formValues?.isFavorite,
                isSave: formValues?.isSaveFilter,
              },
            })
          : await FilterCreate.mutateAsync({
              filterName: formValues?.filterName,
              fromDate: formValues?.fromDate,
              appointmentDate: formValues?.appointmentDate,
              toDate: formValues?.toDate,
              location: remodify(formValues?.location),
              patients: remodify(formValues?.patients),
              provider: remodify(formValues?.provider),
              patientType: remodify(formValues?.patientType),
              columns: remodify(formValues?.columns),
              isFavorite: formValues.isFavorite,
              isSave: formValues.isSaveFilter,
            });
      const rows = response.data.patientDetails.map((cell: any) => ({
        "Patient Id": cell.patientId,
        "Patient Name": cell.firstName + " " + cell.lastName,
        "Type Of Service": cell.typeOfService,
        "Practice Name & Location": cell.practiceNameAndLoc,
        "Appointment Type": cell.appointmentType,
        "Insurance Name/Plan":
          cell.providerFirstName + " " + cell.providerLastName,
        Appointment: cell.scheduleAppointment
          ? dateTimeFormat(new Date(cell.scheduleAppointment))
          : null,
        "Last Verified": cell.lastVerified
          ? dateTimeFormat(new Date(cell.lastVerified))
          : null,
        Status: cell.insuranceStatus,
        "Insurance Payer Code": cell.payerIdCode,
        Speciality: cell.speciality,
        "Date Of Birth": cell.dateOfBirth
          ? dateTimeFormat(new Date(cell.dateOfBirth))
          : null,
        "Subscriber ID": cell.subscriberId,
        "Appointment Rendering Provider": cell.appointmentRenderingProvider,
      }));

      // Define the column headers
      const columnHeaders = {
        "Patient Id": "",
        "Patient Name": "",
        "Type Of Service": "",
        "Practice Name & Location": "",
        "Appointment Type": "",
        "Insurance Name/Plan": "",
        Appointment: "",
        "Last Verified": "",
        Status: "",
        "Insurance Payer Code": "",
        Speciality: "",
        "Date Of Birth": "",
        "Subscriber ID": "",
        "Appointment Rendering Provider": "",
      };

      // If rows are empty, add an empty row to ensure headers are included
      if (rows.length === 0) {
        rows.push(columnHeaders);
      }

      const worksheet = XLSX.utils.json_to_sheet(rows);
      const workBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workBook, worksheet, "data");
      XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    }
  };
  return (
    <>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size={{ xs: "100%", sm: "100%", md: "100%", lg: "100%" }}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader
          toggle={toggle}
          className=" bg-data-tertiary hstack"
          close={
            <>
              <div className="flex-wrap gap-3 hstack">
                <Label check>
                  <Input
                    type="checkbox"
                    name="saveFilter"
                    checked={formValues.isSaveFilter}
                    onChange={() =>
                      setFormValues({
                        ...formValues,
                        isSaveFilter: !formValues?.isSaveFilter,
                      })
                    }
                  />
                  <span className="fs-6">
                    {" "}
                    {selectedOption === "existing"
                      ? "Update / Save as New Filter"
                      : "Save Filter"}
                  </span>
                </Label>
                <Button outline color="primary" onClick={toggle}>
                  Cancel
                </Button>

                <UncontrolledDropdown className="flex-wrap">
                  <DropdownToggle data-toggle="dropdown" tag="span">
                    <Button outline color="primary">
                      Download As Report
                      <FontAwesomeIcon icon={faChevronDown} />
                    </Button>
                  </DropdownToggle>

                  <DropdownMenu className="mt-3">
                    <DropdownItem onClick={submitDownloadPdfForm}>
                      PDF
                    </DropdownItem>

                    <DropdownItem onClick={submitDownloadCsvForm}>
                      CSV
                    </DropdownItem>
                  </DropdownMenu>
                </UncontrolledDropdown>
                <Button
                  color="primary"
                  className="flex-wrap"
                  onClick={() => handleGenerateConfirmation("generate")}
                >
                  Generate Report
                </Button>
              </div>
            </>
          }
        >
          <div className="title">New Patient</div>
        </OffcanvasHeader>

        <OffcanvasBody className="mt-2">
          <NewPatientReportForm
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            setFormValues={setFormValues}
            formValues={formValues}
            stateValues={state}
          />
        </OffcanvasBody>
      </Offcanvas>
      <SaveConfirmation
        saveConfirmationOpen={saveConfirmationOpen}
        setSaveConfirmationOpen={setSaveConfirmationOpen}
        buttonClicked={buttonClicked}
        selectedOption={selectedOption}
        formValues={formValues}
        setFormValues={setFormValues}
        currentForm="new-patient"
      />
    </>
  );
};

export default NewPatientsReport;

export const patientTypeOptions = ["General", "Ortho"];

const NewPatientReportForm = (props: any) => {
  const [selectedFilter, setSelectedFilter] = useState("0");
  const [, setFilteredData] = useState<any>({});
  const auth = useAuth();

  const getAllFormData = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/getallpatients`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
    return response.json();
  };

  useEffect(() => {
    if (props.stateValues) {
      props.setSelectedOption("existing");
      setSelectedFilter(props.stateValues?.id);
      props.setFormValues({
        ...props.formValues,
        filterId: props.stateValues?.id,
      });
    }
  }, [props.stateValues]);

  const getByIdNewPatient = (id: string) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/newpatient/getById/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  useEffect(() => {
    const fetchData = async (selectedFilter: any) => {
      if (selectedFilter !== "0") {
        try {
          const response = getByIdNewPatient(selectedFilter);
          const result = await response();
          props.setFormValues({
            ...props.formValues,
            filterName: result?.data?.newPatients?.filtername,
            isFavorite: result?.data?.newPatients?.isFavorite,
            fromDate: result?.data?.newPatients?.fromDate,
            toDate: result?.data?.newPatients?.toDate,
            patients: modifyPatientList(result?.data?.newPatients?.patients),
            location: modifyOptions(result?.data?.newPatients?.location),
            provider: modifyOptions(result?.data?.newPatients?.provider),
            patientType: modifyOptions(result?.data?.newPatients?.patientType),
            columns: modifyOptions(result?.data?.newPatients?.columns),
            appointmentDate: result?.data?.newPatients?.appointmentDate,
            filterId: selectedFilter,
          });
          setFilteredData(result?.data.newPatients);
        } catch (error) {
          console.error("Error fetching data:", error);
          throw error;
        }
      }
    };
    fetchData(selectedFilter);
  }, [selectedFilter]);

  const modifyOptions: any = (nonModifiedOptions: any) => {
    const modifiedOptions: any = [];
    nonModifiedOptions?.map((item: any) => {
      modifiedOptions.push({ value: item, label: item });
    });
    return modifiedOptions;
  };

  const modifyPatientList = (patientsArray: any) => {
    const modifiedPatientsList: any = [];

    patientsArray?.map((item: any) => {
      modifiedPatientsList.push({
        value: item,
        label: `${item.firstName + " " + item.lastName}`,
      });
    });
    return modifiedPatientsList;
  };

  const { data: formData } = useSuspenseQuery({
    queryKey: ["newPatientsFilters", "getAll"],
    queryFn: getAllFormData,
  });

  const handleSelect = (val: any, key: string) => {
    props.setFormValues({
      ...props.formValues,
      [key]: val,
    });
  };
  return (
    <>
      <React.Suspense fallback={<CommonLoader label="New Patient" />}>
        <Row>
          <Col>
            <span className="mt-2 fs-6 fw-light">Filter Criteria</span>
          </Col>
        </Row>
        <Row className="hstack">
          <Col xs={12} md={12} lg={12}>
            <Row className="mb-2">
              <Col xs={12} md={4}>
                <Label check>
                  <Input
                    type="radio"
                    name="isExisting"
                    value="new"
                    checked={props.selectedOption === "new"}
                    onChange={(e) => {
                      props.setSelectedOption(e.target.value);
                      props.setFormValues({
                        filterName: "",
                        appointmentDate: "",
                        fromDate: "",
                        toDate: "",
                        location: "",
                        provider: [],
                        patientType: [],
                        patients: [],
                        columns: [],
                        isFavorite: false,
                        isSaveFilter: false,
                        filterId: "",
                      });
                    }}
                  />{" "}
                  <span className=" fs-6 fw-normal">Create New</span>
                </Label>
              </Col>
              <Col xs={12} md={6}>
                <Label check>
                  <Input
                    type="radio"
                    name="isExisting"
                    value="existing"
                    checked={props.selectedOption === "existing"}
                    onChange={(e) => {
                      props.setSelectedOption(e.target.value);
                    }}
                  />
                  <span className=" fs-6 fw-normal">Select Existing</span>
                </Label>
              </Col>
            </Row>
            {props.selectedOption === "existing" && (
              <Row>
                <Col xs={12} md={6} lg={6}>
                  <FilterNameNewPatient
                    name="filterName"
                    label="Filter Name"
                    value={selectedFilter}
                    onChange={(e) => {
                      e.preventDefault();
                      setSelectedFilter(e.target.value);
                    }}
                  />
                </Col>
              </Row>
            )}
          </Col>
          <Row>
            <Col>
              <p className="mb-2 fs-5 fw-normal">Select Filter Criteria</p>
            </Col>
          </Row>
          <Row className="mb-2">
            <span className=" fs-6 fw-light">Select Appointment Date Type</span>
            <Col xs={12} md={4}>
              <Label check>
                <Input
                  type="radio"
                  name="appointmentDate"
                  value="pastDate"
                  checked={props.formValues.appointmentDate === "pastDate"}
                  onChange={(e) => {
                    props.setFormValues({
                      ...props.formValues,
                      appointmentDate: e.target.value,
                    });
                  }}
                />
                {"  "}
                <span className=" fs-6 fw-normal">Past Date</span>
              </Label>
            </Col>
            <Col xs={12} md={6}>
              <Label check>
                <Input
                  type="radio"
                  name="appointmentDate"
                  value="futureDate"
                  checked={props?.formValues?.appointmentDate === "futureDate"}
                  onChange={(e) => {
                    props.setFormValues({
                      ...props.formValues,
                      appointmentDate: e.target.value,
                    });
                  }}
                />
                {"  "}
                <span className=" fs-6 fw-normal">Future Date</span>
              </Label>
            </Col>
          </Row>
          <Row>
            <Col xs={6} md={3} lg={3}>
              <FromDate
                required
                value={props?.formValues?.fromDate}
                onChange={(event: any) => {
                  if (event) {
                    props.setFormValues({
                      ...props.formValues,
                      fromDate: event.toString(),
                    });
                  } else {
                    props.setFormValues({
                      ...props.formValues,
                      fromDate: null,
                    });
                  }
                }}
              />
            </Col>
            <Col xs={6} md={3} lg={3}>
              <ToDate
                required
                value={props?.formValues?.toDate}
                onChange={(event: any) => {
                  if (event) {
                    props.setFormValues({
                      ...props.formValues,
                      toDate: event.toString(),
                    });
                  } else {
                    props.setFormValues({
                      ...props.formValues,
                      toDate: null,
                    });
                  }
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="location"
                label="Location"
                required
                options={modifyOptions(formData?.locations)}
                value={props?.formValues?.location}
                onChange={(event) => {
                  handleSelect(event, "location");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="provider"
                label="provider"
                options={modifyOptions(formData?.providers)}
                value={props?.formValues?.provider}
                onChange={(event) => {
                  handleSelect(event, "provider");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="patientType"
                label="Patient Type"
                options={modifyOptions(patientTypeOptions)}
                value={props?.formValues?.patientType}
                onChange={(event) => {
                  handleSelect(event, "patientType");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="patients"
                label="patients"
                options={modifyPatientList(formData?.patients)}
                value={props?.formValues?.patients}
                onChange={(event) => {
                  handleSelect(event, "patients");
                }}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6}>
              <MultipleSelectCheckMarks
                name="column"
                label="Column"
                options={columnsOptions}
                value={props?.formValues?.columns}
                onChange={(event) => {
                  handleSelect(event, "columns");
                }}
              />
            </Col>
          </Row>
        </Row>
      </React.Suspense>
    </>
  );
};
