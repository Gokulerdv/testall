/* eslint-disable @typescript-eslint/no-explicit-any */
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

import {
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
  UncontrolledDropdown,
} from "reactstrap";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { GenerateReportTable } from "../../table/generate-table";

export const GenerateNewPatientReport = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "reports/generate-new-patient",
  });
  const navigate = useNavigate();

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size={{ xs: "100%", sm: "100%", md: "100%", lg: "100%" }}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader
          toggle={toggle}
          className=" bg-data-tertiary hstack"
          close={
            <>
              <div className="flex-wrap gap-3 hstack">
                <UncontrolledDropdown className="flex-wrap">
                  <DropdownToggle data-toggle="dropdown" tag="span">
                    <Button outline color="primary">
                      Download As Report
                      <FontAwesomeIcon icon={faChevronDown} />
                    </Button>
                  </DropdownToggle>

                  <DropdownMenu className="mt-3">
                    <DropdownItem
                    // onClick={() => handleGenerateConfirmation("pdf")}
                    >
                      PDF
                    </DropdownItem>

                    <DropdownItem
                    // onClick={() => handleGenerateConfirmation("csv")}
                    >
                      CSV
                    </DropdownItem>
                  </DropdownMenu>
                </UncontrolledDropdown>
                <Button
                  outline
                  color="primary"
                  className="flex-wrap"
                  onClick={() => navigate(`/reports/new-patient-report`)}
                >
                  Edit Filter Criteria
                </Button>
              </div>
            </>
          }
        >
          <div className="title">New Patient</div>
        </OffcanvasHeader>
        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <EligibilityFields />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const EligibilityFields = () => {
  // Retrieve data from localStorage

  const { state } = useLocation();
  return (
    <>
      <Row className="mb-5">
        <Row className="mt-4">
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Location</span>
              <div> {state?.newPatient?.location.join(",")}</div>
            </Label>
          </Col>

          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Provider</span>
              <div>{state?.newPatient?.provider.join(",")}</div>
            </Label>
          </Col>
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Patient Type</span>
              <p>{state?.newPatient?.patientType?.join(",")}</p>
            </Label>
          </Col>
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Patient</span>
              <p>
                {state?.newPatient?.patients
                  ?.map((data: any) => data.patientId)
                  .join(",")}
              </p>
            </Label>
          </Col>
          <Col md={4}></Col>
        </Row>

        <Row></Row>
      </Row>

      <GenerateReportTable
        reportType="newPatient"
        reportData={state?.patientDetails}
      />
    </>
  );
};

export default GenerateNewPatientReport;
