/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react";

import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import XLSX from "xlsx";

import {
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
  UncontrolledDropdown,
} from "reactstrap";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateTimeFormat } from "../../../../utils/date-time-format";
import GenerateReportTable from "../../table/generate-table";

export const GenerateTransactionReport = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "reports/generate-transaction",
  });
  const navigate = useNavigate();
  const { state } = useLocation();
  const queryClient = useQueryClient();

  const handleGeneratePdf = async () => {
    try {
      // Check if patientBulkPdf.data exists and has the expected structure
      if (state && state.result.pdf && state.result.pdf.data) {
        const bufferData = new Uint8Array(state.result.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } else {
        toast.error("PDF data is missing or in unexpected format");
      }
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };

  const exportAsCSV = () => {
    const rows = state.result.patientDetails?.map((cell: any) => ({
      "Patient Id": cell.patientId,
      "Patient Name": cell.firstName + " " + cell.lastName,
      "Type Of Service": cell.typeOfService,
      "Practice Name & Location": cell.practiceNameAndLoc,
      "Appointment Type": cell.appointmentType,
      "Insurance Name/Plan":
        cell.providerFirstName + " " + cell.providerLastName,
      Appointment: cell.scheduleAppointment
        ? dateTimeFormat(new Date(cell.scheduleAppointment))
        : null,
      "Last Verified": cell.lastVerified
        ? dateTimeFormat(new Date(cell.lastVerified))
        : null,
      Status: cell.insuranceStatus,
      "Insurance Payer Code": cell.payerIdCode,
      Speciality: cell.speciality,
      "Date Of Birth": cell.dateOfBirth
        ? dateTimeFormat(new Date(cell.dateOfBirth))
        : null,
      "Subscriber ID": cell.subscriberId,
      "Appointment Rendering Provider": cell.appointmentRenderingProvider,
    }));

    // Define the column headers
    const columnHeaders = {
      "Patient Id": "",
      "Patient Name": "",
      "Type Of Service": "",
      "Practice Name & Location": "",
      "Appointment Type": "",
      "Insurance Name/Plan": "",
      Appointment: "",
      "Last Verified": "",
      Status: "",
      "Insurance Payer Code": "",
      Speciality: "",
      "Date Of Birth": "",
      "Subscriber ID": "",
      "Appointment Rendering Provider": "",
    };

    // If rows are empty, add an empty row to ensure headers are included
    if (rows.length === 0) {
      rows.push(columnHeaders);
    }

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, worksheet, "data");
    XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
  };
  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size={{ xs: "100%", sm: "100%", md: "100%", lg: "100%" }}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader
          toggle={toggle}
          className=" bg-data-tertiary hstack"
          close={
            <>
              <div className="flex-wrap gap-3 hstack">
                <UncontrolledDropdown className="flex-wrap">
                  <DropdownToggle data-toggle="dropdown" tag="span">
                    <Button outline color="primary">
                      Download As Report
                      <FontAwesomeIcon icon={faChevronDown} />
                    </Button>
                  </DropdownToggle>

                  <DropdownMenu className="mt-3">
                    <DropdownItem onClick={handleGeneratePdf}>PDF</DropdownItem>

                    <DropdownItem onClick={exportAsCSV}>CSV</DropdownItem>
                  </DropdownMenu>
                </UncontrolledDropdown>
                <Button
                  outline
                  color="primary"
                  className="flex-wrap"
                  onClick={() => navigate(`/reports/transaction-report`)}
                >
                  Edit Filter Criteria
                </Button>
              </div>
            </>
          }
        >
          <div className="title">Transaction</div>
        </OffcanvasHeader>
        <OffcanvasBody>
          <React.Suspense fallback="Loading form...">
            <TransactionFields />
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export const TransactionFields = () => {
  const { state } = useLocation();
  return (
    <>
      <Row className="mb-5">
        <Row className="mt-4">
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Location</span>
              <div> &nbsp;&nbsp;{state?.transaction?.location.join(",")}</div>
            </Label>
          </Col>
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">
                Type of Benefit Status
              </span>
              <div>
                {" "}
                &nbsp;&nbsp;{state?.transaction?.benefitsTypes.join(",")}
              </div>
            </Label>
          </Col>
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Type of Patient</span>
              <p> &nbsp;&nbsp;{state?.transaction?.patientType.join(",")}</p>
            </Label>
          </Col>
          <Col md={2}>
            <span className="m-2 fs-6 fw-lighter">Provider</span>
            <p>&nbsp;&nbsp;{state?.transaction?.provider.join(",")}</p>
          </Col>
          <Col md={4}></Col>
        </Row>

        <Row>
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">App.status</span>
              <p> &nbsp;&nbsp;{state?.transaction?.appStatus}</p>
            </Label>
          </Col>
          <Col md={2}>
            <Label>
              <span className="m-2 fs-6 fw-lighter">Patient</span>
              <p>
                {" "}
                &nbsp;&nbsp;
                {state?.transaction?.patients
                  .map((value: any) => value.patientId)
                  .join(",")}
              </p>
            </Label>
          </Col>
          <Col md={4}></Col>
        </Row>
        <Row></Row>
      </Row>
      <GenerateReportTable
        reportType="transaction"
        reportData={state?.patientDetails}
      />
    </>
  );
};

export default GenerateTransactionReport;
