/* eslint-disable @typescript-eslint/no-explicit-any */
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useQueryClient } from "@tanstack/react-query";
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import XLSX from "xlsx";

import {
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
  UncontrolledDropdown,
} from "reactstrap";
import useDrawerFromLocation from "../../../../shared/hooks/use-drawer-from-location";
import { dateTimeFormat } from "../../../../utils/date-time-format";
import { GenerateReportTable } from "../../table/generate-table";

export const GeneratePendingEligibilityReport = () => {
  const { open, toggle } = useDrawerFromLocation({
    matchPath: "reports/generate-pending-eligibility",
  });
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { state } = useLocation();

  const handleGeneratePdf = async () => {
    try {
      // Check if patientBulkPdf.data exists and has the expected structure
      if (state && state.pdfBuffer && state.pdfBuffer.data) {
        const bufferData = new Uint8Array(state.result.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } else {
        toast.error("PDF data is missing or in unexpected format");
      }
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patients/all"],
      });
    }
  };

  const exportAsCSV = () => {
    const rows = state.patientDetails?.map((cell: any) => ({
      "Patient Id": cell.patientId,
      "Patient Name": cell.firstName + " " + cell.lastName,
      "Type Of Service": cell.typeOfService,
      "Practice Name & Location": cell.practiceNameAndLoc,
      "Appointment Type": cell.appointmentType,
      "Insurance Name/Plan":
        cell.providerFirstName + " " + cell.providerLastName,
      Appointment: cell.scheduleAppointment
        ? dateTimeFormat(new Date(cell.scheduleAppointment))
        : null,
      "Last Verified": cell.lastVerified
        ? dateTimeFormat(new Date(cell.lastVerified))
        : null,
      Status: cell.insuranceStatus,
      "Insurance Payer Code": cell.payerIdCode,
      Speciality: cell.speciality,
      "Date Of Birth": cell.dateOfBirth
        ? dateTimeFormat(new Date(cell.dateOfBirth))
        : null,
      "Subscriber ID": cell.subscriberId,
      "Appointment Rendering Provider": cell.appointmentRenderingProvider,
    }));

    // Define the column headers
    const columnHeaders = {
      "Patient Id": "",
      "Patient Name": "",
      "Type Of Service": "",
      "Practice Name & Location": "",
      "Appointment Type": "",
      "Insurance Name/Plan": "",
      Appointment: "",
      "Last Verified": "",
      Status: "",
      "Insurance Payer Code": "",
      Speciality: "",
      "Date Of Birth": "",
      "Subscriber ID": "",
      "Appointment Rendering Provider": "",
    };

    // If rows are empty, add an empty row to ensure headers are included
    if (rows.length === 0) {
      rows.push(columnHeaders);
    }

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, worksheet, "data");
    XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
  };
  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size={{ xs: "100%", sm: "100%", md: "100%", lg: "100%" }}
        direction="end"
        style={{ width: "80%" }}
      >
        <OffcanvasHeader
          toggle={toggle}
          className=" bg-data-tertiary hstack"
          close={
            <>
              <div className="flex-wrap gap-3 hstack">
                <UncontrolledDropdown className="flex-wrap">
                  <DropdownToggle data-toggle="dropdown" tag="span">
                    <Button outline color="primary">
                      Download As Report
                      <FontAwesomeIcon icon={faChevronDown} />
                    </Button>
                  </DropdownToggle>

                  <DropdownMenu className="mt-3">
                    <DropdownItem onClick={handleGeneratePdf}>PDF</DropdownItem>

                    <DropdownItem onClick={exportAsCSV}>CSV</DropdownItem>
                  </DropdownMenu>
                </UncontrolledDropdown>
                <Button
                  outline
                  color="primary"
                  className="flex-wrap"
                  onClick={() =>
                    navigate(`/reports/pending-eligibility-report`)
                  }
                >
                  Edit Filter Criteria
                </Button>
              </div>
            </>
          }
        >
          <div className="title">Pending Eligibility</div>
        </OffcanvasHeader>

        <OffcanvasBody className="mt-2">
          <React.Suspense fallback="Loading form...">
            <>
              <Row className="mb-5">
                <Row className="mt-4">
                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">Location</span>
                      <div>
                        {" "}
                        {state?.pendingEligibility?.location.join(",")}
                      </div>
                    </Label>
                  </Col>

                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">Provider</span>
                      <div>{state?.pendingEligibility?.filterName}</div>
                    </Label>
                  </Col>
                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">Payer</span>
                      <p>{state?.pendingEligibility?.payer.join(",")}</p>
                    </Label>
                  </Col>
                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">
                        Insurance Status
                      </span>
                      <p>
                        {state?.pendingEligibility?.insuranceStatus.join(",")}
                      </p>
                    </Label>
                  </Col>
                  <Col md={4}></Col>
                </Row>

                <Row>
                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">
                        Insurance History
                      </span>
                      <p>
                        {state?.pendingEligibility?.insuranceHierarchy.join(
                          ","
                        )}
                      </p>
                    </Label>
                  </Col>
                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">
                        Insurance Type
                      </span>
                      <p>
                        {state?.pendingEligibility?.insuranceType.join(",")}
                      </p>
                    </Label>
                  </Col>

                  <Col md={2}>
                    <span className="m-2 fs-6 fw-lighter">Patient</span>
                    <p>
                      {state?.pendingEligibility?.patients
                        .map((value: any) => value.patientId)
                        ?.join(",")}
                    </p>
                  </Col>
                  <Col md={2}>
                    <Label>
                      <span className="m-2 fs-6 fw-lighter">
                        Days Since Last Eligibility
                      </span>
                      <p>
                        {state?.pendingEligibility?.lastEligibility.join(",")}
                      </p>
                    </Label>
                  </Col>
                  <Col md={4}></Col>
                </Row>
                <Row></Row>
              </Row>

              <GenerateReportTable
                reportType="pendingEligibility"
                reportData={state?.patientDetails}
              />
            </>
          </React.Suspense>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export default GeneratePendingEligibilityReport;
