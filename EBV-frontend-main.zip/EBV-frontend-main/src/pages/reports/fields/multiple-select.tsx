/* eslint-disable @typescript-eslint/no-explicit-any */
import { capitalCase } from "change-case";
import React from "react";
import Select, { ActionMeta, MultiValue } from "react-select";
import { Label } from "reactstrap";

export type OptionType = {
  value: string;
  label: string;
};

export type SelectProps = {
  help?: React.ReactNode;
  options: { value: string; label: string }[];
  onSelect?: (selected: string[]) => void;
  onChange?: (
    newValue: OptionType[] | null,
    actionMeta: ActionMeta<OptionType>
  ) => void;
  className?: string;
  name: string;
  label: string;
  required?: any;
  value?: OptionType[];
};

export default function MultipleSelectCheckMarks(props: SelectProps) {
  const handleChange = (
    newValue: MultiValue<OptionType>,
    actionMeta: ActionMeta<OptionType>
  ) => {
    if (props.onChange) {
      props.onChange(newValue as OptionType[], actionMeta);
    }
  };

  return (
    <div>
      <Label for={props.label} className="mt-2">
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(props.label)}
      </Label>

      <Select
        name={props.name}
        className={props.className}
        options={props.options}
        value={props.value}
        onChange={handleChange}
        isMulti
      />
    </div>
  );
}
