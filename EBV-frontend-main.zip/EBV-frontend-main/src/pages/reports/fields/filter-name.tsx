/* eslint-disable @typescript-eslint/no-explicit-any */
import { FormControl } from "@mui/material";
import { useSuspenseQuery } from "@tanstack/react-query";
import { capitalCase } from "change-case";
import React from "react";
import { FormText, Input, InputProps, Label } from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../../shared/hooks/use-auth";
import { Config } from "../../../utils/headers-config";

export const key = "filterName";

export const filterNameSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`)
    .optional(),
});

export type FilterNameSchema = z.infer<typeof filterNameSchema>;

export type FilterNameProps = InputProps & {
  help?: React.ReactNode;
};

export const FilterName = (props: FilterNameProps) => {
  const auth = useAuth();

  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: reportData } = useSuspenseQuery({
    queryKey: ["pendingEligibilityReport", "getAll"],
    queryFn: getAll,
  });

  const filterNames = reportData.data.map((filter: any) => ({
    filterName: filter.filterName,
    id: filter.id,
  }));

  return (
    <FormControl fullWidth>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>

      <Input
        id={key}
        type="select"
        value={props.value}
        {...props}
        style={{ width: "64%" }}
      >
        <option value="0">Select filter</option>
        {filterNames.map((filter: any, index: any) => (
          <option key={index} value={filter.id}>
            {filter.filterName}
          </option>
        ))}
      </Input>

      {props.help ? <FormText>{props.help}</FormText> : null}
    </FormControl>
  );
};

export default FilterName;
