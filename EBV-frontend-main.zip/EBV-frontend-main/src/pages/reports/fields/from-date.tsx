/* eslint-disable @typescript-eslint/no-explicit-any */
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { capitalCase } from "change-case";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { FormGroup, FormText, Label } from "reactstrap";
import { z } from "zod";

export const defaultKey = "fromDate";

export const getFromDateValidator = (key: string) =>
  z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} should contain at least 1 character.`);

export const fromDateSchema = z.object({
  fromDate: getFromDateValidator(defaultKey),
});

export type FromDateSchema = z.infer<typeof fromDateSchema>;

export const FromDate = (props: any) => {
  return (
    <FormGroup>
      <Label for={defaultKey}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(defaultKey)}
      </Label>

      <DatePicker
        id={defaultKey}
        className="p-1 ps-4 border border-secondary-subtle rounded calendar-custom date-of-birth"
        selected={props.value}
        selectsStart
        showIcon
        icon={<FontAwesomeIcon icon={faCalendarDays} />}
        calendarIconClassname="text-primary"
        isClearable
        onChange={props.onChange}
      />

      {props.help ? <FormText>{props.help}</FormText> : null}
    </FormGroup>
  );
};

export default FromDate;
