/* eslint-disable @typescript-eslint/no-explicit-any */
import { FormControl } from "@mui/material";
import { useSuspenseQuery } from "@tanstack/react-query";
import { capitalCase } from "change-case";
import { FormText, Input, Label } from "reactstrap";
import { useAuth } from "../../../shared/hooks/use-auth";
import { Config } from "../../../utils/headers-config";
import { FilterNameProps } from "./filter-name";

export const key = "filterName";

export const FilterNameTransaction = (props: FilterNameProps) => {
  const auth = useAuth();

  const getAllTransaction = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: reportData } = useSuspenseQuery({
    queryKey: ["newPatientReport", "getAll"],
    queryFn: getAllTransaction,
  });
  const filterNames = reportData.data.map((filter: any) => ({
    filterName: filter.filterName,
    id: filter.id,
  }));

  return (
    <FormControl fullWidth>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>

      <Input
        id={key}
        type="select"
        value={props.value}
        {...props}
        style={{ width: "64%" }}
      >
        <option value="0">Select filter</option>
        {filterNames.map((filter: any, index: any) => (
          <option key={index} value={filter.id}>
            {filter.filterName}
          </option>
        ))}
      </Input>

      {props.help ? <FormText>{props.help}</FormText> : null}
    </FormControl>
  );
};

export default FilterNameTransaction;
