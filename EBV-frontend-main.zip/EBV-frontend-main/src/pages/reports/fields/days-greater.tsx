import { capitalCase } from "change-case";
import React from "react";
import { FormGroup, FormText, Input, InputProps, Label } from "reactstrap";
import { z } from "zod";

export const defaultKey = "daysGreaterThan";

export const getDaysGreaterValidator = (key: string) =>
  z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} should contain at least 1 character.`);

export const daysGreaterSchema = z.object({
  firstName: getDaysGreaterValidator(defaultKey),
});

export type DaysGreaterSchema = z.infer<typeof daysGreaterSchema>;

export type DaysGreaterProps = InputProps & {
  name?: string;
  help?: React.ReactNode;
};

export const DaysGreater = (props: DaysGreaterProps) => {
  return (
    <FormGroup className="mt-2">
      <Label for={defaultKey}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(defaultKey)}
      </Label>

      <Input id={defaultKey} type="text" {...props} />

      {props.help ? <FormText>{props.help}</FormText> : null}
    </FormGroup>
  );
};

export default DaysGreater;
