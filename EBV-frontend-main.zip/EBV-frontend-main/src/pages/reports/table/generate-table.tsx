/* eslint-disable react-refresh/only-export-components */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { faSortDown, faSortUp } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  flexRender,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { Pagination } from "reactstrap";
import LoadingIndicator from "../../../components/loading-indicator";

import { defaultColumns } from "./generate-column";

export type GenerateReportProps = {
  reportType: "pendingEligibility" | "newPatient" | "transaction";
  reportData: any;
};
export const GenerateReportTable = (props: GenerateReportProps) => {
  const { reportData } = props;

  const defaultData = {
    data: reportData, // Set data to array
    isRefetching: false,
  };

  const table = useReactTable({
    columns: defaultColumns,
    data: reportData,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),
    debugTable: true,
  });

  return (
    <>
      <div className="table-responsive">
        <table className="table mb-0 table-striped table-hover table-borderless">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    className="border-bottom"
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        {...{
                          className: "hstack align-items-center",
                          style: header.column.getCanSort()
                            ? {
                                cursor: "pointer",
                                userSelect: "none",
                              }
                            : undefined,
                          onClick: header.column.getToggleSortingHandler(),
                        }}
                      >
                        <span style={{ maxWidth: "fit-content" }}>
                          {flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                        </span>

                        {header.column.getCanSort() ? (
                          <span
                            className="vstack justify-content-center align-items-center ms-2"
                            style={{
                              maxWidth: "min-content",
                            }}
                          >
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "asc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortUp}
                              style={{ marginBottom: "-1rem" }}
                            />
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "desc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortDown}
                            />
                          </span>
                        ) : null}
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {!defaultData.isRefetching
              ? table.getRowModel().rows.map((row: any) => (
                  <tr key={row.id}>
                    {row.getVisibleCells().map((cell: any) => {
                      return (
                        <td key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))
              : null}

            <tr>
              <td
                colSpan={table.getVisibleLeafColumns()?.length || 1}
                scope="row"
                className="p-0"
                style={{
                  height: defaultData
                    ? `${10 * 2.65}rem`
                    : table.getVisibleLeafColumns()?.length
                    ? `${(10 - table.getRowModel().rows?.length) * 2.65}rem`
                    : `${11 * 2.65}rem`,
                }}
              >
                {defaultData.isRefetching ? <LoadingIndicator /> : null}
              </td>
            </tr>
          </tbody>

          <Pagination table={table} />
        </table>
      </div>
    </>
  );
};
export default GenerateReportTable;
