import { createColumnHelper } from "@tanstack/react-table";
import { dateFormat } from "../../../utils/date-format";

// Define column types
export type ReportGenerate = {
  patientId: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  memberId: string;
  groupId: string;
  relationship: string;
  typeOfService: string;
  practiceNameAndLoc: string;
  scheduleAppointment: string;
  appointmentType: string;
  speciality: string;
  gender: string;
  appointmentRenderingProvider: string;
  procedureCode: string;
  insurancePayer: string;
  dependentFirstName: string;
  dependentLastName: string;
};

// Create column helper
const columnHelper = createColumnHelper<ReportGenerate>();

// Define column headers
export const specialtyColumnHeader = "Specialty";
export const dateOfBirthColumnHeader = "Date of Birth";
export const subscriberIdColumnHeader = "Subscriber ID";
export const appointmentRenderingProviderColumnHeader =
  "Appointment Rendering Provider";
export const insurancePayerCodeColumnHeader = "Insurance Payer Code";

// Define default columns using columnHelper
export const defaultColumns = [
  columnHelper.accessor("patientId", {
    cell: (info) => info.getValue(),
    header: "Patient Id",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("firstName", {
    cell: (info) => info.getValue(),
    header: "First Name",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),

  columnHelper.accessor("lastName", {
    cell: (info) => info.getValue(),
    header: "Last Name",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("dateOfBirth", {
    cell: (info) => dateFormat(new Date(info.getValue())),
    header: "DOB",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("memberId", {
    cell: (info) => info.getValue(),
    header: "MemberId",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("groupId", {
    cell: (info) => info.getValue(),
    header: "GroupId",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("relationship", {
    cell: (info) => info.getValue(),
    header: "Relationship",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("typeOfService", {
    cell: (info) => info.getValue(),
    header: "Type of Service",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("practiceNameAndLoc", {
    cell: (info) => info.getValue(),
    header: "Practice Name & Location",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("scheduleAppointment", {
    cell: (info) => info.getValue(),
    header: "Scheduled Appointment",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("appointmentType", {
    cell: (info) => info.getValue(),
    header: "Appointment Type",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("speciality", {
    cell: (info) => info.getValue(),
    header: "Speciality",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("gender", {
    cell: (info) => info.getValue(),
    header: "Gender",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("appointmentRenderingProvider", {
    cell: (info) => info.getValue(),
    header: "Appointment Rendering provider",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("procedureCode", {
    cell: (info) => info.getValue(),
    header: "procedureCode",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("insurancePayer", {
    cell: (info) => info.getValue(),
    header: "Insurance Payer",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("dependentFirstName", {
    cell: (info) => info.getValue(),
    header: "Dependent FirstName",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
  columnHelper.accessor("dependentLastName", {
    cell: (info) => info.getValue(),
    header: "Dependent LastName",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableHiding: true,
  }),
];

export default defaultColumns;
