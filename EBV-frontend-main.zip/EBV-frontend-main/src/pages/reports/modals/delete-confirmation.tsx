/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import { useAuth } from "../../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../../shared/hooks/use-drawer-from-location";
import Config from "../../../utils/headers-config";

const DeleteConfirmation = () => {
  const location = useLocation();
  const { pathname, state } = location;
  const auth = useAuth();
  const queryClient = useQueryClient();

  const { open, toggle } = useDrawerFromLocation({
    matchPath: `${pathname}`,
    togglePath: "../..",
  });
  const keyword = pathname.includes("pending-eligibility-report")
    ? "pendingEligibility"
    : pathname.includes("new-patient-report")
    ? "newPatient"
    : "transaction";

  const deletePendingEligibility = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/delete/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const deleteNewPatient = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/newpatient/delete/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const deleteTransaction = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/transaction/delete/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const pendingEligibilityDelete = useMutation({
    mutationKey: ["pendingEligibility", "delete"],
    mutationFn: deletePendingEligibility,
  });
  const newPatientDelete = useMutation({
    mutationKey: ["newPatient", "delete"],
    mutationFn: deleteNewPatient,
  });
  const transactionDelete = useMutation({
    mutationKey: ["Transaction", "delete"],
    mutationFn: deleteTransaction,
  });

  const deleteHandler = async () => {
    try {
      keyword === "pendingEligibility"
        ? await pendingEligibilityDelete.mutateAsync(state)
        : keyword === "newPatient"
        ? await newPatientDelete.mutateAsync(state)
        : await transactionDelete.mutateAsync(state);
    } catch (error) {
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["newPatientFilters", "getAll"],
      });
      await queryClient.invalidateQueries({
        queryKey: ["pendingEligibilityFilters", "getAll"],
      });
      await queryClient.invalidateQueries({
        queryKey: ["transaction", "getAll"],
      });
      toggle();
    }
  };

  return (
    <>
      <Modal isOpen={open} toggle={toggle} backdrop={false} keyboard size="lg">
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="primary" onClick={deleteHandler}>
              Yes
            </Button>
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default DeleteConfirmation;
