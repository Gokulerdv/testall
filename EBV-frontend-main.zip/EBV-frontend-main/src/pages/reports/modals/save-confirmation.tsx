/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMutation } from "@tanstack/react-query";
import React from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row,
  UncontrolledDropdown,
} from "reactstrap";
import XLSX from "xlsx";
import { useAuth } from "../../../shared/hooks/use-auth";
import { dateTimeFormat } from "../../../utils/date-time-format";
import Config from "../../../utils/headers-config";

export const SaveConfirmation = (props: any) => {
  const toggle = () => {
    props.setSaveConfirmationOpen(!props.saveConfirmationOpen);
  };

  const navigate = useNavigate();
  const auth = useAuth();

  const [selectedRadioOption, setSelectedRadioOption] =
    React.useState("existingName");

  const PendingEligibilityFilterCreate = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/create`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const NewPatientFilterCreate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/newpatient/create`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const TransactionFilterCreate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/create`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const PendingEligibilityFilterUpdate = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/pendingeligibility/update/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const NewPatientFilterUpdate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/newpatient/update/${
      data.id
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const TransactionFilterUpdate = async (data: any): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/transaction/update/${
      data.id
    }`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
    return response;
  };

  const PendingEligibilityCreate = useMutation({
    mutationKey: ["pendingEligibility", "create"],
    mutationFn: PendingEligibilityFilterCreate,
  });

  const NewPatientsCreate = useMutation({
    mutationKey: ["newPatients", "create"],
    mutationFn: NewPatientFilterCreate,
  });

  const TransactionCreate = useMutation({
    mutationKey: ["transaction", "create"],
    mutationFn: TransactionFilterCreate,
  });

  const PendingEligibilityUpdate = useMutation({
    mutationKey: ["pendingEligibility", "update"],
    mutationFn: PendingEligibilityFilterUpdate,
  });

  const NewPatientUpdate = useMutation({
    mutationKey: ["newPatient", "update"],
    mutationFn: NewPatientFilterUpdate,
  });

  const TransactionUpdate = useMutation({
    mutationKey: ["transaction", "update"],
    mutationFn: TransactionFilterUpdate,
  });

  const remodify = (passedParam: any) => {
    const remodifiedArray: any = [];
    passedParam.map((item: any) => remodifiedArray.push(item.value));
    return remodifiedArray;
  };

  // const remodifyPatients = (passedParam: any) => {
  //   const remodifiedPatientsArray: any = [];
  //   passedParam.map((item: any) =>
  //     remodifiedPatientsArray.push({
  //       patientId: item.value.patientId,
  //       isSchedule: item.value.isSchedule,
  //     })
  //   );
  //   return remodifiedPatientsArray;
  // };

  const submitForm = async () => {
    if (props.currentForm === "pending-eligibility") {
      try {
        const response = await PendingEligibilityCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          toDate: props.formValues?.toDate,
          insuranceHierarchy: remodify(props.formValues?.insuranceHierarchy),
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          insuranceStatus: remodify(props.formValues.insuranceStatus),
          lastEligibility: remodify(props.formValues.daysSinceLastEligibility),
          daysGreaterThan: props.formValues?.daysGreaterThan,
          insuranceType: remodify(props.formValues?.insuranceType),
          columns: remodify(props.formValues?.column),
          payer: remodify(props.formValues?.payer),
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });
        navigate(`/reports/generate-pending-eligibility`, {
          state: response?.data,
        });
        props.setIsGenerate(!props.isGenerate);
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else if (props.currentForm === "new-patient") {
      try {
        const response = await NewPatientsCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          appointmentDate: props.formValues?.appointmentDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          columns: remodify(props.formValues?.columns),
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });
        navigate(`/reports/generate-new-patient`, {
          state: response?.data,
        });
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else if (props.currentForm === "transaction") {
      try {
        const response = await TransactionCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          typeOfBenefitStatus: remodify(props.formValues?.typeOfBenefitStatus),
          appStatus: "",
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });
        navigate(`/reports/generate-transaction`, {
          state: response?.data,
        });
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };

  const updateForm = async () => {
    if (props.currentForm === "pending-eligibility") {
      try {
        const response = await PendingEligibilityUpdate.mutateAsync({
          id: props.formValues.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            insuranceHierarchy: remodify(props.formValues?.insuranceHierarchy),
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            insuranceStatus: remodify(props.formValues.insuranceStatus),
            lastEligibility: remodify(
              props.formValues.daysSinceLastEligibility
            ),
            daysGreaterThan: props.formValues?.daysGreaterThan,
            insuranceType: remodify(props.formValues?.insuranceType),
            columns: remodify(props.formValues?.column),
            payer: remodify(props.formValues?.payer),
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        navigate(`/reports/generate-pending-eligibility`, {
          state: response?.data,
        });
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else if (props.currentForm === "new-patient") {
      try {
        const response = await NewPatientUpdate.mutateAsync({
          id: props.formValues?.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            appointmentDate: props.formValues?.appointmentDate,
            toDate: props.formValues?.toDate,
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            columns: remodify(props.formValues?.columns),
            isFavorite: props.formValues?.isFavorite,
            isSave: props.formValues?.isSaveFilter,
          },
        });
        navigate(`/reports/generate-new-patient`, {
          state: response?.data,
        });
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else if (props.currentForm === "transaction") {
      try {
        const response = await TransactionUpdate.mutateAsync({
          id: props.formValues?.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            patientType: remodify(props.formValues?.patientType),
            typeOfBenefitStatus: remodify(
              props.formValues?.typeOfBenefitStatus
            ),
            appStatus: "",
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        navigate(`/reports/generate-transaction`, {
          state: response?.data,
        });
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };

  const handlePendingEligibityPdf = async () => {
    if (
      props.currentForm === "pending-eligibility" &&
      props.selectedOption === "new"
    ) {
      try {
        const response = await PendingEligibilityCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          toDate: props.formValues?.toDate,
          insuranceHierarchy: remodify(props.formValues?.insuranceHierarchy),
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          insuranceStatus: remodify(props.formValues.insuranceStatus),
          lastEligibility: remodify(props.formValues.daysSinceLastEligibility),
          daysGreaterThan: props.formValues?.daysGreaterThan,
          insuranceType: remodify(props.formValues?.insuranceType),
          columns: remodify(props.formValues?.column),
          payer: remodify(props.formValues?.payer),
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });
        const bufferData = new Uint8Array(response.data.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else {
      try {
        const response = await PendingEligibilityUpdate.mutateAsync({
          id: props.formValues.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            insuranceHierarchy: remodify(props.formValues?.insuranceHierarchy),
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            insuranceStatus: remodify(props.formValues.insuranceStatus),
            lastEligibility: remodify(
              props.formValues.daysSinceLastEligibility
            ),
            daysGreaterThan: props.formValues?.daysGreaterThan,
            insuranceType: remodify(props.formValues?.insuranceType),
            columns: remodify(props.formValues?.column),
            payer: remodify(props.formValues?.payer),
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        const bufferData = new Uint8Array(response.data.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };
  const handleNewPatientPdf = async () => {
    if (props.currentForm === "new-patient" && props.selectedOption === "new") {
      try {
        const response = await NewPatientsCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          appointmentDate: props.formValues?.appointmentDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          columns: remodify(props.formValues?.columns),
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });
        const bufferData = new Uint8Array(response.data.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else {
      try {
        const response = await NewPatientUpdate.mutateAsync({
          id: props.formValues?.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            appointmentDate: props.formValues?.appointmentDate,
            toDate: props.formValues?.toDate,
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            columns: remodify(props.formValues?.columns),
            isFavorite: props.formValues?.isFavorite,
            isSave: props.formValues?.isSaveFilter,
          },
        });
        const bufferData = new Uint8Array(response.data.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };
  const handleTransactionPdf = async () => {
    if (props.currentForm === "transaction" && props.selectedOption === "new") {
      try {
        const response = await TransactionCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          typeOfBenefitStatus: remodify(props.formValues?.typeOfBenefitStatus),
          appStatus: "",
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });

        const bufferData = new Uint8Array(response.data.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else {
      try {
        const response = await TransactionUpdate.mutateAsync({
          id: props.formValues?.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            patientType: remodify(props.formValues?.patientType),
            typeOfBenefitStatus: remodify(
              props.formValues?.typeOfBenefitStatus
            ),
            appStatus: "",
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        const bufferData = new Uint8Array(response.data.pdf.data);
        const blob = await new Blob([bufferData], {
          type: "application/pdf",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "bulk_pdf.pdf";

        a.click();

        window.URL.revokeObjectURL(url);

        toast.success("Pdf downloaded successfully");
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };
  const handleTransactionCsv = async () => {
    if (props.currentForm === "transaction" && props.selectedOption === "new") {
      try {
        const response = await TransactionCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          typeOfBenefitStatus: remodify(props.formValues?.typeOfBenefitStatus),
          appStatus: "",
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });

        const rows = response.data.patientDetails.map((cell: any) => ({
          "Patient Id": cell.patientId,
          "Patient Name": cell.firstName + " " + cell.lastName,
          "Type Of Service": cell.typeOfService,
          "Practice Name & Location": cell.practiceNameAndLoc,
          "Appointment Type": cell.appointmentType,
          "Insurance Name/Plan":
            cell.providerFirstName + " " + cell.providerLastName,
          Appointment: cell.scheduleAppointment
            ? dateTimeFormat(new Date(cell.scheduleAppointment))
            : null,
          "Last Verified": cell.lastVerified
            ? dateTimeFormat(new Date(cell.lastVerified))
            : null,
          Status: cell.insuranceStatus,
          "Insurance Payer Code": cell.payerIdCode,
          Speciality: cell.speciality,
          "Date Of Birth": cell.dateOfBirth
            ? dateTimeFormat(new Date(cell.dateOfBirth))
            : null,
          "Subscriber ID": cell.subscriberId,
          "Appointment Rendering Provider": cell.appointmentRenderingProvider,
        }));

        // Define the column headers
        const columnHeaders = {
          "Patient Id": "",
          "Patient Name": "",
          "Type Of Service": "",
          "Practice Name & Location": "",
          "Appointment Type": "",
          "Insurance Name/Plan": "",
          Appointment: "",
          "Last Verified": "",
          Status: "",
          "Insurance Payer Code": "",
          Speciality: "",
          "Date Of Birth": "",
          "Subscriber ID": "",
          "Appointment Rendering Provider": "",
        };

        // If rows are empty, add an empty row to ensure headers are included
        if (rows.length === 0) {
          rows.push(columnHeaders);
        }

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, worksheet, "data");
        XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else {
      try {
        const response = await TransactionUpdate.mutateAsync({
          id: props.formValues?.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            patientType: remodify(props.formValues?.patientType),
            typeOfBenefitStatus: remodify(
              props.formValues?.typeOfBenefitStatus
            ),
            appStatus: "",
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        const rows = response.data.patientDetails.map((cell: any) => ({
          "Patient Id": cell.patientId,
          "Patient Name": cell.firstName + " " + cell.lastName,
          "Type Of Service": cell.typeOfService,
          "Practice Name & Location": cell.practiceNameAndLoc,
          "Appointment Type": cell.appointmentType,
          "Insurance Name/Plan":
            cell.providerFirstName + " " + cell.providerLastName,
          Appointment: cell.scheduleAppointment
            ? dateTimeFormat(new Date(cell.scheduleAppointment))
            : null,
          "Last Verified": cell.lastVerified
            ? dateTimeFormat(new Date(cell.lastVerified))
            : null,
          Status: cell.insuranceStatus,
          "Insurance Payer Code": cell.payerIdCode,
          Speciality: cell.speciality,
          "Date Of Birth": cell.dateOfBirth
            ? dateTimeFormat(new Date(cell.dateOfBirth))
            : null,
          "Subscriber ID": cell.subscriberId,
          "Appointment Rendering Provider": cell.appointmentRenderingProvider,
        }));

        // Define the column headers
        const columnHeaders = {
          "Patient Id": "",
          "Patient Name": "",
          "Type Of Service": "",
          "Practice Name & Location": "",
          "Appointment Type": "",
          "Insurance Name/Plan": "",
          Appointment: "",
          "Last Verified": "",
          Status: "",
          "Insurance Payer Code": "",
          Speciality: "",
          "Date Of Birth": "",
          "Subscriber ID": "",
          "Appointment Rendering Provider": "",
        };

        // If rows are empty, add an empty row to ensure headers are included
        if (rows.length === 0) {
          rows.push(columnHeaders);
        }

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, worksheet, "data");
        XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };
  const handlePendingEligibilityCsv = async () => {
    if (
      props.currentForm === "pending-eligibility" &&
      props.selectedOption === "new"
    ) {
      try {
        const response = await TransactionCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          typeOfBenefitStatus: remodify(props.formValues?.typeOfBenefitStatus),
          appStatus: "",
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });

        const rows = response.data.patientDetails.map((cell: any) => ({
          "Patient Id": cell.patientId,
          "Patient Name": cell.firstName + " " + cell.lastName,
          "Type Of Service": cell.typeOfService,
          "Practice Name & Location": cell.practiceNameAndLoc,
          "Appointment Type": cell.appointmentType,
          "Insurance Name/Plan":
            cell.providerFirstName + " " + cell.providerLastName,
          Appointment: cell.scheduleAppointment
            ? dateTimeFormat(new Date(cell.scheduleAppointment))
            : null,
          "Last Verified": cell.lastVerified
            ? dateTimeFormat(new Date(cell.lastVerified))
            : null,
          Status: cell.insuranceStatus,
          "Insurance Payer Code": cell.payerIdCode,
          Speciality: cell.speciality,
          "Date Of Birth": cell.dateOfBirth
            ? dateTimeFormat(new Date(cell.dateOfBirth))
            : null,
          "Subscriber ID": cell.subscriberId,
          "Appointment Rendering Provider": cell.appointmentRenderingProvider,
        }));

        // Define the column headers
        const columnHeaders = {
          "Patient Id": "",
          "Patient Name": "",
          "Type Of Service": "",
          "Practice Name & Location": "",
          "Appointment Type": "",
          "Insurance Name/Plan": "",
          Appointment: "",
          "Last Verified": "",
          Status: "",
          "Insurance Payer Code": "",
          Speciality: "",
          "Date Of Birth": "",
          "Subscriber ID": "",
          "Appointment Rendering Provider": "",
        };

        // If rows are empty, add an empty row to ensure headers are included
        if (rows.length === 0) {
          rows.push(columnHeaders);
        }

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, worksheet, "data");
        XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else {
      try {
        const response = await PendingEligibilityUpdate.mutateAsync({
          id: props.formValues.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            insuranceHierarchy: remodify(props.formValues?.insuranceHierarchy),
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            insuranceStatus: remodify(props.formValues.insuranceStatus),
            lastEligibility: remodify(
              props.formValues.daysSinceLastEligibility
            ),
            daysGreaterThan: props.formValues?.daysGreaterThan,
            insuranceType: remodify(props.formValues?.insuranceType),
            columns: remodify(props.formValues?.column),
            payer: remodify(props.formValues?.payer),
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        const rows = response.data.patientDetails.map((cell: any) => ({
          "Patient Id": cell.patientId,
          "Patient Name": cell.firstName + " " + cell.lastName,
          "Type Of Service": cell.typeOfService,
          "Practice Name & Location": cell.practiceNameAndLoc,
          "Appointment Type": cell.appointmentType,
          "Insurance Name/Plan":
            cell.providerFirstName + " " + cell.providerLastName,
          Appointment: cell.scheduleAppointment
            ? dateTimeFormat(new Date(cell.scheduleAppointment))
            : null,
          "Last Verified": cell.lastVerified
            ? dateTimeFormat(new Date(cell.lastVerified))
            : null,
          Status: cell.insuranceStatus,
          "Insurance Payer Code": cell.payerIdCode,
          Speciality: cell.speciality,
          "Date Of Birth": cell.dateOfBirth
            ? dateTimeFormat(new Date(cell.dateOfBirth))
            : null,
          "Subscriber ID": cell.subscriberId,
          "Appointment Rendering Provider": cell.appointmentRenderingProvider,
        }));

        // Define the column headers
        const columnHeaders = {
          "Patient Id": "",
          "Patient Name": "",
          "Type Of Service": "",
          "Practice Name & Location": "",
          "Appointment Type": "",
          "Insurance Name/Plan": "",
          Appointment: "",
          "Last Verified": "",
          Status: "",
          "Insurance Payer Code": "",
          Speciality: "",
          "Date Of Birth": "",
          "Subscriber ID": "",
          "Appointment Rendering Provider": "",
        };

        // If rows are empty, add an empty row to ensure headers are included
        if (rows.length === 0) {
          rows.push(columnHeaders);
        }

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, worksheet, "data");
        XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };

  const handleNewPatientCsv = async () => {
    if (props.currentForm === "transaction" && props.selectedOption === "new") {
      try {
        const response = await NewPatientsCreate.mutateAsync({
          filterName: props.formValues?.filterName,
          fromDate: props.formValues?.fromDate,
          appointmentDate: props.formValues?.appointmentDate,
          toDate: props.formValues?.toDate,
          location: remodify(props.formValues?.location),
          patients: remodify(props.formValues?.patients),
          provider: remodify(props.formValues?.provider),
          patientType: remodify(props.formValues?.patientType),
          columns: remodify(props.formValues?.columns),
          isFavorite: props.formValues.isFavorite,
          isSave: props.formValues.isSaveFilter,
        });

        const rows = response.data.patientDetails.map((cell: any) => ({
          "Patient Id": cell.patientId,
          "Patient Name": cell.firstName + " " + cell.lastName,
          "Type Of Service": cell.typeOfService,
          "Practice Name & Location": cell.practiceNameAndLoc,
          "Appointment Type": cell.appointmentType,
          "Insurance Name/Plan":
            cell.providerFirstName + " " + cell.providerLastName,
          Appointment: cell.scheduleAppointment
            ? dateTimeFormat(new Date(cell.scheduleAppointment))
            : null,
          "Last Verified": cell.lastVerified
            ? dateTimeFormat(new Date(cell.lastVerified))
            : null,
          Status: cell.insuranceStatus,
          "Insurance Payer Code": cell.payerIdCode,
          Speciality: cell.speciality,
          "Date Of Birth": cell.dateOfBirth
            ? dateTimeFormat(new Date(cell.dateOfBirth))
            : null,
          "Subscriber ID": cell.subscriberId,
          "Appointment Rendering Provider": cell.appointmentRenderingProvider,
        }));

        // Define the column headers
        const columnHeaders = {
          "Patient Id": "",
          "Patient Name": "",
          "Type Of Service": "",
          "Practice Name & Location": "",
          "Appointment Type": "",
          "Insurance Name/Plan": "",
          Appointment: "",
          "Last Verified": "",
          Status: "",
          "Insurance Payer Code": "",
          Speciality: "",
          "Date Of Birth": "",
          "Subscriber ID": "",
          "Appointment Rendering Provider": "",
        };

        // If rows are empty, add an empty row to ensure headers are included
        if (rows.length === 0) {
          rows.push(columnHeaders);
        }

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, worksheet, "data");
        XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      } catch (error) {
        console.log(error);
      }
      toggle();
    } else {
      try {
        const response = await PendingEligibilityUpdate.mutateAsync({
          id: props.formValues.filterId,
          data: {
            filterName: props.formValues?.filterName,
            fromDate: props.formValues?.fromDate,
            toDate: props.formValues?.toDate,
            insuranceHierarchy: remodify(props.formValues?.insuranceHierarchy),
            location: remodify(props.formValues?.location),
            patients: remodify(props.formValues?.patients),
            provider: remodify(props.formValues?.provider),
            insuranceStatus: remodify(props.formValues.insuranceStatus),
            lastEligibility: remodify(
              props.formValues.daysSinceLastEligibility
            ),
            daysGreaterThan: props.formValues?.daysGreaterThan,
            insuranceType: remodify(props.formValues?.insuranceType),
            columns: remodify(props.formValues?.column),
            payer: remodify(props.formValues?.payer),
            isFavorite: props.formValues.isFavorite,
            isSave: props.formValues.isSaveFilter,
          },
        });
        const rows = response.data.patientDetails.map((cell: any) => ({
          "Patient Id": cell.patientId,
          "Patient Name": cell.firstName + " " + cell.lastName,
          "Type Of Service": cell.typeOfService,
          "Practice Name & Location": cell.practiceNameAndLoc,
          "Appointment Type": cell.appointmentType,
          "Insurance Name/Plan":
            cell.providerFirstName + " " + cell.providerLastName,
          Appointment: cell.scheduleAppointment
            ? dateTimeFormat(new Date(cell.scheduleAppointment))
            : null,
          "Last Verified": cell.lastVerified
            ? dateTimeFormat(new Date(cell.lastVerified))
            : null,
          Status: cell.insuranceStatus,
          "Insurance Payer Code": cell.payerIdCode,
          Speciality: cell.speciality,
          "Date Of Birth": cell.dateOfBirth
            ? dateTimeFormat(new Date(cell.dateOfBirth))
            : null,
          "Subscriber ID": cell.subscriberId,
          "Appointment Rendering Provider": cell.appointmentRenderingProvider,
        }));

        // Define the column headers
        const columnHeaders = {
          "Patient Id": "",
          "Patient Name": "",
          "Type Of Service": "",
          "Practice Name & Location": "",
          "Appointment Type": "",
          "Insurance Name/Plan": "",
          Appointment: "",
          "Last Verified": "",
          Status: "",
          "Insurance Payer Code": "",
          Speciality: "",
          "Date Of Birth": "",
          "Subscriber ID": "",
          "Appointment Rendering Provider": "",
        };

        // If rows are empty, add an empty row to ensure headers are included
        if (rows.length === 0) {
          rows.push(columnHeaders);
        }

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, worksheet, "data");
        XLSX.writeFile(workBook, "data.csv", { bookType: "csv" });
      } catch (error) {
        console.log(error);
      }
      toggle();
    }
  };
  return (
    <>
      <Modal
        isOpen={props.saveConfirmationOpen}
        toggle={toggle}
        backdrop
        keyboard
        size="md"
        centered
      >
        <ModalHeader toggle={toggle}>
          <div className="title">Filter Criteria</div>{" "}
        </ModalHeader>

        <ModalBody className="modal_body f-13">
          {props?.selectedOption === "existing" && (
            <Row className="mt-2 mb-4">
              <Col xs={12} md={5}>
                <Label check>
                  <Input
                    type="radio"
                    name="new"
                    value="createNew"
                    checked={selectedRadioOption === "createNew"}
                    onChange={(e) => {
                      setSelectedRadioOption(e.target.value);
                      props.setFormValues({
                        ...props.formValues,
                        filterName: "",
                      });
                    }}
                  />{" "}
                  <span className="ms-2 fs-6 fw-normal">Create New Filter</span>
                </Label>
              </Col>
              <Col xs={12} md={6}>
                <Label check>
                  <Input
                    type="radio"
                    name="new"
                    value="existingName"
                    checked={selectedRadioOption === "existingName"}
                    onChange={(e) => {
                      setSelectedRadioOption(e.target.value);
                    }}
                  />
                  <span className="ms-2 fs-6 fw-normal">
                    Update Existing Filter
                  </span>
                </Label>
              </Col>
            </Row>
          )}
          <Row>
            <Col md={12}>
              <Label className="modal_form">Filter Name</Label>
              <Input
                type="text"
                placeholder="Test Report"
                value={props.formValues?.filterName}
                onChange={(event: any) =>
                  props.setFormValues({
                    ...props.formValues,
                    filterName: event.target.value,
                  })
                }
              ></Input>
            </Col>
          </Row>

          <div className="mt-3">
            <input
              type="checkbox"
              onClick={() =>
                props.setFormValues({
                  ...props.formValues,
                  isFavorite: !props.formValues.isFavorite,
                })
              }
              checked={props.formValues?.isFavorite}
            ></input>
            <span className="fs-6"> Mark Filter as Favorite</span>
          </div>
        </ModalBody>

        <ModalFooter>
          <Button
            className="cancelmodal"
            color="primary"
            outline
            onClick={toggle}
          >
            Cancel
          </Button>{" "}
          {props?.buttonClicked === "generate" ? (
            <Button
              outline
              color="primary"
              onClick={() => {
                props.selectedOption === "new" ? submitForm() : updateForm();
              }}
            >
              Save & Generate Report
            </Button>
          ) : (
            <UncontrolledDropdown>
              <DropdownToggle data-toggle="dropdown" tag="span">
                <Button outline color="primary">
                  Save & Download Report
                  <FontAwesomeIcon icon={faChevronDown} />
                </Button>
              </DropdownToggle>

              <DropdownMenu className="mt-3">
                <DropdownItem
                  onClick={
                    props.currentForm === "pending-eligibility"
                      ? handlePendingEligibityPdf
                      : props.currentForm === "new-patient"
                      ? handleNewPatientPdf
                      : handleTransactionPdf
                  }
                >
                  PDF
                </DropdownItem>

                <DropdownItem
                  onClick={
                    props.currentForm === "pending-eligibility"
                      ? handlePendingEligibilityCsv
                      : props.currentForm === "new-patient"
                      ? handleNewPatientCsv
                      : handleTransactionCsv
                  }
                >
                  CSV
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          )}
        </ModalFooter>
      </Modal>
    </>
  );
};

export default SaveConfirmation;
