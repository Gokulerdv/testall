import {

  Col,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
} from "reactstrap";
import { Formik, Form } from "formik";
import { useField } from "formik";

import { useEffect, useState } from "react";


type Role = {
  roleId: string;
  roleName: string;
  roleType: string;
  adminId: string;
  practiceId: string;
  permissions: string[];
  status: null | string;
  createdAt: string;
  updatedAt: string;
  products: any[];
};

type Location = {
  locationId: string;
  locationName: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  state: string;
  zipcode: string;
  status: boolean;
  createdAt: string;
  updatedAt: string;
  practiceId: string;
  role: Role;
};

type Practice = {
  practiceId: string;
  locations: Location[];
};

type User = {
  userId: string;
  userName: string;
  userType: null | string;
  email: string;
  phoneNumber: string;
  adminId: string;
  status: null | string;
  createdAt: string;
  updatedAt: string;
  practice: Practice;
};

const FormInput = ({
  id,
  label,
  placeholder,
  name,
  readonly,
}: {
  id: string;
  label: string;
  placeholder: string;
  name: string;
  readonly?: boolean;
}) => {
  const [field, meta] = useField(name);

  return (
    <Col md={4}>
      <FormGroup>
        <Label for={id}>{label}</Label>
        <Input
          {...field}
          type="text"
          id={id}
          placeholder={placeholder}
          className="flex-grow-1 formstyle"
          disabled={!readonly}
        />
        {meta.touched && meta.error ? (
          <div className="error">{meta.error}</div>
        ) : null}
      </FormGroup>
    </Col>
  );
};

const FormRow = ({ children }: { children: React.ReactNode }) => (
  <Row className="formstyle">{children}</Row>
);

const BasicDetails: React.FC<{
  user: User | null;
}> = ({ user }) => {

  const [userRoles, setUserRoles] = useState<Role | null>(null);

  const [showPopup, setShowPopup] = useState(false);


  useEffect(() => {
    const fetchRoles = user?.practice?.locations[0]?.role ?? null;
    setUserRoles(fetchRoles);
  }, [user])

  return (
    <div className="p-6 bg-white rounded-lg add-user-form">
      <div className="">
        {user && userRoles !== null ? (
          <Formik
            initialValues={{
              username: user?.userName || "",
              userid: user?.userId || "",
              email: user?.email || "",
              phoneNumber: user?.phoneNumber || "",
              role: user?.practice?.locations[0].role.roleName || "",
              city: user?.practice?.locations[0].city,
              state: user?.practice?.locations[0].state,
              address: user?.practice?.locations[0].address,
              locationName: user?.practice?.locations[0].locationName,
              zipcode: user?.practice?.locations[0].zipcode,
              practiceId: user?.practice.practiceId || "",
              ...user.practice.locations.reduce(
                (acc, location, index) => ({
                  ...acc,
                  [`locationName${index}`]: location.locationName,
                  [`userRole${index}`]: location.role.roleName,
                }),
                {}
              ),

            }}
            onSubmit={() => { }}

          >
            {() => (
              <>
                <Form>
                  <div
                    className={"page-header page-header-bg practiceTab-form "}
                  >
                    <span className="mb-0">Users</span>

                  </div>
                  <div className="practice-tab">
                    <h2 className="section-head my-3">Basic Details</h2>
                    <FormRow>
                      <FormInput
                        id="username"
                        label="User Name"
                        name="username"
                        placeholder="Enter User Name"
                        readonly={false}
                      />
                      <FormInput
                        id="userid"
                        label="User ID"
                        placeholder="Enter User ID"
                        name="userid"
                        readonly={false}
                      />
                    </FormRow>
                    <FormRow>
                      <FormInput
                        id="email"
                        label="Official Email ID"
                        placeholder="Enter Email"
                        name="email"
                        readonly={false}
                      />
                      <FormInput
                        id="phoneNumber"
                        label="Phone Number"
                        placeholder="Enter Phone Number"
                        name="phoneNumber"
                        readonly={false}
                      />
                    </FormRow>
                    {
                      user?.practice?.locations.length > 0 &&
                      user?.practice?.locations.map((location) => (
                        <FormGroup key={location.locationId}>
                          <FormRow>

                            <FormInput

                              id="locationName"
                              label="location Name"
                              placeholder="Enter Phone Number"
                              name="locationName"
                              readonly={false}
                            />


                            <FormInput
                              id="role"
                              label="User Role"
                              placeholder="Enter role Name"
                              name="role"
                              readonly={false}
                            />

                          </FormRow>
                        </FormGroup>
                      ))}


                    <h2 className="section-head py-2">Practice Details</h2>
                    <FormRow>
                      <FormInput
                        id="practiceId"
                        label="Practice ID"
                        placeholder="Enter Practice ID"
                        name="practiceId"
                        readonly={false}
                      />
                    </FormRow>
                    <FormRow>
                      <FormInput
                        id="city"
                        label="City"
                        placeholder="Enter City"
                        name="city"
                        readonly={false}
                      />
                      <FormInput
                        id="state"
                        label="State"
                        placeholder="Enter State"
                        name="state"
                        readonly={false}
                      />
                    </FormRow>
                    <FormRow>
                      <FormInput
                        id="zipcode"
                        label="Zipcode"
                        placeholder="Enter Zipcode"
                        name="zipcode"
                        readonly={false}
                      />
                      <FormInput
                        id="address"
                        label="Address"
                        placeholder="Enter Address"
                        name="address"
                        readonly={false}
                      />
                    </FormRow>
                  </div>
                </Form>
                <Modal isOpen={showPopup} toggle={() => setShowPopup(false)}>
                  <ModalHeader toggle={() => setShowPopup(false)}>
                    Location Not Found
                  </ModalHeader>
                  <ModalBody>
                    The location you are trying to add is not found. Please
                    check and try again.
                  </ModalBody>
                </Modal>
              </>
            )}
          </Formik>
        ) : null}
      </div>
    </div>
  );
};

export default BasicDetails;
