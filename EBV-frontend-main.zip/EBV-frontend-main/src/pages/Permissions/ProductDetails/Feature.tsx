import React from "react";
const Feature: React.FC<{
  data: Feature[];
  permission: string[] | undefined;
}> = ({ data, permission }) => {

  return (
    <div className="pl-5">
      {data.map((item, itemIndex) => {
        const filteredPermissions = permission
          ? (item?.feature_name, permission ?? [""])
          : item?.permissions;

        return (
          <div
            key={`feature-${item.feature_name}-${itemIndex}`}
            className="row"
          >
            <div className="col-3 feature-container ">
              <p className="label mb-0"> Feature </p>
              <p className="value "> {item?.feature_name} </p>
            </div>
            <div className="col-9">
              <p className="label mb-0 permission-label "> Permissions </p>
              {filteredPermissions?.map((i, index, permissionsArray) => (
                <>
                  <span
                    className="permission d-inline-block "
                    style={{ paddingRight: "5px" }}
                  >
                    {i}
                  </span>
                  {index < permissionsArray.length - 1 ? ", " : ""}
                </>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Feature;
