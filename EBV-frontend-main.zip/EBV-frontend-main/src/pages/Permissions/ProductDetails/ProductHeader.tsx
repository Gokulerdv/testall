import { faHandshake } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";

const ProductHeader: React.FC<{ title: string }> = ({ title }) => {
  return (
    <div className="prod-accordian-header">
      <input type="checkbox" name="" id="" checked />
      <FontAwesomeIcon icon={faHandshake} color="#E18922" />
      {title.toLocaleUpperCase()}
    </div>
  );
};

export default ProductHeader;
