import React, { useEffect, useState } from "react";
import {
  UncontrolledAccordion,
  AccordionBody,
  AccordionHeader,
  AccordionItem,
  Spinner,
} from "reactstrap";
import ProductHeader from "./ProductHeader";
import Modules from "./Modules";


type Role = {
  roleId: string;
  roleName: string;
  roleType: string;
  adminId: string;
  practiceId: string;
  permissions: string[];
  status: null | string;
  createdAt: string;
  updatedAt: string;
  products: any[];
};

type Location = {
  locationId: string;
  locationName: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  state: string;
  zipcode: string;
  status: boolean;
  createdAt: string;
  updatedAt: string;
  practiceId: string;
  role: Role;
};

type Practice = {
  practiceId: string;
  locations: Location[];
};

type User = {
  userId: string;
  userName: string;
  userType: null | string;
  email: string;
  phoneNumber: string;
  adminId: string;
  status: null | string;
  createdAt: string;
  updatedAt: string;
  practice: Practice;
};
const ProductDetailV2: React.FC<{
  roleId: string;
  user: User;
  config?: {
    type: string;
    component: {
      header: JSX.Element;
      body: JSX.Element;
    };
  };
}> = ({ roleId, user }) => {
  const [productDetails, setProductDetails] = useState<{
    productDetails: ProductDetail[];
  }>();

  useEffect(() => {
    const productDetails = user?.practice?.locations[0]?.role?.products;
    setProductDetails({ productDetails: productDetails });
  }, [user])



  return (
    <>
      {!roleId ? (
        <div className="text-center">
          <Spinner />
        </div>
      ) : (
        <UncontrolledAccordion toggle={() => { }} defaultOpen={["0"]} stayOpen>
          {
            (productDetails && productDetails?.productDetails?.length !== 0) ? (
              productDetails?.productDetails?.map((product, index) => (
                <AccordionItem key={index} className="my-3 border">
                  <AccordionHeader
                    className="prod-detail-accordian"
                    targetId={`${index}`}
                  >

                    <ProductHeader title={product.product_name} />

                  </AccordionHeader>
                  <AccordionBody accordionId={`${index}`}>

                    <Modules
                      data={product.modules}
                    />
                  </AccordionBody>
                </AccordionItem>
              ))
            ) : (
              <p className="text-center">No Product Details found</p>
            )}
        </UncontrolledAccordion>
      )}
    </>
  );
};

export default ProductDetailV2;
