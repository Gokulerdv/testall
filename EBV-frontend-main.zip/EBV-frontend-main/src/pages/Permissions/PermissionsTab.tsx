import React from "react";

import PageHeader from "../../components/PageHeader";
import ProductDetailV2 from "./ProductDetails/ProductDetailV2";

const PermissionsTab: React.FC<{ roleId: string, user: any }> = ({ roleId, user }) => {


  return (
    <>
      <PageHeader title="Permissions" />
      {roleId !== "" ? (
        <div className="user-tab">
          <ProductDetailV2 roleId={roleId} user={user} />
        </div>
      ) : (
        <p className="text-center py-5 border ">Role id not found</p>
      )}
    </>
  );
};

export default PermissionsTab;
