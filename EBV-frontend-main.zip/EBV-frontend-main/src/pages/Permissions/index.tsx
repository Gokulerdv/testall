import { useState } from "react";

import PermissionsTab from "./PermissionsTab";

import PracticeTab from "./BasicDetails";

import { Spinner } from "reactstrap";
import { PermissionSidebar } from "./PermissionSidebar";


const Permissions = () => {
  const [tabName, setTabName] = useState("basicDetails");



  const userDetails = JSON.parse(localStorage.getItem("auth") ?? "").userData;

  const modules = [
    {
      id: 1,
      label: "Basic Details",
      active: tabName === "basicDetails",
      value: "basicDetails",
    },
    {
      id: 2,
      label: "Product & Permissions",
      active: tabName === "permissions",
      value: "permissions",
    },
  ];

  const toggleTabs = (tabName: string) => {
    setTabName(tabName);
  };

  return userDetails ? (
    <>
      <div className="practice-wrapper d-flex ">
        <div className="first-container">
          <PermissionSidebar
            modules={modules}
            user={userDetails}
            toggleTabs={toggleTabs}
          />
        </div>

        <div className="second-container p-3">
          {tabName === "basicDetails" ? (
            <PracticeTab user={userDetails} />
          ) : null}
          {tabName === "permissions" ? (
            <PermissionsTab
              roleId={userDetails?.practice?.locations[0]?.role?.roleId}
              user={userDetails}
            />
          ) : null}
        </div>
      </div>
    </>
  ) : (
    <Spinner />
  );
};

export default Permissions;
