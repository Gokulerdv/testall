import { FormControl, ListItemText } from "@mui/material";
import Autocomplete from "@mui/material/Autocomplete";
import Checkbox from "@mui/material/Checkbox";
import TextField from "@mui/material/TextField";
import * as React from "react";

const names = [
  "A Oliver Hansen",
  "Van Henry",
  "April Tucker",
  "Ralph Hubbard",
  "Omar Alexander",
  "Carlos Abbott",
  "Miriam Wagner",
  "Bradley Wilkerson",
  "Virginia Andrews",
  "Kelly Snyder",
];

export default function MultipleSelectCheckmarks() {
  const [personName, setPersonName] = React.useState<string[]>([]);

  const handleChange = (_event: React.SyntheticEvent, value: string[]) => {
    setPersonName(value);
  };

  return (
    <div>
      <FormControl sx={{ m: 1, width: 300 }}>
        <Autocomplete
          multiple
          id="tags-outlined"
          options={names}
          value={personName}
          onChange={handleChange}
          renderInput={(params) => (
            <TextField
              {...params}
              variant="outlined"
              label="Tag"
              placeholder="Search..."
            />
          )}
          renderOption={(props, option, { selected }) => (
            <li {...props}>
              <Checkbox checked={selected} />
              <ListItemText primary={option} />
            </li>
          )}
          isOptionEqualToValue={(option, value) => option === value}
        />
      </FormControl>
    </div>
  );
}
