import { faCircleCheck, faHeart } from "@fortawesome/free-regular-svg-icons";
import {
  faCircleInfo,
  faSquarePollVertical,
  faUsers,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Dialog, DialogContent, Stack } from "@mui/material";
import React from "react";
import { Button, Card, CardBody, Col, Container, Row } from "reactstrap";

export const Faq = () => {
  const iframeRef = React.useRef<HTMLIFrameElement>(null);
  const [open, setOpen] = React.useState(false);
  const handleChatModal = () => {
    setOpen(!open);
  };

  return (
    <div style={{ background: "#F9FAFB" }}>
      <Container>
        <Stack gap={2}>
          <Card className="border border-0">
            <CardBody>
              <Stack className="text-center" gap={3}>
                <Stack className="text-primary fs-6">FAQs</Stack>
                <Stack className="fs-3">Ask us anything</Stack>
                <Stack className="fs-5 text-secondary">
                  Need something cleared up? Here are our most frequently asked
                  questions
                </Stack>
                <Stack alignItems="center">
                  <Stack style={{ position: "relative", maxWidth: "25rem" }}>
                    {/* <FontAwesomeIcon
                      icon={faSearch}
                      style={{
                        position: "absolute",
                        left: "10px",
                        top: "50%",
                        transform: "translateY(-50%)",
                        color: "#aaa", // Change color as needed
                      }}
                    /> */}
                    {/* <Input
                      id="exampleEmail"
                      placeholder="search"
                      type="search"
                      style={{
                        maxWidth: "25rem",
                        paddingLeft: "30px", // Adjust padding to make space for the icon
                        boxSizing: "border-box",
                      }}
                    /> */}
                  </Stack>
                </Stack>
              </Stack>
            </CardBody>
          </Card>

          <Row style={{ background: "#F9FAFB" }}>
            <Col xs={4}>
              <Card
                className="border border-0"
                style={{ background: "#F9FAFB" }}
              >
                <CardBody>
                  <Stack gap={2} alignItems="start">
                    <Stack>
                      <div>
                        {" "}
                        <FontAwesomeIcon
                          className="border rounded-circle text-primary "
                          style={{
                            width: 20,
                            height: 20,
                            background: "#F4EBFF",
                            padding: 15,
                          }}
                          icon={faHeart}
                        />
                      </div>
                    </Stack>
                    <Stack className="fs-5">
                      What is Eligibility Benefits Verification?
                    </Stack>
                    <Stack>
                      <p className="text-secondary">
                        Eligibility Benefits Verification is a process through
                        which dental providers verify a patient's insurance
                        coverage and benefits before providing treatment. It
                        ensures that patients are aware of their coverage and
                        potential out-of-pocket expenses.
                      </p>
                    </Stack>
                  </Stack>
                </CardBody>
              </Card>
            </Col>
            <Col xs={4}>
              <Card
                className="border border-0"
                style={{ background: "#F9FAFB" }}
              >
                <CardBody>
                  <Stack gap={2} alignItems="start">
                    <Stack>
                      <div>
                        {" "}
                        <FontAwesomeIcon
                          className="border rounded-circle text-primary "
                          style={{
                            width: 20,
                            height: 20,
                            background: "#F4EBFF",
                            padding: 15,
                          }}
                          icon={faUsers}
                        />
                      </div>
                    </Stack>
                    <Stack className="fs-5">
                      Why is Eligibility Benefits Verification important for
                      dental patients?
                    </Stack>
                    <Stack>
                      <p className="text-secondary">
                        Eligibility Benefits Verification helps patients
                        understand their insurance coverage, including
                        deductibles, copayments, and limitations, allowing them
                        to make informed decisions about their dental care and
                        finances.
                      </p>
                    </Stack>
                  </Stack>
                </CardBody>
              </Card>
            </Col>
            <Col xs={4}>
              <Card
                className="border border-0"
                style={{ background: "#F9FAFB" }}
              >
                <CardBody>
                  <Stack gap={2} alignItems="start">
                    <Stack>
                      <div>
                        {" "}
                        <FontAwesomeIcon
                          className="border rounded-circle text-primary "
                          style={{
                            width: 20,
                            height: 20,
                            background: "#F4EBFF",
                            padding: 15,
                          }}
                          icon={faCircleCheck}
                        />
                      </div>
                    </Stack>
                    <Stack className="fs-5">
                      How does the Eligibility Benefits Verification process
                      work?
                    </Stack>
                    <Stack>
                      <p className="text-secondary">
                        Dental providers submit patient information to the web
                        application, which then communicates with insurance
                        companies to retrieve details about the patient's
                        coverage and benefits. The application then presents
                        this information to the provider and patient.
                      </p>
                    </Stack>
                  </Stack>
                </CardBody>
              </Card>
            </Col>
            <Col xs={4}>
              <Card
                className="border border-0"
                style={{ background: "#F9FAFB" }}
              >
                <CardBody>
                  <Stack gap={2} alignItems="start">
                    <Stack>
                      <div>
                        {" "}
                        <FontAwesomeIcon
                          className="border rounded-circle text-primary "
                          style={{
                            width: 20,
                            height: 20,
                            background: "#F4EBFF",
                            padding: 15,
                          }}
                          icon={faCircleInfo}
                        />
                      </div>
                    </Stack>
                    <Stack className="fs-5">
                      What information do I need to provide for Eligibility
                      Benefits Verification?
                    </Stack>
                    <Stack>
                      <p className="text-secondary">
                        To verify eligibility benefits, you typically need to
                        provide the patient's insurance ID, date of birth, and
                        possibly their name and other identifying information.
                      </p>
                    </Stack>
                  </Stack>
                </CardBody>
              </Card>
            </Col>
            <Col xs={4}>
              <Card
                className="border border-0"
                style={{ background: "#F9FAFB" }}
              >
                <CardBody>
                  <Stack gap={2} alignItems="start">
                    <Stack>
                      <div>
                        {" "}
                        <FontAwesomeIcon
                          className="border rounded-circle text-primary "
                          style={{
                            width: 20,
                            height: 20,
                            background: "#F4EBFF",
                            padding: 15,
                          }}
                          icon={faSquarePollVertical}
                        />
                      </div>
                    </Stack>
                    <Stack className="fs-5">
                      How long does it take to receive eligibility verification
                      results?
                    </Stack>
                    <Stack>
                      <p className="text-secondary">
                        The time it takes to receive verification results can
                        vary depending on the insurance company and the
                        efficiency of the web application. In many cases,
                        results are returned within seconds or minutes.
                      </p>
                    </Stack>
                  </Stack>
                </CardBody>
              </Card>
            </Col>
            <Col xs={4}>
              <Card
                className="border border-0"
                style={{ background: "#F9FAFB" }}
              >
                <CardBody>
                  <Stack gap={2} alignItems="start">
                    <Stack>
                      <div>
                        {" "}
                        <FontAwesomeIcon
                          className="border rounded-circle text-primary "
                          style={{
                            width: 20,
                            height: 20,
                            background: "#F4EBFF",
                            padding: 15,
                          }}
                          icon={faCircleCheck}
                        />
                      </div>
                    </Stack>
                    <Stack className="fs-5">
                      Can I verify eligibility benefits for multiple patients at
                      once?
                    </Stack>
                    <Stack>
                      <p className="text-secondary">
                        Yes, many eligibility verification web applications
                        allow batch processing, enabling dental providers to
                        verify benefits for multiple patients simultaneously,
                        saving time and effort.
                      </p>
                    </Stack>
                  </Stack>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Container
            style={{
              padding: "30px",
              borderRadius: "15px",
              background: "#ffffff",
            }}
          >
            <Stack direction="row" justifyContent="space-between">
              <Stack className=" fs-5">Still have questions?</Stack>
              <Stack>
                <Button color="primary" onClick={handleChatModal}>
                  Get In Touch
                </Button>
              </Stack>
            </Stack>
            <Stack className="text-secondary">
              Can't find the answer you're looking for?Please chat to our
              friendly team.
            </Stack>
          </Container>
        </Stack>
      </Container>

      <Dialog
        open={open}
        onClose={handleChatModal}
        maxWidth="xs"
        fullWidth
        PaperProps={{
          style: {
            backgroundColor: "#f0f0f0",
            boxShadow: "none",
            overflow: "visible",
            borderRadius: 16,
            position: "absolute",
            right: 20,
          },
        }}
      >
        <DialogContent style={{ height: "100vh" }}>
          <iframe
            ref={iframeRef}
            src={import.meta.env.VITE_CHATBOT_INTEGRATION_URL}
            title="ebv"
            style={{ width: "100%", height: "100vh" }}
          ></iframe>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Faq;
