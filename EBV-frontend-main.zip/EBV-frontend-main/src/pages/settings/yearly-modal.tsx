/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
} from "reactstrap";

function YearlyModal(props: {
  isOpen: any;
  toggle: any;
  className: any;
  title: string;
}) {
  const { isOpen, toggle, title } = props;

  const handleSaveChanges = () => {
    toggle();
  };

  const [dayData, setDayData] = React.useState({
    dayOfWeek: "",
    month: "",
  });

  const handleInputChangeDays = (e: any) => {
    const { name, value } = e.target;
    setDayData({ ...dayData, [name]: value });
  };

  const [selectedOption, setSelectedOption] = React.useState("");

  const handleRadioChange = (e: any) => {
    setSelectedOption(e.target.value);
  };
  const currentDate = new Date().toLocaleDateString();
  return (
    <>
      <Modal className="modal_main" isOpen={isOpen} toggle={toggle} centered>
        <ModalHeader toggle={toggle}>{title} </ModalHeader>
        <ModalBody className="modal_body f-13">
          <Form>
            <div className="row">
              <div className="col-4">
                <FormGroup>
                  <Label for="start">Start</Label>
                  <Input
                    type="text"
                    name="start"
                    id="start"
                    value={currentDate}
                    disabled
                  />
                </FormGroup>
              </div>
            </div>
            <div className="row">
              <div className="col-3">
                <FormGroup>
                  <Label for="dayOfWeek">Repeat Every</Label>
                  <Input type="select" name="star" id="dayOfWeek">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  </Input>
                </FormGroup>
              </div>
              <div className="col-3 mt-2">
                <FormGroup>
                  <Label for="repeatEvery"></Label>
                  <Input
                    type="text"
                    name="repeatEvery"
                    id="repeatEvery"
                    placeholder="Week"
                  />
                </FormGroup>
              </div>
            </div>
            <div className="row">
              <div className="col-2 mt-2">
                <FormGroup check>
                  <Label check>
                    <Input
                      type="radio"
                      name="on day"
                      value="option1"
                      checked={selectedOption === "option1"}
                      onChange={handleRadioChange}
                    />{" "}
                    On day
                  </Label>
                </FormGroup>
              </div>
              <div className="col-2">
                <FormGroup>
                  <Input type="text" name="start" id="start" placeholder="1" />
                </FormGroup>
              </div>
            </div>
            <div className="row">
              <div className="col-2 mt-2">
                <FormGroup check>
                  <Label check>
                    <Input
                      type="radio"
                      name="on the"
                      value="option2"
                      checked={selectedOption === "option1"}
                      onChange={handleRadioChange}
                    />{" "}
                    On the
                  </Label>
                </FormGroup>
              </div>
              <div className="col-3">
                <FormGroup>
                  <Input
                    type="select"
                    name="dayOfWeek"
                    id="dayOfWeek"
                    onChange={handleInputChangeDays}
                  >
                    <option value="First">First</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                  </Input>
                </FormGroup>
              </div>
              <div className="col-3">
                <FormGroup>
                  <Input
                    type="select"
                    name="dayOfWeek"
                    id="dayOfWeek"
                    value={dayData.dayOfWeek}
                    onChange={handleInputChangeDays}
                  >
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                  </Input>
                </FormGroup>
              </div>
              or
              <div className="col-3">
                <FormGroup>
                  <Input
                    type="select"
                    name="month"
                    id="month"
                    value={dayData.month}
                    onChange={handleInputChangeDays}
                  >
                    <option value="January">January</option>
                    <option value="February">February</option>
                    <option value="March">March</option>
                    <option value="April">April</option>
                    <option value="May">May</option>
                    <option value="June">June</option>
                    <option value="July">July</option>
                    <option value="August">August</option>
                    <option value="September">September</option>
                    <option value="October">October</option>
                    <option value="November">November</option>
                    <option value="December">December</option>
                  </Input>
                </FormGroup>
              </div>
            </div>
          </Form>
        </ModalBody>

        <ModalFooter>
          <Button
            className="cancelmodal"
            color="primary"
            outline
            onClick={toggle}
          >
            Cancel
          </Button>{" "}
          <Button color="primary text-white" onClick={handleSaveChanges}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
}

export default YearlyModal;
