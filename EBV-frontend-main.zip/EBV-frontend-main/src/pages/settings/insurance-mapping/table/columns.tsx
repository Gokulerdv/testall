import { createColumnHelper } from "@tanstack/react-table";
import AlignTableItems from "../../../../components/align-table-items";

export type PayerInsurance = {
  payerId: string;
  payerName: string;
  clearingHouse: string;
  payerLogo: string;
};

const columnHelper = createColumnHelper<PayerInsurance>();

export const defaultColumns = [
  columnHelper.accessor("payerId", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Payer ID",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("payerName", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Insurance/payer Name",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("clearingHouse", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Clearing House",
    footer: (props) => props.column.id,
    enableColumnFilter: true,
    enableGlobalFilter: false,
  }),
  columnHelper.accessor("payerLogo", {
    cell: (info) => (
      <>
        <img
          src={info.getValue()}
          className="img-fluid"
          // width={100}
          // height={100}
        />
      </>
    ),
    header: "LOGO",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
    enableGlobalFilter: false,
  }),
];
