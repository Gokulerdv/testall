import { capitalCase } from "change-case";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";

export type FieldProps = InputProps & {
  help?: React.ReactNode;
  name: string;
};

export const Field = (props: FieldProps) => {
  const { control } = useFormContext();
  const key = props.name;

  return (
    <FormGroup>
      <Label for={key} className="payor_labels">
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>

      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
              style={{ width: "20rem" }}
            >
              {props.children}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};
