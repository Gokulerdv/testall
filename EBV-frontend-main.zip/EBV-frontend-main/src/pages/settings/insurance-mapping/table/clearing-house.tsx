/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSuspenseQuery } from "@tanstack/react-query";
import { capitalCase } from "change-case";
import { Controller, useFormContext } from "react-hook-form";
import { FormFeedback, FormGroup, Input, Label } from "reactstrap";
import { z } from "zod";
import { useAuth } from "../../../../shared/hooks/use-auth";
import Config from "../../../../utils/headers-config";

export const key = "Clearing House";

export const clearingHouseSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`),
});

export type ClearingHouseSchema = z.infer<typeof clearingHouseSchema>;

export const ClearingHouse = () => {
  const { control } = useFormContext();
  const auth = useAuth();
  const getAll = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/clearinghouse/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
    return response.json();
  };
  const { data: clearingHouseData } = useSuspenseQuery({
    queryKey: ["clearingHouse", "getAll"],
    queryFn: getAll,
  });
  return (
    <FormGroup>
      <Label for={key} className="payor_labels">
        {capitalCase(key)}
      </Label>
      <Controller
        name="clearingHouse"
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              style={{ width: "20rem" }}
            >
              <option value="">Select</option>
              {clearingHouseData.data.map((type: any) => (
                <option value={type.name} key={type.id}>
                  {type.name}
                </option>
              ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default ClearingHouse;
