import { Card } from "reactstrap";
import MyInsuranceMappingTable from "./table";

export const MyInsuranceMapper = () => {
  return (
    <>
      <Card>
        <MyInsuranceMappingTable />
      </Card>
    </>
  );
};

export default MyInsuranceMapper;
