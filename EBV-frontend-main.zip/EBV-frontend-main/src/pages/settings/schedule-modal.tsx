/* eslint-disable @typescript-eslint/no-explicit-any */
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import ConfirmationModal from "../../components/confirmation-modal";
import { useAuth } from "../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../shared/hooks/use-dialog-with-form-reset";
import { CreateScheduleCreatePermission } from "../../utils/constant";
import Config from "../../utils/headers-config";
import { RolesPermission } from "../../utils/role-permission";
import { ScheduledSettingsAddBody } from "./apis/schedule-settings-add";
import NumberOfPatients, {
  numberOfPatientsSchema,
} from "./fields/no-of-patients";
import ScheduledAction, {
  scheduledActionSchema,
} from "./fields/scheduled-action";
import TimeToRun, { timeToRunSchema } from "./fields/time-to-run";
import MonthlyModal from "./monthly-modal";
import WeeklyModal from "./weekly-modal";

export const scheduledFormSchema = z.object({
  weeklydays: z.string().optional(),
  isweekly: z.boolean().optional(),
  isdaily: z.boolean().optional(),
  ismonthly: z.boolean().optional(),
  everyweek: z.string().optional(),
  everymonth: z.string().optional(),
  oncountofdays: z.string().optional(),
  oncountofweekdays: z.string().optional(),
  oncountofweeks: z.string().optional(),

  statusflag: z.string().optional(),

  ...scheduledActionSchema.shape,
  ...timeToRunSchema.shape,
  ...numberOfPatientsSchema.shape,
});

scheduledFormSchema.merge(scheduledActionSchema);
scheduledFormSchema.merge(timeToRunSchema);
scheduledActionSchema.merge(numberOfPatientsSchema);

export type ScheduledFormData = z.infer<typeof scheduledFormSchema>;

export type ScheduledModalProps = {
  onSuccess?: () => Promise<void>;
};

export const ScheduleModal = (props: ScheduledModalProps) => {
  const methods = useForm<ScheduledFormData>({
    resolver: zodResolver(scheduledFormSchema),
  });

  const { open, toggle } = useDialogWithFormReset(methods);
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;

  const scheduledSettingsAdd = async (body: ScheduledSettingsAddBody) => {
    const overwrittenBody: ScheduledSettingsAddBody = {
      ...body,
      scheduledaction: body.scheduledaction || "",
      weeklydays: body.weeklydays || "",
      isweekly: body.isweekly ? true : false,
      isdaily: body.isdaily ? true : false,
      ismonthly: body.ismonthly ? true : false,
      timetorun: body.timetorun || "",
      numberofpatients: body.numberofpatients || null,
      oncountofweekdays: body.oncountofweekdays || "",
      oncountofdays: body.oncountofdays || "",
      oncountofweeks: body.oncountofweeks || "",
      everymonth: body.everymonth || "",
      everyweek: body.everyweek || "",
      statusflag: "A",
    } as unknown as ScheduledSettingsAddBody;

    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/scheduledSettings/create`;

    const options: RequestInit = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
      body: JSON.stringify(overwrittenBody),
    };

    const response = await fetch(url, options);
    return await response.json();
  };

  const scheduledCreate = useMutation({
    mutationKey: ["scheduled", "create"],
    mutationFn: scheduledSettingsAdd,
  });

  const queryClient = useQueryClient();

  const numberofpatients = methods.watch("numberofpatients");
  const scheduledaction = methods.watch("scheduledaction");
  const timetorun = methods.watch("timetorun");

  const [isCreateWeeklyModalOpen, setIsCreateWeeklyModalOpen] = useState(false);
  const [isCreateMonthlyModalOpen, setIsCreateMonthlyModalOpen] =
    useState(false);
  const [repeatEvery, setRepeatEvery] = useState("");
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [days, setDays] = useState<string[]>([]);

  const [cardOpen, setCardOpen] = useState(false);

  const [isWeekly, setIsWeekly] = useState(false);
  const [isMonthly, setIsMonthly] = useState(false);
  const [isDaily, setIsDaily] = useState(false);

  const [repeatEveryMonth, setRepeatEveryMonth] = useState("");
  const [onCountOfDays, setOnCountOfDays] = useState("");
  const [onCountOfWeekDays, setOnCountOfWeekDays] = useState("");
  const [onCountOfWeeks, setOnCountOfWeeks] = useState("");

  const toggleWeeklyCreateModal = () => {
    setIsCreateWeeklyModalOpen(!isCreateWeeklyModalOpen);
    setIsWeekly(true);
    setIsDaily(false);
    setIsMonthly(false);
  };

  const toggleMonthlyCreateModal = () => {
    setIsCreateMonthlyModalOpen(!isCreateMonthlyModalOpen);
    setIsMonthly(true);
    setIsWeekly(false);
    setIsDaily(false);
  };
  //utility function
  const convertTo12HourFormat = (time: string | undefined): string => {
    if (!time) {
      return "";
    }
    const [hour, minute] = time.split(":").map(Number);
    const period = hour >= 12 ? "PM" : "AM";
    const adjustedHour = hour % 12 || 12;
    return `${adjustedHour}:${minute < 10 ? "0" : ""}${minute}${period}`;
  };

  const onSubmit: SubmitHandler<ScheduledFormData> = async (data) => {
    try {
      if (selectedOption === "weekdays") {
        // Set the selected weekdays data to the weeklydays field
        data.weeklydays = days.join(",");
        data.everyweek = "1";
        data.isdaily = isDaily ? false : true;
      } else {
        data.weeklydays = selectedDays.join(",");
      }
      if (
        data.numberofpatients &&
        data.scheduledaction &&
        data.timetorun &&
        selectedOption
      ) {
        if (
          (selectedOption === "monthly" &&
            (onCountOfWeekDays !== "" ||
              onCountOfDays !== "" ||
              onCountOfWeeks !== "" ||
              repeatEveryMonth !== "")) ||
          (selectedOption === "weekdays" && days?.length > 0) ||
          (selectedOption === "weekly" &&
            (repeatEvery !== "" || selectedDays?.length > 0)) ||
          selectedOption === "daily"
        ) {
          const time12 = convertTo12HourFormat(timetorun);
          await scheduledCreate.mutateAsync({
            scheduledaction,
            timetorun: time12,
            numberofpatients,
            statusflag: "A",
            isweekly: isWeekly ? true : false,
            isdaily: isDaily ? true : false,
            ismonthly: isMonthly ? true : false,
            everyweek: repeatEvery || data.everyweek || "",
            everymonth: repeatEveryMonth || "",
            oncountofdays: onCountOfDays || "",
            oncountofweeks: onCountOfWeeks || "",
            oncountofweekdays: onCountOfWeekDays || "",
            adminId: `${userId}`,
            weeklydays: data.weeklydays || "", // Add this line to include weeklydays in the request
          });
          toast.success("Scheduled Settings Created successfully");
          props.onSuccess?.();
          toggle();
        } else {
          toast.error("Please enter valid details for specified frequency");
        }
      } else {
        toast.error("Please enter valid data");
      }
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["scheduled", "getAll"],
      });
    }
  };

  const [selectedOption, setSelectedOption] = useState("");

  const handleSelectChange = (event: any) => {
    setSelectedOption(event.target.value);
    if (event.target.value === "weekdays") {
      setIsDaily(false);
      setIsMonthly(false);
      setIsWeekly(false);
      setCardOpen(!cardOpen);
    } else setCardOpen(false);

    setSelectedOption(event.target.value);
    if (event.target.value === "monthly") {
      setDays([]);
      setIsCreateMonthlyModalOpen(!isCreateMonthlyModalOpen);
    } else setIsCreateMonthlyModalOpen(false);

    setSelectedOption(event.target.value);
    if (event.target.value === "weekly") {
      setDays([]);
      setIsCreateWeeklyModalOpen(!isCreateWeeklyModalOpen);
    } else setIsCreateWeeklyModalOpen(false);

    setSelectedOption(event.target.value);
    if (event.target.value === "daily") {
      setDays([]);
      setIsDaily(true);
      setIsMonthly(false);
      setIsWeekly(false);
    }
  };

  const handleCardClose = () => {
    setCardOpen(!cardOpen);
  };

  const handleCheckboxChange = (e: any) => {
    const { value, checked } = e.target;
    if (checked) {
      // If checkbox is checked, add the value to the selectedDays array
      setDays([...days, value]);
    } else {
      // If checkbox is unchecked, remove the value from the selectedDays array
      setDays(days.filter((day) => day !== value));
    }
  };

  const handleCloseModal = () => {
    setCardOpen(false);
    setDays([]);
    setOnCountOfWeekDays("");
    setOnCountOfDays("");
    setOnCountOfWeeks("");
    setRepeatEveryMonth("");
    setRepeatEvery("");
    setSelectedDays([]);
  };

  return (
    <>
      {RolesPermission(CreateScheduleCreatePermission) && (
        <Button color="primary" className="text-white" onClick={toggle}>
          <p className="gap-2 mb-0 hstack">
            <FontAwesomeIcon icon={faPlus} />
            <span className="mb-0">Create Schedule</span>
          </p>
        </Button>
      )}

      <Modal
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size="lg"
        onClosed={handleCloseModal}
      >
        <ModalHeader toggle={toggle}>
          <div className="title">Create Schedule</div>{" "}
        </ModalHeader>
        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit, console.log)}>
            <ModalBody className="modal_body f-13">
              <Label className="modal_form">Scheduled Action</Label>
              <FormGroup>
                <ScheduledAction />
              </FormGroup>

              <Label className="modal_form">Frequency run</Label>
              <Row>
                <FormGroup style={{ position: "relative" }}>
                  <Input
                    type="select"
                    name="select"
                    id="frequencyDropdown"
                    onChange={handleSelectChange}
                    style={{ width: "63%" }}
                  >
                    <option>Select Option</option>

                    <option value="daily">Daily</option>

                    <option value="weekdays">Weekdays</option>

                    <option value="weekly">Weekly</option>

                    <option value="monthly">Monthly</option>
                  </Input>
                </FormGroup>
                {cardOpen && (
                  <Card
                    className="p-2 "
                    style={{
                      width: "9.625rem",
                      position: "absolute",
                      left: "32rem",
                    }}
                  >
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          value="1"
                          checked={days.includes("1")}
                          onChange={handleCheckboxChange}
                        />
                        Monday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="tuesday"
                          value="2"
                          checked={days.includes("2")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Tuesday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="wednesday"
                          value="3"
                          checked={days.includes("3")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Wednesday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="thursday"
                          value="4"
                          checked={days.includes("4")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Thursday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="friday"
                          value="5"
                          checked={days.includes("5")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Friday
                      </Label>
                    </FormGroup>
                    <Row>
                      <Col>
                        <Button
                          color="primary"
                          className="float-end"
                          size="sm"
                          onClick={handleCardClose}
                        >
                          Save
                        </Button>
                      </Col>
                    </Row>
                  </Card>
                )}

                {isCreateWeeklyModalOpen && (
                  <WeeklyModal
                    isOpen={isCreateWeeklyModalOpen}
                    toggle={toggleWeeklyCreateModal}
                    repeatEvery={repeatEvery}
                    selectedDays={selectedDays}
                    setRepeatEvery={setRepeatEvery}
                    setSelectedDays={setSelectedDays}
                    onClick={() => {
                      setIsWeekly(true);
                      setIsDaily(false);
                      setIsMonthly(false);
                    }}
                  />
                )}

                {isCreateMonthlyModalOpen && (
                  <MonthlyModal
                    isOpen={isCreateMonthlyModalOpen}
                    toggle={toggleMonthlyCreateModal}
                    onClick={() => {
                      setIsMonthly(true);
                      setIsDaily(false);
                      setIsWeekly(false);
                    }}
                    repeatEveryMonth={repeatEveryMonth}
                    onCountOfWeekDays={onCountOfWeekDays}
                    onCountOfWeeks={onCountOfWeeks}
                    onCountOfDays={onCountOfDays}
                    setRepeatEveryMonth={setRepeatEveryMonth}
                    setOnCountOfDays={setOnCountOfDays}
                    setOnCountOfWeekDays={setOnCountOfWeekDays}
                    setOnCountOfWeeks={setOnCountOfWeeks}
                  />
                )}
              </Row>

              <FormGroup>
                <Label className="modal_form" for="timeToRun">
                  Time to Run
                </Label>
                <TimeToRun />
              </FormGroup>
              <FormGroup>
                <Label className="modal_form" for="numberOfPatients">
                  No of Patients
                </Label>
                <NumberOfPatients />
              </FormGroup>
            </ModalBody>
          </Form>
        </FormProvider>

        <ModalFooter>
          <Button
            className="cancelmodal"
            color="primary"
            outline
            onClick={toggle}
          >
            Cancel
          </Button>{" "}
          <ConfirmationModal
            onClick={methods.handleSubmit(onSubmit)}
            value="Save"
          />
        </ModalFooter>
      </Modal>
    </>
  );
};

export default ScheduleModal;
