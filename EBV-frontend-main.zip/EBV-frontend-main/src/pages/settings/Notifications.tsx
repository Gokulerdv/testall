/* eslint-disable @typescript-eslint/no-explicit-any */
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Checkbox from "@mui/material/Checkbox";
import FormControl from "@mui/material/FormControl";
import ListItemText from "@mui/material/ListItemText";
import MenuItem from "@mui/material/MenuItem";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Col,
  FormGroup,
  Input,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane,
  Table,
} from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import { Config } from "../../utils/headers-config";
import { getTabActiveStyles } from "../patient-benefit-information";

const Notifications = () => {
  const [searchParams] = useSearchParams();
  const tabId = searchParams.get("tabId");

  const [activeTab, setActiveTab] = React.useState(tabId || "1");
  const toggle = (tab: string) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  return (
    <React.Suspense fallback={"loading data..."}>
      {/* <Container> */}
      <Nav pills style={{ marginLeft: "-9px" }}>
        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "1")}
            onClick={() => {
              toggle("1");
            }}
          >
            User
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "2")}
            onClick={() => {
              toggle("2");
            }}
          >
            Patient
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent activeTab={activeTab}>
        <TabPane tabId="1">
          <UserTab />
        </TabPane>
        <TabPane tabId="2">
          <PatientTab />
        </TabPane>
      </TabContent>
      {/* </Container> */}
    </React.Suspense>
  );
};
export default Notifications;

export const UserTab = () => {
  const ITEM_HEIGHT = 48;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 7.5,
        width: 400,
        borderBottom: "1px solid black",
      },
    },
  };
  const queryClient = useQueryClient();
  const auth = useAuth();

  const updateUser = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/usernotification/update/${data.typeofnotify}`;
    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const getAllUserNotifications = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/usernotification/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const userNotificationUpdate = useMutation({
    mutationKey: ["userNotification", "update"],
    mutationFn: updateUser,
  });

  const { data: userNotificationsData } = useSuspenseQuery({
    queryKey: ["user", "getAll"],
    queryFn: getAllUserNotifications,
  });

  const updateHandler = async (keyName: string, data: object) => {
    try {
      await userNotificationUpdate.mutateAsync({
        typeofnotify: keyName,
        data: data,
      });
      toast.success("User Notifications updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["userNotification", "getAll"],
      });
    }
  };

  const options: any = {
    Success: "success",
    Technical: "technical",
    "Not Linked": "notlinked",
    Demographic: "demographic",
  };
  const patientOptions: any = {
    PMS: "opendental",
    Manual: "manual",
    Import: "csv",
  };

  const bulkOptions: any = {
    Success: "success",
    Technical: "technical",
    "Not Linked": "notlinked",
    Demographic: "demographic",
    PMS: "opendental",
    Manual: "manual",
    Import: "csv",
  };
  const [manualVerificationSelected, setManualVerificationSelected] =
    React.useState<string[]>([]);
  const [scheduleVerificationPmsSelected, setScheduleVerificationPmsSelected] =
    React.useState<string[]>([]);
  const [
    scheduleVerificationImportSelected,
    setScheduleVerificationImportSelected,
  ] = React.useState<string[]>([]);
  const [patientsUpdateSelected, setPatientsUpdateSelected] = React.useState<
    string[]
  >([]);
  const [patientsDeleteSelected, setPatientsDeleteSelected] = React.useState<
    string[]
  >([]);
  const [patientsBulkVerifySelected, setPatientsBulkVerifySelected] =
    React.useState<string[]>([]);
  const [manualEmailChecked, setManualEmailChecked] =
    React.useState<boolean>(false);
  const [manualInappChecked, setManualInappChecked] =
    React.useState<boolean>(false);
  const [manualSmsChecked, setManualSmsChecked] =
    React.useState<boolean>(false);
  const [pmsEmailChecked, setPmsEmailChecked] = React.useState<boolean>(false);
  const [pmsInappChecked, setPmsInappChecked] = React.useState<boolean>(false);
  const [pmsSmsChecked, setPmsSmsChecked] = React.useState<boolean>(false);
  const [pmsFromDate, setPmsFromDate] = React.useState<Date | null>(null);
  const [pmsToDate, setPmsToDate] = React.useState<Date | null>(null);
  const [importEmailChecked, setImportEmailChecked] =
    React.useState<boolean>(false);
  const [importSmsChecked, setImportSmsChecked] =
    React.useState<boolean>(false);
  const [importInappChecked, setImportInappChecked] =
    React.useState<boolean>(false);
  const [importFromDate, setImportFromDate] = React.useState<Date | null>(null);
  const [importToDate, setImportToDate] = React.useState<Date | null>(null);
  const [patientUpdateInappChecked, setPatientUpdateInappChecked] =
    React.useState<boolean>(false);
  const [patientUpdateSmsChecked, setPatientUpdateSmsChecked] =
    React.useState<boolean>(false);
  const [patientUpdateEmailChecked, setPatientUpdateEmailChecked] =
    React.useState<boolean>(false);
  const [patientDeleteEmailChecked, setPatientDeleteEmailChecked] =
    React.useState<boolean>(false);
  const [patientDeleteInappChecked, setPatientDeleteInappChecked] =
    React.useState<boolean>(false);
  const [patientDeleteSmsChecked, setPatientDeleteSmsChecked] =
    React.useState<boolean>(false);
  const [patientsBulkVerifySmsChecked, setPatientsBulkVerifySmsChecked] =
    React.useState<boolean>(false);
  const [patientsBulkVerifyEmailChecked, setPatientsBulkVerifyEmailChecked] =
    React.useState<boolean>(false);
  const [patientsBulkVerifyInappChecked, setPatientsBulkVerifyInappChecked] =
    React.useState<boolean>(false);

  React.useEffect(() => {
    userNotificationsData.data.map((item: any) => {
      if (item?.typeofnotify === "manual") {
        setManualVerificationSelected(item.notifyinapp);
        setManualEmailChecked(item.isemail);
        setManualSmsChecked(item.issms);
        setManualInappChecked(item.isinapp);
      }
      if (item?.typeofnotify === "opendental") {
        setScheduleVerificationPmsSelected(item.notifyinapp);
        setPmsEmailChecked(item.isemail);
        setPmsSmsChecked(item.issms);
        setPmsInappChecked(item.isinapp);
        setPmsFromDate(new Date(item.fromDate));
        setPmsToDate(new Date(item.toDate));
      }
      if (item?.typeofnotify === "csv") {
        setScheduleVerificationImportSelected(item.notifyinapp);
        setImportEmailChecked(item.isemail);
        setImportSmsChecked(item.issms);
        setImportInappChecked(item.isinapp);
        setImportFromDate(new Date(item.fromDate));
        setImportToDate(new Date(item.toDate));
      }
      if (item?.typeofnotify === "ispatientupdate") {
        setPatientsUpdateSelected(item.notifyinapp);
        setPatientUpdateEmailChecked(item.isemail);
        setPatientUpdateSmsChecked(item.issms);
        setPatientUpdateInappChecked(item.isinapp);
      }
      if (item?.typeofnotify === "ispatientdelete") {
        setPatientsDeleteSelected(item.notifyinapp);
        setPatientDeleteEmailChecked(item.isemail);
        setPatientDeleteSmsChecked(item.issms);
        setPatientDeleteInappChecked(item.isinapp);
      }
      if (item?.typeofnotify === "isbulkverify") {
        setPatientsBulkVerifySelected(item.notifyinapp);
        setPatientsBulkVerifyEmailChecked(item.isemail);
        setPatientsBulkVerifySmsChecked(item.issms);
        setPatientsBulkVerifyInappChecked(item.isinapp);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userNotificationsData]);

  return (
    <>
      <div className="mt-3">
        <h5>User</h5>
      </div>
      <hr />

      <Table striped className="notification-table-striped">
        <thead>
          <tr>
            <td className="notification-header" align="left">
              Type of notifications
            </td>
            <td className="notification-header" align="left">
              Notification - Inapp
            </td>
            <td className="notification-header" align="left">
              Time Filter
            </td>
            <td className="notification-header">Inapp</td>
            <td
              style={{
                fontSize: "14px",
                width: "270px",
                fontWeight: "500",
                lineHeight: "16.8px",
              }}
            >
              Email
            </td>
            <td
              style={{
                fontSize: "14px",
                width: "270px",
                fontWeight: "500",
                lineHeight: "16.8px",
              }}
            >
              SMS
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ fontSize: "12px" }}>
              Manual Eligibility Verification
            </td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="UserManualEligibilityVerificationNotification"
                  name="notifyinapp"
                  className="select-styling  select-fontSize"
                  displayEmpty
                  multiple
                  value={manualVerificationSelected}
                  onChange={(
                    event: SelectChangeEvent<typeof manualVerificationSelected>
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setManualVerificationSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? manualVerificationSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value
                    );

                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? manualVerificationSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value;
                    updateHandler("manual", constructedObject);
                  }}
                  renderValue={(manualVerificationSelected) =>
                    manualVerificationSelected.length > 0
                      ? Object.keys(options)
                          .filter((option) =>
                            manualVerificationSelected.includes(
                              `${options[option]}`
                            )
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem key="all" value={Object.values(options).join(",")}>
                    <Checkbox
                      checked={
                        manualVerificationSelected.sort().join(",") ===
                        Object.values(options).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(options).map((option) => (
                    <MenuItem key={option} value={options[option]}>
                      <Checkbox
                        checked={
                          manualVerificationSelected.indexOf(options[option]) >
                          -1
                        }
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td></td>
            <td>
              <FormGroup
                switch
                name="UserManualEligibilityVerificationInApp"
                className="switch-class"
              >
                <Input
                  name="isinapp"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={manualInappChecked}
                  onChange={(e) => {
                    setManualInappChecked(!manualInappChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("manual", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="UserManualEligibilityVerificationEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4 "
                  checked={manualEmailChecked}
                  onChange={(e) => {
                    setManualEmailChecked(!manualEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("manual", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="UserManualEligibilityVerificationSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={manualSmsChecked}
                  onChange={(e) => {
                    setManualSmsChecked(!manualSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("manual", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>Scheduled Verification - PMS</td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="ScheduledVerificationPmsNotification"
                  name="notifyinapp"
                  className="select-styling select-fontSize"
                  placeholder="Select"
                  multiple
                  displayEmpty
                  value={scheduleVerificationPmsSelected}
                  onChange={(
                    event: SelectChangeEvent<
                      typeof scheduleVerificationPmsSelected
                    >
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setScheduleVerificationPmsSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? scheduleVerificationPmsSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? scheduleVerificationPmsSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value;
                    updateHandler("opendental", constructedObject);
                  }}
                  renderValue={(scheduleVerificationPmsSelected: any) =>
                    scheduleVerificationPmsSelected.length > 0
                      ? Object.keys(options)
                          .filter((option) =>
                            scheduleVerificationPmsSelected.includes(
                              `${options[option]}`
                            )
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem key="all" value={Object.values(options).join(",")}>
                    <Checkbox
                      checked={
                        scheduleVerificationPmsSelected.sort().join(",") ===
                        Object.values(options).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(options).map((option) => (
                    <MenuItem key={option} value={options[option]}>
                      <Checkbox
                        checked={
                          scheduleVerificationPmsSelected.indexOf(
                            options[option]
                          ) > -1
                        }
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td>
              <FormGroup>
                <Row>
                  <Col>
                    <DatePicker
                      className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom w-60"
                      selected={pmsFromDate}
                      selectsStart
                      startDate={pmsFromDate}
                      endDate={pmsToDate}
                      showIcon
                      icon={<FontAwesomeIcon icon={faCalendarDays} />}
                      calendarIconClassname="text-primary"
                      isClearable
                      onChange={(event) => {
                        setPmsFromDate(event);
                        const constructedObject = {} as any;
                        constructedObject["fromDate"] = event;
                        updateHandler("opendental", constructedObject);
                      }}
                    />
                  </Col>
                  <Col>
                    <DatePicker
                      className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom w-60"
                      selected={pmsToDate}
                      selectsEnd
                      startDate={pmsFromDate}
                      endDate={pmsToDate}
                      showTimeSelect
                      timeIntervals={10}
                      dateFormat={"MM/d/yyyy h:mm aa"}
                      showIcon
                      icon={<FontAwesomeIcon icon={faCalendarDays} />}
                      calendarIconClassname="text-primary"
                      isClearable
                      onChange={(event) => {
                        setPmsToDate(event);
                        const constructedObject = {} as any;
                        constructedObject["toDate"] = event;
                        updateHandler("opendental", constructedObject);
                      }}
                    />
                  </Col>
                </Row>
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ScheduledVerificationPmsInApp"
                className="switch-class"
              >
                <Input
                  name="isinapp"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={pmsInappChecked}
                  onChange={(e) => {
                    setPmsInappChecked(!pmsInappChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("opendental", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ScheduledVerificationPmsSms"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={pmsEmailChecked}
                  onChange={(e) => {
                    setPmsEmailChecked(!pmsEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("opendental", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ScheduledVerificationPmsSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={pmsSmsChecked}
                  onChange={(e) => {
                    setPmsSmsChecked(!pmsSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("opendental", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>
              Scheduled Verification - Import
            </td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="ScheduledVerificationImportNotification"
                  name="notifyinapp"
                  className="select-styling select-fontSize"
                  placeholder="Select"
                  displayEmpty
                  multiple
                  value={scheduleVerificationImportSelected}
                  onChange={(
                    event: SelectChangeEvent<
                      typeof scheduleVerificationImportSelected
                    >
                  ) => {
                    const {
                      target: { value },
                    } = event;

                    setScheduleVerificationImportSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? scheduleVerificationImportSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? scheduleVerificationImportSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value;
                    updateHandler("csv", constructedObject);
                  }}
                  renderValue={(scheduleVerificationImportSelected: any) =>
                    scheduleVerificationImportSelected.length > 0
                      ? Object.keys(options)
                          .filter((option) =>
                            scheduleVerificationImportSelected.includes(
                              `${options[option]}`
                            )
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem key="all" value={Object.values(options).join(",")}>
                    <Checkbox
                      checked={
                        scheduleVerificationImportSelected.sort().join(",") ===
                        Object.values(options).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(options).map((option) => (
                    <MenuItem key={option} value={options[option]}>
                      <Checkbox
                        checked={
                          scheduleVerificationImportSelected.indexOf(
                            options[option]
                          ) > -1
                        }
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td>
              <FormGroup>
                <Row>
                  <Col>
                    <DatePicker
                      className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom w-60"
                      selected={importFromDate}
                      selectsStart
                      startDate={importFromDate}
                      endDate={importToDate}
                      showIcon
                      icon={<FontAwesomeIcon icon={faCalendarDays} />}
                      calendarIconClassname="text-primary"
                      isClearable
                      onChange={(event) => {
                        setImportFromDate(event);
                        const constructedObject = {} as any;
                        constructedObject["fromDate"] = event;
                        updateHandler("csv", constructedObject);
                      }}
                    />
                  </Col>
                  <Col>
                    <DatePicker
                      className="p-1 border rounded ps-4 border-secondary-subtle calendar-custom w-60"
                      selected={importToDate}
                      selectsEnd
                      showTimeSelect
                      timeIntervals={10}
                      dateFormat={"MM/d/yyyy h:mm aa"}
                      startDate={importFromDate}
                      endDate={importToDate}
                      showIcon
                      icon={<FontAwesomeIcon icon={faCalendarDays} />}
                      calendarIconClassname="text-primary"
                      isClearable
                      onChange={(event) => {
                        setImportToDate(event);
                        const constructedObject = {} as any;
                        constructedObject["toDate"] = event;
                        updateHandler("csv", constructedObject);
                      }}
                    />
                  </Col>
                </Row>
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ScheduledVerificationImportInApp"
                className="switch-class"
              >
                <Input
                  name="isinapp"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={importInappChecked}
                  onChange={(e) => {
                    setImportInappChecked(!importInappChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("csv", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ScheduledVerificationImportEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={importEmailChecked}
                  onChange={(e) => {
                    setImportEmailChecked(!importEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("csv", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ScheduledVerificationImportSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={importSmsChecked}
                  onChange={(e) => {
                    setImportSmsChecked(!importSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("csv", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>Patient Details Update</td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="PatientDetailsUpdate"
                  name="notifyinapp"
                  className="select-styling select-fontSize"
                  placeholder="Select"
                  multiple
                  displayEmpty
                  value={patientsUpdateSelected}
                  onChange={(
                    event: SelectChangeEvent<typeof patientsUpdateSelected>
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setPatientsUpdateSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(
                            Object.values(patientOptions).join(",")
                          )
                        ? patientsUpdateSelected.length ===
                          Object.values(patientOptions).length
                          ? []
                          : Object.values(patientOptions)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(
                            Object.values(patientOptions).join(",")
                          )
                        ? patientsUpdateSelected.length ===
                          Object.values(patientOptions).length
                          ? []
                          : Object.values(patientOptions)
                        : value;
                    updateHandler("ispatientupdate", constructedObject);
                  }}
                  renderValue={(patientsUpdateSelected) =>
                    patientsUpdateSelected.length > 0
                      ? Object.keys(patientOptions)
                          .filter((option) =>
                            patientsUpdateSelected.includes(
                              `${patientOptions[option]}`
                            )
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem
                    key="all"
                    value={Object.values(patientOptions).join(",")}
                  >
                    <Checkbox
                      checked={
                        patientsUpdateSelected.sort().join(",") ===
                        Object.values(patientOptions).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(patientOptions).map((option) => (
                    <MenuItem key={option} value={patientOptions[option]}>
                      <Checkbox
                        checked={
                          patientsUpdateSelected.indexOf(
                            patientOptions[option]
                          ) > -1
                        }
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td></td>
            <td>
              <FormGroup
                switch
                name="PatientDetailsUpdateInApp"
                className="switch-class"
              >
                <Input
                  name="isinapp"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientUpdateInappChecked}
                  onChange={(e) => {
                    setPatientUpdateInappChecked(!patientUpdateInappChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("ispatientupdate", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientDetailsUpdateEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientUpdateEmailChecked}
                  onChange={(e) => {
                    setPatientUpdateEmailChecked(!patientUpdateEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("ispatientupdate", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientDetailsUpdateSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientUpdateSmsChecked}
                  onChange={(e) => {
                    setPatientUpdateSmsChecked(!patientUpdateSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("ispatientupdate", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>Patients Delete</td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="PatientsDeleteNotification"
                  name="notifyinapp"
                  className="select-styling select-fontSize"
                  placeholder="Select"
                  multiple
                  displayEmpty
                  value={patientsDeleteSelected}
                  onChange={(
                    event: SelectChangeEvent<typeof patientsDeleteSelected>
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setPatientsDeleteSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(
                            Object.values(patientOptions).join(",")
                          )
                        ? patientsDeleteSelected.length ===
                          Object.values(patientOptions).length
                          ? []
                          : Object.values(patientOptions)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(
                            Object.values(patientOptions).join(",")
                          )
                        ? patientsDeleteSelected.length ===
                          Object.values(patientOptions).length
                          ? []
                          : Object.values(patientOptions)
                        : value;
                    updateHandler("ispatientdelete", constructedObject);
                  }}
                  renderValue={(patientsDeleteSelected) =>
                    patientsDeleteSelected.length > 0
                      ? Object.keys(patientOptions)
                          .filter((option) =>
                            patientsDeleteSelected.includes(
                              `${patientOptions[option]}`
                            )
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem
                    key="all"
                    value={Object.values(patientOptions).join(",")}
                  >
                    <Checkbox
                      checked={
                        patientsDeleteSelected.sort().join(",") ===
                        Object.values(patientOptions).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(patientOptions).map((option) => (
                    <MenuItem key={option} value={patientOptions[option]}>
                      <Checkbox
                        checked={
                          patientsDeleteSelected.indexOf(
                            patientOptions[option]
                          ) > -1
                        }
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td></td>
            <td>
              <FormGroup
                switch
                name="PatientsDeleteInApp"
                className="switch-class"
              >
                <Input
                  name="isinapp"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientDeleteInappChecked}
                  onChange={(e) => {
                    setPatientDeleteInappChecked(!patientDeleteInappChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("ispatientdelete", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientsDeleteEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientDeleteEmailChecked}
                  onChange={(e) => {
                    setPatientDeleteEmailChecked(!patientDeleteEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("ispatientdelete", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientsDeleteSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientDeleteSmsChecked}
                  onChange={(e) => {
                    setPatientDeleteSmsChecked(!patientDeleteSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("ispatientdelete", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>Bulk Verification</td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="PatientsBukVerify"
                  name="notifyinapp"
                  className="select-styling select-fontSize"
                  placeholder="Select"
                  multiple
                  displayEmpty
                  value={patientsBulkVerifySelected}
                  onChange={(
                    event: SelectChangeEvent<typeof patientsBulkVerifySelected>
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setPatientsBulkVerifySelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(bulkOptions).join(","))
                        ? patientsBulkVerifySelected.length ===
                          Object.values(bulkOptions).length
                          ? []
                          : Object.values(bulkOptions)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(bulkOptions).join(","))
                        ? patientsBulkVerifySelected.length ===
                          Object.values(bulkOptions).length
                          ? []
                          : Object.values(bulkOptions)
                        : value;
                    updateHandler("isbulkverify", constructedObject);
                  }}
                  renderValue={(patientsBulkVerifySelected) =>
                    patientsBulkVerifySelected.length > 0
                      ? Object.keys(bulkOptions)
                          .filter((option) =>
                            patientsBulkVerifySelected.includes(
                              `${bulkOptions[option]}`
                            )
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem
                    key="all"
                    value={Object.values(bulkOptions).join(",")}
                  >
                    <Checkbox
                      checked={
                        patientsBulkVerifySelected.sort().join(",") ===
                        Object.values(bulkOptions).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(bulkOptions).map((option) => (
                    <MenuItem key={option} value={bulkOptions[option]}>
                      <Checkbox
                        checked={
                          patientsBulkVerifySelected.indexOf(
                            bulkOptions[option]
                          ) > -1
                        }
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td></td>
            <td>
              <FormGroup
                switch
                name="PatientsBulkVerifyInApp"
                className="switch-class"
              >
                <Input
                  name="isinapp"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientsBulkVerifyInappChecked}
                  onChange={(e) => {
                    setPatientsBulkVerifyInappChecked(
                      !patientsBulkVerifyInappChecked
                    );
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("isbulkverify", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientsBulkVerifyEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientsBulkVerifyEmailChecked}
                  onChange={(e) => {
                    setPatientsBulkVerifyEmailChecked(
                      !patientsBulkVerifyEmailChecked
                    );
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("isbulkverify", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientsBulkVerifySms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={patientsBulkVerifySmsChecked}
                  onChange={(e) => {
                    setPatientsBulkVerifySmsChecked(
                      !patientsBulkVerifySmsChecked
                    );
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("isbulkverify", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
        </tbody>
      </Table>
    </>
  );
};

export const PatientTab = () => {
  const ITEM_HEIGHT = 48;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 7.5,
        width: 400,
      },
    },
  };

  const queryClient = useQueryClient();

  const options: any = {
    Success: "success",
    Technical: "technical",
    "Not Linked": "notlinked",
    Demographic: "demographic",
  };
  const [manualSelected, setManualSelected] = React.useState<string[]>([]);
  const [pmsSelected, setPmsSelected] = React.useState<string[]>([]);
  const [importSelected, setImportSelected] = React.useState<string[]>([]);
  const [manualEmailChecked, setManualEmailChecked] =
    React.useState<boolean>(false);
  const [manualSmsChecked, setManualSmsChecked] =
    React.useState<boolean>(false);
  const [pmsEmailChecked, setPmsEmailChecked] = React.useState<boolean>(false);
  const [pmsSmsChecked, setPmsSmsChecked] = React.useState<boolean>(false);
  const [importEmailChecked, setImportEmailChecked] =
    React.useState<boolean>(false);
  const [importSmsChecked, setImportSmsChecked] =
    React.useState<boolean>(false);

  const auth = useAuth();

  const getAllPatientNotifications = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patientnotification/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const updatePatient = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patientnotification/update/${data.typeofnotify}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data.data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const patientNotificationUpdate = useMutation({
    mutationKey: ["userNotification", "update"],
    mutationFn: updatePatient,
  });

  const { data: patientNotificationsData } = useSuspenseQuery({
    queryKey: ["user", "getAll"],
    queryFn: getAllPatientNotifications,
  });

  React.useEffect(() => {
    patientNotificationsData.data.map((item: any) => {
      if (item?.typeofnotify === "manual") {
        setManualSelected(item.notifyinapp);
        setManualEmailChecked(item.isemail);
        setManualSmsChecked(item.issms);
      }
      if (item?.typeofnotify === "opendental") {
        setPmsSelected(item.notifyinapp);
        setPmsEmailChecked(item.isemail);
        setPmsSmsChecked(item.issms);
      }
      if (item?.typeofnotify === "csv") {
        setImportSelected(item.notifyinapp);
        setImportEmailChecked(item.isemail);
        setImportSmsChecked(item.issms);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientNotificationsData]);

  const updateHandler = async (keyName: string, data: object) => {
    try {
      await patientNotificationUpdate.mutateAsync({
        typeofnotify: keyName,
        data: data,
      });
      toast.success("Patient Notifications updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["patientNotification", "getAll"],
      });
    }
  };

  return (
    <>
      <div className="mt-3">
        <h5>Patient</h5>
      </div>
      <hr />

      <Table striped className="notification-table-striped">
        <thead>
          <tr>
            <td className="notification-header" align="left">
              Type of notifications
            </td>
            <td className="notification-header" align="left">
              Eligibility Benefit Status
            </td>
            <td className="notification-header">Email</td>
            <td className="notification-header">SMS</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ fontSize: "12px" }}>
              Manual Eligibility Verification
            </td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="PatientManualEligibilityVerificationStatus"
                  name="notifyinapp"
                  className="select-styling  select-fontSize"
                  placeholder="Select"
                  multiple
                  displayEmpty
                  value={manualSelected}
                  onChange={(
                    event: SelectChangeEvent<typeof manualSelected>
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setManualSelected(
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? manualSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string" ? value.split(",") : value;
                    updateHandler("manual", constructedObject);
                  }}
                  renderValue={(manualSelected) =>
                    manualSelected.length > 0
                      ? Object.keys(options)
                          .filter((option: any) =>
                            manualSelected.includes(`${options[option]}`)
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem key="all" value={Object.values(options).join(",")}>
                    <Checkbox
                      checked={
                        manualSelected.sort().join(",") ===
                        Object.values(options).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(options).map((option) => (
                    <MenuItem key={option} value={options[option]}>
                      <Checkbox
                        checked={manualSelected.indexOf(options[option]) > -1}
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientManualEligibilityVerificationEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={manualEmailChecked}
                  onChange={(e) => {
                    setManualEmailChecked(!manualEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("manual", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="ManualEligibilityVerificationSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={manualSmsChecked}
                  onChange={(e) => {
                    setManualSmsChecked(!manualSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("manual", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>Patient from PMS</td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="PatientFromPmsStatus"
                  name="notifyinapp"
                  className="select-styling  select-fontSize"
                  placeholder="Select"
                  multiple
                  displayEmpty
                  value={pmsSelected}
                  onChange={(event: SelectChangeEvent<typeof pmsSelected>) => {
                    const {
                      target: { value },
                    } = event;
                    setPmsSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? pmsSelected.length === Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value
                    );
                    const constructedObject = {} as any;
                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? pmsSelected.length === Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value;
                    updateHandler("opendental", constructedObject);
                  }}
                  renderValue={(pmsSelected) =>
                    pmsSelected.length > 0
                      ? Object.keys(options)
                          .filter((option: any) =>
                            pmsSelected.includes(`${options[option]}`)
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem key="all" value={Object.values(options).join(",")}>
                    <Checkbox
                      checked={
                        pmsSelected.sort().join(",") ===
                        Object.values(options).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(options).map((option) => (
                    <MenuItem key={option} value={options[option]}>
                      <Checkbox
                        checked={pmsSelected.indexOf(options[option]) > -1}
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientFromPmsEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={pmsEmailChecked}
                  onChange={(e) => {
                    setPmsEmailChecked(!pmsEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("opendental", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientFromPmsSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={pmsSmsChecked}
                  onChange={(e) => {
                    setPmsSmsChecked(!pmsSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("opendental", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
          <tr>
            <td style={{ fontSize: "12px" }}>Patient from Import</td>
            <td>
              <FormControl sx={{ width: "15rem" }}>
                <Select
                  id="PatientFromImportStatus"
                  multiple
                  displayEmpty
                  value={importSelected}
                  className="select-styling  select-fontSize"
                  placeholder="Select"
                  onChange={(
                    event: SelectChangeEvent<typeof importSelected>
                  ) => {
                    const {
                      target: { value },
                    } = event;
                    setImportSelected(
                      // On autofill we get a stringified value.
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? importSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value
                    );
                    const constructedObject = {} as any;

                    constructedObject[event.target.name] =
                      typeof value === "string"
                        ? value.split(",")
                        : value.includes(Object.values(options).join(","))
                        ? importSelected.length ===
                          Object.values(options).length
                          ? []
                          : Object.values(options)
                        : value;
                    updateHandler("csv", constructedObject);
                  }}
                  renderValue={(importSelected) =>
                    importSelected.length > 0
                      ? Object.keys(options)
                          .filter((option: any) =>
                            importSelected.includes(`${options[option]}`)
                          )
                          .join(",")
                      : "Select"
                  }
                  MenuProps={MenuProps}
                >
                  <MenuItem key="all" value={Object.values(options).join(",")}>
                    <Checkbox
                      checked={
                        importSelected.sort().join(",") ===
                        Object.values(options).sort().join(",")
                      }
                    />
                    <ListItemText primary="All">All</ListItemText>
                  </MenuItem>
                  {Object.keys(options).map((option) => (
                    <MenuItem key={option} value={options[option]}>
                      <Checkbox
                        checked={importSelected.indexOf(options[option]) > -1}
                      />
                      <ListItemText primary={option} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientFromImportEmail"
                className="switch-class"
              >
                <Input
                  name="isemail"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={importEmailChecked}
                  onChange={(e) => {
                    setImportEmailChecked(!importEmailChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("csv", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
            <td>
              <FormGroup
                switch
                name="PatientFromImportSms"
                className="switch-class"
              >
                <Input
                  name="issms"
                  role="switch"
                  type="switch"
                  className="ml-4"
                  checked={importSmsChecked}
                  onChange={(e) => {
                    setImportSmsChecked(!importSmsChecked);
                    const constructedObject = {} as any;
                    constructedObject[e.target.name] = e.target.checked;
                    updateHandler("csv", constructedObject);
                  }}
                />
              </FormGroup>
            </td>
          </tr>
        </tbody>
      </Table>
    </>
  );
};
