import React, { useState } from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  Input,
  FormFeedback,
  FormText,
  InputProps,
  Label,
  Button,
} from "reactstrap";
import { capitalCase } from "change-case";

export const key = "excludeclone";

export const excludeCloneSchema = z.object({
  [key]: z.boolean().optional(),
});

export type ExcludeCloneSchema = z.infer<typeof excludeCloneSchema>;

export type ExcludeCloneProps = InputProps & {
  help?: React.ReactNode;
};

export const ExcludeClone = (props: ExcludeCloneProps) => {
  const { control } = useFormContext();
  const [isChecked, setIsChecked] = useState(false);

  const handleToggle = () => {
    setIsChecked(!isChecked);
  };

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={props.name || key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="number"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
      <Button color="primary" onClick={handleToggle}>
        {isChecked ? "Enabled" : "Disabled"}
      </Button>
    </FormGroup>
  );
};

export default ExcludeClone;
