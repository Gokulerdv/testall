import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  // Label,
  Input,
  InputProps,
} from "reactstrap";
import { z } from "zod";

export const key = "verifiedinpast";

export const verifiedInPastSchema = z.object({
  [key]: z.coerce
    .number({ required_error: `${capitalCase(key)} is required.` })
    // .min(1, `${capitalCase(key)} should contain at least 1 character.`)
    .optional(),
});

export type VerifiedInPastSchema = z.infer<typeof verifiedInPastSchema>;

export type VerifiedInPastProps = InputProps & {
  help?: React.ReactNode;
};

export const VerifiedInPast = (props: VerifiedInPastProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      {/* <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label> */}
      <Controller
        name={props.name || key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="number"
              min={0}
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default VerifiedInPast;
