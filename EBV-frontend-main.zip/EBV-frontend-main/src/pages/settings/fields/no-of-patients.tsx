import { capitalCase } from "change-case";
import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
} from "reactstrap";
import { z } from "zod";

export const key = "numberofpatients";

export const numberOfPatientsSchema = z.object({
  [key]: z.coerce
    .number({ required_error: `${capitalCase(key)} is required.` })
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
});

export type NumberOfPatientsSchema = z.infer<typeof numberOfPatientsSchema>;

export type NumberOfPatientsProps = InputProps & {
  help?: React.ReactNode;
};

export const NumberOfPatients = (props: NumberOfPatientsProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Controller
        name={props.name || key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="number"
              min={0}
              invalid={Boolean(fieldState.error?.message)}
              {...props}
              style={{ width: "63%" }}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default NumberOfPatients;
