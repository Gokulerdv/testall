import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  // Label,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";

export const key = "userhistoryname";

export const userHistoryNameSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    // .min(1, `${capitalCase(key)} should contain at least 1 character.`)
    .optional(),
});

export type UserHistoryNameSchema = z.infer<typeof userHistoryNameSchema>;

export type UserHistoryNameProps = InputProps & {
  help?: React.ReactNode;
};

export const UserHistoryName = (props: UserHistoryNameProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      {/* <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label> */}
      <Controller
        name={props.name || key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default UserHistoryName;
