import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  // Label,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";

export const key = "timetorun";

export const timeToRunSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .optional(),
});

export type TimeToRunSchema = z.infer<typeof timeToRunSchema>;

export type TimeToRunProps = InputProps & {
  help?: React.ReactNode;
};

export const TimeToRun = (props: TimeToRunProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Controller
        name={props.name || key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="time"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
              style={{ width: "64%" }}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default TimeToRun;
