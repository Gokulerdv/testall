import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  Label,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";

export const scheduledAction = [
  {
    value: "Eligibility Verification",
    label: "Eligibility Verification",
  },
];

export const key = "scheduledaction";

export const scheduledActionSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .min(1, `${capitalCase(key)} is required.`)
    .optional(),
});

export type ScheduledActionSchema = z.infer<typeof scheduledActionSchema>;

export type ScheduledActionProps = InputProps & {
  help?: React.ReactNode;
};

export const ScheduledAction = (props: ScheduledActionProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              {scheduledAction.map((type) => (
                <option value={type.value} key={type.value}>
                  {type.label}
                </option>
              ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default ScheduledAction;
