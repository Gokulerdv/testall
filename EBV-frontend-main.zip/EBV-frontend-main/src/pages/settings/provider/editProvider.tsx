import { faEdit } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { CellContext } from "@tanstack/react-table";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  Form,
  Input,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import ConfirmationModal from "../../../components/confirmation-modal";
import { DropdownField } from "../../../components/drop-down";
import { Field } from "../../../components/field";
import { useAuthContext } from "../../../shared/hooks/use-auth";
import { ProviderEditPermission } from "../../../utils/constant";
import { defaultMutateOptions } from "../../../utils/default-mutate-options";
import { Config } from "../../../utils/headers-config";
import { RolesPermission } from "../../../utils/role-permission";
import { Provider, providerSchema } from "./table/columns";

export const ProviderFormFields = () => {
  const auth = useAuthContext();
  const data = auth.state.user as {
    userData: {
      practice: { practiceName: string; locations: [] };
      userId: string;
    };
  };
  const locationNames =
    data?.userData?.practice?.locations?.map((e: { locationName: string }) => {
      return { key: e?.locationName, value: e?.locationName };
    }) || [];
  const practiceName = data?.userData?.practice?.practiceName || "";

  return (
    <>
      <Row className="">
        <Col md={12}>
          <Field name="doctorName" />
        </Col>
        <Col md={12}>
          <Field name="ssn" />
        </Col>
        <Col md={12}>
          <Field name="npiId" />
        </Col>
        <Col md={12}>
          <Field name="taxId" />
        </Col>
        <Col md={12}>
          <Field name="deaNumber" />
        </Col>
        <Col md={12}>
          <DropdownField
            name="practiceName"
            data={
              practiceName ? [{ key: practiceName, value: practiceName }] : []
            }
          />
        </Col>
        <Col md={12}>
          <DropdownField name="location" data={locationNames} />
        </Col>
      </Row>
    </>
  );
};

export type ProviderEdit = {
  id?: number;
  uniqueId?: string;
  doctorName?: string;
  ssn?: string;
  npiId?: string;
  taxId?: string;
  deaNumber?: string;
  practiceName?: string;
  location?: string;
  adminId?: string;
  status?: string;
};

export const EditProvider = (info: CellContext<Provider, unknown>) => {
  const auth = useAuthContext();
  const rowData = info.row.original;
  const [selectedOption, setSelectedOption] = React.useState(
    String(rowData.status)
  );

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleRadioChange = (e: any) => {
    const value = e.target.value;
    setSelectedOption(value);
  };

  const methods = useForm<Provider>({
    resolver: zodResolver(providerSchema),
  });

  React.useEffect(() => {
    methods.reset({
      doctorName: rowData.doctorName,
      ssn: String(rowData.ssn),
      npiId: String(rowData.npiId),
      taxId: String(rowData.taxId),
      deaNumber: String(rowData.deaNumber),
      practiceName: rowData.practiceName,
      location: rowData.location,
      status: String(rowData.status),
    });
    setSelectedOption(String(rowData.status));
  }, [methods, rowData]);

  const { open, toggle } = useDialogWithFormReset(methods);
  const providerEdit = async (body: ProviderEdit) => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/provider/update/${
      rowData.uniqueId
    }`;

    return await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(body),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };
  const provider = useMutation({
    mutationKey: ["provider/edit"],
    mutationFn: providerEdit,
  });
  const queryClient = useQueryClient();
  const onSubmit: SubmitHandler<Provider> = async (data) => {
    try {
      const requestPayload = { ...data, status: selectedOption };

      const response = await provider.mutateAsync(
        requestPayload,
        defaultMutateOptions
      );
      if (!response?.error) {
        toast.success("Provider updated successfully");
        toggle();
      } else {
        toast.error(response?.message || "An error occurred!");
      }
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      queryClient.invalidateQueries({
        queryKey: ["provider", "getAll"],
      });
    }
  };

  return (
    <>
      {RolesPermission(ProviderEditPermission) && (
        <FontAwesomeIcon
          icon={faEdit}
          onClick={toggle}
          className="text-primary"
        />
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size="lg"
        direction="end"
        style={{ width: "37%" }}
      >
        <OffcanvasHeader
          className=" border-bottom w-100"
          style={{ width: "100%!important" }}
          close={
            <div
              className="hstack justify-content-between "
              style={{ width: "100%" }}
            >
              <div className="title" style={{ fontSize: "20px" }}>
                Edit
              </div>
              <div className="gap-2 hstack">
                <Button color="primary" outline onClick={toggle}>
                  Cancel
                </Button>
                <ConfirmationModal
                  onClick={methods.handleSubmit(onSubmit)}
                  value="Save"
                />
              </div>
            </div>
          }
        ></OffcanvasHeader>

        <OffcanvasBody style={{ paddingLeft: "30px" }}>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <ProviderFormFields />
              <div className="vstack">
                <Label>Status</Label>
                <Label check>
                  <Input
                    type="radio"
                    name="Active"
                    value="true"
                    checked={selectedOption === "true"}
                    onChange={handleRadioChange}
                  />
                  Active
                </Label>
                <Label check>
                  <Input
                    type="radio"
                    name="Inactive"
                    value="false"
                    checked={selectedOption === "false"}
                    onChange={handleRadioChange}
                  />
                  Inactive
                </Label>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </>
  );
};

export default EditProvider;
