import React from "react";
import { Card } from "reactstrap";
import { ProviderTable } from "../provider/table";
export const Provider = React.memo(() => {
  return (
    <>
      <Card>
        <React.Suspense>
          <ProviderTable />
        </React.Suspense>
      </Card>
    </>
  );
});

export default Provider;
