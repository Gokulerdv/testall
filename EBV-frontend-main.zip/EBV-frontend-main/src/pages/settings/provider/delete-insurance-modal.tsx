import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";

import { CellContext } from "@tanstack/react-table";
import { toast } from "react-toastify";

import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { useAuthContext } from "../../../shared/hooks/use-auth";
import { ProviderDeletePermission } from "../../../utils/constant";
import { Config } from "../../../utils/headers-config";
import { RolesPermission } from "../../../utils/role-permission";
import { Provider } from "./table/columns";

export const DeleteModal = (info: CellContext<Provider, unknown>) => {
  const auth = useAuthContext();
  const rowData = info.row.original;

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const providerDelete = async () => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/provider/delete/${
      rowData.uniqueId
    }`;

    return await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };
  const provider = useMutation({
    mutationKey: ["provider/delete"],
    mutationFn: providerDelete,
  });
  const queryClient = useQueryClient();

  const deletePatient = async () => {
    try {
      if (!rowData.uniqueId) return;

      const response = await provider.mutateAsync();
      if (response?.data?.length) {
        toast.success("Provider deleted successfully");
        toggle();
      } else {
        toast.error(response?.message || "An error occurred!");
      }
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      queryClient.invalidateQueries({
        queryKey: ["provider", "getAll"],
      });
    }
  };

  return (
    <>
      {RolesPermission(ProviderDeletePermission) && (
        <FontAwesomeIcon
          icon={faTrash}
          className="text-primary"
          onClick={toggle}
        />
      )}

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md" centered>
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" onClick={deletePatient}>
              {provider.isPending ? (
                <>
                  <Spinner size="sm">Deleting...</Spinner>
                  <span> Deleting...</span>
                </>
              ) : (
                <span>Yes</span>
              )}
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default DeleteModal;
