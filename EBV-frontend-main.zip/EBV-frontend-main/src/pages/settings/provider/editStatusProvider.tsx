import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CellContext } from "@tanstack/react-table";
import { toast } from "react-toastify";
import { FormGroup, Input } from "reactstrap";
import { useAuth } from "../../../shared/hooks/use-auth";
import { defaultMutateOptions } from "../../../utils/default-mutate-options";
import { Config } from "../../../utils/headers-config";
import { Provider } from "./table/columns";

export type ProviderEdit = {
  id?: number;
  uniqueId?: string;
  doctorName?: string;
  ssn?: string;
  npiId?: string;
  taxId?: string;
  deaNumber?: string;
  practiceName?: string;
  location?: string;
  adminId?: string;
  status?: boolean;
};

export const EditStatusProvider = (info: CellContext<Provider, unknown>) => {
  const rowData = info.row.original;
  const auth = useAuth();

  const providerEdit = async (body: ProviderEdit) => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/provider/update/${
      rowData.uniqueId
    }`;

    return await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(body),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };
  const provider = useMutation({
    mutationKey: ["provider/edit"],
    mutationFn: providerEdit,
  });
  const queryClient = useQueryClient();
  const onSubmit = async (value: boolean) => {
    try {
      const requestPayload = { ...rowData, status: !value };

      const response = await provider.mutateAsync(
        requestPayload,
        defaultMutateOptions
      );
      if (!response?.error) {
        if (value === true) {
          toast.success("Provider deactivated succesfully ");
        } else {
          toast.success("Provider activated succesfully ");
        }
      } else {
        toast.error(response?.message || "An error occurred!");
      }
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      queryClient.invalidateQueries({
        queryKey: ["provider", "getAll"],
      });
    }
  };

  return (
    <>
      <div className="verification_switch d-flex">
        <FormGroup switch name="isverifiedautomatically">
          <Input
            name="status"
            role="switch"
            type="switch"
            className="ml-4"
            checked={Boolean(info.getValue())}
            onChange={() => {
              onSubmit(Boolean(info.getValue()));
            }}
          />
        </FormGroup>
      </div>
    </>
  );
};

export default EditStatusProvider;
