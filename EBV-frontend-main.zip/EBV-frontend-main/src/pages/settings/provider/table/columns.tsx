import { createColumnHelper } from "@tanstack/react-table";
import { DeepPartial } from "react-hook-form";
import { z } from "zod";
import { Response } from "../../../../apis/mocks/response";
import DeleteModal from "../delete-insurance-modal";
import EditProvider from "../editProvider";
import EditStatusProvider from "../editStatusProvider";

export const providerSchema = z.object({
  id: z.number().optional(),
  uniqueId: z.string().optional(),
  doctorName: z.string().min(1),
  ssn: z.string().regex(/^[a-zA-Z0-9]{9}$/, "Must be of length 9"),
  npiId: z.string().regex(/^[a-zA-Z0-9]{10}$/, "Must be of length 10"),
  taxId: z.string().regex(/^[a-zA-Z0-9]{9}$/, "Must be of length 9"),
  deaNumber: z.string().regex(/^[a-zA-Z0-9]+$/, "Required"),
  practiceName: z.string().min(1),
  location: z.string().min(1),
  adminId: z.string().optional(),
  status: z.string().optional(),
  providerOption: z.string().optional(),
});

export type Provider = z.infer<typeof providerSchema> & {
  [key: string]: unknown;
};
export type Providers = DeepPartial<Provider>[];

export type ProvidersAllResponse = Response<Providers>;

const columnHelper = createColumnHelper<Provider>();

export const defaultColumns = [
  columnHelper.accessor("doctorName", {
    cell: (info) => info.getValue(),
    header: "Doctor Name",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("ssn", {
    cell: (info) => "XXXXX" + String(info.getValue()).slice(-4),
    header: "SSN/TIN Number",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("npiId", {
    cell: (info) => info.getValue(),
    header: "NPI ID",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("taxId", {
    cell: (info) => "XXXXX" + String(info.getValue()).slice(-4),
    header: "Tax ID",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("deaNumber", {
    cell: (info) => info.getValue(),
    header: "DEA Number",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("practiceName", {
    cell: (info) => info.getValue(),
    header: "Practice Name",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("location", {
    cell: (info) => info.getValue(),
    header: "Location",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("adminId", {
    cell: (info) => info.getValue(),
    header: "Admin Id",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("status", {
    cell: (info) => <EditStatusProvider {...info} />,
    header: "Status",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.display({
    id: "actions",
    header: "Actions",
    cell: (info) => (
      <div className="gap-2 hstack">
        <EditProvider {...info} />
        <DeleteModal {...info} />
      </div>
    ),
    enableHiding: true,
  }),
];
