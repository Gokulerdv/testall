import {
  faSearch,
  faSortDown,
  faSortUp,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useSuspenseQuery } from "@tanstack/react-query";
import {
  PaginationState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import { Button, InputGroup, InputGroupText } from "reactstrap";
import DebouncedInput from "../../../../components/debounced-input";
import { useAuthContext } from "../../../../shared/hooks/use-auth";
import { ProviderCreatePermission } from "../../../../utils/constant";
import { fuzzyFilter } from "../../../../utils/fuzzy-filter";
import { Config } from "../../../../utils/headers-config";
import { RolesPermission } from "../../../../utils/role-permission";
import NewProvider from "../../provider/new-provider-model";
import {
  Provider,
  ProvidersAllResponse,
  defaultColumns,
} from "../../provider/table/columns";
import Pagination from "../../provider/table/pagination";

export const ProviderTable = () => {
  const [globalFilter, setGlobalFilter] = React.useState("");
  const [search, setSearch] = React.useState("");
  const auth = useAuthContext();
  const userId = auth?.state?.user?.userData?.userId;
  const handleClearGlobalFilter = () => {
    setSearch("");
    setGlobalFilter("");
  };

  const handleSetGlobalFilter = () => {
    setGlobalFilter(search);
  };
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [pagination, setPagination] = React.useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const ProvidersAll = async (): Promise<ProvidersAllResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/provider/getAll/${userId}`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as ProvidersAllResponse;
    return response;
  };

  const providerdataResp = useSuspenseQuery({
    queryKey: ["provider", "getAll"],
    queryFn: ProvidersAll,
  });
  const data = React.useMemo(() => {
    return providerdataResp.data.data;
  }, [providerdataResp.data.data]);

  const onSuccess = React.useCallback(async () => {
    await providerdataResp.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const table = useReactTable({
    columns: defaultColumns,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: data as any,
    state: {
      sorting,
      pagination,
      globalFilter,
    },
    globalFilterFn: fuzzyFilter<Provider>(),
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),
    debugTable: true,
  });
  return (
    <div className="table-responsive">
      {import.meta.env.DEV ? (
        <ReactTableDevtools initialIsOpen={false} table={table} />
      ) : null}
      <table className="table mb-0 table-striped table-hover table-borderless">
        <thead>
          <tr>
            <th colSpan={table.getVisibleLeafColumns().length} className="p-0">
              <div className="p-3 hstack justify-content-between border-bottom">
                <div className="gap-2 hstack">
                  <InputGroup className="w-100">
                    <InputGroupText>
                      <FontAwesomeIcon icon={faSearch} />
                    </InputGroupText>
                    <DebouncedInput
                      value={search ?? ""}
                      onChange={(value) => setSearch(String(value))}
                      placeholder="Search content"
                    />
                  </InputGroup>
                  <Button color="primary" onClick={handleSetGlobalFilter}>
                    Search
                  </Button>
                  <Button
                    outline={true}
                    color="primary"
                    onClick={handleClearGlobalFilter}
                  >
                    Clear
                  </Button>
                </div>
                <div>
                  {RolesPermission(ProviderCreatePermission) && (
                    <NewProvider onSuccess={onSuccess} />
                  )}
                </div>
              </div>
            </th>
          </tr>
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <th
                  key={header.id}
                  colSpan={header.colSpan}
                  className="border-bottom"
                >
                  {header.isPlaceholder ? null : (
                    <div
                      {...{
                        className: "hstack align-items-center",
                        style: header.column.getCanSort()
                          ? {
                              cursor: "pointer",
                              userSelect: "none",
                            }
                          : undefined,
                        onClick: header.column.getToggleSortingHandler(),
                      }}
                    >
                      <span style={{ maxWidth: "fit-content" }}>
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                      </span>

                      {header.column.getCanSort() ? (
                        <span
                          className="vstack justify-content-center align-items-center ms-2"
                          style={{
                            maxWidth: "min-content",
                          }}
                        >
                          <FontAwesomeIcon
                            className={`${(() => {
                              if (header.column.getIsSorted() === "asc")
                                return "text-black";
                              return "text-body-tertiary";
                            })()}`}
                            icon={faSortUp}
                            style={{ marginBottom: "-1rem" }}
                          />
                          <FontAwesomeIcon
                            className={`${(() => {
                              if (header.column.getIsSorted() === "desc")
                                return "text-black";
                              return "text-body-tertiary";
                            })()}`}
                            icon={faSortDown}
                          />
                        </span>
                      ) : null}
                    </div>
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id}>
              {row.getVisibleCells().map((cell) => (
                <td
                  key={cell.id}
                  style={{
                    backgroundColor:
                      row.original.statusflag === "I"
                        ? "rgba(0, 0, 0, 0.2)"
                        : "initial",
                  }}
                >
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        <Pagination table={table} />
      </table>
    </div>
  );
};
