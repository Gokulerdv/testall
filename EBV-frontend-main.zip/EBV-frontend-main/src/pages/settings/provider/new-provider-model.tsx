import React from "react";

import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  Input,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import ConfirmationModal from "../../../components/confirmation-modal";
import { DropdownField } from "../../../components/drop-down";
import { Field } from "../../../components/field";
import { useAuth, useAuthContext } from "../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import { defaultMutateOptions } from "../../../utils/default-mutate-options";
import { Config } from "../../../utils/headers-config";
import { Provider, providerSchema } from "./table/columns";

export const ProviderFormFields = () => {
  const auth = useAuthContext();
  const data = auth.state.user as {
    userData: {
      practice: { practiceName: string; locations: [] };
      userId: string;
    };
  };

  const locationNames =
    data?.userData?.practice?.locations.map((e: { locationName: string }) => {
      return { key: e?.locationName, value: e?.locationName };
    }) || [];

  const practiceName = data?.userData?.practice?.practiceName || "";

  return (
    <>
      <Row className="">
        <Col md={12}>
          <Field name="doctorName" />
        </Col>
        <Col md={12}>
          <Field name="ssn" />
        </Col>
        <Col md={12}>
          <Field name="npiId" />
        </Col>
        <Col md={12}>
          <Field name="taxId" />
        </Col>
        <Col md={12}>
          <Field name="deaNumber" />
        </Col>
        <Col md={12}>
          <DropdownField
            name="practiceName"
            data={
              practiceName ? [{ key: practiceName, value: practiceName }] : []
            }
          />
        </Col>
        <Col md={12}>
          <DropdownField name="location" data={locationNames} />
        </Col>
      </Row>
    </>
  );
};
export type ProviderModalProps = {
  onSuccess?: () => Promise<void>;
};

export type Provideradd = {
  doctorName?: string;
  ssn?: string;
  npiId?: string;
  taxId?: string;
  deaNumber?: string;
  practiceName?: string;
  location?: string;
  adminId?: string;
  status?: string;
};
export const NewProvider = (props: ProviderModalProps) => {
  const methods = useForm<Provider>({
    resolver: zodResolver(providerSchema),
  });
  const { open, toggle } = useDialogWithFormReset(methods);
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;

  const providerAdd = async (body: Provideradd) => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/provider/create`;

    return await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(body),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();
  };

  const provider = useMutation({
    mutationKey: ["provider/add"],
    mutationFn: providerAdd,
  });
  const queryClient = useQueryClient();

  const onSubmit: SubmitHandler<Provider> = async (data) => {
    try {
      const requestPayload = {
        ...data,
        status: selectedOption,
        adminId: `${userId}`,
      };

      const response = await provider.mutateAsync(
        requestPayload,
        defaultMutateOptions
      );
      if (response?.data?.id) {
        props.onSuccess?.();
        toast.success("Provider added successfully");
        toggle();
      } else {
        toast.error(response?.message || "An error occurred!");
      }
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      queryClient.invalidateQueries({
        queryKey: ["provider", "getAll"],
      });
    }
  };

  const [selectedOption, setSelectedOption] = React.useState("false");

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleRadioChange = (e: any) => {
    const value = e.target.value;
    setSelectedOption(value);
  };
  return (
    <>
      <Button color="primary" className="text-white" onClick={toggle}>
        <div className="gap-2 mb-0 hstack">
          <FontAwesomeIcon icon={faPlus} />
          <span className="mb-0">New</span>
        </div>
      </Button>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size="lg"
        direction="end"
        style={{ width: "37%" }}
      >
        <OffcanvasHeader
          className=" border-bottom w-100"
          style={{ width: "100%!important" }}
          close={
            <div
              className="hstack justify-content-between "
              style={{ width: "100%" }}
            >
              <div className="title" style={{ fontSize: "20px" }}>
                New
              </div>
              <div className="gap-2 hstack">
                <Button color="primary" outline onClick={toggle}>
                  Cancel
                </Button>
                <ConfirmationModal
                  onClick={methods.handleSubmit(onSubmit)}
                  value="Submit"
                />
              </div>
            </div>
          }
        ></OffcanvasHeader>
        <OffcanvasBody style={{ paddingLeft: "30px" }}>
          <FormProvider {...methods}>
            <Form>
              <ProviderFormFields />
              <div className="vstack">
                <Label>Status</Label>
                <Label check>
                  <Input
                    type="radio"
                    name="Active"
                    value="true"
                    checked={selectedOption === "true"}
                    onChange={handleRadioChange}
                  />
                  Active
                </Label>
                <Label check>
                  <Input
                    type="radio"
                    name="Inactive"
                    value="false"
                    checked={selectedOption === "false"}
                    onChange={handleRadioChange}
                  />
                  Inactive
                </Label>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </>
  );
};

export default NewProvider;
