import { Card } from "reactstrap";
import ProcedureCodeMapperTable from "./table";
export const ProcedureCodeMapper = () => {
  return (
    <>
      <Card>
        <ProcedureCodeMapperTable />
      </Card>
    </>
  );
};

export default ProcedureCodeMapper;
