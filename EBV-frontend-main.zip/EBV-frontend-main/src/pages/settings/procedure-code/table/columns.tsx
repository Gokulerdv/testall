import { createColumnHelper } from "@tanstack/react-table";
import AlignTableItems from "../../../../components/align-table-items";

export type ProcedureCode = {
  id: string;
  procedureCode: string;
  procedureType: string;
  description: string;
};

const columnHelper = createColumnHelper<ProcedureCode>();

export const defaultColumns = [
  columnHelper.accessor("id", {
    // id: "serialNumber",
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    // cell: (info) => String(info.row.index + 1).padStart(2, "0"),
    header: "S.no",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("procedureCode", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Procedure Code",
    footer: (props) => props.column.id,
    enableGlobalFilter: true,
  }),
  columnHelper.accessor("procedureType", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Procedure Type",
    footer: (props) => props.column.id,
    enableColumnFilter: true,
    filterFn: "arrIncludesSome",
    enableGlobalFilter: false,
  }),
  columnHelper.accessor("description", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Description",
    footer: (props) => props.column.id,
    filterFn: "equals",
    enableColumnFilter: false,
    enableGlobalFilter: true,
  }),
];
