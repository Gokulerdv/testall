/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faClose,
  faSortDown,
  faSortUp,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useSuspenseQuery } from "@tanstack/react-query";
import {
  ColumnFiltersState,
  FilterFn,
  PaginationState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import { FormProvider, useForm } from "react-hook-form";
import { Button, Form } from "reactstrap";
import Pagination from "../../../eligibility/table/pagination";
// import ClearingHouse from "./clearing-house";
import { ProcedureCode, defaultColumns } from "./columns";
// import Filter from "./procedure-type";
import { Divider, Popover, Stack, Typography } from "@mui/material";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";
import Filter from "./procedure-type";
import SearchInput from "./search";

export type ProcedureCodeSearch = {
  search: string;
  procedureType: string;

  // clearingHouse: string;
};
export const ProcedureCodeMapperTable = () => {
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [globalFilter, setGlobalFilter] = React.useState("");
  // const [dropdownOpen, setDropdownOpen] = useState(false);

  // const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  // const [procedureType, setProcedureType] = useState(""); // State for procedure type
  // const [dropdownOpen, setDropdownOpen] = useState(false);
  // const toggleDropdown = () => setDropdownOpen((prevState) => !prevState);

  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [pagination, setPagination] = React.useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const methods = useForm<ProcedureCodeSearch>({
    defaultValues: {
      search: "",
      procedureType: "",
    },
  });
  const auth = useAuth();
  const getAll = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/procedurecodes/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
    return response.json();
  };

  const { data: procedureCodeData } = useSuspenseQuery({
    queryKey: ["procedurecodes", "procedureCodesGetAll"],
    queryFn: getAll,
  });
  const customGlobalFilterFn: FilterFn<ProcedureCode> = (
    row: any,
    columnIds,
    filterValue
  ) => {
    const nonSearchColumnsIds = ["procedureType"];
    if (nonSearchColumnsIds.includes(columnIds)) {
      return false;
    } else {
      const value = row.getValue(columnIds);
      return (
        value !== undefined &&
        String(value).toLowerCase().includes(filterValue.toLowerCase())
      );
    }
  };
  const table = useReactTable({
    columns: defaultColumns,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: procedureCodeData.data as any,
    state: {
      columnFilters,
      sorting,
      pagination,
      globalFilter,
    },
    // globalFilterFn: fuzzyFilter<ProcedureCode>(),
    globalFilterFn: customGlobalFilterFn,
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),
    debugTable: true,
  });
  const procedureTypeColumn = table.getColumn("procedureType");
  const handleReset = () => {
    methods.reset({
      search: "",
      procedureType: "",
    });
    setColumnFilters([]);
    setGlobalFilter("");
  };
  // const [modalOpen, setModalOpen] = useState(false);

  // const toggleModal = () => {
  //   setModalOpen(!modalOpen);
  // };

  // const filterButtonRef = useRef<HTMLButtonElement>(null); // Specify the type of ref
  // const [modalPosition, setModalPosition] = useState({ top: 150, right: 0 });

  // useEffect(() => {
  //   if (filterButtonRef.current) {
  //     const buttonRect = filterButtonRef.current.getBoundingClientRect(); // Assert type here
  //     setModalPosition({
  //       top: buttonRect.bottom + window.pageYOffset,
  //       right: buttonRect.right + window.pageXOffset,
  //     });
  //   }
  // }, [dropdownOpen]);

  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(
    null
  );

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  // const id = open ? "simple-popover" : undefined;
  return (
    <>
      {" "}
      <div className="table-responsive">
        {import.meta.env.DEV ? (
          <ReactTableDevtools initialIsOpen table={table} />
        ) : null}
        <table className="table mb-0 table-striped table-hover table-borderless">
          <thead>
            <tr>
              <th
                colSpan={table.getVisibleLeafColumns().length}
                className="p-0"
              >
                <div className="p-3 hstack justify-content-between border-bottom">
                  <div className="gap-2 hstack">
                    <FormProvider {...methods}>
                      <Form
                        className="gap-2 hstack"
                        onSubmit={(e) => e.preventDefault()}
                        // onSubmit={methods.handleSubmit(onSubmit, console.log)}
                      >
                        {/* <Input
                          value={globalFilter ?? ""}
                          onChange={(e) => setGlobalFilter(e.target.value)}
                          placeholder="Search content"
                          style={{ width: "100px !important" }}
                        /> */}
                        <SearchInput
                          name="search"
                          onGlobalFilterChange={setGlobalFilter}
                        />
                        <div>
                          <Button
                            // ref={filterButtonRef}
                            outline
                            color="primary"
                            onClick={(
                              event: React.MouseEvent<HTMLButtonElement>
                            ) => handleClick(event)}
                          >
                            Filters
                          </Button>
                          <Popover
                            id="simple-popover"
                            open={open}
                            anchorEl={anchorEl}
                            onClose={handleClose}
                            anchorOrigin={{
                              vertical: "bottom",
                              horizontal: "left",
                            }}
                          >
                            <Typography component="div">
                              <Stack
                                direction="row"
                                className="d-flex justify-content-between"
                                sx={{ p: 2 }}
                              >
                                <Typography variant="h6">Filter</Typography>
                                <Typography variant="h6">
                                  <FontAwesomeIcon
                                    className="cursorPointer"
                                    icon={faClose}
                                    onClick={handleClose}
                                  />
                                </Typography>
                              </Stack>
                              <Divider />
                              <Stack sx={{ p: 2 }}>
                                <div>Procedure Type</div>
                                <Filter
                                  column={procedureTypeColumn}
                                  table={table}
                                />{" "}
                              </Stack>
                            </Typography>
                          </Popover>
                        </div>
                      </Form>
                    </FormProvider>
                    <Button onClick={handleReset} outline color="primary">
                      Clear All
                    </Button>
                  </div>
                </div>
              </th>
            </tr>

            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    className="border-bottom"
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        {...{
                          className: "hstack align-items-center",
                          style: header.column.getCanSort()
                            ? {
                                cursor: "pointer",
                                userSelect: "none",
                              }
                            : undefined,
                          onClick: header.column.getToggleSortingHandler(),
                        }}
                      >
                        <span style={{ maxWidth: "fit-content" }}>
                          {flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                        </span>

                        {header.column.getCanSort() ? (
                          <span
                            className="vstack justify-content-center align-items-center ms-2"
                            style={{
                              maxWidth: "min-content",
                            }}
                          >
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "asc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortUp}
                              style={{ marginBottom: "-1rem" }}
                            />
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "desc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortDown}
                            />
                          </span>
                        ) : null}
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>

          <tbody>
            {table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={24} style={{ textAlign: "center" }}>
                  No Record found{" "}
                </td>
              </tr>
            ) : null}
            {!procedureCodeData.isFetching && !procedureCodeData.isError ? (
              table.getRowModel().rows.map((row) => (
                <tr key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={table.getVisibleLeafColumns().length}
                  className="text-center"
                >
                  {procedureCodeData.isError
                    ? "Error fetching data"
                    : "Loading..."}
                </td>
              </tr>
            )}
          </tbody>

          <Pagination table={table} />
        </table>
      </div>
    </>
  );
};
export default ProcedureCodeMapperTable;
