/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Checkbox,
  FormControl,
  ListItemText,
  MenuItem,
  OutlinedInput,
  Select,
  SelectChangeEvent,
} from "@mui/material";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Column, RowData, Table } from "@tanstack/react-table";
import React, { useEffect } from "react";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { Config } from "../../../../utils/headers-config";

type SelectInputProps = {
  columnFilterValue: string[] | null;
  setFilterValue: (updater: any) => void;
};

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const SelectInput: React.FC<SelectInputProps> = ({
  columnFilterValue,
  setFilterValue,
}) => {
  const auth = useAuth();
  const getAll = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/procedurecodes/types`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
    return response.json();
  };

  const { data: procedureCodeData } = useSuspenseQuery({
    queryKey: ["procedureCode", "getAll"],
    queryFn: getAll,
  });

  const [personName, setPersonName] = React.useState<string[]>([]);

  const handleChange = (event: SelectChangeEvent<typeof personName>) => {
    const { value } = event.target;
    if (value.includes("all")) {
      // If "All" is selected
      if (personName.length === procedureCodeData?.data?.length) {
        // If all checkboxes are already selected, deselect all
        setPersonName([]);
        setFilterValue([]);
      } else {
        // Otherwise, select all checkboxes
        const allValues = procedureCodeData?.data ?? [];
        setPersonName(allValues);
        setFilterValue(allValues);
      }
    } else {
      // If individual checkboxes are selected
      setPersonName(value as string[]);
      setFilterValue(value as string[]);
    }
  };

  useEffect(() => {
    if (columnFilterValue) {
      setPersonName(columnFilterValue);
    }
  }, [columnFilterValue]);
  return (
    <FormControl sx={{ m: 1, width: 300 }}>
      <Select
        labelId="demo-multiple-checkbox-label"
        id="demo-multiple-checkbox"
        multiple
        value={personName}
        onChange={handleChange}
        displayEmpty
        input={<OutlinedInput />}
        size="small"
        renderValue={
          personName.length === 0
            ? () => <div>Select...</div>
            : (selected) => selected.join(", ")
        }
        // renderValue={(selected) => selected.join(', ')}
        MenuProps={MenuProps}
        inputProps={{ "aria-label": "Without label" }}
      >
        <MenuItem key={"all"} value={"all"}>
          <Checkbox
            checked={personName.length === procedureCodeData?.data?.length}
          />
          <ListItemText primary={"all"} />
        </MenuItem>
        {/* <Divider style={{ backgroundColor: "black" }} /> */}

        {procedureCodeData.data.map((name: any) => (
          <MenuItem key={name} value={name}>
            <Checkbox checked={personName.indexOf(name) > -1} />
            <ListItemText primary={name} />
            {/* <Divider style={{ backgroundColor: "black" }} /> */}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

type Props<T extends RowData> = {
  column: Column<T, unknown> | undefined;
  table: Table<T>;
};

export function Filter<T extends RowData>({ column }: Props<T>) {
  if (column === undefined) return;
  const columnFilterValue = column.getFilterValue() as string[];

  return (
    <SelectInput
      columnFilterValue={columnFilterValue || []}
      setFilterValue={column.setFilterValue}
    />
  );
}

export default Filter;
