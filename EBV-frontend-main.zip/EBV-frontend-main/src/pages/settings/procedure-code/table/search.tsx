import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useController, useFormContext } from "react-hook-form";
import { Input, InputProps } from "reactstrap";

export type FieldProps = InputProps & {
  help?: React.ReactNode;
  name: string;
  onGlobalFilterChange: (value: string) => void;
};

export const SearchInput = ({
  name,
  onGlobalFilterChange,
  ...props
}: FieldProps) => {
  const { control } = useFormContext();
  const { field } = useController({ name, control });

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    field.onChange(value);
    onGlobalFilterChange(value);
  };

  return (
    <div style={{ position: "relative", width: "100%" }}>
      <FontAwesomeIcon
        icon={faSearch}
        style={{
          position: "absolute",
          left: "10px",
          top: "50%",
          transform: "translateY(-50%)",
          color: "#aaa", // Change color as needed
        }}
      />
      <Input
        {...field} // Include field properties from react-hook-form
        id="exampleEmail"
        placeholder="search"
        type="search"
        style={{
          width: "100%",
          paddingLeft: "30px", // Adjust padding to make space for the icon
          boxSizing: "border-box",
        }}
        onChange={handleChange}
        {...props}
      >
        {props.children}
      </Input>
    </div>
  );
};

export default SearchInput;
