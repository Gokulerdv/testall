/* eslint-disable @typescript-eslint/no-explicit-any */
import { faPenToSquare, faTrashCan } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import { NavLink as RouterLink } from "react-router-dom";
import { Button } from "reactstrap";

import { useSuspenseQuery } from "@tanstack/react-query";
import { useAuth } from "../../shared/hooks/use-auth";
import {
  CreateScheduleDeletePermission,
  CreateScheduleEditPermission,
  CreateScheduleViewPermission,
} from "../../utils/constant";
import { Config } from "../../utils/headers-config";
import { RolesPermission } from "../../utils/role-permission";
import ErrorLogs from "./errorlogs";
import ScheduleModal from "./schedule-modal";

export const Schedule = () => {
  const [errorsId, setErrorId] = useState(null);
  const [isErrorsModalOpen, setIsErrorsModalOpen] = useState(false);
  const auth = useAuth();

  const adminId = auth?.state?.user?.userData?.userId;

  const getLog = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/scheduledLogs/getScheduledLogs/${adminId}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/scheduledSettings/getAll/${adminId}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const toggleErrorsModal = (itemId: any) => {
    setIsErrorsModalOpen(!isErrorsModalOpen);
    setErrorId(itemId);
  };

  const { data: scheduledData } = useSuspenseQuery({
    queryKey: ["scheduled", "getAll", adminId],
    queryFn: getAll,
  });

  const { data: scheduledLog } = useSuspenseQuery({
    queryKey: ["scheduled", "getLog", adminId],
    queryFn: getLog,
  });

  return (
    <React.Suspense fallback={"loading data..."}>
      <hr className="hr-specs" />
      <div className="d-flex justify-content-between">
        <div>
          <h6>Scheduled Process</h6>
        </div>
        <div>
          <ScheduleModal />
        </div>
      </div>
      {RolesPermission(CreateScheduleViewPermission) && (
        <table className="table payer_table ">
          <thead>
            <tr>
              <th scope="col">Scheduled Action</th>
              <th scope="col">Frequency Run</th>
              <th scope="col">Time To Run</th>
              <th scope="col">No. of Patient</th>
              <th scope="col">Logs</th>
            </tr>
          </thead>
          <tbody>
            {scheduledData?.data?.map((item: any) => (
              <>
                <tr key={item.id} className="table-secondary ">
                  <td>{item.scheduledaction}</td>
                  <td>
                    {item.isweekly
                      ? "Weekly"
                      : item.isdaily
                      ? "Daily"
                      : item.ismonthly
                      ? "Monthly"
                      : item.weeklydays
                      ? "Weekdays"
                      : null}
                  </td>
                  <td>{item.timetorun}</td>
                  <td>{item.numberofpatients}</td>
                  <td>
                    <Button
                      color="link"
                      className="p-0"
                      style={{ textAlign: "left" }}
                      onClick={() => toggleErrorsModal(item.id)}
                    >
                      Logs
                    </Button>
                  </td>
                  <ErrorLogs
                    isOpen={isErrorsModalOpen && errorsId === item.id}
                    toggle={toggleErrorsModal}
                    className="your-modal-class"
                    title="Error Logs"
                    itemId={errorsId}
                  />
                  {RolesPermission(CreateScheduleEditPermission) && (
                    <td>
                      <RouterLink
                        to={`${item.id}/schedule-edit`}
                        state={item}
                        className="text-decoration-none"
                      >
                        <FontAwesomeIcon
                          className="cursorPointer"
                          icon={faPenToSquare}
                          color="#09ab89"
                        />
                      </RouterLink>
                    </td>
                  )}
                  {RolesPermission(CreateScheduleDeletePermission) && (
                    <td className="w-25">
                      <RouterLink
                        to={`${item.id}/schedule-delete`}
                        state={item}
                        className="text-decoration-none"
                      >
                        <FontAwesomeIcon
                          className="cursorPointer"
                          icon={faTrashCan}
                          color="#09ab89"
                        />
                      </RouterLink>
                    </td>
                  )}
                </tr>
              </>
            ))}
          </tbody>
        </table>
      )}

      <div className="d-flex justify-content-between">
        <h6>Scheduled Log</h6>
      </div>
      <table className="table payer_table ">
        <thead>
          <tr>
            <th scope="col">Scheduled Action</th>
            <th scope="col">Frequency Run</th>
            <th scope="col">Time To Run</th>
            <th scope="col">Time to Last Run</th>
          </tr>
        </thead>
        <tbody>
          {scheduledLog?.data?.map((item: any) => (
            <>
              <tr key={item.adminId} className="table-secondary ">
                <td>{item.scheduledaction}</td>
                <td>
                  {item?.isWeekly
                    ? "Weekly"
                    : item?.isDaily
                    ? "Daily"
                    : item?.isMonthly
                    ? "Monthly"
                    : ""}
                </td>
                <td>{item?.timeToRun}</td>
                <td></td>
              </tr>
            </>
          ))}
        </tbody>
      </table>
    </React.Suspense>
  );
};
export default Schedule;
