/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSuspenseQuery } from "@tanstack/react-query";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import { useAuth } from "../../shared/hooks/use-auth";
import { Config } from "../../utils/headers-config";

export const ErrorLogs = (props: {
  isOpen: any;
  toggle: any;
  className: any;
  title: string;
  itemId: any;
  children?: React.ReactNode;
}) => {
  const { isOpen, toggle, title } = props;
  const auth = useAuth();

  const getAll = async (): Promise<any> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/Errorlogs/getAll`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: errorLogsData } = useSuspenseQuery({
    queryKey: ["errorlogs", "getAll"],
    queryFn: getAll,
  });

  return (
    <>
      <Modal className="modal_main" isOpen={isOpen} toggle={toggle} centered>
        <ModalHeader toggle={toggle}>{title}</ModalHeader>
        <ModalBody className="modal_body f-13">
          <table className="table table-striped ">
            <thead>
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Log File</th>
                <th scope="col">Last Modified</th>
                <th scope="col">Size</th>
              </tr>
            </thead>
            <tbody>
              {errorLogsData?.data?.map((item: any) => (
                <>
                  <tr key={item.id}>
                    <td>{item.date}</td>
                    <td>
                      <Button color="link" className="p-0">
                        {item.logfile}
                      </Button>
                    </td>
                    <td>{item.updatedAt}</td>
                    <td>{item.size}</td>
                  </tr>
                </>
              ))}
            </tbody>
          </table>
        </ModalBody>
      </Modal>
    </>
  );
};
export default ErrorLogs;
