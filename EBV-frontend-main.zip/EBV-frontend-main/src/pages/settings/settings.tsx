import React from "react";

import { Nav, NavItem, NavLink, TabContent, TabPane } from "reactstrap";

import {
  GeneralSettingsViewPermission,
  InsurancePayerViewPermission,
  ProcedureCodeViewPermission,
  ProviderViewPermission,
} from "../../utils/constant";
import { RolesPermission } from "../../utils/role-permission";
import Provider from "../settings/provider";
import GlobalInsurance from "./GlobalInsurance";
import Notifications from "./Notifications";
import MyInsuranceMapper from "./insurance-mapping";
import MyInsurancePayer from "./my-insurance-payer";
import ProcedureCodeMapper from "./procedure-code";
const Settings = () => {
  const [activeTab, setActiveTab] = React.useState("1");
  const toggle = (tab: React.SetStateAction<string>) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  return (
    <>
      <div className="p-3 m-3 bg-white ">
        <Nav pills>
          {RolesPermission(GeneralSettingsViewPermission) && (
            <NavItem style={{ cursor: "pointer" }}>
              <NavLink
                active={activeTab === "1"}
                className={` position-relative ${
                  activeTab === "1" ? "text-white" : "text-body-emphasis"
                }`}
                onClick={() => {
                  toggle("1");
                }}
              >
                General Settings
              </NavLink>
            </NavItem>
          )}

          {RolesPermission(InsurancePayerViewPermission) && (
            <NavItem style={{ cursor: "pointer" }}>
              <NavLink
                active={activeTab === "2"}
                className={` position-relative ${
                  activeTab === "2" ? "text-white" : "text-body-emphasis"
                }`}
                onClick={() => {
                  toggle("2");
                }}
              >
                Payer
              </NavLink>
            </NavItem>
          )}

          <NavItem style={{ cursor: "pointer" }}>
            <NavLink
              active={activeTab === "3"}
              className={` position-relative ${
                activeTab === "3" ? "text-white" : "text-body-emphasis"
              }`}
              onClick={() => {
                toggle("3");
              }}
            >
              Insurance/Payer Mapping
            </NavLink>
          </NavItem>
          {RolesPermission(ProviderViewPermission) && (
            <NavItem style={{ cursor: "pointer" }}>
              <NavLink
                active={activeTab === "4"}
                className={` position-relative ${
                  activeTab === "4" ? "text-white" : "text-body-emphasis"
                }`}
                onClick={() => {
                  toggle("4");
                }}
              >
                Provider
              </NavLink>
            </NavItem>
          )}

          <NavItem style={{ cursor: "pointer" }}>
            <NavLink
              active={activeTab === "5"}
              className={` position-relative ${
                activeTab === "5" ? "text-white" : "text-body-emphasis"
              }`}
              onClick={() => {
                toggle("5");
              }}
            >
              Notifications
            </NavLink>
          </NavItem>
          {RolesPermission(ProcedureCodeViewPermission) && (
            <NavItem style={{ cursor: "pointer" }}>
              <NavLink
                active={activeTab === "6"}
                className={` position-relative ${
                  activeTab === "6" ? "text-white" : "text-body-emphasis"
                }`}
                onClick={() => {
                  toggle("6");
                }}
              >
                Procedure Code Master
              </NavLink>
            </NavItem>
          )}
        </Nav>
        <hr />
        <TabContent activeTab={activeTab}>
          <TabPane tabId="1">
            <GlobalInsurance />
          </TabPane>

          <TabPane tabId="2">
            <MyInsurancePayer />
          </TabPane>

          <TabPane tabId="3">
            <MyInsuranceMapper />
          </TabPane>

          <TabPane tabId="4">
            <Provider />
          </TabPane>

          <TabPane tabId="5">
            <Notifications />
          </TabPane>
          <TabPane tabId="6">
            <ProcedureCodeMapper />
          </TabPane>
        </TabContent>
      </div>
    </>
  );
};

export default Settings;
