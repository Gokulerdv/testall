/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Button,
  Form,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
} from "reactstrap";

export type WeeklyModalProps = {
  isOpen: any;
  toggle: any;
  repeatEvery: string;
  selectedDays: string[];
  setRepeatEvery: (value: string) => void;
  setSelectedDays: (days: string[]) => void;
  onClick?: () => void;
};

function WeeklyModal(props: WeeklyModalProps) {
  const { isOpen, toggle } = props;

  return (
    <>
      {isOpen ? (
        <Modal
          backdrop
          keyboard
          size="lg"
          isOpen={isOpen}
          toggle={toggle}
          centered
        >
          <WeeklyModalForm {...props} />
        </Modal>
      ) : null}
    </>
  );
}

export const WeeklyModalForm = (props: WeeklyModalProps) => {
  const { toggle } = props;

  const handleSaveChanges = () => {
    if (props.setRepeatEvery && props.setSelectedDays) {
      props.setRepeatEvery(props.repeatEvery);
      props.setSelectedDays(props.selectedDays);
      toggle();
    }
  };

  const handleCheckboxChange = (e: any) => {
    const { value, checked } = e.target;
    if (checked) {
      // If checkbox is checked, add the value to the selectedDays array
      props.setSelectedDays([...props.selectedDays, value]);
    } else {
      // If checkbox is unchecked, remove the value from the selectedDays array
      props.setSelectedDays(props.selectedDays.filter((day) => day !== value));
    }
  };

  const handleCancelModal = () => {
    props.setSelectedDays([]);
    props.setRepeatEvery("");
    toggle();
  };

  const currentDate = new Date().toLocaleDateString();
  return (
    <>
      <ModalHeader toggle={toggle}>
        <div className="title">Edit recurrence</div>
      </ModalHeader>

      <ModalBody className="modal_body f-13">
        <Form>
          <div className="row">
            <div className="col-4">
              <FormGroup>
                <Label for="start">Start</Label>
                <Input
                  type="text"
                  name="start"
                  id="start"
                  value={currentDate}
                  disabled
                />
              </FormGroup>
            </div>
          </div>
          <div className="row">
            <div className="col-3">
              <FormGroup>
                <Label for="dayOfWeek">Repeat Every</Label>
                <Input
                  type="select"
                  name="star"
                  id="dayOfWeek"
                  value={props.repeatEvery}
                  onChange={(e) => props.setRepeatEvery(e.target.value)}
                >
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </Input>
              </FormGroup>
            </div>
            <div className="mt-2 col-3">
              <FormGroup>
                <Label for="repeatEvery"></Label>
                <Input
                  type="text"
                  name="repeatEvery"
                  id="repeatEvery"
                  placeholder="Week"
                  disabled
                />
              </FormGroup>
            </div>
          </div>
          <div className="row">
            <div className="col-2">
              <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="monday"
                    value="1"
                    checked={props.selectedDays.includes("1")}
                    onChange={handleCheckboxChange}
                  />{" "}
                  Mon
                </Label>
              </FormGroup>
            </div>
            <div className="col-2">
              <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="tuesday"
                    value="2"
                    checked={props.selectedDays.includes("2")}
                    onChange={handleCheckboxChange}
                  />{" "}
                  Tue
                </Label>
              </FormGroup>
            </div>
            <div className="col-2">
              <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="wednesday"
                    value="3"
                    checked={props.selectedDays.includes("3")}
                    onChange={handleCheckboxChange}
                  />{" "}
                  Wed
                </Label>
              </FormGroup>
            </div>
            <div className="col-2">
              <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="thursday"
                    value="4"
                    checked={props.selectedDays.includes("4")}
                    onChange={handleCheckboxChange}
                  />{" "}
                  Thur
                </Label>
              </FormGroup>
            </div>
            <div className="col-2">
              <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="friday"
                    value="5"
                    checked={props.selectedDays.includes("5")}
                    onChange={handleCheckboxChange}
                  />{" "}
                  Fri
                </Label>
              </FormGroup>
            </div>
          </div>
        </Form>
      </ModalBody>

      <ModalFooter>
        <Button
          className="cancelmodal"
          color="primary"
          outline
          onClick={handleCancelModal}
        >
          Cancel
        </Button>{" "}
        <Button color="primary text-white" onClick={handleSaveChanges}>
          Save
        </Button>
      </ModalFooter>
    </>
  );
};

export default WeeklyModal;
