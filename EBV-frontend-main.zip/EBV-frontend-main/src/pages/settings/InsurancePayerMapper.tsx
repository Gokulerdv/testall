import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import { Form } from "react-router-dom";
import { Row, Col, FormGroup, Label, Input, Button, Table } from "reactstrap";

const InsuranceMapper = () => {
  const payerIdData = [
    "11198",
    "7000",
    "AARP1",
    "CX076",
    "43168",
    "dentadental.com",
    "dentadental.com",
  ];

  const nameData = [
    "32 BJ",
    "3M Dental Services",
    "AARP Dental Insurance Plan",
    "Administrative Services Only (ASO)",
    "Advantica",
    "Aetna Better Health of Kansas",
    "Michael Knight",
  ];

  const clearingHouseData = [
    "DENTALEXCHANGE",
    "DENTALEXCHANGE",
    "DENTALEXCHANGE",
    "DENTALEXCHANGE",
    "DENTALEXCHANGE",
    "DENTALEXCHANGE",
    "DENTALEXCHANGE",
  ];

  const [searchTerm, setSearchTerm] = useState("");
  const [searchClearingHouse, setSearchClearingHouse] = useState("");
  const [filteredData, setFilteredData] = useState([]);

  const handleSearch = (e: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearchTerm(e.target.value);
    filterData(e.target.value, searchClearingHouse);
  };

  const handleClearingHouseSearch = (e: {
    target: { value: React.SetStateAction<any> };
  }) => {
    setSearchClearingHouse(e.target.value);
    filterData(searchTerm, e.target.value);
  };

  const filterData = (
    nameSearchTerm: React.SetStateAction<any>,
    clearingHouseSearchTerm: string
  ) => {
    const filteredResult: any = nameData.filter(
      (name, index) =>
        name.toLowerCase().includes(nameSearchTerm.toLowerCase()) &&
        clearingHouseData[index]
          .toLowerCase()
          .includes(clearingHouseSearchTerm.toLowerCase())
    );
    setFilteredData(filteredResult);
  };

  const handleSearchButton = () => {
    filterData(searchTerm, searchClearingHouse);
  };

  const handleCancel = () => {
    setSearchTerm("");
    setSearchClearingHouse("");
    setFilteredData([]);
    window.history.back(); // Navigates back to the previous route
  };

  const dataToShow = filteredData.length > 0 ? filteredData : nameData;

  return (
    <React.Suspense fallback={"loading data..."}>
      <nav className="navbar navbar-light ">
        <form className="d-flex">
          <div className="container-fluid">
            <form className="d-flex">
              <div className="input-group mb-3">
                <input
                  type="search"
                  className="form-control"
                  placeholder="Search here"
                  aria-label="Search"
                  style={{ borderRight: "0px" }}
                  aria-describedby="search-addon"
                  onChange={handleSearch}
                />
                <span className="input-group-text" id="search-addon">
                  <FontAwesomeIcon icon={faMagnifyingGlass} />
                </span>
              </div>
            </form>
          </div>
        </form>
      </nav>
      <Form>
        <Row>
          <Col md={4}>
            <FormGroup>
              <Label className=" payer_label " for="name">
                Name
              </Label>
              <Input
                className="ml-2"
                type="text"
                name="name"
                id="name"
                onChange={handleSearch}
              />
            </FormGroup>
          </Col>
          <Col md={4}>
            <FormGroup>
              <Label className="payer_label" for="clearingHouse">
                Clearing House
              </Label>
              <input
                type="search"
                className="form-control"
                placeholder=""
                aria-label="Search Clearing House"
                style={{ borderRight: "0px" }}
                aria-describedby="clearing-house-search-addon"
                onChange={handleClearingHouseSearch}
              />
              <div className="payer-button d-flex mt-3 pt-2">
                <Button
                  className="cancelmodal"
                  color="primary"
                  outline
                  onClick={handleCancel}
                >
                  Cancel
                </Button>
                <Button
                  className="searchbtn"
                  color="primary text-white"
                  onClick={handleSearchButton}
                >
                  Search
                </Button>
              </div>
            </FormGroup>
          </Col>
        </Row>
      </Form>
      <Table striped className="payer_table">
        <thead>
          <tr>
            <th>Payer ID</th>
            <th>Name</th>
            <th>Clearing House</th>
          </tr>
        </thead>
        <tbody>
          {dataToShow.map((name, index) => (
            <tr key={index}>
              <td width={"175px"} className="py-2">
                {payerIdData[index]}
              </td>
              <td width={"300px"} className="py-2">
                {name}
              </td>
              <td className="py-2">{clearingHouseData[index]}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </React.Suspense>
  );
};

export default InsuranceMapper;
