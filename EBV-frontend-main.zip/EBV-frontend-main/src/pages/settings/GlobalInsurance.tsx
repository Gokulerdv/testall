/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { zodResolver } from "@hookform/resolvers/zod";
import React, { useEffect, useState } from "react";
import {
  FormProvider,
  SubmitHandler,
  useForm,
  useWatch,
} from "react-hook-form";
import { Button, Form, FormGroup, Input, Label } from "reactstrap";
import { z } from "zod";

import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { toast } from "react-toastify";
import ConfirmationModal from "../../components/confirmation-modal";
import { useAuth } from "../../shared/hooks/use-auth";
import { GeneralSettingsEditPermission } from "../../utils/constant";
import { Config } from "../../utils/headers-config";
import { RolesPermission } from "../../utils/role-permission";
import ActiveDays from "./fields/active-days";
import BenefitSummaryMedicaid from "./fields/benefit-summary-medicaid";
import BenefitSummaryStandard from "./fields/benefit-summary-standard";
import UserHistoryName from "./fields/user-history-name";
import { VerificationCodes } from "./fields/verification-codes";
import VerifiedInPast from "./fields/verified-in-past";
import VerifyScheduleMedicaid from "./fields/verify-schedule-medicaid";
import VerifyScheduleStandard from "./fields/verify-schedule-standard";
import WarningDays from "./fields/warning-days";
import Schedule from "./schedule";

const generalSettingFormSchema = z.object({
  isverifyautomatically: z.boolean().optional(),
  verifyschedulestandard: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  verifyschedulemedicaid: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  benefitsummarystandard: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  benefitsummarymedicaid: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  excludeclone: z.boolean().optional(),
  verifiedinpast: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  warningdays: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  activedays: z.coerce
    .number()
    .nonnegative("Value must be non-negative")
    .int("Value must be an integer")
    .optional(),
  userhistoryname: z.string().optional(),
  ishistory: z.boolean().optional(),
  verificationcodes: z.string().optional(),
});

export type GeneralSettingsEditFormData = z.infer<
  typeof generalSettingFormSchema
>;

export type GeneralSettingsEditFormDataProps = {
  defaultvalues?: Partial<GeneralSettingsEditFormData>;
};

export const GlobalInsurance = () => {
  const [addedVerificationCodes, setAddedVerificationCodes] = useState<
    string[]
  >([]);
  const [isFormDirty, setIsFormDirty] = useState(false);

  const methods = useForm<GeneralSettingsEditFormData>({
    resolver: zodResolver(generalSettingFormSchema),
    defaultValues: {} as GeneralSettingsEditFormData,
    mode: "onChange",
  });

  const queryClient = useQueryClient();

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/generalSettings/update/${data.adminId}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const handleRemove = async (deletedItem: string) => {
    const updatedVerificationCodes = [...addedVerificationCodes].filter(
      (item) => item !== deletedItem
    );
    setAddedVerificationCodes(updatedVerificationCodes);
    try {
      await globalSettingsUpdate.mutateAsync({
        verificationcodes: updatedVerificationCodes,
        adminId: `${userId}`,
      });

      toast.success("General Settings updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      queryClient.invalidateQueries({
        queryKey: ["globalSettings", "getAll"],
      });
    }
  };

  const clearVerificationCode = () => {
    methods.reset({ verificationcodes: "" });
  };

  const handleVerificationCode = async () => {
    const verificationCodesValue = methods.getValues("verificationcodes");
    if (verificationCodesValue?.trim()) {
      const newCode = verificationCodesValue.split(",");
      const updatedVerificationCodes = newCode
        ? [...addedVerificationCodes, ...newCode]
        : [];
      setAddedVerificationCodes(updatedVerificationCodes);
      methods.reset({ verificationcodes: "" });

      try {
        await globalSettingsUpdate.mutateAsync({
          verificationcodes: updatedVerificationCodes,
          adminId: `${userId}`,
        });

        toast.success("General Settings updated successfully");
      } catch (error) {
        toast.error("An error occurred!");
      } finally {
        queryClient.invalidateQueries({
          queryKey: ["globalSettings", "getAll"],
        });
      }
    } else {
      toast.error("Verification codes should not be empty");
    }
  };
  const auth = useAuth();

  const userId = auth?.state?.user?.userData?.userId;

  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/generalSettings/get/${userId}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const { data: generalSettingsData } = useSuspenseQuery({
    queryKey: ["general", "getAll"],
    queryFn: getAll,
  });

  useEffect(() => {
    if (generalSettingsData) {
      const data = generalSettingsData.data;
      setAddedVerificationCodes(data?.verificationcodes || []);
      methods.reset({
        isverifyautomatically: data?.isverifyautomatically,
        verifyschedulestandard: data?.verifyschedulestandard,
        verifyschedulemedicaid: data?.verifyschedulemedicaid,
        benefitsummarystandard: data?.benefitsummarystandard,
        benefitsummarymedicaid: data?.benefitsummarymedicaid,
        excludeclone: data?.excludeclone,
        verifiedinpast: data?.verifiedinpast,
        warningdays: data?.warningdays,
        userhistoryname: data?.userhistoryname,
        ishistory: data?.ishistory,
        activedays: data?.activedays,
      });
    }
  }, [generalSettingsData, methods]);

  const confirmationMessage = "You have unsaved changes. Continue?";

  useEffect(() => {
    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      if (isFormDirty) {
        event.preventDefault();
        event.returnValue = confirmationMessage;
        return confirmationMessage;
      }
    };

    const handlePopState = (event: PopStateEvent) => {
      if (isFormDirty && !window.confirm(confirmationMessage)) {
        event.preventDefault();
        event.stopPropagation();
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      window.removeEventListener("popstate", handlePopState);
    };
  }, [isFormDirty]);

  useEffect(() => {
    const subscription = methods.watch(() => {
      setIsFormDirty(true);
    });

    return () => subscription.unsubscribe();
  }, [methods]);

  const globalSettingsUpdate = useMutation({
    mutationKey: ["globalSettings", "update"],
    mutationFn: update,
  });

  const verifyschedulestandard = useWatch({
    control: methods.control,
    name: "verifyschedulestandard",
  });
  const verifyschedulemedicaid = useWatch({
    control: methods.control,
    name: "verifyschedulemedicaid",
  });
  const benefitsummarystandard = useWatch({
    control: methods.control,
    name: "benefitsummarystandard",
  });
  const benefitsummarymedicaid = useWatch({
    control: methods.control,
    name: "benefitsummarymedicaid",
  });
  const verifiedinpast = useWatch({
    control: methods.control,
    name: "verifiedinpast",
  });
  const warningdays = useWatch({
    control: methods.control,
    name: "warningdays",
  });
  const activedays = useWatch({
    control: methods.control,
    name: "activedays",
  });
  const userhistoryname = useWatch({
    control: methods.control,
    name: "userhistoryname",
  });
  const ishistory = methods.watch("ishistory");
  const isverifyautomatically = methods.watch("isverifyautomatically");
  const excludeclone = useWatch({
    control: methods.control,
    name: "excludeclone",
  });

  const onSubmit: SubmitHandler<GeneralSettingsEditFormData> = async () => {
    try {
      await globalSettingsUpdate.mutateAsync({
        verifyschedulestandard,
        verifyschedulemedicaid,
        benefitsummarystandard,
        benefitsummarymedicaid,
        verifiedinpast,
        warningdays,
        userhistoryname,
        isverifyautomatically,
        excludeclone,
        ishistory,
        activedays,
        adminId: `${userId}`,
      });

      toast.success("General Settings updated successfully");
      setIsFormDirty(false);
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["globalSettings", "getAll"],
      });
    }
  };

  return (
    <React.Suspense fallback={"loading data..."}>
      {RolesPermission(GeneralSettingsEditPermission) && (
        <div className="d-flex justify-content-between">
          <div className="global_verification_tab1">
            <h6>Global Insurance Verification Settings</h6>
            <p>The below settings will appear to your verification module</p>
          </div>

          <div className="d-flex d-md-block">
            <Button className="me-3 cancelmodal" color="primary" outline>
              Cancel
            </Button>

            <ConfirmationModal
              onClick={methods.handleSubmit(onSubmit, console.log)}
              value="Save Changes"
            />
          </div>
        </div>
      )}

      {RolesPermission(GeneralSettingsEditPermission) && (
        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit, console.log)}>
            <hr className="hr-specs" />

            <div className="d-flex justify-content-between">
              <div className="verification-desc">
                <h6>Automatically Verify Patient Eligibility and Benefits</h6>
              </div>
              <div className="verification_switch d-flex">
                <FormGroup switch name="isverifyautomatically">
                  <Input
                    name="isverifyautomatically"
                    role="switch"
                    type="switch"
                    className="ml-4"
                    checked={isverifyautomatically}
                    onChange={() => {
                      methods.setValue(
                        "isverifyautomatically",
                        !isverifyautomatically
                      );
                    }}
                  />
                  <Label check>Verify Automatically</Label>
                </FormGroup>
              </div>
            </div>
            <div className="row">
              {isverifyautomatically ? (
                <>
                  <div className="patient_eligibility_settings col-md-3 ">
                    <h6>Verify Patients When,</h6>
                    <div className=" row">
                      <div>
                        <p className="text-muted">
                          Date until scheduled appointment
                        </p>
                      </div>
                    </div>
                    <div>
                      <p className="mt-2 text-muted">
                        Benefit summary not verified in
                      </p>
                    </div>
                  </div>
                  <div className="patient_eligibility_settings col-md-6 ">
                    <div className="row ">
                      <div className=" col-2 f-13">
                        <h6>Standard</h6>
                      </div>
                      <div className=" col-2 f-13">
                        <h6>Medicaid</h6>
                      </div>
                    </div>

                    <div className="row">
                      <div className=" col-2 f-13">
                        <VerifyScheduleStandard />
                      </div>

                      <div className=" col-2 f-13">
                        <VerifyScheduleMedicaid />
                      </div>
                    </div>
                    <div className="row">
                      <div className=" col-2 f-13">
                        <BenefitSummaryStandard />
                      </div>

                      <div className=" col-2 f-13">
                        <BenefitSummaryMedicaid />
                      </div>
                    </div>
                  </div>
                  <div>
                    <FormGroup check inline className="mt-2 ">
                      <Input
                        name="excludeclone"
                        type="checkbox"
                        checked={excludeclone}
                        onChange={() => {
                          methods.setValue("excludeclone", !excludeclone);
                        }}
                      />
                      <Label className="f-13" check>
                        Exclude patient Clone
                      </Label>
                    </FormGroup>
                  </div>

                  <div className="py-1 mt-2 ml-2 col-4">
                    <span className="f-13">
                      Do not verify patients that have been verified in the past
                    </span>
                  </div>
                  <div className="py-1 ml-2 col-1">
                    <VerifiedInPast />
                  </div>
                  <div className="py-1 mt-2 ml-2 col-4">Days</div>
                </>
              ) : (
                <></>
              )}
            </div>

            <div className="row">
              <div className="row">
                <div className="col-12">
                  <hr className="hr-specs" />
                  <h6>Recent Verification Warning Message</h6>
                </div>
                <div className="row">
                  <div className="col-12">
                    <p className="mt-2 f-13">
                      Based on the below setting, a warning message wil display
                      in the portal when anyone tries to run a verification for
                      a patient who had a previous verification performed{" "}
                    </p>
                  </div>
                </div>
              </div>
              <div className="py-1 mt-2 ml-2 col-6" style={{ width: "52%" }}>
                <span className="f-13">
                  Show a warning message when there is a previous patient
                  verification performed within the last
                </span>
              </div>
              <div className="py-1 ml-2 col-1">
                <WarningDays />
              </div>
              <div className="py-1 mt-2 ml-2 col-4">Days</div>
              <hr className="hr-specs" />
              <div className="history_settings">
                <h6 className="mb-3">Keep History in Genyus</h6>
                <label className="text-secondary">User Name</label>
                <UserHistoryName />
                <div className="my-3 d-flex">
                  <Label className="pt-1 pb-3 f-13" check>
                    Store history in Genuys
                  </Label>
                  <FormGroup style={{ paddingLeft: "3em" }} switch>
                    <Input
                      name="ishistory"
                      className="ml-4"
                      role="switch"
                      type="switch"
                      checked={ishistory}
                      onChange={() => {
                        methods.setValue("ishistory", !ishistory);
                      }}
                    />
                  </FormGroup>
                </div>
                <p className="f-13">
                  Enabling the below toggle will keep a history of the last 5
                  verifications in Genyus's portal as a reminder, you have the
                  history of verifications in your practice management system's
                  documents for each patient
                </p>
              </div>
              {ishistory && (
                <div>
                  <h6 className="mb-3">
                    Number of days the patient details need to be moved from
                    Eligibility to History
                  </h6>
                  <div className="col-1 patient_eligibility_settings">
                    <ActiveDays />
                  </div>
                </div>
              )}
              <Schedule />

              <FormGroup>
                <hr className="hr-specs" />
                <h6>Verification codes and PDF/view quick filters</h6>
                <p className="f-13">
                  Many payers show data that includes hundreds of ADA Codes. In
                  order to download and view a condensed PDF, enter the most
                  common codes you use when verifying patients below in order to
                  create a summarized PDF with just the below codes. This will
                  also be used to retrieve data for those payers that allow
                  search by code, as well as create a quick filter in the Genyus
                  Portal when viewing the patient benefits.
                </p>
                <p>
                  Enter ADA codes below the click on SAVE (eg D2740, D2750,
                  etc.);
                </p>
                <div className="ADA_codes_area">
                  <VerificationCodes required />
                  <div className="pt-3 d-flex justify-content-end">
                    <Button
                      color="primary"
                      outline
                      className="mx-3"
                      onClick={clearVerificationCode}
                    >
                      Cancel
                    </Button>

                    <ConfirmationModal
                      onClick={handleVerificationCode}
                      value="Save"
                    />
                  </div>
                </div>
              </FormGroup>

              <div className="pt-4 mt-3 row">
                <div className="w-40 col-md-5 col-sm-12">
                  <div className="row">
                    {addedVerificationCodes?.map((item, index) => (
                      <div key={index} className="mb-3 col-md-2 col-sm-4">
                        <div className="chip">
                          {item}
                          <Button
                            className="close-btn"
                            variant="link"
                            onClick={() => handleRemove(item)}
                          >
                            X
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Form>
        </FormProvider>
      )}
    </React.Suspense>
  );
};

export default GlobalInsurance;
