import { faTrash, faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import {
  Container,
  Row,
  Col,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  FormGroup,
  Label,
  Input,
  Table,
} from "reactstrap";

const PayerCredential = () => {
  const [showpassword, setshowpassword] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggle1 = () => setDropdownOpen((prevState) => !prevState);
  const passwordhandle = () => {
    setshowpassword(!showpassword);
  };
  return (
    <React.Suspense fallback={"loading data..."}>
      <Container>
        <h6>Payer Credentials</h6>

        <p className="f-13">
          Payer Credentials Provider login credentials for payers ni order to
          improve the verification process. By providing credentials you wil get
          access to more complete Eligibility and Benefits data for payers.
        </p>
        <Row>
          <Col md={4} className="pr-5">
            <Dropdown isOpen={dropdownOpen} toggle={toggle1}>
              <label className="payer_label" htmlFor="">
                Select Payer
              </label>
              <DropdownToggle caret size="md" className="setting-payer">
                Payer
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem header>Text</DropdownItem>
                <DropdownItem>Text</DropdownItem>
                <DropdownItem>Text</DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </Col>
          <Col md={4} className="px-5">
            <FormGroup>
              <Label className="payer_label" for="">
                user Name
              </Label>
              <Input id="" name="zip" />
            </FormGroup>
          </Col>
          <Col md={4} className="px-5">
            <FormGroup>
              <Label className="payer_label" for="exampleZip">
                Password
              </Label>
              <Input id="" name="zip" />
            </FormGroup>
          </Col>
        </Row>
        <Table striped className="payer_table">
          <thead>
            <tr>
              <th style={{ width: "50px" }}></th>
              <th className=" py-2 w-200 ">Payer/Website</th>
              <th className="py-2 w-200 ">Username</th>
              <th className=" py-2 w-200">Password</th>
              <th className=" py-2 "></th>
            </tr>
          </thead>
          <tbody>
            {[...Array(7)].map((_, index) => (
              <tr key={index}>
                <td className=" ">
                  <FontAwesomeIcon icon={faTrash} />
                </td>
                <td className="  ">Genyus Data</td>
                <td className=" ">Username Data</td>
                <td className=" ">
                  ******{" "}
                  <span className="px-2" onClick={passwordhandle}>
                    {" "}
                    <FontAwesomeIcon
                      icon={showpassword ? faEye : faEyeSlash}
                    />{" "}
                  </span>{" "}
                </td>
                <td>
                  <a>Edit</a>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Container>
    </React.Suspense>
  );
};

export default PayerCredential;
