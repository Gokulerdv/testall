/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react";
import {
  Button,
  Form,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
} from "reactstrap";

export type MonthlyModalProps = {
  isOpen: any;
  toggle: any;
  repeatEveryMonth: string;
  onCountOfDays: string;
  onCountOfWeekDays: string;
  onCountOfWeeks: string;
  setRepeatEveryMonth: (value: string) => void;
  setOnCountOfDays: (days: string) => void;
  setOnCountOfWeekDays: (value: string) => void;
  setOnCountOfWeeks: (value: string) => void;

  onClick?: () => void;
};

function MonthlyModal(props: MonthlyModalProps) {
  const { isOpen, toggle } = props;

  return (
    <>
      {isOpen ? (
        <Modal
          backdrop
          keyboard
          size="lg"
          isOpen={isOpen}
          toggle={toggle}
          centered
        >
          <MonthlyModalForm {...props} />
        </Modal>
      ) : null}
    </>
  );
}

export const MonthlyModalForm = (props: MonthlyModalProps) => {
  const [selectedOption, setSelectedOption] = React.useState("");
  const { toggle } = props;

  React.useEffect(() => {
    if (props.onCountOfDays) {
      setSelectedOption("option1");
    } else if (props.onCountOfWeekDays && props.onCountOfWeeks) {
      setSelectedOption("option2");
    } else setSelectedOption("");
  }, []);

  const handleSaveChanges = () => {
    if (selectedOption === "option1") {
      if (props.setOnCountOfDays && props.setRepeatEveryMonth) {
        props.setOnCountOfDays(props.onCountOfDays);
        props.setRepeatEveryMonth(props.repeatEveryMonth);
        props.setOnCountOfWeekDays("");
        props.setOnCountOfWeeks("");

        setSelectedOption("");
      }
      toggle();
    } else if (selectedOption === "option2") {
      if (
        props.setOnCountOfWeekDays &&
        props.setRepeatEveryMonth &&
        props.setOnCountOfWeeks
      ) {
        props.setOnCountOfWeekDays(props.onCountOfWeekDays);
        props.setOnCountOfWeeks(props.onCountOfWeeks);
        props.setRepeatEveryMonth(props.repeatEveryMonth);
        props.setOnCountOfDays("");
        setSelectedOption("");
      }
      toggle();
    }
  };

  const handleRadioChange = (e: any) => {
    setSelectedOption(e.target.value);
  };
  const currentDate = new Date().toLocaleDateString();

  const handleCancelModal = () => {
    props.setOnCountOfWeekDays("");
    props.setOnCountOfDays("");
    props.setOnCountOfWeeks("");
    props.setRepeatEveryMonth("");
    toggle();
  };

  return (
    <>
      <ModalHeader toggle={toggle}>
        <div className="title">set recurrence</div>
      </ModalHeader>
      <ModalBody className="modal_body f-13">
        <Form>
          <div className="row">
            <div className="col-4">
              <FormGroup>
                <Label for="start">Start</Label>
                <Input
                  type="text"
                  name="start"
                  id="start"
                  value={currentDate}
                  disabled
                />
              </FormGroup>
            </div>
          </div>
          <div className="row">
            <div className="col-3">
              <FormGroup>
                <Label for="dayOfWeek">Repeat Every</Label>
                <Input
                  type="select"
                  name="star"
                  id="month"
                  value={props.repeatEveryMonth}
                  onChange={(e) => props.setRepeatEveryMonth(e.target.value)}
                >
                  <option>Month</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                </Input>
              </FormGroup>
            </div>
            <div className="mt-2 col-3">
              <FormGroup>
                <Label for="repeatEvery"></Label>
                <Input
                  type="text"
                  name="repeatEvery"
                  id="repeatEvery"
                  placeholder="Month"
                  disabled
                />
              </FormGroup>
            </div>
          </div>
          <div className="row">
            <div className="mt-2 col-3">
              <FormGroup check>
                <Label check>
                  <Input
                    type="radio"
                    name="on day"
                    value="option1"
                    checked={selectedOption === "option1"}
                    onChange={handleRadioChange}
                  />{" "}
                  On day
                </Label>
              </FormGroup>
            </div>
            <div className="col-4">
              <FormGroup>
                <Input
                  type="text"
                  name="oncountofdays"
                  id="oncountofdays"
                  placeholder="Days"
                  value={props.onCountOfDays}
                  onChange={(e) => props.setOnCountOfDays(e.target.value)}
                />
              </FormGroup>
            </div>
          </div>
          <div className="row">
            <div className="mt-2 col-3">
              <FormGroup check>
                <Label check>
                  <Input
                    type="radio"
                    name="on the"
                    value="option2"
                    checked={selectedOption === "option2"}
                    onChange={handleRadioChange}
                  />{" "}
                  On the
                </Label>
              </FormGroup>
            </div>
            <div className="col-4">
              <FormGroup>
                <Input
                  type="select"
                  name="oncountofweeks"
                  id="oncountofweeks"
                  value={props.onCountOfWeeks}
                  onChange={(e) => props.setOnCountOfWeeks(e.target.value)}
                >
                  <option value="first">First</option>
                  <option value="second">second</option>
                  <option value="third">Third</option>
                  <option value="fourth">Fourth</option>
                </Input>
              </FormGroup>
            </div>
            <div className="col-5">
              <FormGroup>
                <Input
                  type="select"
                  name="oncountofweekdays"
                  id="oncountofweekdays"
                  value={props.onCountOfWeekDays}
                  onChange={(e) => props.setOnCountOfWeekDays(e.target.value)}
                >
                  <option value="">Select a day</option>
                  <option value="1">Monday</option>
                  <option value="2">Tuesday</option>
                  <option value="3">Wednesday</option>
                  <option value="4">Thursday</option>
                  <option value="5">Friday</option>
                </Input>
              </FormGroup>
            </div>
          </div>
        </Form>
      </ModalBody>

      <ModalFooter>
        <Button
          className="cancelmodal"
          color="primary"
          outline
          onClick={handleCancelModal}
        >
          Cancel
        </Button>{" "}
        <Button color="primary text-white" onClick={handleSaveChanges}>
          Save
        </Button>
      </ModalFooter>
    </>
  );
};

export default MonthlyModal;
