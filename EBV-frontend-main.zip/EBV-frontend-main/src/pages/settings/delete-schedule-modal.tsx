/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader, Spinner } from "reactstrap";
import { ScheduledModalProps } from "./schedule-modal";

import { useAuth } from "../../shared/hooks/use-auth";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import { Config } from "../../utils/headers-config";
import {
  ScheduleSettingsDeleteProps,
  ScheduleSettingsDeleteResponse,
} from "./apis/schedule-settings-delete";

export type DeleteModalProps = ScheduledModalProps;

export const ScheduleDeleteModal = (props: DeleteModalProps) => {
  const { id: id } = useParams();

  const scheduleSettingsDelete = async ({
    id,
  }: ScheduleSettingsDeleteProps): Promise<ScheduleSettingsDeleteResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/scheduledSettings/delete/${id}`;

    const response = (await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as ScheduleSettingsDeleteResponse;

    return response;
  };

  const { open, toggle } = useDrawerFromLocation({
    matchPath: "settings/:id/schedule-delete",
    togglePath: "../..",
  });

  const scheduledSettingsRemove = useMutation({
    mutationKey: ["scheduled", "remove"],
    mutationFn: scheduleSettingsDelete,
  });

  const queryClient = useQueryClient();

  const deleteChanges = async () => {
    try {
      if (!id) return;

      await scheduledSettingsRemove.mutateAsync({ id }, defaultMutateOptions);
      props.onSuccess?.();

      toast.success("Scheduled Settings deleted successfully");
      await scheduledData.refetch();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["scheduled", "getAll", `${adminId}`],
      });
      toggle();
    }
  };

  const [searchParams] = useSearchParams();

  const refresh = searchParams.get("refresh");
  const auth = useAuth();

  const adminId = auth?.state?.user?.userData?.userId;
  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/scheduledSettings/getAll/${adminId}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };

  const scheduledData = useSuspenseQuery({
    queryKey: ["scheduled", "getAll", { adminId }],
    queryFn: getAll,
  });

  React.useEffect(() => {
    (async () => {
      if (refresh) await scheduledData.refetch();
    })();
  }, [scheduledData, refresh]);

  return (
    <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
      <ModalHeader toggle={toggle} className="text-white bg-primary">
        Delete
      </ModalHeader>
      <ModalBody className="m-auto">
        <p>Are you sure want to delete the details?</p>

        <div className="gap-4 hstack justify-content-center">
          <Button outline color="primary" onClick={deleteChanges}>
            {scheduledSettingsRemove.isPending ? (
              <>
                <Spinner size="sm">Deleting...</Spinner>
                <span> Deleting...</span>
              </>
            ) : (
              <span>Yes</span>
            )}
          </Button>
          <Button outline color="secondary" onClick={toggle}>
            No
          </Button>
        </div>
      </ModalBody>
    </Modal>
  );
};

export default ScheduleDeleteModal;
