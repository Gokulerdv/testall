import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const scheduleSettingsDeleteSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type ScheduleSettingsDelete = z.infer<
  typeof scheduleSettingsDeleteSchema
>;
export type ScheduleSettingsDeleteResponse = Response<ScheduleSettingsDelete>;

export type ScheduleSettingsDeleteProps = {
  id: string;
};
