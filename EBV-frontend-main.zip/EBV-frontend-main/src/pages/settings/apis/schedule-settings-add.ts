export type ScheduledSettingsAddBody = {
  adminId?: string;
  scheduledaction?: string;
  weeklydays?: string;
  isweekly?: boolean;
  isdaily?: boolean;
  ismonthly?: boolean;
  timetorun?: string;
  numberofpatients?: number;
  oncountofweekdays?: string;
  oncountofdays?: string;
  oncountofweeks?: string;
  everyweek?: string;
  everymonth?: string;
  statusflag?: string;
};
