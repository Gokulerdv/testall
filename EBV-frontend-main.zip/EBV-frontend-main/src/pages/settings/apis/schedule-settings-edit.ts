/* eslint-disable @typescript-eslint/no-explicit-any */
import { ScheduledSettingsAddBody } from "./schedule-settings-add";

export type ScheduledSettingsEditBody = Partial<ScheduledSettingsAddBody>;

export type ScheduleSettingsEditProps = {
  id: string;
};

// TODO: Verify why this is not working - getting 500 status code
