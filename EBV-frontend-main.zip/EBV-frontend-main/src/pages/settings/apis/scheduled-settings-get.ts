/* eslint-disable @typescript-eslint/no-explicit-any */
import { z } from "zod";

export const scheduledSettingsGetSchema = z.object({
  adminId: z.string(),
  scheduledaction: z.string(),
  weeklydays: z.string(),
  isweekly: z.boolean(),
  isdaily: z.boolean(),
  ismonthly: z.boolean(),
  timetorun: z.string(),
  numberofpatients: z.number(),
  oncountofweekdays: z.string(),
  oncountofdays: z.string(),
  oncountofweeks: z.string(),
  everyweek: z.string(),
  everymonth: z.string(),
  statusflag: z.string(),
  id: z.number(),
});

export type ScheduleSettingsGet = z.infer<typeof scheduledSettingsGetSchema> & {
  [key: string]: unknown;
};
