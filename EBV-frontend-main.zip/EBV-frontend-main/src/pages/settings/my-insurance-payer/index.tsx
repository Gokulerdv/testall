import { Card } from "reactstrap";
import MyInsurancePayerTable from "./table";

export const MyInsurancePayer = () => {
  return (
    <>
      <Card>
        <MyInsurancePayerTable />
      </Card>
    </>
  );
};

export default MyInsurancePayer;
