import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { Input } from "reactstrap";

export type MaskedInputProps = {
  password: string;
};
export const MaskedInput = (props: MaskedInputProps) => {
  const [showPassword, setShowPassword] = React.useState(false);

  const handlePasswordMask = () => {
    setShowPassword(!showPassword);
  };
  return (
    <>
      <div className="hstack gap-2">
        <Input
          value={props.password}
          type={showPassword ? "text" : "password"}
          className="border-0 disabled"
          disabled
          style={{ background: "inherit" }}
        />
        <FontAwesomeIcon
          className="text-primary"
          icon={showPassword ? faEyeSlash : faEye}
          onClick={handlePasswordMask}
        />
      </div>
    </>
  );
};
