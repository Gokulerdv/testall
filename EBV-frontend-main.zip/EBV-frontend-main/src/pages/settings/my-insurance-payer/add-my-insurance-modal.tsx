/* eslint-disable @typescript-eslint/no-explicit-any */
import { faEdit, faPlus, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { Stack, Typography } from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  FormGroup,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import ConfirmationModal from "../../../components/confirmation-modal";
import { Field } from "../../../components/field";
import { useAuth } from "../../../shared/hooks/use-auth";
import { Config } from "../../../utils/headers-config";
import { PayerInsurance } from "./table/columns";
export const insurancePayerSchema = z.object({
  payer: z.string().min(1, "Required"),
  website: z.string().min(1, "Required"),
  username: z.string().min(1, "Required"),
  password: z.string().min(1, "Required"),
});

export type InsuranceModalProps = {
  onSuccess?: () => Promise<void>;
};

export const MyInsuranceFormFields = () => {
  return (
    <>
      <Row className="">
        <Col md={12}>
          <Field name="payer" />
        </Col>
        <Col md={12}>
          <Field name="website" />
        </Col>
        <Col md={12}>
          <Field name="username" />
        </Col>
        <Col md={12}>
          <Field name="password" />
        </Col>
      </Row>
    </>
  );
};

export const CreateMyInsurance = () => {
  const methods = useForm<PayerInsurance>({
    resolver: zodResolver(insurancePayerSchema),
  });
  const [open, setOpen] = React.useState(false);
  const toggle = () => {
    setOpen(!open);
    methods.reset();
    setImageUrl(null);
    setFileSizeExceedError("");
  };
  const [imageUrl, setImageUrl] = React.useState<string | null>();

  const [fileSizeExceedError, setFileSizeExceedError] = React.useState("");
  const auth = useAuth();

  const userId = auth?.state?.user?.userData?.userId;

  const queryClient = useQueryClient();
  const create = async (data: any): Promise<unknown> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/settings/createCredential`;

    const response = await (
      await fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const payerCreate = useMutation({
    mutationKey: ["payerInsurance", "create"],
    mutationFn: create,
  });
  const onSubmit: SubmitHandler<PayerInsurance> = async (data) => {
    try {
      if (fileSizeExceedError === "") {
        await payerCreate.mutateAsync({
          payer: data.payer,
          website: data.website,
          username: data.username,
          adminId: userId,
          password: data.password,
          payerLogo: imageUrl,
        });
        toast.success("Insurance payer added successfully", {
          toastId: "payerAddSuccess",
        });
        toggle();
        setFileSizeExceedError("");
      } else {
        toast.error("File size exceeding ");
        setImageUrl(null);
        setFileSizeExceedError("");
      }
    } catch (error) {
      toast.error("An error occurred!", { toastId: "payerAddError" });

      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["insurancePayer", "getAll"],
      });
    }
  };

  const onFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files) return;

    const file = event.target.files[0];
    const fileSize = file.size;
    const fileMb = fileSize / 1024 ** 2;

    const reader = new FileReader();

    reader.readAsDataURL(file);

    reader.onload = async () => {
      const base64Data = reader.result?.toString();
      if (base64Data) {
        setImageUrl(base64Data);
      }
    };
    if (fileMb >= 2) {
      setFileSizeExceedError("File size should not exceed 2MB.");
      return;
    }

    setFileSizeExceedError("");

    if (!file) return;
  };
  const handleDeleteImage = () => {
    setImageUrl(null);
    setFileSizeExceedError("");
  };

  const handleClose = () => {
    toggle();
    setImageUrl(null);
    setFileSizeExceedError("");
  };
  return (
    <>
      <Button color="primary" className="text-white" onClick={toggle}>
        <div className="gap-2 mb-0 hstack">
          <FontAwesomeIcon icon={faPlus} />
          <span className="mb-0">Add</span>
        </div>
      </Button>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size="lg"
        direction="end"
        style={{ width: "37%" }}
      >
        <OffcanvasHeader
          // toggle={toggle}
          className=" border-bottom w-100"
          style={{ width: "100%!important" }}
          close={
            <div
              className="hstack justify-content-between "
              style={{ width: "100%" }}
            >
              <div className="title" style={{ fontSize: "20px" }}>
                New
              </div>
              <div className="gap-2 hstack">
                <Button color="primary" outline onClick={handleClose}>
                  Cancel
                </Button>

                <ConfirmationModal
                  onClick={methods.handleSubmit(onSubmit)}
                  value="Save"
                />
              </div>
            </div>
          }
        ></OffcanvasHeader>

        <OffcanvasBody style={{ paddingLeft: "30px" }}>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <Row>
                <Col md={12}>
                  <FormGroup>
                    <label htmlFor="Photo">
                      <Label>LOGO</Label>
                    </label>
                    <Stack gap={2}>
                      {imageUrl === null ? (
                        <div
                          className="rounded bg-info-subtle d-flex align-items-center "
                          style={{ height: "150px", width: "150px" }}
                        >
                          <p style={{ fontSize: "0.7rem" }} className="m-auto">
                            Upload logo here
                          </p>
                        </div>
                      ) : (
                        <img
                          src={imageUrl}
                          style={{ width: "150px", height: "150px" }}
                          className="img-fluid"
                        />
                      )}
                      <div className="gap-3 hstack">
                        <label
                          className="border-0 "
                          htmlFor="visitorPassImageFile"
                        >
                          <FontAwesomeIcon
                            icon={faEdit}
                            size="lg"
                            className="text-primary"
                          />
                        </label>
                        <FontAwesomeIcon
                          icon={faTrash}
                          className="text-primary"
                          size="lg"
                          onClick={handleDeleteImage}
                        />
                      </div>

                      <input
                        type="file"
                        style={{
                          display: "none",
                        }}
                        className="form-control"
                        id="visitorPassImageFile"
                        onChange={onFileChange}
                      />
                      {fileSizeExceedError ? (
                        <Typography color="red">
                          {fileSizeExceedError}
                        </Typography>
                      ) : null}
                    </Stack>
                  </FormGroup>
                </Col>
              </Row>
              <MyInsuranceFormFields />
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </>
  );
};
export default CreateMyInsurance;
