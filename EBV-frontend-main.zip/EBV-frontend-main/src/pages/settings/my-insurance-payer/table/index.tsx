/* eslint-disable @typescript-eslint/no-explicit-any */
import { faSortDown, faSortUp } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useSuspenseQuery } from "@tanstack/react-query";
import {
  ColumnFiltersState,
  PaginationState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ReactTableDevtools } from "@tanstack/react-table-devtools";
import React from "react";
import { Button, Form } from "reactstrap";
import { fuzzyFilter } from "../../../../utils/fuzzy-filter";

import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { Field } from "../../../../components/field";
import { useAuth } from "../../../../shared/hooks/use-auth";
import { InsurancePayerCreatePermission } from "../../../../utils/constant";
import { Config } from "../../../../utils/headers-config";
import { RolesPermission } from "../../../../utils/role-permission";
import Pagination from "../../../eligibility/table/pagination";
import CreateMyInsurance from "../add-my-insurance-modal";
import { PayerInsurance, defaultColumns } from "./columns";
export type PayerSearch = {
  payer: string;
  username: string;
};
export const MyInsurancePayerTable = () => {
  const methods = useForm<PayerSearch>({
    defaultValues: {
      payer: "",
      username: "",
    },
  });

  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [pagination, setPagination] = React.useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const auth = useAuth();

  const getAll = async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/settings/credentialgetall`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });

    return response.json();
  };
  const { data: myInsurancePayerData } = useSuspenseQuery({
    queryKey: ["insurancePayer", "getAll"],
    queryFn: getAll,
  });

  const table = useReactTable({
    columns: defaultColumns,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: myInsurancePayerData.data as any,
    state: {
      columnFilters,
      sorting,
      pagination,
    },
    globalFilterFn: fuzzyFilter<PayerInsurance>(),
    onColumnFiltersChange: setColumnFilters,
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),
    debugTable: true,
  });

  const onSubmit: SubmitHandler<PayerSearch> = async (data) => {
    try {
      setColumnFilters([
        {
          id: "payer",
          value: data.payer,
        },
        {
          id: "username",
          value: data.username,
        },
      ]);
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };
  const handleReset = () => {
    methods.reset({
      payer: "",
      username: "",
    });
    setColumnFilters([]);
  };

  return (
    <>
      <div className="table-responsive">
        {import.meta.env.DEV ? (
          <ReactTableDevtools initialIsOpen table={table} />
        ) : null}
        <table className="table mb-0 table-striped table-hover table-borderless">
          <thead>
            <tr>
              <th
                colSpan={table.getVisibleLeafColumns().length}
                className="p-0"
              >
                <div className="gap-2 p-3 vstack">
                  <div className="h5">Payer Credentials</div>
                  <small className="p" style={{ fontWeight: "lighter" }}>
                    Provider login credentials for payers in order to improve
                    the verification process.By providing credentials you will
                    get access to more complete Eligibility and Benefits data
                    for payers
                  </small>
                </div>
              </th>
            </tr>
            <tr>
              <th
                colSpan={table.getVisibleLeafColumns().length}
                className="p-0"
              >
                <div className="p-3 hstack justify-content-between border-bottom">
                  <div className="gap-2 hstack ps-3">
                    <FormProvider {...methods}>
                      <Form
                        onSubmit={methods.handleSubmit(onSubmit, console.error)}
                      >
                        <div className="gap-2 hstack">
                          <Field name="payer" style={{ width: "20rem" }} />

                          <Field name="username" style={{ width: "20rem" }} />
                        </div>
                      </Form>
                    </FormProvider>
                    <div
                      className="gap-2 mb-3 hstack"
                      style={{ alignSelf: "end" }}
                    >
                      <Button
                        color="primary"
                        onClick={methods.handleSubmit(onSubmit, console.log)}
                      >
                        Search
                      </Button>
                      <Button color="primary" outline onClick={handleReset}>
                        Clear
                      </Button>
                    </div>
                  </div>
                  <div className="mb-3" style={{ alignSelf: "end" }}>
                    {RolesPermission(InsurancePayerCreatePermission) && (
                      <CreateMyInsurance />
                    )}
                  </div>
                </div>
              </th>
            </tr>

            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    className="border-bottom"
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        {...{
                          className: "hstack align-items-center",
                          style: header.column.getCanSort()
                            ? {
                                cursor: "pointer",
                                userSelect: "none",
                              }
                            : undefined,
                          onClick: header.column.getToggleSortingHandler(),
                        }}
                      >
                        <span style={{ maxWidth: "fit-content" }}>
                          {flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                        </span>

                        {header.column.getCanSort() ? (
                          <span
                            className="vstack justify-content-center align-items-center ms-2"
                            style={{
                              maxWidth: "min-content",
                            }}
                          >
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "asc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortUp}
                              style={{ marginBottom: "-1rem" }}
                            />
                            <FontAwesomeIcon
                              className={`${(() => {
                                if (header.column.getIsSorted() === "desc")
                                  return "text-black";
                                return "text-body-tertiary";
                              })()}`}
                              icon={faSortDown}
                            />
                          </span>
                        ) : null}
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>

          <tbody>
            {!myInsurancePayerData.isRefetching
              ? table.getRowModel().rows.map((row) => (
                  <tr key={row.id}>
                    {row.getVisibleCells().map((cell) => {
                      return (
                        <td key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))
              : null}
          </tbody>

          <Pagination table={table} />
        </table>
      </div>
    </>
  );
};
export default MyInsurancePayerTable;
