import { createColumnHelper } from "@tanstack/react-table";

import AlignTableItems from "../../../../components/align-table-items";
import {
  InsurancePayerDeletePermission,
  InsurancePayerEditPermission,
} from "../../../../utils/constant";
import { RolesPermission } from "../../../../utils/role-permission";
import { MaskedInput } from "../components/masked-input";
import DeleteModal from "../delete-insurance-modal";
import EditMyInsurance from "../edit-my-insurance-modal";

export type PayerInsurance = {
  id?: number;
  payer: string;
  website: string;
  username: string;
  password: string;
  payerLogo: string;
};

const columnHelper = createColumnHelper<PayerInsurance>();

export const defaultColumns = [
  columnHelper.accessor("payer", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Payer",
    footer: (props) => props.column.id,
    enableColumnFilter: true,
  }),
  columnHelper.accessor("website", {
    cell: (info) => (
      <AlignTableItems>
        <a href={info.getValue()}>{info.getValue()}</a>
      </AlignTableItems>
    ),
    header: "Website",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  //edit logo changes
  columnHelper.accessor("payerLogo", {
    cell: (info) => (
      <>
        {info.getValue !== null ? (
          <img
            src={info.getValue()}
            className="img-fluid"
            style={{ height: 60 }}
          />
        ) : null}
      </>
    ),
    header: "Logo",
    footer: (props) => props.column.id,
    enableColumnFilter: false,
  }),
  columnHelper.accessor("username", {
    cell: (info) => <AlignTableItems>{info.getValue()}</AlignTableItems>,
    header: "Username",
    footer: (props) => props.column.id,
    enableColumnFilter: true,
  }),
  columnHelper.accessor("password", {
    cell: (info) => (
      <AlignTableItems>
        <MaskedInput password={info.getValue()} />
      </AlignTableItems>
    ),
    header: "Password",
    footer: (props) => <AlignTableItems> {props.column.id}</AlignTableItems>,
    enableColumnFilter: false,
  }),

  // Display Column
  columnHelper.accessor("id", {
    id: "actions",
    header: "",
    enableSorting: false,
    cell: (info) => (
      <AlignTableItems>
        <div className="hstack gap-2 ">
          {RolesPermission(InsurancePayerEditPermission) && (
            <EditMyInsurance payerId={info.getValue() || 0} />
          )}
          {RolesPermission(InsurancePayerDeletePermission) && (
            <DeleteModal payerId={info.getValue() || 0} />
          )}
        </div>
      </AlignTableItems>
    ),
  }),
];
