/* eslint-disable @typescript-eslint/no-explicit-any */
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { toast } from "react-toastify";
import { Button, Modal, ModalBody, ModalHeader } from "reactstrap";
import { useAuthContext } from "../../../shared/hooks/use-auth";
import { Config } from "../../../utils/headers-config";

export type DeleteModalProps = {
  payerId: number;
};

export const DeleteModal = (props: DeleteModalProps) => {
  const { payerId } = props;

  const [open, setOpen] = React.useState(false);
  const queryClient = useQueryClient();
  const toggle = () => setOpen(!open);
  const auth = useAuthContext();

  const remove = async (id: string): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/settings/credentialdelete/${id}`;

    const response = await (
      await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const myInsurancePayerRemove = useMutation({
    mutationKey: ["insurancePayer", "remove"],
    mutationFn: remove,
  });

  const deletePatient = async () => {
    try {
      await myInsurancePayerRemove.mutateAsync(String(payerId));
      toast.success("Patient deleted successfully", {
        toastId: "payerdeleteSuccess",
      });

      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["insurancePayer", "getAll"],
      });
      toggle();
    }
  };

  return (
    <>
      <FontAwesomeIcon
        icon={faTrash}
        className="text-primary cursorPointer"
        onClick={toggle}
      />
      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="md" centered>
        <ModalHeader toggle={toggle} className="text-white bg-primary">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" onClick={deletePatient}>
              <span>Yes</span>
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default DeleteModal;
