/* eslint-disable @typescript-eslint/no-explicit-any */
import { faEdit, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";

import { zodResolver } from "@hookform/resolvers/zod";
import { Stack, Typography } from "@mui/material";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React from "react";
import { Form } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  FormGroup,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import ConfirmationModal from "../../../components/confirmation-modal";
import { Field } from "../../../components/field";
import { useAuth } from "../../../shared/hooks/use-auth";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import { Config } from "../../../utils/headers-config";
import { insurancePayerSchema } from "./add-my-insurance-modal";
import { PayerInsurance } from "./table/columns";
export type InsuranceModalProps = {
  payerId: number;
};

export const MyInsuranceFormFields = () => {
  return (
    <>
      <Row className="">
        <Col md={12}>
          <Field name="payer" />
        </Col>
        <Col md={12}>
          <Field name="website" />
        </Col>
        <Col md={12}>
          <Field name="username" />
        </Col>
        <Col md={12}>
          <Field name="password" />
        </Col>
      </Row>
    </>
  );
};

export const EditMyInsurance = (props: InsuranceModalProps) => {
  const methods = useForm<PayerInsurance>({
    resolver: zodResolver(insurancePayerSchema),
  });
  const { payerId } = props;
  const { open, toggle } = useDialogWithFormReset(methods);
  const [imageUrl, setImageUrl] = React.useState<string | null>();

  const [fileSizeExceedError, setFileSizeExceedError] = React.useState("");

  const queryClient = useQueryClient();
  const auth = useAuth();
  const userId = auth?.state?.user?.userData?.userId;

  const getById = (id: number) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/settings/credentialget/${id}`;

    const response = await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const update = async (data: any): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/settings/credentialUpdate/${data.id}`;

    const response = await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json();

    return response;
  };

  const editMyInsurancePayerCredentials = useSuspenseQuery({
    queryKey: ["insurancePayer", "get", payerId],
    queryFn: getById(payerId),
  });
  const myInsurancePayerUpdate = useMutation({
    mutationKey: ["insurancePayer", "update"],
    mutationFn: update,
  });

  React.useEffect(() => {
    methods.reset({
      payer: editMyInsurancePayerCredentials.data.deta.payer,
      website: editMyInsurancePayerCredentials.data.deta.website,
      username: editMyInsurancePayerCredentials.data.deta.username,
      password: editMyInsurancePayerCredentials.data.deta.password,
    });
    setImageUrl(editMyInsurancePayerCredentials.data.deta.payerLogo);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editMyInsurancePayerCredentials.isFetchedAfterMount]);
  const onSubmit: SubmitHandler<PayerInsurance> = async (data) => {
    try {
      if (fileSizeExceedError === "") {
        await myInsurancePayerUpdate.mutateAsync({
          payer: data.payer,
          website: data.website,
          username: data.username,
          adminId: userId,
          password: data.password,
          payerLogo: imageUrl,
          id: payerId,
        });
        toggle;
        toast.success("Insurance payer updated successfully", {
          toastId: "payerUpdateSuccess",
        });
        setFileSizeExceedError("");
      } else {
        toast.error("File size exceeding ");
        setFileSizeExceedError("");
        setImageUrl(null);
      }
    } catch (error) {
      toast.error("An error occurred!", { toastId: "payerUpdateError" });
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["insurancePayer", "getAll"],
      });
      toggle();
    }
  };

  const onFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files) return;

    const file = event.target.files[0];
    const fileSize = file.size;
    const fileMb = fileSize / 1024 ** 2;

    const reader = new FileReader();

    reader.readAsDataURL(file);

    reader.onload = async () => {
      const base64Data = reader.result?.toString();
      if (base64Data) {
        setImageUrl(base64Data);
      }
    };
    if (fileMb >= 2) {
      setFileSizeExceedError("File size should not exceed 2MB.");
      return;
    }

    setFileSizeExceedError("");

    if (!file) return;
  };
  const handleDeleteImage = () => {
    setImageUrl(null);
    setFileSizeExceedError("");
  };
  const handleClose = () => {
    toggle();
    setImageUrl(null);
    setFileSizeExceedError("");
  };
  return (
    <>
      <FontAwesomeIcon
        icon={faEdit}
        onClick={toggle}
        className="text-primary cursorPointer"
      />

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        backdrop
        keyboard
        size="lg"
        direction="end"
        style={{ width: "37%" }}
      >
        <OffcanvasHeader
          // toggle={toggle}
          className=" border-bottom w-100"
          style={{ width: "100%!important" }}
          close={
            <div
              className="hstack justify-content-between "
              style={{ width: "100%" }}
            >
              <div>Edit</div>
              <div className="gap-2 hstack">
                <Button color="primary" outline onClick={handleClose}>
                  Cancel
                </Button>

                <ConfirmationModal
                  onClick={methods.handleSubmit(onSubmit)}
                  value="Submit"
                />
              </div>
            </div>
          }
        ></OffcanvasHeader>

        <OffcanvasBody style={{ paddingLeft: "30px" }}>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <Row>
                <Col md={12}>
                  <FormGroup>
                    <label htmlFor="Photo">
                      <Label>LOGO</Label>
                    </label>
                    <Stack gap={2}>
                      {imageUrl === null ? (
                        <div
                          className="rounded bg-info-subtle d-flex align-items-center "
                          style={{ height: "150px", width: "150px" }}
                        >
                          <p style={{ fontSize: "0.7rem" }} className="m-auto">
                            Upload logo here
                          </p>
                        </div>
                      ) : (
                        <img
                          src={imageUrl}
                          style={{ width: "150px", height: "150px" }}
                          className="img-fluid"
                        />
                      )}
                      <div className="gap-3 hstack">
                        <label
                          className="border-0 "
                          htmlFor="visitorPassImageFile"
                        >
                          <FontAwesomeIcon
                            icon={faEdit}
                            size="lg"
                            className="text-primary"
                          />
                        </label>
                        <FontAwesomeIcon
                          icon={faTrash}
                          className="text-primary"
                          size="lg"
                          onClick={handleDeleteImage}
                        />
                      </div>

                      <input
                        type="file"
                        style={{
                          display: "none",
                        }}
                        className="form-control"
                        id="visitorPassImageFile"
                        onChange={onFileChange}
                      />
                      {fileSizeExceedError ? (
                        <Typography color="red">
                          {fileSizeExceedError}
                        </Typography>
                      ) : null}
                    </Stack>
                  </FormGroup>
                </Col>
              </Row>
              <MyInsuranceFormFields />
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </>
  );
};
export default EditMyInsurance;
