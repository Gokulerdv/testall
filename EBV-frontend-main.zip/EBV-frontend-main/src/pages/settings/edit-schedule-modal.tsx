/* eslint-disable @typescript-eslint/no-explicit-any */
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import React, { useState } from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import NumberOfPatients from "./fields/no-of-patients";
import ScheduledAction from "./fields/scheduled-action";
import TimeToRun from "./fields/time-to-run";
import MonthlyModal from "./monthly-modal";
import WeeklyModal from "./weekly-modal";
// import { ScheduledSettingsEdit } from "./apis/schedule-settings-edit";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { scheduledFormSchema } from "./schedule-modal";

import { defaultMutateOptions } from "../../utils/default-mutate-options";

import { Location, useLocation } from "react-router-dom";
import ConfirmationModal from "../../components/confirmation-modal";
import { useAuth } from "../../shared/hooks/use-auth";
import Config from "../../utils/headers-config";
import { ScheduledSettingsEditBody } from "./apis/schedule-settings-edit";
import { ScheduleSettingsGet } from "./apis/scheduled-settings-get";

export const scheduledEditFormSchema = z.object({
  ...scheduledFormSchema.shape,
});

export type ScheduledEditFormData = z.infer<typeof scheduledEditFormSchema>;

export type ScheduledEditFormDataProps = {
  onSuccess?: () => Promise<void>;
  defaultValues?: Partial<ScheduledEditFormData>;
};

export const EditModalPopup = (props: ScheduledEditFormDataProps) => {
  const [isCreateWeeklyModalOpen, setIsCreateWeeklyModalOpen] = useState(false);
  const [, setSearchParams] = useSearchParams();

  const [isCreateMonthlyModalOpen, setIsCreateMonthlyModalOpen] =
    useState(false);

  const [repeatEvery, setRepeatEvery] = useState("");
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [days, setDays] = useState<string[]>([]);

  const [cardOpen, setCardOpen] = useState(false);

  const [isWeekly, setIsWeekly] = useState(false);
  const [isMonthly, setIsMonthly] = useState(false);
  const [isDaily, setIsDaily] = useState(false);

  const [repeatEveryMonth, setRepeatEveryMonth] = useState("");
  const [onCountOfDays, setOnCountOfDays] = useState("");
  const [onCountOfWeekDays, setOnCountOfWeekDays] = useState("");
  const [onCountOfWeeks, setOnCountOfWeeks] = useState("");

  const convertTo12HourFormat = (time: string | undefined): string => {
    if (!time) {
      return "";
    }
    const [hour, minute] = time.split(":").map(Number);
    const period = hour >= 12 ? "PM" : "AM";
    const adjustedHour = hour % 12 || 12;
    return `${adjustedHour}:${minute < 10 ? "0" : ""}${minute}${period}`;
  };

  function convertTo24Hour(timeString: string): string {
    const modifier: string = timeString.slice(-2);
    const time: string = timeString.slice(0, -2);
    // eslint-disable-next-line prefer-const
    let [hours, minutes]: string[] = time.split(":");

    let hoursNum: number = parseInt(hours);

    if (modifier === "PM" && hoursNum !== 12) {
      hoursNum += 12;
    }
    if (modifier === "AM" && hoursNum === 12) {
      hoursNum = 0;
    }

    hours = hoursNum.toString().padStart(2, "0");

    return `${hours}:${minutes}`;
  }

  const toggleWeeklyCreateModal = () => {
    setIsCreateWeeklyModalOpen(!isCreateWeeklyModalOpen);
    setIsWeekly(true);
    setIsDaily(false);
    setIsMonthly(false);
  };

  const toggleMonthlyCreateModal = () => {
    setIsCreateMonthlyModalOpen(!isCreateMonthlyModalOpen);
    setIsMonthly(true);
    setIsWeekly(false);
    setIsDaily(false);
  };

  const {
    state: { id },
  } = useLocation() as Location<ScheduleSettingsGet>;

  const methods = useForm<ScheduledEditFormData>({
    resolver: zodResolver(scheduledFormSchema),
  });

  const queryClient = useQueryClient();
  const auth = useAuth();

  const userId = auth?.state?.user?.userData?.userId;

  const ScheduledSettingsGetId = (id: any) => async (): Promise<any> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/scheduledSettings/get/${id}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
    return response.json();
  };

  const ScheduledSettingsEdit =
    (id: any) =>
    async (body: ScheduledSettingsEditBody): Promise<any> => {
      const overwrittenBody: ScheduledSettingsEditBody = {
        ...body,
        scheduledaction: body.scheduledaction || "",
        weeklydays: body.weeklydays || "",
        isweekly: body.isweekly ? true : false,
        isdaily: body.isdaily ? true : false,
        ismonthly: body.ismonthly ? true : false,
        timetorun: body.timetorun || "",
        numberofpatients: body.numberofpatients || undefined,
        oncountofweekdays: body.oncountofweekdays || "",
        oncountofdays: body.oncountofdays || "",
        oncountofweeks: body.oncountofweeks || "",
        everymonth: body.everymonth || "",
        everyweek: body.everyweek || "",
        statusflag: "A",
      };

      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/scheduledSettings/update/${id}`;

      const response = await (
        await fetch(url, {
          method: "PUT",
          body: JSON.stringify(overwrittenBody),
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json();

      return response;
    };

  const scheduledUpdate = useMutation({
    mutationKey: ["scheduled", "update", id],
    mutationFn: ScheduledSettingsEdit(id),
  });

  const scheduledGetItem = useSuspenseQuery({
    queryKey: ["scheduled", "get", id],
    queryFn: ScheduledSettingsGetId(id),
  });
  React.useEffect(() => {
    const dataItem = scheduledGetItem.data.deta;

    if (dataItem.isweekly) {
      setSelectedOption("weekly");
      setIsWeekly(true);
      setRepeatEvery(dataItem.everyweek);
      setSelectedDays(dataItem.weeklydays?.split(",") || []);
    } else if (dataItem.ismonthly) {
      setSelectedOption("monthly");
      setIsMonthly(true);
      setRepeatEveryMonth(dataItem.everymonth);
      setOnCountOfDays(dataItem.oncountofdays);
      setOnCountOfWeeks(dataItem.oncountofweeks);
      setOnCountOfWeekDays(dataItem.oncountofweekdays || "");
    } else if (dataItem.weeklydays) {
      setSelectedOption("weekdays");
      setDays(dataItem.weeklydays?.split(",") || []);
    } else if (dataItem.isdaily) {
      setSelectedOption("daily");
      setIsDaily(true);
    }
    methods.reset({
      scheduledaction: dataItem.scheduledaction,
      timetorun: convertTo24Hour(dataItem.timetorun),
      numberofpatients: dataItem.numberofpatients,
      isdaily: dataItem.isdaily ? true : false,
      ismonthly: dataItem.ismonthly ? true : false,
      isweekly: dataItem.isweekly ? true : false,
      weeklydays: dataItem.weeklydays,
      everyweek: dataItem.everyweek,
      everymonth: dataItem.everymonth,
      oncountofdays: dataItem.oncountofdays,
      oncountofweekdays: dataItem.oncountofweekdays || "",
      oncountofweeks: dataItem.oncountofweeks,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scheduledGetItem.data.deta]);

  const { open, toggle } = useDrawerFromLocation({
    matchPath: "settings/:id/schedule-edit",
    togglePath: "../../?refresh=true",
    historyPopInstead: false,
  });

  const scheduledaction = methods.watch("scheduledaction");
  const timetorun = methods.watch("timetorun");
  const numberofpatients = methods.watch("numberofpatients");

  const onSubmit: SubmitHandler<ScheduledEditFormData> = async (data) => {
    try {
      if (selectedOption === "weekdays") {
        // Set the selected weekdays data to the weeklydays field
        data.weeklydays = days.join(",");
        data.everyweek = "1";
        data.isdaily = isDaily ? false : true;
      } else {
        data.weeklydays = selectedDays.join(",");
      }

      await scheduledUpdate.mutateAsync(
        {
          scheduledaction,
          timetorun: convertTo12HourFormat(timetorun),
          numberofpatients,
          statusflag: "A",
          isweekly: isWeekly ? true : false,
          isdaily: isDaily ? true : false,
          ismonthly: isMonthly ? true : false,
          everyweek: repeatEvery || data.everyweek || "",
          everymonth: repeatEveryMonth || "",
          oncountofdays: onCountOfDays || "",
          oncountofweeks: onCountOfWeeks || "",
          oncountofweekdays: onCountOfWeekDays || "",
          weeklydays: data.weeklydays || "",
        },
        defaultMutateOptions
      );
      props.onSuccess?.();
      toggle();
      setDays([]);
      toast.success("Scheduled Settings updated successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
      toggle();
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["scheduled", "getAll", `${userId}`],
      });
      setSearchParams({ refresh: String(true) });
    }
  };

  const [selectedOption, setSelectedOption] = useState("");

  const handleSelectChange = (event: any) => {
    setSelectedOption(event.target.value);
    if (event.target.value === "weekdays") {
      setCardOpen(!cardOpen);
    } else setCardOpen(false);

    setSelectedOption(event.target.value);
    if (event.target.value === "monthly") {
      setIsCreateMonthlyModalOpen(!isCreateMonthlyModalOpen);
    } else setIsCreateMonthlyModalOpen(false);

    setSelectedOption(event.target.value);
    if (event.target.value === "weekly") {
      setIsCreateWeeklyModalOpen(!isCreateWeeklyModalOpen);
    } else setIsCreateWeeklyModalOpen(false);

    setSelectedOption(event.target.value);
    if (event.target.value === "daily") {
      setIsDaily(true);
      setIsMonthly(false);
      setIsWeekly(false);
    }
  };

  const handleCardClose = () => {
    setCardOpen(!cardOpen);
  };

  const handleCheckboxChange = (e: any) => {
    const { value, checked } = e.target;
    if (checked) {
      // If checkbox is checked, add the value to the selectedDays array
      setDays([...days, value]);
    } else {
      // If checkbox is unchecked, remove the value from the selectedDays array
      setDays(days.filter((day) => day !== value));
    }
  };

  return (
    <>
      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle}>
          <div className="title">Edit</div>
        </ModalHeader>
        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit, console.log)}>
            <ModalBody className="modal_body f-13">
              <Label className="modal_form">Scheduled Action</Label>
              <FormGroup>
                <ScheduledAction />
              </FormGroup>

              <Label className="modal_form">Frequency run</Label>
              <Row>
                <FormGroup style={{ position: "relative" }}>
                  <Input
                    type="select"
                    name="select"
                    id="frequencyDropdown"
                    value={selectedOption}
                    onChange={handleSelectChange}
                    style={{ width: "63%" }}
                  >
                    <option>Select Option</option>
                    <option value="daily">Daily</option>

                    <option value="weekdays">Weekdays</option>

                    <option value="weekly">Weekly</option>

                    <option value="monthly">Monthly</option>
                  </Input>
                </FormGroup>
                {cardOpen && (
                  <Card
                    className="p-2 "
                    style={{
                      width: "9.625rem",
                      position: "absolute",
                      left: "32rem",
                    }}
                  >
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          value="1"
                          checked={days.includes("1")}
                          onChange={handleCheckboxChange}
                        />
                        Monday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="tuesday"
                          value="2"
                          checked={days.includes("2")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Tuesday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="wednesday"
                          value="3"
                          checked={days.includes("3")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Wednesday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="thursday"
                          value="4"
                          checked={days.includes("4")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Thursday
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="checkbox"
                          name="friday"
                          value="5"
                          checked={days.includes("5")}
                          onChange={handleCheckboxChange}
                        />{" "}
                        Friday
                      </Label>
                    </FormGroup>
                    <Row>
                      <Col>
                        <Button
                          color="primary"
                          className="float-end"
                          size="sm"
                          onClick={handleCardClose}
                        >
                          Save
                        </Button>
                      </Col>
                    </Row>
                  </Card>
                )}
                {isCreateWeeklyModalOpen && (
                  <WeeklyModal
                    isOpen={isCreateWeeklyModalOpen}
                    toggle={toggleWeeklyCreateModal}
                    repeatEvery={repeatEvery}
                    selectedDays={selectedDays}
                    setRepeatEvery={setRepeatEvery}
                    setSelectedDays={setSelectedDays}
                    onClick={() => {
                      setIsWeekly(true);
                      setIsDaily(false);
                      setIsMonthly(false);
                    }}
                  />
                )}

                {isCreateMonthlyModalOpen && (
                  <MonthlyModal
                    isOpen={isCreateMonthlyModalOpen}
                    toggle={toggleMonthlyCreateModal}
                    onClick={() => {
                      setIsMonthly(true);
                      setIsDaily(false);
                      setIsWeekly(false);
                    }}
                    repeatEveryMonth={repeatEveryMonth}
                    onCountOfWeekDays={onCountOfWeekDays}
                    onCountOfWeeks={onCountOfWeeks}
                    onCountOfDays={onCountOfDays}
                    setRepeatEveryMonth={setRepeatEveryMonth}
                    setOnCountOfDays={setOnCountOfDays}
                    setOnCountOfWeekDays={setOnCountOfWeekDays}
                    setOnCountOfWeeks={setOnCountOfWeeks}
                  />
                )}
              </Row>

              <FormGroup>
                <Label className="modal_form" for="timeToRun">
                  Time to Run
                </Label>
                <TimeToRun />
              </FormGroup>
              <FormGroup>
                <Label className="modal_form" for="numberOfPatients">
                  No of Patients
                </Label>
                <NumberOfPatients />
              </FormGroup>
            </ModalBody>
          </Form>
        </FormProvider>

        <ModalFooter>
          <Button
            className="cancelmodal"
            color="primary"
            outline
            onClick={() => {
              toggle();
            }}
          >
            Cancel
          </Button>{" "}
          <ConfirmationModal
            onClick={methods.handleSubmit(onSubmit)}
            value="Save"
          />
          {/* <Button
            color="primary text-white"
            onClick={methods.handleSubmit(onSubmit, console.log)}
          >
            {scheduledUpdate.isPending ? (
              <>
                <Spinner size="sm">Submitting...</Spinner>
                <span> Submitting...</span>
              </>
            ) : (
              <span>Save</span>
            )}
          </Button> */}
        </ModalFooter>
      </Modal>
    </>
  );
};

export default EditModalPopup;
