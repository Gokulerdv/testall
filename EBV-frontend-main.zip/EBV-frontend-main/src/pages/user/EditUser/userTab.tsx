import React from "react";
import PageHeader from "../../../components/PageHeader";
import ProductDetailV2 from "../Add-user/ProductDetail/ProductDetailV2";

const UserTab: React.FC<{ roleId: string }> = ({ roleId }) => {
  return (
    <>
      <PageHeader title="Permissions" />
      {roleId !== "" ? (
        <div className="user-tab">
          <ProductDetailV2 roleId={roleId} />
        </div>
      ) : (
        <p className="text-center py-5 border ">Role id not found</p>
      )}
    </>
  );
};

export default UserTab;
