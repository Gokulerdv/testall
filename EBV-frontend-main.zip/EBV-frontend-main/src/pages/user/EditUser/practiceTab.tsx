/* eslint-disable @typescript-eslint/no-explicit-any */
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Field, Form, Formik, useField } from "formik";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  Button,
  Col,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
  Spinner,
} from "reactstrap";
import { UserServices } from "../../../services/user";

type Role = {
  roleId: string;
  roleName: string;
  roleType: string;
  adminId: string;
  practiceId: string;
  permissions: string[];
  status: null | string;
  createdAt: string;
  updatedAt: string;
  products: any[];
};

type Location = {
  locationId: string;
  locationName: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  state: string;
  zipcode: string;
  status: boolean;
  createdAt: string;
  updatedAt: string;
  practiceId: string;
  role: Role;
};

type Practice = {
  practiceId: string;
  locations: Location[];
};

type User = {
  userId: string;
  userName: string;
  userType: null | string;
  email: string;
  phoneNumber: string;
  adminId: string;
  status: null | string;
  createdAt: string;
  updatedAt: string;
  practice: Practice;
};

const FormInput = ({
  id,
  label,
  placeholder,
  name,
  readonly,
}: {
  id: string;
  label: string;
  placeholder: string;
  name: string;
  readonly?: boolean;
}) => {
  const [field, meta] = useField(name);

  return (
    <Col md={4}>
      <FormGroup>
        <Label for={id}>{label}</Label>
        <Input
          {...field}
          type="text"
          id={id}
          placeholder={placeholder}
          className="flex-grow-1 formstyle"
          disabled={!readonly}
        />
        {meta.touched && meta.error ? (
          <div className="error">{meta.error}</div>
        ) : null}
      </FormGroup>
    </Col>
  );
};

const FormRow = ({ children }: { children: React.ReactNode }) => (
  <Row className="formstyle">{children}</Row>
);

const PracticeTab: React.FC<{
  user: User | null;
}> = ({ user }) => {
  const [refresh, setRefresh] = useState<boolean>(false);
  const [userRoles, setUserRoles] = useState<Role[]>([]);
  const [edit, setEdit] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");

  const practiceId = userDetails?.userData?.practice?.practiceId;

  const userId = userDetails?.userData?.userId;

  const [additionalLocations, setAdditionalLocations] = useState<
    | {
        id: number;
        location: any;
        role: any;
      }[]
    | null
  >(null);
  const [locationList, setLocationList] = useState<any[]>([]);
  const [userLocation, setUserLocation] = useState<any[]>([]);
  useEffect(() => {
    if (user?.practice.practiceId) {
      UserServices.getAllRoles(user?.practice.practiceId)
        .then(({ data }) => {
          setUserRoles(data);
          setUserLocation(user?.practice.locations);
        })
        .catch(() => toast.error("Error in fetching Roles"));
      UserServices.getPracticeById(user?.practice.practiceId)
        .then(({ data }) => {
          setLocationList(data?.locations);
        })
        .catch(() => toast.error("Error in fetching Locations"));
    }
  }, [user?.practice.locations, user?.practice.practiceId]);

  const handleSubmit = async (values: any) => {
    const location_old =
      userLocation.map((_, index) => ({
        locationId: locationList?.find(
          (loc) => loc?.locationName === values[`locationName${index}`]
        ).locationId,
        roleId: userRoles.find(
          (role) => role.roleName === values[`userRole${index}`]
        )?.roleId,
      })) ?? [];
    const Practice = await UserServices.getPracticeById(
      user?.practice.practiceId ?? ""
    );
    const subscriptionId =
      Practice?.data?.subscriptionpractices[0]?.subscriptionId;
    const location_new =
      additionalLocations?.map((location) => {
        return {
          locationId: locationList?.find(
            (loc) => loc?.locationName === location.location
          ).locationId,
          roleId: userRoles?.find((role) => role.roleName === location.role)
            ?.roleId,
        };
      }) ?? [];
    const payload = {
      userName: values.username,
      adminId: userId,
      practiceId: values.practiceId,
      locations: [...location_old, ...location_new],
      email: values.email,
      phoneNumber: values.phoneNumber,
      userType: user?.userType ?? "",
    };

    user &&
      UserServices.updateUser(user?.userId, practiceId, payload, subscriptionId)
        .then(() => {
          toast.success("User Updated Successfully");
        })
        .catch((err) => {
          toast.error("User Update Failed", err.message);
        })
        .finally(() => {
          // setRefreshKey((prev) => prev + 1);
          setAdditionalLocations(null);
          setRefresh(!refresh);
          window.location.reload();
        });
  };

  const handleSave = () => {
    setEdit(!edit);
  };

  const handleAddLocation = () => {
    if (
      locationList?.length ===
      (userLocation.length ?? 0) +
        (additionalLocations ? additionalLocations?.length : 0)
    ) {
      toast.info("Maximum location for the practice reached!");
      return;
    }
    setAdditionalLocations((prev) => {
      if (prev === null) {
        return [
          {
            id: additionalLocations?.length ?? 0,
            location: "",
            role: "",
          },
        ];
      }
      return [
        ...prev,
        {
          id: additionalLocations?.length ?? 0,
          location: "",
          role: "",
        },
      ];
    });
  };
  const handleEditUser = (index: number) => {
    setUserLocation((prevLocationList) => {
      if (prevLocationList?.length <= 1) {
        toast.info("At least one location is mandatory.");
        return prevLocationList;
      }
      return prevLocationList.filter((_, i) => i !== index);
    });
  };
  if (!user?.practice.practiceId) {
    return (
      <div className="p-6 bg-white rounded-lg add-user-form">
        <p className="py-5 text-center border">Practice id not found</p>
      </div>
    );
  }
  return (
    <div className="p-6 bg-white rounded-lg add-user-form">
      <div className="">
        {user && userRoles.length > 0 ? (
          <Formik
            initialValues={{
              username: user?.userName || "",
              userid: user?.userId || "",
              email: user?.email || "",
              phoneNumber: user?.phoneNumber || "",
              city: user?.practice?.locations[0].city,
              state: user?.practice?.locations[0].state,
              address: user?.practice?.locations[0].address,
              zipcode: user?.practice?.locations[0].zipcode,
              practiceId: user?.practice.practiceId || "",
              ...user.practice.locations.reduce(
                (acc, location, index) => ({
                  ...acc,
                  [`locationName${index}`]: location.locationName,
                  [`userRole${index}`]: location.role.roleName,
                }),
                {}
              ),
            }}
            onSubmit={handleSubmit}
          >
            {() => (
              <>
                <Form>
                  <div
                    className={"page-header page-header-bg practiceTab-form "}
                  >
                    <span className="mb-0">Users</span>
                    <div>
                      {edit ? (
                        <Button
                          btntype="outlined"
                          type={"button"}
                          onClick={handleSave}
                          className="me-2 submit-btn"
                          style={{ backgroundColor: "#3ba2ed" }}
                        >
                          {"Save"}
                        </Button>
                      ) : (
                        <Button
                          btntype="outlined"
                          type={"submit"}
                          onClick={handleSave}
                          className="me-2 submit-btn"
                          style={{ backgroundColor: "#3ba2ed" }}
                        >
                          {"Edit"}
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="practice-tab">
                    <h2 className="my-3 section-head">Basic Details</h2>
                    <FormRow>
                      <FormInput
                        id="username"
                        label="User Name"
                        name="username"
                        placeholder="Enter User Name"
                        readonly={edit}
                      />
                      <FormInput
                        id="userid"
                        label="User ID"
                        placeholder="Enter User ID"
                        name="userid"
                        readonly={false}
                      />
                    </FormRow>
                    <FormRow>
                      <FormInput
                        id="email"
                        label="Official Email ID"
                        placeholder="Enter Email"
                        name="email"
                        readonly={edit}
                      />
                      <FormInput
                        id="phoneNumber"
                        label="Phone Number"
                        placeholder="Enter Phone Number"
                        name="phoneNumber"
                        readonly={edit}
                      />
                    </FormRow>
                    {userLocation &&
                      userLocation.length > 0 &&
                      userLocation.map((location, index) => (
                        <FormGroup key={location.locationId}>
                          <FormRow>
                            <Col md={4}>
                              <Label
                                for={`locationName${index}`}
                                className="label"
                              >
                                Location {index + 1}
                              </Label>
                              <Field
                                className="w-100 dropdown"
                                as="select"
                                name={`locationName${index}`}
                                id={`locationName${index}`}
                                readOnly={edit}
                                disabled={!edit}
                              >
                                {locationList.map((loc) => (
                                  <option
                                    key={loc.locationId}
                                    value={loc.locationName}
                                  >
                                    {loc.locationName}
                                  </option>
                                ))}
                              </Field>
                            </Col>
                            <Col md={4} className="d-flex align-items-end">
                              <div className="w-100">
                                <div className="d-flex justify-content-between align-items-center">
                                  <Label
                                    for={`userRole${index}`}
                                    className="label"
                                  >
                                    User Role {index + 1}
                                  </Label>
                                  {edit && index === 0 && (
                                    <Button
                                      type="button"
                                      onClick={handleAddLocation}
                                      className=""
                                      style={{
                                        backgroundColor: "#3ba2ed",
                                        padding: "3px 11px",
                                        margin: "0px 0px 5px 1px",
                                        fontSize: "12px",
                                      }}
                                    >
                                      Add
                                    </Button>
                                  )}
                                </div>
                                <Field
                                  className="w-100 dropdown"
                                  as="select"
                                  name={`userRole${index}`}
                                  id={`userRole${index}`}
                                  readOnly={edit}
                                  disabled={!edit}
                                >
                                  {userRoles.map((role) => (
                                    <option
                                      key={role.roleId}
                                      value={role.roleName}
                                    >
                                      {role.roleName}
                                    </option>
                                  ))}
                                </Field>
                              </div>
                            </Col>
                            <Col md={1}>
                              {edit && (
                                <FontAwesomeIcon
                                  icon={faTrash}
                                  className="py-3 mt-4 location-delete"
                                  onClick={() => handleEditUser(index)}
                                />
                              )}
                            </Col>
                          </FormRow>
                        </FormGroup>
                      ))}

                    {additionalLocations &&
                      additionalLocations.length > 0 &&
                      additionalLocations.map((location, index) => (
                        <FormGroup key={location.id}>
                          <FormRow>
                            <Col md={4}>
                              <Label
                                for={`additionalLocationName${index}`}
                                className="label"
                              >
                                Additional Location {index + 1}
                              </Label>
                              <Field
                                className="w-100 dropdown"
                                as="select"
                                name={`additionalLocationName${index}`}
                                id={`additionalLocationName${index}`}
                                readOnly={edit}
                                disabled={!edit}
                                onChange={(e: any) =>
                                  setAdditionalLocations((prev) => {
                                    if (!prev)
                                      return [
                                        {
                                          id: index,
                                          location: e.target.value,
                                          role:
                                            additionalLocations[index].role ??
                                            "",
                                        },
                                      ];

                                    const prev_filter = prev.filter(
                                      (loc) =>
                                        loc.id !== additionalLocations[index].id
                                    );

                                    return [
                                      ...prev_filter,
                                      {
                                        id: index,
                                        location: e.target.value,
                                        role:
                                          additionalLocations[index]?.role ??
                                          "",
                                      },
                                    ];
                                  })
                                }
                              >
                                <option value={""}> Select </option>
                                {locationList &&
                                  locationList.length > 0 &&
                                  locationList.map((loc) => (
                                    <option
                                      key={loc.locationId}
                                      value={loc.locationName}
                                    >
                                      {loc.locationName}
                                    </option>
                                  ))}
                              </Field>
                            </Col>
                            <Col md={4}>
                              <Label
                                for={`additionalUserRole${index}`}
                                className="label"
                              >
                                Additional User Role {index + 1}
                              </Label>
                              <Field
                                className="w-100 dropdown"
                                as="select"
                                name={`additionalUserRole${index}`}
                                id={`additionalUserRole${index}`}
                                readOnly={edit}
                                disabled={!edit}
                                onChange={(e: any) =>
                                  setAdditionalLocations((prev) => {
                                    if (!prev)
                                      return [
                                        {
                                          id: index,
                                          role: e.target.value,
                                          location:
                                            additionalLocations[index]
                                              ?.location ?? "",
                                        },
                                      ];
                                    const prev_filter = prev.filter(
                                      (loc) =>
                                        loc.id !== additionalLocations[index].id
                                    );
                                    return [
                                      ...prev_filter,
                                      {
                                        id: index,
                                        role: e.target.value,
                                        location:
                                          additionalLocations[index]
                                            ?.location ?? "",
                                      },
                                    ];
                                  })
                                }
                              >
                                <option value={""}>Select </option>
                                {userRoles.map((role) => (
                                  <option
                                    key={role.roleId}
                                    value={role.roleName}
                                  >
                                    {role.roleName}
                                  </option>
                                ))}
                              </Field>
                            </Col>
                            <Col md={1}>
                              {edit && (
                                <FontAwesomeIcon
                                  icon={faTrash}
                                  className="py-3 mt-4 location-delete"
                                  onClick={() => {
                                    setAdditionalLocations(
                                      additionalLocations?.filter(
                                        (_, i) => i !== index
                                      )
                                    );
                                  }}
                                />
                              )}
                            </Col>
                          </FormRow>
                        </FormGroup>
                      ))}
                    <h2 className="py-2 section-head">Practice Details</h2>
                    <FormRow>
                      <FormInput
                        id="practiceId"
                        label="Practice ID"
                        placeholder="Enter Practice ID"
                        name="practiceId"
                        readonly={false}
                      />
                    </FormRow>
                    <FormRow>
                      <FormInput
                        id="city"
                        label="City"
                        placeholder="Enter City"
                        name="city"
                        readonly={false}
                      />
                      <FormInput
                        id="state"
                        label="State"
                        placeholder="Enter State"
                        name="state"
                        readonly={false}
                      />
                    </FormRow>
                    <FormRow>
                      <FormInput
                        id="zipcode"
                        label="Zipcode"
                        placeholder="Enter Zipcode"
                        name="zipcode"
                        readonly={false}
                      />
                      <FormInput
                        id="address"
                        label="Address"
                        placeholder="Enter Address"
                        name="address"
                        readonly={false}
                      />
                    </FormRow>
                  </div>
                </Form>
                <Modal isOpen={showPopup} toggle={() => setShowPopup(false)}>
                  <ModalHeader toggle={() => setShowPopup(false)}>
                    Location Not Found
                  </ModalHeader>
                  <ModalBody>
                    The location you are trying to add is not found. Please
                    check and try again.
                  </ModalBody>
                </Modal>
              </>
            )}
          </Formik>
        ) : (
          <div className="text-center">
            <Spinner />
          </div>
        )}
      </div>
    </div>
  );
};

export default PracticeTab;
