import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import UserTab from "./userTab";

import { EditUserSidebar } from "./EdituserSidebar";
import PracticeTab from "../EditUser/practiceTab";
import { UserServices } from "../../../services/user";
import { Spinner } from "reactstrap";
type Role = {
  roleId: string;
  roleName: string;
  roleType: string;
  adminId: string;
  practiceId: string;
  permissions: string[];
  status: null | string;
  createdAt: string;
  updatedAt: string;
  products: any[];
};

type Location = {
  locationId: string;
  locationName: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  state: string;
  zipcode: string;
  status: boolean;
  createdAt: string;
  updatedAt: string;
  practiceId: string;
  role: Role;
};

type Practice = {
  practiceId: string;
  locations: Location[];
};

type User = {
  userId: string;
  userName: string;
  userType: null | string;
  email: string;
  phoneNumber: string;
  adminId: string;
  status: null | string;
  createdAt: string;
  updatedAt: string;
  practice: Practice;
};

const EditUser = () => {
  const [tabName, setTabName] = useState("basicDetails");
  const { id } = useParams<{ id: string }>();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false)


  useEffect(() => {
    if (id) {
      setLoading(true)
      UserServices.getByUserId(id)
        .then(({ data }) => {
          setUser(data);
          console.log(data);

        })
        .catch((err) => {
          console.log(err);
        }).finally(() => {
          setLoading(false)
        });
    }
  }, [id]);
  const modules = [
    {
      id: 1,
      label: "Basic Details",
      active: tabName === "basicDetails",
      value: "basicDetails",
    },
    {
      id: 2,
      label: "Product & Permissions",
      active: tabName === "permissions",
      value: "permissions",
    },
  ];

  const toggleTabs = (tabName: string) => {
    setTabName(tabName);
  };

  return !loading ? (
    user ? <>
      <div className="practice-wrapper d-flex ">
        <div className="first-container">
          <EditUserSidebar
            modules={modules}
            user={user}
            toggleTabs={toggleTabs}
          />
        </div>

        <div className="second-container p-3">
          {tabName === "basicDetails" ? (
            <PracticeTab user={user} />
          ) : null}
          {tabName === "permissions" ? (
            <UserTab
              roleId={user?.practice?.locations[0]?.role?.roleId ?? ""}
            />
          ) : null}
        </div>
      </div>
    </>
      :
      <>Error fetching data</>
  ) : (
    <Spinner />
  );
};

export default EditUser;
