import React from "react";
import PageHeader from "../../../components/PageHeader";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleCheck } from "@fortawesome/free-solid-svg-icons";
import { Spinner } from "reactstrap";

type User = {
  userId: string;
  userName: string;
  userType: null | string;
  email: string;
  phoneNumber: string;
  adminId: string;
  status: null | string;
  createdAt: string;
  updatedAt: string;
  // practice: Practice;
};
interface EdituserSidebarProps {
  modules: { id: number; label: string; active: boolean; value: string }[];
  toggleTabs: (arg: string) => void;
  user: User | null;
}

export const EditUserSidebar: React.FC<EdituserSidebarProps> = (props) => {
  const { modules, toggleTabs, user } = props;

  return user ? (
    <>
      <PageHeader title="Plan Details" type="subheading" />
      <div className="hspt-details d-flex p-3 gap-3">
        <div className="hspt-details">
          <h3>{user?.userName}</h3>
          <p className="mb-1">
            <span>User ID : </span>
            <span>{user?.userId}</span>
          </p>
          <div
            style={{
              backgroundColor: user?.status
                ? "rgba(30, 185, 101, 0.1)"
                : "rgba(219, 73, 73, 0.42)",
              color: user?.status ? "#1EB965" : "#ac1616",
              fontSize: "12px",
            }}
            className="cmn-badge "
          >
            {user?.status ? "Active" : "Inactive"}
          </div>
        </div>
      </div>

      <div className="prac-module-wrapper">
        {modules.map(
          (data: {
            id: number;
            label: string;
            active: boolean;
            value: string;
          }) => (
            <div
              key={data.id}
              className={`cursor-pointer ${data.active ? "module-active" : ""}`}
              onClick={() => {
                toggleTabs(data.value);
              }}
            >
              <span className="me-2">
                <FontAwesomeIcon icon={faCircleCheck} color="#1EB965" />
              </span>
              {data.label}
            </div>
          )
        )}
      </div>
    </>
  ) : (
    <p>
      {" "}
      <Spinner />{" "}
    </p>
  );
};
