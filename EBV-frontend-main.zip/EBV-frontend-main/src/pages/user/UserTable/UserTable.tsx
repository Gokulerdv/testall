import { Key, SetStateAction, useCallback, useEffect, useState } from "react";
import PageHeader from "../../../components/PageHeader";
import { Link, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUpload,
  faTableColumns,
  faPenToSquare,
  // faTrash,
  faUser,
  faSort,
} from "@fortawesome/free-solid-svg-icons";
import DataTable, { TableColumn } from "react-data-table-component";
import Button from "../../../components/Button";
import FormSearch from "../../../components/FormSearch";
import HospitalDetails from "../../../components/HospitalDetails";
import { UserServices } from "../../../services/user";
import Permissions from "../../../components/Permissions";

import AddUser from "../Add-user/AddUser";
import {
  Badge,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Spinner,
  UncontrolledDropdown,
} from "reactstrap";
import ActivateDeactivatePopup from "../../../components/ActivatePopup";
import { toast } from "react-toastify";


import { CSVLink } from "react-csv";
import UserFilter from "./UserFilter";
import moment from "moment";
import { Tooltip, OverlayTrigger } from "react-bootstrap";


interface SelectOption {
  value: string;
  label: string;
}
const customStyles = {
  head: {
    style: {
      fontWeight: 600,
      fontSize: "14px",
    },
  },
  headRow: {
    style: {
      backgroundColor: "#E0E3E6",
    },
  },
};
type ColumnKey =
  | "userName"
  | "userId"
  | "role"
  | "assignedProducts"
  | "permissions"
  | "location"
  | "lastLogin"
  | "phoneNumber"
  | "actions";
const UserTable = () => {
  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");
  const navigate = useNavigate();
  const practiceId = userDetails?.userData?.practice?.practiceId;




  const [data, setData] = useState<UserDetail[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [showAddUser, setShowAddUser] = useState(false);
  const [showModal, setShowModal] = useState<string | null>(null);
  const [userIdToDelete, setUserIdToDelete] = useState<{
    userId: string;
    type: string;
    practiceId: string;
  }>({
    userId: "",
    type: "",
    practiceId: "",
  });
  const [refreshKey, setRefreshKey] = useState(0);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [locationOptions, setLocationOptions] = useState<SelectOption[]>([]);
  const [filteredData, setFilterData] = useState<any[]>([]);
  const [productOptions, setProductOptions] = useState<SelectOption[]>([]);
  const [showPermissionModal, setPermissionShowModal] = useState(false);
  const [permission, setPermissions] = useState<string[]>([]);
  const [filterByUserData, setFilterByUserData] = useState<{
    role: SelectOption[] | null;
    product: SelectOption[] | null;
    location: SelectOption[] | null;
    permission: SelectOption[] | null;
  }>({
    role: null,
    product: null,
    location: null,
    permission: null,
  });
  const [columnVisibility, setColumnVisibility] = useState<
    Record<ColumnKey, boolean>
  >({
    userName: true,
    userId: true,
    role: true,
    assignedProducts: true,
    permissions: true,
    location: true,
    lastLogin: true,
    phoneNumber: true,
    actions: true,
  });
  const handleShowModal = (show: boolean, permissions: string[]) => {
    setPermissionShowModal(show);
    setPermissions(permissions);
  }
  const TableColumns: TableColumn<UserDetail>[] = [
    {
      name: "User Name",
      sortable: true,
      sortFunction: (a, b) => {
        return a.userName.localeCompare(b.userName);
      },
      cell: (row) => {
        return (
          <span
            onClick={() => handleEditClick(row.userId)}
            className="txt-underline"
          >
            {row.userName}
          </span>
        );
      },
      omit: !columnVisibility.userName,
    },
    {
      name: "User ID",
      sortable: true,
      selector: (row) => row.userId,
      omit: !columnVisibility.userId,
    },
    {
      name: "Role",
      sortable: true,
      cell: (row) => {
        const a =
          row?.roles.length > 0
            ? row?.roles.map((role: Role) => role.roleName)
            : ["-"];
        return a.join(", ");
      },
      sortFunction: (a, b) => {
        return a.roles[0].roleName.localeCompare(b.roles[0].roleName);
      },
      omit: !columnVisibility.role,
    },
    {
      name: "Assigned Products",
      sortable: true,
      cell: (row) => {
        const products =
          row?.roles.length > 0
            ? row.roles
              .map((role: Role) =>
                role.products.map((product: any) => product.product_name)
              )
              .flat()
            : [];
        const maxVisibleProducts = 1;
        const visibleProducts = products.slice(0, maxVisibleProducts);
        const remainingProducts = products.length - maxVisibleProducts;

        return (
          <div className="d-flex flex-row" style={{ alignItems: "center" }}>
            {visibleProducts.map((product, index) => (
              <span key={index} className="prod-badge">
                {product}
              </span>
            ))}
            {remainingProducts > 0 && (
              <OverlayTrigger
                placement="bottom"
                overlay={
                  <Tooltip id={`tooltip-${row.userId}`}>
                    {products.slice(maxVisibleProducts).join(", ")}
                  </Tooltip>
                }
              >
                <span className="cursor-pointer px-2">
                  {remainingProducts}+
                </span>
              </OverlayTrigger>
            )}
          </div>
        );
      },
      sortFunction: (a, b) => {
        return a.roles[0].products[0].product_name.localeCompare(
          b.roles[0].products[0].product_name
        );
      },
      omit: !columnVisibility.assignedProducts,
    },
    {
      name: "Permissions",
      width: "220px",

      cell: ({ roles: row }) => {
        const visiblePermissions = row[0]?.permissions.slice(0, 2);
        const remainingPermissions = row[0]?.permissions.slice(2);


        return (
          <div className='modl-badge'>
            {visiblePermissions?.map((permission: string, index: Number) => (
              <Badge key={index as Key} className='m-1' style={{ margin: '3px', color: "black", fontSize: "11px", fontWeight: "500" }}>
                {permission}
              </Badge>
            ))}
            <div>
              {remainingPermissions?.length > 0 && (
                <span className='p-2'
                  style={{ textDecoration: 'underline', cursor: 'pointer', color: 'blue' }}
                  onClick={() => handleShowModal(true, remainingPermissions)}
                >
                  +{remainingPermissions.length} more
                </span>
              )}
            </div>

          </div>
        );
      }, sortable: true,
      omit: !columnVisibility.permissions,
      sortFunction: (a, b) => {
        const aPermissions = a.roles.length > 0 ? Array.from(new Set(a.roles.flatMap(role => role.permissions))) : ["-"];
        const bPermissions = b.roles.length > 0 ? Array.from(new Set(b.roles.flatMap(role => role.permissions))) : ["-"];
        return aPermissions[0].localeCompare(bPermissions[0]);
      }
    },

    {
      name: "Location",
      sortable: true,
      cell: (row) => {
        return row.practices
          ?.map((practice: any) => `${practice?.city}, ${practice?.state}`)
          .join(", ");
      },
      sortFunction: (a, b) => {
        return a.practices[0].locations[0].locationName.localeCompare(
          b.practices[0].locations[0].locationName
        );
      },
      omit: !columnVisibility.location,
    },
    {
      name: "Last Login",
      sortable: true,

      selector: (row) => moment(row.updatedAt).format("DD-MM-YYYY") ?? "-",
      sortFunction: (a, b) => {
        return a.updatedAt.localeCompare(b.updatedAt);
      },
      omit: !columnVisibility.lastLogin,
    },
    {
      name: "Phone Number",
      sortable: true,
      selector: (row) => row.phoneNumber,
      sortFunction: (a, b) => {
        return a.phoneNumber.localeCompare(b.phoneNumber);
      },
      omit: !columnVisibility.phoneNumber,
    },
    {
      name: "Actions",
      cell: (row) => {
        return (
          <div>
            <Button
              btntype="transparent"
              className="p-0 me-3"
              onClick={() => handleEditClick(row.userId)}
            >
              <FontAwesomeIcon
                icon={faPenToSquare}
                color="#557AFF"
                style={{ fontSize: "14px" }}
              />
            </Button>
            {/* <Button
              btntype="transparent"
              onClick={() => handleDactivate(row.userId, "delete")}
              className="p-0 me-3"
            >
              <FontAwesomeIcon
                icon={faTrash}
                color="#E32F2F"
                style={{ fontSize: "14px" }}
              />
            </Button> */}
            <Button
              btntype="transparent"
              onClick={() =>
                handleDactivate(
                  row.userId,
                  row.status ? "deactivate" : "activate",
                  row?.practices[0]?.practiceId
                )
              }
              className="p-1"
            >
              <FontAwesomeIcon
                icon={faUser}
                color={`${row && typeof row.status === "boolean" && row.status === false
                  ? "red"
                  : "#557AFF"
                  }`}
                style={{ fontSize: "14px" }}
              />
            </Button>
          </div>
        );
      },
      omit: !columnVisibility.actions,
    },
  ];

  const handleDactivate = (id: string, type: string, practiceId: string) => {
    setUserIdToDelete({
      userId: id,
      type: type,
      practiceId: practiceId,
    });
    setShowModal(type);
  };

  const deactivateUser = async (id: string) => {
    const Practice = await UserServices.getPracticeById(practiceId ?? "");
    const payload = showModal === "activate" ? "true" : "false";
    const subid =
      (await Practice?.data?.subscriptionpractices[0]?.subscriptionId) ?? "";
    UserServices.deactivateUser(id, practiceId, payload, subid)
      .then(() => {
        toast.success(
          `User ${showModal !== "activate" ? "Deactivated" : "Activated"
          } Successfully`
        );
        setRefreshKey((oldKey) => oldKey + 1);
      })
      .catch((err: any) => {
        if (err.response.status == 403) {
          toast.warn(err?.response.data.message);
        } else {
          toast.error(err?.message);
        }
      });
    setShowModal(null);
  };
  const deleteUser = (id: string) => {
    UserServices.deleteUser(id, practiceId)
      .then(() => {
        toast.success("User Deleted Successfully");
        setRefreshKey((oldKey) => oldKey + 1);
      })
      .catch(() => {
        toast.error("Error deleting user");
      });
    setShowModal(null);
  };
  const handleModal = (value: string | null) => {
    if (value === null && showModal === "delete" && userIdToDelete) {
      return deleteUser(userIdToDelete.userId);
    }
    if (value === null && showModal === "deactivate" && userIdToDelete) {
      return deactivateUser(userIdToDelete.userId);
    }
    if (value === null && showModal === "activate" && userIdToDelete) {
      return deactivateUser(userIdToDelete.userId);
    }
    value === "cancel" ? setShowModal(null) : setShowModal(value);
  };

  useEffect(() => {
    if (practiceId) {


      setLoading(true);
      UserServices.getByUserPracticeId(practiceId)
        .then((res: { data: SetStateAction<UserDetail[]>; }) => {
          setData(res.data);
        })
        .finally(() => setLoading(false));
    }
  }, [refreshKey, practiceId, showAddUser]);

  const handleClose = () => setShowAddUser(!showAddUser);
  const handleEditClick = (id: string) => {
    // will be removed once the API is updated
    navigate(`edituser/${id}`);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  useEffect(() => {
    const filterData = () =>
      data.filter((user) =>
        Object.values(user).some((value) => {
          if (typeof value === "string") {
            const lowercaseValue = value.toLowerCase();
            return (
              lowercaseValue.includes(searchQuery.toLowerCase()) ||
              (Array.isArray(user.roles) &&
                user.roles.some((role: { roleName: string }) =>
                  role.roleName
                    .toLowerCase()
                    .includes(searchQuery.toLowerCase())
                )) ||
              user.practices
                .flatMap((practice) =>
                  practice.locations.map((location: { locationName: string }) =>
                    location.locationName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                  )
                )
                .some((location) => location) ||
              user.phoneNumber.includes(searchQuery)
            );
          }
          return false;
        })
      );
    if (data) {
      setFilterData(filterData());
    }
  }, [data, searchQuery]);
  const formatDate = (dateString: string | number | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB");
  };

  const formatTime = (dateString: string | number | Date) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString("en-GB");
  };

  const csv_data: any = filteredData?.map((user) => {
    return {
      User_Name: user.userName,
      User_ID: user.userId,
      Role: Array.isArray(user.roles)
        ? user.roles.map((role: Role) => role.roleName).join(", ")
        : "",
      Assigned_Products: Array.isArray(user.roles)
        ? user.roles
          .map((role: Role) =>
            role.products.map((product) => product.product_name)
          )
          .flat()
          .join(", ")
        : "",
      Permissions: Array.from(
        new Set(
          Array.isArray(user.roles)
            ? user.roles.flatMap((role: Role) => role.permissions)
            : []
        )
      )
        .map((i) => (i as string))
        .join(", "),
      Location: user.practices
        .flatMap((practice: { locations: { locationName: string }[] }) =>
          practice.locations.map(
            (location: { locationName: string }) => location.locationName
          )
        )
        .join(", "),
      Last_Login: user.lastlogin ?? new Date().toLocaleDateString(),
      Phone_Number: user.phoneNumber,
      Created_At_Date: formatDate(user.createdAt),
      Created_At_Time: formatTime(user.createdAt),
      Updated_At_Date: formatDate(user.updatedAt),
      Updated_At_Time: formatTime(user.updatedAt),
    };
  });

  const filterByUser = useCallback(
    (
      productData: string[],

      permissionData: string[],
      locationData: string[]
    ) => {
      const filterByUserData = data.filter((user) => {
        const products = user?.roles
          .map((role: Role) =>
            role.products.map((product: any) => product.product_name)
          )
          .flat();

        const permissions = user?.roles
          .flatMap((role: Role) => role.permissions)
          .map((i) =>
            i.split("_")[i.split("_").length - 1].toLocaleLowerCase()
          );

        const locations = user?.practices.flatMap((practice: any) =>
          practice.locations.map(
            (location: { locationName: string }) => location.locationName
          )
        );

        return (
          (productData.length === 0 ||
            productData.some((product) => products.includes(product))) &&
          (permissionData.length === 0 || permissionData.includes("all")
            ? true
            : permissionData.some((element) => {
              return permissions?.includes(element.toLocaleLowerCase());
            })) &&
          (locationData.length === 0 ||
            locationData.some((location) => locations.includes(location)))
        );
      });
      setFilterData(filterByUserData);

      return filterByUserData;
    },
    [data]
  );
  useEffect(() => {
    if (filterByUserData) {
      const productData =
        filterByUserData.product?.map((product) => product.value) ?? [];
      const permissionData =
        filterByUserData.permission?.map((permission) => permission.value) ??
        [];
      const locationData =
        filterByUserData.location?.map((location) => location.value) ?? [];
      filterByUser(productData, permissionData, locationData);
    }
  }, [filterByUserData]);

  const generateAssignedProductOptions = (data: UserDetail[]) => {
    const productOptions = data.flatMap((user) =>
      user.roles
        .map((role: Role) =>
          role.products.map((product: any) => product.product_name)
        )
        .flat()
    );
    return Array.from(new Set(productOptions)).map((product) => ({
      value: product,
      label: product,
    }));
  };
  useEffect(() => {
    if (data?.length > 0) {
      setProductOptions(generateAssignedProductOptions(data));
    }
  }, [data]);
  const generateLocationOptions = (data: UserDetail[]) => {
    const locationOptions = data.flatMap((user) =>
      user.practices.flatMap((practice: any) =>
        practice.locations.map(
          (location: { locationName: string }) => location.locationName
        )
      )
    );
    return Array.from(new Set(locationOptions)).map((location) => ({
      value: location,
      label: location,
    }));
  };
  useEffect(() => {
    setLocationOptions(generateLocationOptions(data));
  }, [data]);

  const permissionOptions = [
    { value: "all", label: "All" },
    { value: "view", label: "View" },
    { value: "edit", label: "Edit" },
    { value: "create", label: "Create" },
    { value: "delete", label: "Delete" },
  ];
  const columnKeys: ColumnKey[] = [
    "userName",
    "userId",
    "role",
    "assignedProducts",
    "permissions",
    "location",
    "lastLogin",
    "phoneNumber",
    "actions",
  ];
  const handleColumnVisibilityChange = (column: ColumnKey) => {
    setColumnVisibility((prevState) => ({
      ...prevState,
      [column]: !prevState[column],
    }));
  };
  return (
    <>
      <div className="user-table">
        <PageHeader
          title="Users"
          btnTxt="Add Users"
          btnClick={() => setShowAddUser(true)}
        />
        <div className="p-3">
          {data[0]?.practices[0] && (
            <HospitalDetails data={data[0]?.practices[0]} />
          )}
          <div className="tabs-indicator d-flex align-items-center gap-2">
            <div className="p-2 active cursor-pointer bold-3">User</div>
            <Link to={"/user/roles"} className="p-2 cursor-pointer">
              <span>Role</span>
            </Link>
          </div>
          <div className="mt-3">
            <div className="d-flex justify-content-between">
              <div className="d-flex gap-2 search-input-wrapper">
                <FormSearch onSearch={handleSearch} />

                <UserFilter
                  filterByUserData={filterByUserData}
                  setFilterByUserData={setFilterByUserData}
                  config={[productOptions, permissionOptions, locationOptions]}
                />
              </div>
              <div className="d-flex gap-2">
                <UncontrolledDropdown className="user-column">
                  <DropdownToggle
                    btntype="outlined"
                    className="mx-2 user-column"
                  >
                    <FontAwesomeIcon icon={faTableColumns} className="mx-1" />
                    Columns
                  </DropdownToggle>
                  <DropdownMenu>
                    {columnKeys?.map((key: ColumnKey) => (
                      <DropdownItem
                        key={key}
                        toggle={false}
                        onClick={() => handleColumnVisibilityChange(key)}
                      >
                        <input
                          type="checkbox"
                          checked={columnVisibility[key]}
                          readOnly
                        />{" "}
                        {key.charAt(0).toUpperCase() + key.slice(1)}
                      </DropdownItem>
                    ))}
                  </DropdownMenu>
                </UncontrolledDropdown>
                <Button btntype="outlined">
                  <FontAwesomeIcon icon={faUpload} className="me-1" />
                  <CSVLink style={{ color: "#3ba2ed" }} data={csv_data}>
                    Export
                  </CSVLink>
                </Button>
              </div>
            </div>
            <div className="table-wrapper mt-3">
              {loading && (
                <div className="text-center">
                  <Spinner />
                </div>
              )}
              {!loading && (
                <DataTable
                  columns={TableColumns}
                  data={filteredData} // Use the filtered data here
                  pagination
                  sortIcon={<FontAwesomeIcon icon={faSort} />}
                  className="border"
                  customStyles={customStyles}
                />
              )}
            </div>
          </div>
        </div>
      </div>
      {showAddUser && (
        <AddUser handleModalClose={handleClose} showAddUser={showAddUser} />
      )}
      {(showPermissionModal) &&
        <Permissions
          permissions={permission}
          showModal={showPermissionModal}
          handleCloseModal={() => setPermissionShowModal(false)}
        />
      }
      <ActivateDeactivatePopup
        isOpen={showModal !== null ? true : false}
        proceedFunction={() => handleModal(null)}
        toggle={() => handleModal("cancel")}
        action={showModal ?? ""}
        name={"User"}
      />
    </>
  );
};

export default UserTable;
