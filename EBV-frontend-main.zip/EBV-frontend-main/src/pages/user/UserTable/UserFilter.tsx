import { faFilter, faTimes } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Select from "react-select";
import { Dropdown, Form } from "react-bootstrap";
import { useState } from "react";

interface SelectOption {
  value: string;
  label: string;
}

interface UserFilterProps {
  filterByUserData: {
    product: SelectOption[] | null;
    role: SelectOption[] | null;
    permission: SelectOption[] | null;
    location: SelectOption[] | null;
  };
  setFilterByUserData: any;
  config: any;
}

const UserFilter = ({
  filterByUserData,
  setFilterByUserData,
  config,
}: UserFilterProps) => {
  const [productOptions, permissionOptions, locationOptions] = config;
  const [isOpen, setIsOpen] = useState(false);
  const handleFilterChange = (name: string, value: any) => {
    setFilterByUserData((prev: any) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <Dropdown
      show={isOpen}
      onToggle={() => {
        setIsOpen(!isOpen);
      }}
      className="filter-dropdown"
    >
      <Dropdown.Toggle
        variant="primary"
        id="dropdown-basic"
        className="ml-3 filter-button"
      >
        <FontAwesomeIcon icon={faFilter} className="me-1" />
        Filters
      </Dropdown.Toggle>

      <Dropdown.Menu
        style={{ width: "21rem", padding: "10px" }}
        className="filter"
      >
        <div className="close-modal-btn">
          <p>Filters</p>
          <button onClick={() => setIsOpen(false)}>
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>
        <Form.Group controlId="claim-number" className="mb-4">
          <Form.Label>Assigned Product</Form.Label>
          <Select
            options={productOptions}
            isMulti
            placeholder="Select"
            className="basic-multi-select"
            classNamePrefix="select"
            value={filterByUserData.product}
            onChange={(value) => handleFilterChange("product", value)}
          />

          <Form.Label>Permission</Form.Label>
          <Select
            options={permissionOptions}
            isMulti
            placeholder="Select"
            className="basic-multi-select"
            value={filterByUserData.permission}
            classNamePrefix="select"
            onChange={(value) => handleFilterChange("permission", value)}
          />

          <Form.Label>Location</Form.Label>
          <Select
            options={locationOptions}
            isMulti
            placeholder="Select"
            value={filterByUserData.location}
            onChange={(value) => handleFilterChange("location", value)}
          />
        </Form.Group>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default UserFilter;
