import { useEffect, useState } from "react";
import PageHeader from "../../components/PageHeader";
import { Link, useNavigate } from "react-router-dom";
import FormSearch from "../../components/FormSearch";
import Button from "../../components/Button";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUpload } from "@fortawesome/free-solid-svg-icons";
import AddUser from "./Add-user/AddUser";

import { Spinner } from "reactstrap";
import { UserServices } from "../../services/user";

const User = () => {
  const [practice, setPractice] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [showAddUser, setShowAddUser] = useState(false);
  const navigate = useNavigate();
  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");
  const practiceId = userDetails?.userData?.practice?.practiceId;


  const handleImageClick = (id: string) => {
    navigate(`/usertable/${id}`);
  };
  const handleClose = () => {
    setShowAddUser(!showAddUser);
  };
  useEffect(() => {
    setLoading(true);
    UserServices.getAllPractices(practiceId)
      .then(({ data }: { data: any }) => {
        setPractice(data);
      })
      .then(() => {
        setLoading(false);
      });
  }, [showAddUser]);
  return (
    <>
      <PageHeader
        title="Manage Users"
        btnTxt="Add Users"
        btnClick={handleClose}
      />
      <div className="p-3">
        <div className="tabs-indicator d-flex align-items-center gap-2">
          <div className="p-2 active cursor-pointer bold-3">User</div>
          <Link to={"/user/roles"} className="p-2 cursor-pointer">
            <span>Role</span>
          </Link>
        </div>

        <div className="mt-3">
          <div className="d-flex justify-content-between">
            <FormSearch
              onSearch={(query) => console.log(query, "checking the query")}
            />
            <Button btntype="outlined">
              <FontAwesomeIcon
                icon={faUpload}
                className="me-1"
                onClick={() => { }}
              />
              Export
            </Button>
            {showAddUser && (
              <AddUser
                handleModalClose={handleClose}
                showAddUser={showAddUser}
              />
            )}
          </div>
          <div className="users-wrapper">
            <p className="fts-3 mt-3">
              {practice ? practice?.length : "0"} Practice(s) Found
            </p>
            <div className="users d-flex gap-3">
              {!loading ? (
                practice !== null ? (
                  practice.map((practice: Practice) => {
                    return (
                      <div
                        className="user-container p-3 border"
                        key={practice.practiceId}
                        onClick={() => handleImageClick(practice.practiceId)}
                      >
                        <div className="top-row pb-2 d-flex">
                          <div className="user-count d-flex flex-column">
                            <span className="bold-3">
                              {/* {practice.userCount ?? "0"} */}
                            </span>
                            <span>Users</span>
                          </div>
                          <div className="location-count d-flex flex-column ps-3">
                            <span className="bold-3">
                              {/* {practice.locationCount} */}
                            </span>
                            <span>Locations</span>
                          </div>
                        </div>
                        <div className="user-details d-flex mt-3 gap-2">
                          <div className="user-img-wrapper"></div>
                          <div className="d-flex flex-column gap-1">
                            <p className="mb-0 bold-2 dark-blue-txt">
                              {practice.practiceName ?? "No Practice Name"}
                            </p>
                            <p className="mb-0">
                              <span className="grey-color fts-2">
                                Practice ID
                              </span>{" "}
                              {practice.practiceId ?? "-"}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p>No Practice Found</p>
                )
              ) : (
                <p className="text-center">
                  <Spinner />
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default User;
