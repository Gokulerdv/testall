import { faCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { FormGroup, Input, Label } from "reactstrap";

export const CustomDropdown: React.FC<{
  label: string;
  options_custom?: {
    total: string[];
    choosed: string[];
  };
  options?: string[];
  value?: string | null;
  type: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  readonly?: boolean;
  error?: string;
  placeholder?: string;
}> = ({
  label,
  options,
  type,
  value,
  options_custom,
  placeholder,
  onChange,
  readonly,
  error,
}) => {
  switch (type) {
    case "input":
      return (
        <FormGroup>
          <Label for="user-name" className="label">
            {label}
          </Label>
          <Input
            type="text"
            value={(value as string) ?? ""}
            onChange={onChange}
            id="user-name"
            disabled={readonly}
            placeholder={placeholder}
          />
          {error && <span className="error">{error}</span>}
        </FormGroup>
      );

    case "dropdown_custom": {
      const { total, choosed } = options_custom as {
        total: string[];
        choosed: string[];
      };
      return (
        <FormGroup>
          <Label for="practice-name" className="label">
            {label}
          </Label>
          <Input
            className="w-100"
            type="select"
            id="practice-name"
            value={value as string}
            onChange={onChange}
          >
            {value ? (
              <option hidden value="">
                {value}
              </option>
            ) : (
              <option hidden value="">
                Select
              </option>
            )}

            {total &&
              total.map((option) => {
                return (
                  <option
                    disabled={choosed.includes(option)}
                    selected={option === value}
                    key={option}
                  >
                    {choosed.includes(option) && (
                      <FontAwesomeIcon icon={faCheck} />
                    )}{" "}
                    {option}
                  </option>
                );
              })}
          </Input>
          {error && <span className="error">{error}</span>}
        </FormGroup>
      );
    }

    case "dropdown":
      return (
        <FormGroup>
          <Label for="practice-name" className="label">
            {label}
          </Label>
          <Input
            className="w-100"
            type="select"
            disabled={readonly}
            id="practice-name"
            value={value as string}
            onChange={onChange}
          >
            <option hidden value="">
              Select
            </option>
            {options &&
              options.map((option) => {
                return (
                  <option selected={option === value} key={option}>
                    {option}
                  </option>
                );
              })}
          </Input>
          {error && <span className="error">{error}</span>}
        </FormGroup>
      );
  }
};
