/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useCallback, useEffect, useMemo, useState } from "react";
import Offcanvas from "react-bootstrap/Offcanvas";
import { Col, FormGroup, Input, Label, Row, Spinner } from "reactstrap";
import ProductDetailV2 from "./ProductDetail/ProductDetailV2";
// import { UserServices } from "../../../services/user";
import { toast } from "react-toastify";
import AddUserHeader from "./AddUserHeader";
import { CustomDropdown } from "./CustomDropdown";

import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "react-toastify/dist/ReactToastify.css";
// import { useSelector } from "react-redux";
// import { RootState } from "../../../slice";
import { countries } from "../../../constants/users";
import { UserServices } from "../../../services/user";

type ErrorField = {
  username: string;
  emailId: string;
  phoneNumber: string;
  selectedPractice: string;
  // userType: string;
  location: string;
  role: string;
};
type Errors = ErrorField & { message?: string };
export const AddUser: React.FC<{
  showAddUser: boolean;
  handleModalClose: () => void;
}> = ({ showAddUser, handleModalClose }) => {
  const [show] = useState(showAddUser);
  const [practiceData, setPracticeData] = useState<Practice | null>(null);
  const [userRoles, setUserRoles] = useState<RoleDetails[] | null>(null);
  const [numRoles, setNumRoles] = useState(1);
  const [selectedPractice, setSelectedPractice] = useState<string | null>("");
  const [username, setUsername] = useState<string | null>("");
  const [phoneNumber, setPhoneNumber] = useState<string | number | null>("");
  const [emailId, setEmailId] = useState<string | null>("");
  const [activeTab, setActiveTab] = useState(1);
  const [userType, setUserType] = useState<string>("");
  const [telCode, setTelCode] = useState<string>("+91");
  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");

  const practiceId = userDetails?.userData?.practice?.practiceId;
  const userId = userDetails?.userData?.userId;

  const [roles, setRoles] = useState<{
    [key: number]: { userRole: string; location: string };
  }>({ 1: { userRole: "", location: "" } });
  const [errors, setErrors] = useState<{
    username: string;
    emailId: string;
    phoneNumber: string;
    selectedPractice: string;
    userType: string;
    location: string;
    role: string;
  }>({
    username: "",
    emailId: "",
    phoneNumber: "",
    selectedPractice: "",
    userType: "",
    location: "",
    role: "",
  });

  const getUserRoleorLocation = useCallback(
    (roleNumber: number = activeTab, key: string) => {
      const a =
        roles[roleNumber]?.[
          key as keyof { userRole: string; location: string }
        ];

      return a;
    },
    [roles, activeTab]
  );

  const practiceNameList = useMemo(
    () => practiceData?.practiceName,
    [practiceData]
  );
  const roleList = useMemo(
    () => userRoles?.map((role: RoleDetails) => role.roleName) ?? [],
    [userRoles]
  );
  const LocationList = useMemo(
    () =>
      Array.from(
        new Set(
          practiceData?.locations?.map((location) => location.locationName) ??
            []
        )
      ),
    [practiceData]
  );

  useEffect(() => {
    UserServices.getAllPractices(practiceId).then(({ data }) => {
      setPracticeData(data);
    });
    UserServices.getAllRoles(practiceId).then(({ data }) => {
      setUserRoles(data);
    });
  }, [practiceId]);

  const choosedRoles = Object.values(roles).map((role) => role?.userRole);
  const choosedLocation = Object.values(roles).map((role) => role?.location);
  const handleClose = () => {
    handleModalClose();
  };
  const transformRoles = (): { locationId: string; roleId: string }[] => {
    return Object.entries(roles).map(([, value]) => {
      const roleId = userRoles?.find(
        (role: RoleDetails) => role.roleName === value?.userRole
      )?.roleId;
      const locationId = practiceData?.locations.find(
        (location: Location) => location.locationName === value.location
      )?.locationId;
      return { locationId: locationId ?? "", roleId: roleId ?? "" };
    });
  };
  const handleFieldChange = (field: keyof Errors, value: string) => {
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: value ? "" : `${field} is required`,
    }));
    const setters: {
      [key in keyof Errors]: React.Dispatch<React.SetStateAction<any>>;
    } = {
      username: setUsername,
      emailId: setEmailId,
      phoneNumber: setPhoneNumber,
      selectedPractice: setSelectedPractice,
      // userType: setUserType,
      location: () => {},
      role: () => {},
    };

    (setters[field] as React.Dispatch<React.SetStateAction<any>>)(value);
  };
  const onSubmit = () => {
    const payload = {
      userName: username,
      adminId: userId,
      practiceId: practiceData?.practiceId,
      locations: transformRoles(),
      email: emailId,
      status: true,
      phoneNumber: `${telCode} ${phoneNumber}`,
      userType: userType !== "" ? userType : "user",
    };

    const requiredFields: any = {
      username,
      emailId,
      phoneNumber,
      selectedPractice,
      // userType,
      location: roles[1].location,
      roles,
    };

    const newErrors = { ...errors };
    let hasError = false;
    Object.keys(requiredFields).forEach((key) => {
      if (!requiredFields[key]) {
        newErrors[key as keyof ErrorField] = `${key} is required`;
        hasError = true;
      } else {
        newErrors[key as keyof ErrorField] = "";
      }
    });

    const hasEmptyRole = Object.values(roles).some(
      (role) => role.userRole === ""
    );
    const hasEmptyLocation = Object.values(roles).some(
      (role) => role.location === ""
    );

    if (hasEmptyRole) {
      newErrors.role = "Role is required";
      hasError = true;
    }

    if (hasEmptyLocation) {
      newErrors.location = "Location is required";
      hasError = true;
    }

    setErrors(newErrors);
    if (hasError) {
      return;
    }
    if (practiceData) {
      UserServices.createUser(
        practiceData?.subscriptionpractices[0]?.subscriptionId,
        practiceData?.practiceId,
        payload
      )
        .then((data) => {
          toast.success(data?.message);
        })
        .catch((err) => {
          if (err.response.status == 403) {
            toast.warn(err?.response.data.message);
          } else {
            toast.error(err?.message);
          }
        })
        .finally(() => {
          handleClose();
        });
    } else {
      console.error("Subscription practices not available");
    }
  };

  const addTab = () => {
    setNumRoles((prev: number) => (prev < 5 ? prev + 1 : prev));
    setActiveTab(numRoles + 1);
    setRoles((prevRoles) => {
      const newRoles = { ...prevRoles };
      newRoles[numRoles + 1] = { userRole: "", location: "" };
      return newRoles;
    });
  };

  const dropdownhandle = (e: any) => {
    handleFieldChange("role", e);
    setRoles((prevRoles) => {
      const newRoles = { ...prevRoles };
      const role = newRoles[activeTab] || {
        [activeTab]: { userRole: "", location: "" },
      };
      newRoles[activeTab] = {
        ...role,
        userRole: typeof e === "string" ? e : e.target.value,
      };
      return newRoles;
    });
  };

  const Locdropdownhandle = (e: any) => {
    handleFieldChange("location", e.target.value);
    setRoles((prevRoles) => {
      const newRoles = { ...prevRoles };
      const role = newRoles[activeTab] || {
        [activeTab]: { userRole: "", location: "" },
      };
      newRoles[activeTab] = {
        ...role,
        location: typeof e === "string" ? e : e.target.value,
      };
      return newRoles;
    });
  };

  return (
    <>
      <Offcanvas
        show={show}
        onHide={handleClose}
        placement="end"
        style={{ width: "60%" }}
      >
        <Offcanvas.Header className="add-user-header">
          <AddUserHeader
            handleClose={handleClose}
            onSubmit={onSubmit}
            addTab={addTab}
          />
        </Offcanvas.Header>
        <Offcanvas.Body className="add-user-form">
          <div className="gap-2 pb-4 tabs-indicator d-flex justify-content-between align-items-center">
            <div className="d-flex">
              {Array.from({ length: numRoles }, (_, i) => (
                <div
                  key={`role${i + 1}`}
                  onClick={() => setActiveTab(i + 1)}
                  className={`p-2 ${
                    activeTab === i + 1 ? "active" : ""
                  } cursor-pointer bold-3`}
                >
                  Role {i + 1}
                </div>
              ))}
            </div>
            {numRoles > 1 && (
              <button
                className="btn "
                onClick={() => {
                  setRoles((prevRoles) => {
                    const newRoles = { ...prevRoles };
                    delete newRoles[numRoles];
                    return newRoles;
                  });
                  if (numRoles === 1) {
                    return;
                  }
                  setNumRoles((prev) => prev - 1);
                  setActiveTab(numRoles - 1);
                }}
              >
                <FontAwesomeIcon icon={faTrash} color="red" />
              </button>
            )}
          </div>

          {practiceData ? (
            <div className="p-6 bg-white rounded-lg ">
              <div className="space-y-6">
                <div>
                  <h2 className="section-head">Practice details</h2>
                  <Row className="formstyle">
                    <Col md={5}>
                      <CustomDropdown
                        label="Practice Name"
                        options={[practiceNameList ?? ""]}
                        type="dropdown"
                        value={selectedPractice}
                        onChange={(e) =>
                          handleFieldChange(
                            "selectedPractice",
                            typeof e === "string" ? e : e.target.value
                          )
                        }
                        readonly={!(activeTab === 1)}
                        error={errors.selectedPractice}
                      />
                    </Col>
                    <Col md={5}>
                      <CustomDropdown
                        label="Location"
                        options_custom={{
                          total: LocationList,
                          choosed: choosedLocation,
                        }}
                        type="dropdown_custom"
                        value={roles[activeTab]?.location}
                        onChange={Locdropdownhandle}
                        error={errors.location}
                      />
                    </Col>
                  </Row>
                </div>
                <div className="formstyle">
                  <h2 className="section-head">User details</h2>
                  <Row>
                    <Col md={5}>
                      <CustomDropdown
                        type="input"
                        label="Username"
                        value={username}
                        onChange={(e) =>
                          handleFieldChange(
                            "username",
                            typeof e === "string" ? e : e.target.value
                          )
                        }
                        readonly={!(activeTab === 1)}
                        placeholder="Enter your Name"
                        error={errors.username}
                      />
                    </Col>
                    <Col md={5}>
                      <CustomDropdown
                        label="UserRole"
                        options_custom={{
                          total: roleList,
                          choosed: choosedRoles,
                        }}
                        type="dropdown_custom"
                        value={roles[activeTab]?.userRole}
                        onChange={dropdownhandle}
                        error={errors.role}
                      />
                    </Col>
                  </Row>
                  <Row form className="formstyle">
                    <Col md={5}>
                      <CustomDropdown
                        type="input"
                        label="Email-id"
                        value={emailId}
                        readonly={!(activeTab === 1)}
                        onChange={(e) =>
                          handleFieldChange(
                            "emailId",
                            typeof e === "string" ? e : e.target.value
                          )
                        }
                        placeholder="enter your email"
                        error={errors.emailId}
                      />
                    </Col>
                    <Col md={5}>
                      <FormGroup>
                        <Label for="phone-number">Phone Number</Label>
                        <div className="d-flex ">
                          <Input
                            type="select"
                            id="phone-code"
                            value={telCode}
                            disabled={!(activeTab === 1)}
                            className="p-0 w-25 "
                            onChange={(e) => setTelCode(e.target.value)}
                          >
                            {countries.map((code) => (
                              <option
                                selected={code === telCode}
                                key={code}
                                value={code}
                              >
                                {code}
                              </option>
                            ))}
                          </Input>
                          <Input
                            type="number"
                            id="phone-number"
                            placeholder="enter your phoneNumber"
                            className="flex-grow-1 formstyle"
                            disabled={!(activeTab === 1)}
                            value={phoneNumber ?? ""}
                            onChange={(e) =>
                              handleFieldChange("phoneNumber", e.target.value)
                            }
                          />
                        </div>
                        {errors.phoneNumber && (
                          <span className="error">{errors.phoneNumber}</span>
                        )}
                      </FormGroup>
                    </Col>
                  </Row>
                </div>

                <FormGroup check inline className=" formstyle">
                  <Input
                    onChange={() => setUserType("PRACTICE_ADMIN")}
                    checked={userType === "PRACTICE_ADMIN"}
                    type="checkbox"
                  />
                  <Label check>Practice Admin</Label>
                </FormGroup>

                <h2 className="mt-3 section-head ProductDetail">
                  Product details
                </h2>

                {userRoles !== null ? (
                  <div className="my-3 user-tab">
                    <ProductDetailV2
                      roleId={
                        userRoles?.find(
                          (role: RoleDetails) =>
                            role.roleName ===
                            getUserRoleorLocation(activeTab, "userRole")
                        )?.roleId ?? ""
                      }
                    />
                  </div>
                ) : (
                  <div>
                    <p>loading...</p>
                  </div>
                )}
              </div>
            </div>
          ) : practiceData ? (
            <p>No practice Found. Please create practice.</p>
          ) : (
            <div className="text-center">
              <Spinner />
            </div>
          )}
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};

export default AddUser;
