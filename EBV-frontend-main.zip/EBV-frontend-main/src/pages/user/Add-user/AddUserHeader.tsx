import React, { useState } from "react";
import { Button } from "reactstrap";

const AddUserHeader: React.FC<{
  handleClose: () => void;
  onSubmit: () => void;
  addTab: () => void;
}> = ({ handleClose, onSubmit, addTab }) => {
  const [isSaveDisabled, setIsSaveDisabled] = useState(false);

  const handleSaveClick = () => {
    setIsSaveDisabled(true);
    onSubmit();
  };

  return (
    <>
      <div className="d-flex w-100 justify-content-between">
        <p className="title">Add User</p>
        <div className="d-flex gap-3">
          <Button color="secondary" className="add-role" onClick={addTab}>
            +Add Role
          </Button>
          <Button
            color="outline-secondary"
            onClick={handleClose}
            className="cancel"
          >
            Cancel
          </Button>
          <Button
            color="primary"
            onClick={handleSaveClick}
            className="save"
            disabled={isSaveDisabled}
          >
            Save
          </Button>
        </div>
      </div>
    </>
  );
};

export default AddUserHeader;
