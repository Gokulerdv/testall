import React, { useEffect, useState } from "react";
import {
  UncontrolledAccordion,
  AccordionBody,
  AccordionHeader,
  AccordionItem,
  Spinner,
} from "reactstrap";
import ProductHeader from "./ProductHeader";
import Modules from "./Modules";
import { UserServices } from "../../../../services/user";


const ProductDetailV2: React.FC<{
  roleId: string;
  config?: {
    type: string;
    component: {
      header: JSX.Element;
      body: JSX.Element;
    };
  };
}> = ({ roleId, config }) => {
  const [productDetails, setProductDetails] = useState<{
    permissions: string[];
    productDetails: ProductDetail[];
  }>();
  const [loading, setLoading] = useState(false);

  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");

  const practiceId = userDetails?.userData?.practice?.practiceId;


  useEffect(() => {
    const fetchProductDetails = async () => {
      setLoading(true);
      if (roleId) {
        const { data } = await UserServices.getProductsbyRole(
          roleId,
          practiceId
        );
        setProductDetails(data);
      }
      setLoading(false);
    };
    fetchProductDetails();
  }, [roleId, practiceId]);

  return (
    <>
      {!config?.type && roleId && loading ? (
        <div className="text-center">
          <Spinner />
        </div>
      ) : (
        <UncontrolledAccordion toggle={() => { }} defaultOpen={["0"]} stayOpen>
          {config?.type ||
            (productDetails && productDetails?.productDetails?.length !== 0) ? (
            productDetails?.productDetails?.map((product, index) => (
              <AccordionItem key={index} className="my-3 border">
                <AccordionHeader
                  className="prod-detail-accordian"
                  targetId={`${index}`}
                >
                  {config?.component.header ?? (
                    <ProductHeader title={product.product_name} />
                  )}{" "}
                </AccordionHeader>
                <AccordionBody accordionId={`${index}`}>
                  {config ? (
                    config.component.body
                  ) : (
                    <Modules
                      data={product.modules}
                      permission={productDetails?.permissions}
                    />
                  )}
                </AccordionBody>
              </AccordionItem>
            )) ?? (
              <AccordionItem>
                <AccordionHeader
                  className="prod-detail-accordian"
                  targetId={`0`}
                >
                  {config?.component.header}
                </AccordionHeader>
                <AccordionBody accordionId={`0`}>
                  {config?.component.body}
                </AccordionBody>
              </AccordionItem>
            )
          ) : (
            <p className="text-center">No Product Details found</p>
          )}
        </UncontrolledAccordion>
      )}
    </>
  );
};

export default ProductDetailV2;
