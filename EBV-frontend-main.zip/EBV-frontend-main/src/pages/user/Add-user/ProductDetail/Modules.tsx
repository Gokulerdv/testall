import React from "react";
import Feature from "./Feature";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck } from "@fortawesome/free-solid-svg-icons";
import {
  UncontrolledAccordion,
  AccordionItem,
  AccordionHeader,
  AccordionBody,
} from "reactstrap";

const Modules: React.FC<{ data: Module[]; permission?: string[] }> = ({
  data,
  permission,
}) => {
  return (
    <>
      <p className="choose-module">Choose Modules</p>
      <UncontrolledAccordion
        className="border-0"
        toggle={() => { }}
        defaultOpen={["0"]}
        stayOpen
      >
        {data && data.length !== 0 ? (
          data?.map((item, index) => (
            <AccordionItem className="module-accordian my-3">
              <AccordionHeader className="header" targetId={`${index}`}>
                <div className="module-container pt-1 pb-1 px-3">

                  <p className="value module-value pt-3"> <span className="pt-2">
                    <FontAwesomeIcon icon={faCheck} color="#2f86eb" />{" "}
                  </span>{item.module_name} </p>
                </div>
              </AccordionHeader>
              <AccordionBody accordionId={`${index}`}>
                <Feature data={item.features} permission={permission} />
              </AccordionBody>
            </AccordionItem>
          ))
        ) : (
          <p className="text-center">No Module Found.</p>
        )}
      </UncontrolledAccordion>
    </>
  );
};

export default Modules;
