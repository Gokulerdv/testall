import { faFilter, faTimes } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Select from "react-select";
import { Dropdown, Form } from "react-bootstrap";
import { useState } from "react";

interface SelectOption {
  value: string;
  label: string;
}

interface RolesFilterProps {
  filterData: {
    role: SelectOption[] | null;
    product: SelectOption[] | null;
    roleType: SelectOption[] | null;
    permission: SelectOption[] | null;
    date: any;
  };
  setFilteredData: any;
  config: any;
}

const RolesFilter = ({
  filterData,
  setFilteredData,
  config,
}: RolesFilterProps) => {
  const [roleOptions, assignedProductOptions, roleTypes, permissionOptions] =
    config;
  const [isOpen, setIsOpen] = useState(false);
  const handleFilterChange = (name: string, value: any) => {
    setFilteredData((prev: any) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <Dropdown
      show={isOpen}
      onToggle={() => {
        setIsOpen(!isOpen);
      }}
      className="filter-dropdown"
    >
      <Dropdown.Toggle id="dropdown-basic" className=" filter-button">
        <FontAwesomeIcon icon={faFilter} className="me-1" />
        Filters
      </Dropdown.Toggle>

      <Dropdown.Menu
        style={{ width: "21rem", padding: "10px" }}
        className="filter"
      >
        <div className="close-modal-btn">
          <p>Filters</p>
          <button onClick={() => setIsOpen(false)}>
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>
        <Form.Group controlId="claim-number" className="mb-4">
          <Form.Label>Role Name</Form.Label>
          <Select
            options={roleOptions}
            isMulti
            placeholder="Select"
            className="basic-multi-select"
            classNamePrefix="select"
            value={filterData.role}
            onChange={(value) => handleFilterChange("role", value)}
          />

          <Form.Label>Products</Form.Label>
          <Select
            options={assignedProductOptions}
            isMulti
            placeholder="Select"
            className="basic-multi-select"
            value={filterData.product}
            classNamePrefix="select"
            onChange={(value) => handleFilterChange("product", value)}
          />

          <Form.Label>Created On</Form.Label>
          <Form.Control
            type="date"
            placeholder="Select"
            value={filterData.date}
            onChange={(e) => handleFilterChange("date", e.target.value)}
          />

          <Form.Label>Permissions</Form.Label>
          <Select
            options={permissionOptions}
            isMulti
            placeholder="Select"
            className="basic-multi-select"
            value={filterData.permission}
            classNamePrefix="select"
            onChange={(value) => handleFilterChange("permission", value)}
          />

          <Form.Label>Role Type</Form.Label>
          <Select
            options={roleTypes.map((type: any) => ({
              label: type,
              value: type,
            }))}
            isSearchable={true}
            isMulti
            placeholder="Select"
            value={filterData.roleType}
            classNamePrefix="select"
            onChange={(value) => handleFilterChange("roleType", value)}
          />
        </Form.Group>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default RolesFilter;
