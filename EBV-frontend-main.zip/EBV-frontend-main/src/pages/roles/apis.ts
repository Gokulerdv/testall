import axios from "axios";


const API_URL = import.meta.env.VITE_API_HOST;

export const API = axios.create({
    baseURL: API_URL
});

class UserRoles {
    async getAllProducts() {
        return API.get("product/getall");
    }

    async getProductDetails(id: string) {
        return API.get(`product/get/${id}`);
    }

    async getRoleById(practid: string, roleid: string) {
        return API.get(`userrole/get/${roleid}?practiceId=${practid}`)
    }

    async postRoles(body: any) {
        return API.post("userrole/create", body);
    }

    async getAllRoles(practId: string) {
        return API.get("userrole/getall", {
            params: {
                practiceId: practId
            }
        });
    }

    async deleteRole({
        recordId,
        practiceId
    }: {
        recordId: string;
        practiceId: string;
    }) {
        return API.delete(`userrole/delete/${recordId}`, {
            params: {
                practiceId
            }
        });
    }

    async updateRoledata(id: string, body: any) {
        return API.put(`userrole/update/${id}`, body);
    }
}

export const userrolesapi = new UserRoles();
