import React, { useState, useEffect } from "react";
import PageHeader from "../../components/PageHeader";
// import HospitalDetails from '../../components/HospitalDetails';
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUpload,
  faTableColumns,
  faPenToSquare,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import DataTable, { TableColumn } from "react-data-table-component";
import DevButton from "../../components/Button";
import FormSearch from "../../components/FormSearch";
import {

  Badge,
  Button,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  Offcanvas,
  OffcanvasBody,
  Row,
  Spinner,
  UncontrolledDropdown,
} from "reactstrap";
import Select from "react-select";
import { userrolesapi } from "./apis";
// import { Spinner } from "../../components/Spinner";
import { Accordion } from "../../components/Accordion";
import moment from "moment";
import DeletePopup from "../../components/DeletePopup";

import HospitalDetails from "../../components/HospitalDetails";
import { CSVLink } from "react-csv";
import AddUser from "../user/Add-user/AddUser";
import RolesFilter from "./RolesFilter";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import { toast } from "react-toastify";
import Permissions from "../../components/Permissions";

interface UserData {
  admin: any;
  id: number;
  roleId: string;
  username: string;
  roleName: string;
  userid: number;
  role: string;
  assignedproduct: string;
  permissions: string[];
  emailid: string;
  productDetails: any[];
  phonenumber: string;
  createdAt: string;
}
interface SelectOption {
  value: string;
  label: string;
}

const customStyles = {
  head: {
    style: {
      fontWeight: 600,
      fontSize: "14px",
    },
  },
  headRow: {
    style: {
      backgroundColor: "#E0E3E6",
    },
  },
};
type ColumnKey =
  | "roleId"
  | "createdAt"
  | "role"
  | "assignedProducts"
  | "permissions"
  | "phoneNumber"
  | "actions"
  | "createdBy";
  
  
  
 

const Roles = () => {
  const [createRoleCanvasFlag, setCreateRoleCanvasFlag] = useState(false);
  const userDetails = JSON.parse(localStorage.getItem("auth") || "{}");

  const practiceId = userDetails?.userData?.practice?.practiceId;

  const products = userDetails?.userData?.practice?.locations[0]?.role?.products;
  const [locationData, setLocationData] = useState({
    practiceLogo: "",
    practiceName: userDetails?.userData?.practice?.practiceName,
    practiceId: practiceId,
  });
  const [loading, setLoading] = useState(false);
  const [modulesData, setModulesData] = useState<any[]>([]);
  const [allrolesData, setAllrolesData] = useState<any[]>([]);
  const [permissionsChecks, setPermissionsChecks] = useState<string[]>([]);
  const [roleName, setRoleName] = useState<string>("");
  const [deleteRecord, setDeleteRecord] = useState<any>();
  const [deletePopupFlag, setDeletePopupFlag] = useState<boolean>(false);
  const [editRoleId, setEditRoleId] = useState<any>(null);
  const [productsData, setProductsData] = useState<any[]>([]);
  const [defaultProductValue, setDefaultProductValue] = useState<any>([]);

  const [filterData, setFilteredData] = useState<{
    role: SelectOption[] | null;
    product: SelectOption[] | null;
    roleType: SelectOption[] | null;
    permission: SelectOption[] | null;
    date: any;
  }>({
    role: null,
    product: null,
    roleType: null,
    permission: null,
    date: "",
  });
  const [assignedProductOptions, setAssignedProductOptions] = useState<any[]>(
    []
  );
  const [roleTypes, setRoleTypes] = useState<string[]>([]);
  const disableSaveBtn =
    permissionsChecks.length > 0 &&
    roleName.length > 0 &&
    modulesData.length > 0;
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showModal, setShowModal] = useState(false);
  const [permission, setPermissions] = useState<string[]>([]);
  const [csvData, setCsvData] = useState<any>(null);
  const [filteredPractices, setFilteredPractices] = useState<any>(null);
  const [showAddUser, setShowAddUser] = useState(false);
  const [columnVisibility, setColumnVisibility] = useState<
    Record<ColumnKey, boolean>
  >({
    role: true,
    roleId: true,
    createdAt: true,
    assignedProducts: true,
    permissions: true,
    phoneNumber: true,
    actions: true,
    createdBy:true
  });
  // const [practiceD] = useState<any>()
  const handleShowModal = (show: boolean, permissions: string[]) => {
    setShowModal(show);
    setPermissions(permissions);
  }
  const productConversion = (prod: any) => {
    return prod.map((a: any) => {
      return {
        label: a.product_name,
        value: a.product_id,
      };
    });
  };
  const filterByRole = (
    roleData: string[],
    productData: string[],
    roleTypeData: string[],
    permissionData: string[],
    Date: string
  ) => {
    const filteredData = allrolesData?.filter((role: any) => {
      return (
        (roleData.length === 0 ? true : roleData.includes(role?.roleName)) &&
        (productData?.length === 0
          ? true
          : productData.some((element) =>
            role?.productDetails
              ?.map(
                (productDetail: { product_id: any }) =>
                  productDetail.product_id
              )
              ?.includes(element)
          )) &&
        (roleTypeData.length === 0
          ? true
          : roleTypeData.includes(role?.roleType)) &&
        (permissionData?.length === 0 || permissionData?.includes("all")
          ? true
          : permissionData?.some((element) => {
            return role?.permissions?.some((permission: string) => {
              const splitted = permission?.split("_");
              const lastElement =
                splitted[splitted.length - 1]?.toLocaleLowerCase();
              return lastElement?.includes(element?.toLocaleLowerCase());
            });
          })) &&
        (Date === ""
          ? true
          : moment(role?.createdAt).format("YYYY-MM-DD") === Date)
      );
    });

    setFilteredPractices(filteredData);
  };


  useEffect(() => {
    if (filteredPractices) {
      setLoading(true)
      const roleData = filterData?.role?.map((data) => data.value) ?? [];
      const productData = filterData?.product?.map((data) => data.value) ?? [];
      const roleTypeData =
        filterData?.roleType?.map((data) => data.value) ?? [];
      const permissionData =
        filterData?.permission?.map((data) => data.value) ?? [];
      const Date = filterData?.date;
      filterByRole(roleData, productData, roleTypeData, permissionData, Date);
      setLoading(false)
    }

  }, [filterData]);
  const handleClose = () => {
    setShowAddUser(!showAddUser);
  };

  const getAllProducts = async () => {
    const formatProdData = productConversion(products);
    setProductsData(formatProdData);
  };
  useEffect(() => {
    getAllProducts();
    getAllRolesfn();
  }, [showAddUser]);

  const deletePopupopen = (data: any) => {
    setDeletePopupFlag(true);
    setDeleteRecord(data);
  };

  const editRoleDatafn = (data: any) => {
    // setEditRecordData(data)

    const { practiceId, roleId } = data;
    setLoading(true);
    setEditRoleId(roleId);
    userrolesapi
      .getRoleById(practiceId, roleId)
      .then((data: any) => {
        const {
          roleName,
          productDetails: pdDetails,
          permissions,
        } = data.data.data;
        setRoleName(roleName);
        const editProductData = productConversion(pdDetails);
        setModulesData(pdDetails);
        setDefaultProductValue(editProductData);
        setPermissionsChecks(permissions);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err, "checking the error");
      })
      .finally(() => {
        setLoading(false);
        setCreateRoleCanvasFlag(true);
      });
  };

  const proceedDelete = () => {
    setLoading(true);
    userrolesapi
      .deleteRole({
        recordId: deleteRecord.roleId,
        practiceId: practiceId,
      })
      .then((data) => {
        console.log(data);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        getAllRolesfn();
        setDeletePopupFlag(false);
        setDeleteRecord(null);
      });
  };

  const columns: TableColumn<UserData>[] = [
    {
      name: "Role ID",
      cell: (row) => {
        return <span className="txt-underline">{row.roleId}</span>;
      },
      sortable: true,
      sortFunction: (a, b) => parseInt(a.roleId) - parseInt(b.roleId),
      omit: !columnVisibility.roleId,
    },
    {
      name: "Role",
      selector: (row) => row.roleName,
      sortable: true,
      omit: !columnVisibility.role,
    },
    {
      name: "Assigned Products",
      sortable: true,
      cell: (row) => {
        const products = row?.productDetails || [];
        const maxVisibleProducts = 2;
        const visibleProducts = products.slice(0, maxVisibleProducts);
        const remainingProducts = products.length - maxVisibleProducts;

        return (
          <div className="d-flex flex-row" style={{ alignItems: "center" }}>
            {visibleProducts.map((product, index) => (
              <span key={index} className="prod-badge me-2">
                {product.product_name}
              </span>
            ))}
            {remainingProducts > 0 && (
              <OverlayTrigger
                placement="bottom"
                overlay={
                  <Tooltip id={`tooltip-${row.userid}`}>
                    {products
                      .slice(maxVisibleProducts)
                      .map((product) => product.product_name)
                      .join(", ")}
                  </Tooltip>
                }
              >
                <span className="cursor-pointer px-2">
                  {remainingProducts}+
                </span>
              </OverlayTrigger>
            )}
          </div>
        );
      },
      sortFunction: (a, b) =>
        a?.productDetails?.length - b?.productDetails?.length,
      omit: !columnVisibility.assignedProducts,
    },

    {
      name: "Permissions",
      style: { flexWrap: "wrap", gap: "10px",  },
      cell: (row) => {
        const visiblePermissions = row?.permissions.slice(0, 2);
        const remainingPermissions = row.permissions.slice(2);

        return (
          <div className='modl-badge'>
            {visiblePermissions.map((permission, index) => (
              <Badge key={index} className='m-1' style={{ margin: '3px', color: "black", fontSize: "11px", fontWeight: "500" }}>
                {permission}
              </Badge>
            ))}
            {remainingPermissions.length > 0 && (
              <div>
                <span className='p-2'
                  style={{ textDecoration: 'underline', cursor: 'pointer', color: 'blue' }}
                  onClick={() => handleShowModal(true, remainingPermissions)}
                >
                  +{remainingPermissions.length} more
                </span>
              </div>
            )}

          </div>
        );
      },
      sortable: true,
      omit: !columnVisibility.permissions,
      sortFunction: (a, b) => a.permissions.length - b.permissions.length,
    },



    {
      name: "Created At",
      style:{margin:'10px 22px'},
      selector: (row) => {
        return moment(row.createdAt).format("DD-MM-YYYY");
      },
      sortable: true,
      omit: !columnVisibility.createdAt,
    },
    {
      name: "Created BY",
      selector: (row) => row.admin?.adminName ?? "-",
      omit: !columnVisibility.createdBy,
    },
    {
      name: "Active User",
      selector: (row) => row.phonenumber,
      omit: !columnVisibility.phoneNumber,
    },
    {
      name: "Actions",
      cell: (row: any) => {
        return (
          <div>
            {!row.practiceId ? (
              <DevButton
                btntype="transparent"
                className="p-0 me-2"
                onClick={() => editRoleDatafn(row)}
              >
                <FontAwesomeIcon
                  icon={faPenToSquare}
                  color="#557AFF"
                  style={{ fontSize: "14px" }}
                />
              </DevButton>
            ) : null}
            <DevButton
              btntype="transparent"
              className="p-0"
              onClick={() => deletePopupopen(row)}
            >
              <FontAwesomeIcon
                icon={faTrash}
                color="#E32F2F"
                style={{ fontSize: "14px" }}
              />
            </DevButton>
          </div>
        );
      },
      omit: !columnVisibility.actions,
    },
  ];
  const selectProduct = (val: any, removedVal: any) => {
    if (removedVal.action === "remove-value") {
      const { removedValue } = removedVal;
      const newmodues = [...modulesData].filter(
        (data) => data.product_id !== removedValue.value
      );
      setModulesData(newmodues);
    } else if (removedVal.action === "clear") {
      setModulesData([]);
      setPermissionsChecks([]);
    } else {
      const prodId: string = val[val.length - 1].value;
      const moduleDetails = (products || []).find(
        (data: any) => data.product_id === prodId
      );
      setModulesData((prev) => [...prev, { ...moduleDetails }]);
    }
  };

  const checkPermissions = (e: any) => {
    const changeType = e.target.checked;
    const value = e.target.value;
    if (changeType) {
      setPermissionsChecks((prev) => [...prev, value]);
      // Adding the module ids to the array
      // settingIds(prodId, modulId, featurId)
    } else {
      const newpermissions = permissionsChecks.filter((data) => data !== value);
      setPermissionsChecks(newpermissions);
    }
  };

  const checkAllPermissions = (e: any, values: string[]) => {
    const changeType = e.target.checked;
    let newpermissions = [...permissionsChecks];
    if (changeType) {
      newpermissions = [...newpermissions, ...values];
      // settingIds(prodId, modulId, featurId)
    } else {
      newpermissions = [...newpermissions].filter(
        (data: string) => values.indexOf(data) == -1
      );
    }
    newpermissions = [...new Set(newpermissions)];
    setPermissionsChecks(newpermissions);
  };
  const openRoleCanvas = () => {
    setModulesData([]);
    setCreateRoleCanvasFlag(true);
    setPermissionsChecks([]);
    setDefaultProductValue([]);
    setEditRoleId("");
    setRoleName("");
  };

  const getAllRolesfn = () => {
    setLoading(true);
    userrolesapi
      .getAllRoles(practiceId)
      .then((data: any) => {
        const practDetails = { ...locationData };
        practDetails["practiceLogo"] = data.data.practiceLogo;
        setLocationData(practDetails);
        setAllrolesData(data.data.data);
        setFilteredPractices(data.data.data);
      })
      .catch((err) => {
        console.log(err, "err");
      })
      .finally(() => {
        setLoading(false);
      });
  };
  const saveRole = () => {
    setLoading(true);
    const userData = localStorage.getItem('auth')
  const userInfo = JSON.parse(userData? userData :'' )
    
    function managePermissions(data: any, selectedPermissions: any) {
      const result: any = {
        roleName: roleName,
        roleType: "custom",
        practiceId: practiceId,
        admin:{
          adminName:userInfo?.userData?.userName,
          adminId:userInfo?.userData?.userId
        } ,
        products: [],
        modules: [],
        features: [],
        permissions: [],
      };

      const addToResult = (
        permission: any,
        feature: any,
        module: any,
        product: any
      ) => {
        if (!result.permissions.includes(permission)) {
          result.permissions.push(permission);
        }
        if (!result.features.includes(feature.feature_id)) {
          result.features.push(feature.feature_id);
        }
        if (!result.modules.includes(module.module_id)) {
          result.modules.push(module.module_id);
        }
        if (!result.products.includes(product.product_id)) {
          result.products.push(product.product_id);
        }
      };

      data.forEach((product: any) => {
        product.modules.forEach((module: any) => {
          module.features.forEach((feature: any) => {
            feature.permissions.forEach((permission: any) => {
              if (selectedPermissions.includes(permission)) {
                addToResult(permission, feature, module, product);
              }
            });
          });
        });
      });

      return result;
    }
    const resultData = managePermissions(modulesData, permissionsChecks);
    const handleRequest = (promise: any) => {
      return promise
        .then((data: any) => {
          console.log(data);

          toast.success(data?.data?.message)
        })
        .catch((err: any) => {
          console.log(err);
          toast.error(err?.data?.message)
        })
        .finally(() => {
          setLoading(false);
          getAllRolesfn();
          setCreateRoleCanvasFlag(false);
        });
    };
    if (editRoleId) {
      handleRequest(userrolesapi.updateRoledata(editRoleId, resultData)).then(
        () => {
          setEditRoleId("");
          setDefaultProductValue([]);
        }
      );
    } else {
      handleRequest(userrolesapi.postRoles(resultData));
    }
  };
  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  };
  useEffect(() => {
    setLoading(true);
    if (searchQuery && allrolesData) {
      const escapedQuery = escapeRegExp(searchQuery.toLowerCase());
      const filtered = allrolesData.filter((role: any) => {
        return (
          role?.roleName?.toLowerCase().includes(escapedQuery) ||
          role?.roleId?.toLowerCase().includes(escapedQuery) ||
          role?.createdAt?.toLowerCase().includes(escapedQuery) ||
          role?.updatedAt?.toLowerCase().includes(escapedQuery) ||
          role?.productDetails?.some((d: any) =>
            d.product_name.toLowerCase().includes(escapedQuery)
          )
        );
      });

      setFilteredPractices(filtered);
    } else {
      setFilteredPractices(allrolesData);
    }
    setLoading(false)
  }, [searchQuery, allrolesData]);
  useEffect(() => {
    if (allrolesData.length !== 0) {
      const csvData = allrolesData?.map((data) => {
        return {
          "Role ID": data?.roleId,
          Role: data?.roleName,
          // "Assigned Products": data?.productDetails
          //   .map((d: any) => d?.product_name)
          //   .join(", "),
          Permissions: data?.permissions.join(", "),
          "Created At": moment(data?.createdAt).format("DD-MM-YYYY"),
          "Active User": data?.phonenumber ?? "NA",
        };
      });
      setCsvData(csvData);
    }
  }, [allrolesData]);

  const generateAssignedProductOptions = () => {
    const productOptions = new Map();
    allrolesData?.forEach((role) => {
      role?.productDetails?.forEach((product: any) => {
        if (!productOptions.has(product.product_id)) {
          productOptions.set(product.product_id, {
            value: product.product_id,
            label: product.product_name,
          });
        }
      });
    });
    return Array.from(productOptions.values());
  };
  useEffect(() => {
    const options = generateAssignedProductOptions();
    setAssignedProductOptions(options);
  }, [allrolesData]);
  const roleOptions = allrolesData.map((role) => ({
    value: role.roleName,
    label: role.roleName,
  }));
  const fetchAndSetRoleTypes = async () => {
    setLoading(true);

    const fetchedRoleTypes = allrolesData.map((role: any) => role.roleType);
    setRoleTypes([...new Set(fetchedRoleTypes)]);
    setLoading(false);
  };
  useEffect(() => {
    fetchAndSetRoleTypes();
  }, []);
  const permissionOptions = [
    { value: "all", label: "All" },
    { value: "view", label: "View" },
    { value: "edit", label: "Edit" },
    { value: "create", label: "Create" },
    { value: "delete", label: "Delete" },
  ];
  const columnKeys: ColumnKey[] = [
    "role",
    "roleId",
    "assignedProducts",
    "permissions",
    "createdAt",
    "phoneNumber",
    "actions",
  ];
  const handleColumnVisibilityChange = (column: ColumnKey) => {
    setColumnVisibility((prevState) => ({
      ...prevState,
      [column]: !prevState[column],
    }));
  };
  return (
    <React.Fragment>
      <div>
        <PageHeader
          title="Role"
          btnTxt="Create Role"
          btnTxt2="Add Users"
          btnClick2={handleClose}
          btnClick={() => openRoleCanvas()}
        />
        {showAddUser && (
          <AddUser handleModalClose={handleClose} showAddUser={showAddUser} />
        )}
        <div className="p-3">
          <HospitalDetails data={{ ...locationData }} />

          {/* Tabs */}
          <div className="tabs-indicator d-flex align-items-center gap-2">
            <Link to={"/user"} className="p-2 cursor-pointer">
              <span>User</span>
            </Link>
            <div className="p-2 active cursor-pointer bold-3">Role</div>
          </div>

          <div className="mt-3">
            <div className="d-flex justify-content-between">
              <div className="d-flex gap-2">
                <FormSearch onSearch={(query) => setSearchQuery(query)} />
                <RolesFilter
                  filterData={filterData}
                  setFilteredData={setFilteredData}
                  config={[
                    roleOptions,
                    assignedProductOptions,
                    roleTypes,
                    permissionOptions,
                  ]}
                />
              </div>
              <div className="d-flex gap-2">
                <UncontrolledDropdown className="user-column">
                  <DropdownToggle
                    btntype="outlined"
                    className="mx-2 user-column"
                  >
                    <FontAwesomeIcon icon={faTableColumns} className="mx-1" />
                    Columns
                  </DropdownToggle>
                  <DropdownMenu>
                    {columnKeys.map((key: ColumnKey) => (
                      <DropdownItem
                        key={key}
                        toggle={false}
                        onClick={() => handleColumnVisibilityChange(key)}
                      >
                        <input
                          type="checkbox"
                          checked={columnVisibility[key]}
                          readOnly
                        />{" "}
                        {key.charAt(0).toUpperCase() + key.slice(1)}
                      </DropdownItem>
                    ))}
                  </DropdownMenu>
                </UncontrolledDropdown>
                {csvData && (
                  <DevButton btntype="outlined">
                    <FontAwesomeIcon icon={faUpload} className="me-1" />
                    <CSVLink style={{ color: "#66b6f1" }} data={csvData}>
                      Export
                    </CSVLink>
                  </DevButton>
                )}
              </div>
            </div>
            <div className="table-wrapper mt-3">

              {filteredPractices !== null && filteredPractices.length !== 0 ?
                <DataTable
                  columns={columns}
                  data={filteredPractices}
                  className="border"
                  customStyles={customStyles}
                /> :

                <div className="spinnner-style" >
                  {loading && <Spinner />}

                </div>

              }
            </div>
          </div>
        </div>
        <Offcanvas
          isOpen={createRoleCanvasFlag}
          direction="end"
          style={{ width: "900px" }}
        >
          <header className="popup-header">
            <div className="d-flex justify-content-between align-items-center">
              <h5 className="mb-0 bold-2 dark-blue-txt ">Create Role</h5>
              <div>
                <DevButton
                  btntype="outlined"
                  onClick={() => setCreateRoleCanvasFlag(false)}
                >
                  Cancel
                </DevButton>
                <Button
                  className="ms-2 fts-4 temp-save"
                  type="submit"
                  onClick={saveRole}
                  disabled={!disableSaveBtn}
                >
                  Save
                </Button>
              </div>
            </div>
          </header>
          <OffcanvasBody>
            <p className="mb-2 dark-blue-txt bold-2">User Role details</p>
            <form>
              <Row>
                <Col md={5}>
                  <label>Product</label>
                  <Select
                    options={productsData}
                    isMulti
                    defaultValue={defaultProductValue}
                    onChange={selectProduct}
                  />
                </Col>
              </Row>
              <Row className="my-3">
                <Col md={5}>
                  <label>Role</label>
                  <Input
                    onChange={(e) => setRoleName(e.target.value)}
                    value={roleName}
                  />
                </Col>
              </Row>
            </form>
            <label className="mb-2 dark-blue-txt bold-2">Permissions</label>
            {(modulesData || []).map((pdata) => {
              return (
                <Accordion
                  key={pdata.product_name}
                  title={pdata.product_name}
                  editphase={editRoleId}
                >
                  <span className="dark-blue-txt">Choose Modules</span>
                  {(pdata.modules || []).map((mdata: any) => {
                    return (
                      <Accordion
                        key={mdata.module_id}
                        title={mdata.module_name}
                        // heading="Module"
                        editphase={editRoleId}
                      >
                        {(mdata.features || []).map((fdata: any) => (
                          <div
                            className="features px-3 d-flex"
                            key={fdata.feature_name}
                          >
                            <div className="feature-name">
                              {/* <p className="grey-color mb-0">Feature</p> */}
                              <p className="dark-blue-txt mb-0 bold-2">
                                {fdata.feature_name}
                              </p>
                            </div>
                            <div className="feature-permission">
                              <p className="mb-0 grey-color">Permissions</p>
                              <div className="d-flex gap-4">
                                <label className="d-flex align-items-center gap-2">
                                  <input
                                    type="checkbox"
                                    checked={(fdata.permissions || []).every(
                                      (item: string) =>
                                        permissionsChecks.indexOf(item) !== -1
                                    )}
                                    onChange={(e) =>
                                      checkAllPermissions(e, fdata.permissions)
                                    }
                                  />
                                  All
                                </label>
                                <label className="d-flex align-items-center gap-2">
                                  <input
                                    type="checkbox"
                                    value={fdata.permissions[0]}
                                    onChange={(e) => {
                                      checkPermissions(e);
                                    }}
                                    checked={permissionsChecks.includes(
                                      fdata.permissions[0]
                                    )}
                                  />
                                  View
                                </label>
                                <label className="d-flex align-items-center gap-2">
                                  <input
                                    type="checkbox"
                                    value={fdata.permissions[1]}
                                    onChange={(e) => {
                                      checkPermissions(e);
                                    }}
                                    checked={permissionsChecks.includes(
                                      fdata.permissions[1]
                                    )}
                                  />
                                  Edit
                                </label>
                                <label className="d-flex align-items-center gap-2">
                                  <input
                                    type="checkbox"
                                    value={fdata.permissions[2]}
                                    onChange={(e) => {
                                      checkPermissions(e);
                                    }}
                                    checked={permissionsChecks.includes(
                                      fdata.permissions[2]
                                    )}
                                  />
                                  Create
                                </label>
                                <label className="d-flex align-items-center gap-2">
                                  <input
                                    type="checkbox"
                                    value={fdata.permissions[3]}
                                    onChange={(e) => {
                                      checkPermissions(e);
                                    }}
                                    checked={permissionsChecks.includes(
                                      fdata.permissions[3]
                                    )}
                                  />
                                  Delete
                                </label>
                              </div>
                            </div>
                          </div>
                        ))}
                      </Accordion>
                    );
                  })}
                </Accordion>
              );
            })}
          </OffcanvasBody>
        </Offcanvas>
        {(showModal) &&
          <Permissions
            permissions={permission}
            showModal={showModal}
            handleCloseModal={() => setShowModal(false)}
          />
        }
        <DeletePopup
          isOpen={deletePopupFlag}
          toggle={() => {
            setDeleteRecord(null);
            setDeletePopupFlag(false);
          }}
          proceedFunction={proceedDelete}
          name={deleteRecord?.roleName}
        />
      </div>
    </React.Fragment>
  );
};

export default Roles;
