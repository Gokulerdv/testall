import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormText,
  InputGroup,
  InputGroupText,
  InputProps,
} from "reactstrap";
import { z } from "zod";
import DebouncedInput from "../../../../components/debounced-input";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";

export const key = "search";

export const searchFilterSchema = z.object({
  [key]: z.string().optional(),
});

export type SearchFilterSchema = z.infer<typeof searchFilterSchema>;

export type SearchFilterProps = InputProps & {
  help?: React.ReactNode;
  setValue: (value: string) => void;
};

export const Search = (props: SearchFilterProps) => {
  const { control } = useFormContext();

  return (
    <>
      <Controller
        key={key}
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <InputGroup>
              <InputGroupText>
                <FontAwesomeIcon icon={faSearch} />
              </InputGroupText>

              <DebouncedInput
                {...field}
                id={key}
                invalid={Boolean(fieldState.error?.message)}
                {...props}
                onChange={(value) => props.setValue(value as string)}
                placeholder="Search content"
              />
              {fieldState.error?.message ? (
                <FormFeedback>{fieldState.error.message}</FormFeedback>
              ) : null}
              {props.help ? <FormText>{props.help}</FormText> : null}
            </InputGroup>
          </>
        )}
      />
    </>
  );
};

export default Search;
