import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";

export const key = "ADA-Code";

export const adaCodeFilterSchema = z.object({
  [key]: z.boolean().optional(),
});

export type AdaCodeFilterSchema = z.infer<typeof adaCodeFilterSchema>;

export type AdaCodeFilterProps = InputProps & {
  help?: React.ReactNode;
};

export const AdaCodeSwitch = (props: AdaCodeFilterProps) => {
  const { control } = useFormContext();

  return (
    <>
      <Controller
        key={key}
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <FormGroup switch>
              <Input
                {...field}
                id={key}
                type="switch"
                invalid={Boolean(fieldState.error?.message)}
                {...props}
              />
              {fieldState.error?.message ? (
                <FormFeedback>{fieldState.error.message}</FormFeedback>
              ) : null}
              {props.help ? <FormText>{props.help}</FormText> : null}
            </FormGroup>
          </>
        )}
      />
    </>
  );
};

export default AdaCodeSwitch;
