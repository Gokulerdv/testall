import React from "react";
import { z } from "zod";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormGroup,
  Label,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";

export const inNetworkKey = "In-Network";
export const outNetworkKey = "Out-Of-Network";

export const keys = [inNetworkKey, outNetworkKey];

export const networkSchema = z.object({
  [inNetworkKey]: z.boolean().optional(),
  [outNetworkKey]: z.boolean().optional(),
});

export type NetworkSchema = z.infer<typeof networkSchema>;

export type NetworkProps = InputProps & {
  help?: React.ReactNode;
};

export const Network = (props: NetworkProps) => {
  const { control } = useFormContext();

  return (
    <>
      {keys.map((key) => (
        <Controller
          key={key}
          name={key}
          control={control}
          render={({ field, fieldState }) => (
            <>
              <FormGroup check>
                <Label for={key} check>
                  {props.required ? (
                    <span className="text-danger">*&nbsp;</span>
                  ) : null}
                  {capitalCase(key)}
                </Label>

                <Input
                  {...field}
                  id={key}
                  type="checkbox"
                  invalid={Boolean(fieldState.error?.message)}
                  {...props}
                />
                {fieldState.error?.message ? (
                  <FormFeedback>{fieldState.error.message}</FormFeedback>
                ) : null}
                {props.help ? <FormText>{props.help}</FormText> : null}
              </FormGroup>
            </>
          )}
        />
      ))}
    </>
  );
};

export default Network;
