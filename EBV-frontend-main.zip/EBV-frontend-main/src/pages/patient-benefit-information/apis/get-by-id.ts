import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const activeCoverageSchema = z.object({
  serviceType: z.string(),
  planCoverageDescription: z.string(),
  insuranceType: z.string(),
  message: z.string(),
});

export const coInsuranceSchema = z.object({
  code: z.string().optional(),
  network: z.string(),
  serviceType: z.string(),
  coverageLevel: z.string(),
  percent: z.string(),
  insuranceType: z.string(),
  authorizationRequired: z.string().optional(),
  message: z.string().optional(),
});

export const deductibleSchema = z.object({
  serviceType: z.string(),
  network: z.string(),
  coverageLevel: z.string(),
  planPeriod: z.string(),
  amount: z.string(),
  insuranceType: z.string(),
  message: z.string().optional(),
});

export const limitationAndMaximumSchema = z.object({
  serviceType: z.string(),
  network: z.string(),
  coverageLevel: z.string(),
  planPeriod: z.string(),
  amount: z.string(),
  insuranceType: z.string(),
});

export const notCoveredSchema = z.object({
  serviceType: z.string(),
  network: z.string(),
  coverageLevel: z.string(),
  insuranceType: z.string(),
});

export type AdaProcedure = z.infer<typeof coInsuranceSchema> & {
  [key: string]: unknown;
};

export type CoInsurance = z.infer<typeof coInsuranceSchema> & {
  [key: string]: unknown;
};

export type ActiveCoverage = z.infer<typeof activeCoverageSchema> & {
  [key: string]: unknown;
};

export type LimitationAndMaximum = z.infer<
  typeof limitationAndMaximumSchema
> & {
  [key: string]: unknown;
};

export type Deductible = z.infer<typeof deductibleSchema> & {
  [key: string]: unknown;
};

export type NotCovered = z.infer<typeof notCoveredSchema> & {
  [key: string]: unknown;
};

export const planSchema = z.object({
  groupNumber: z.string(),
  groupName: z.string(),
  subscriberId: z.string(),
  coverageIndicator: z.string(),
  effectiveDateFrom: z.string(),
});

export const addressSchema = z.object({
  address1: z.string(),
  address2: z.string(),
  city: z.string(),
  state: z.string(),
  zipCode: z.string(),
});

export const dentalXchangeResponseSchema = z.object({
  status: z.object({ code: z.number(), description: z.string() }),
  messages: z.array(z.unknown()),
  transactionId: z.number(),
  response: z.object({
    payer: z.object({ name: z.string(), id: z.string() }),
    subscriber: z.object({
      firstName: z.string(),
      lastName: z.string(),
      address: z.object(addressSchema.shape),
      dateOfBirth: z.string(),
      gender: z.string(),
      plan: z.object(planSchema.shape),
    }),
    patient: z.object({
      firstName: z.string(),
      lastName: z.string(),
      address: z.object(addressSchema.shape),
      dateOfBirth: z.string(),
      relationship: z.string(),
      gender: z.string(),
      plan: z.object(planSchema.shape),
    }),
    activeCoverage: z.array(activeCoverageSchema),
    coInsurance: z.array(coInsuranceSchema),
    deductible: z.array(deductibleSchema),
    limitationAndMaximum: z.array(limitationAndMaximumSchema),
    notCovered: z.array(notCoveredSchema),
  }),
});

export type DentalXchangeResponse = z.infer<typeof dentalXchangeResponseSchema>;

export const benefitSchema = z.array(
  z.object({
    adminId: z.string(),
    dentalXchangeResponse: z.object(dentalXchangeResponseSchema.shape),
    uniqueId: z.string(),
    verificationType: z.string(),
    patientid: z.string().optional(),
    lastverified: z.string(),
  })
);

export type Benefit = z.infer<typeof benefitSchema>;
export type GetByIdResponse = Response<Benefit>;

export type GetByIdProps = {
  patientId: string;
};

// export const getById =
//   ({ patientId }: GetByIdProps) =>
//   async (): Promise<GetByIdResponse> => {
//     const url = `${
//       import.meta.env.VITE_API_HOST ?? ""
//     }/patients/getpatientbenefits?patientId=${patientId}`;

//     const response = (await (
//       await fetch(url, urlEncodedRequestOptions({}))
//     ).json()) as GetByIdResponse;

//     return response;
//   };
