import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const eligibilityUpdateSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type EligibilityUpdate = z.infer<typeof eligibilityUpdateSchema>;

export type EligibilityUpdateResponse = Response<EligibilityUpdate>;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type EligibilityUpdateBody = any;

export type EligibilityUpdateProps = {
  body: EligibilityUpdateBody & {
    uniqueId: string;
  };
};
