import { z } from "zod";
import { Response } from "../../../apis/mocks/response";

export const eligibilityUpdateSchema = z.object({
  ConsumedCapacity: z.object({
    TableName: z.string(),
    CapacityUnits: z.number(),
  }),
});

export type EligibilityCreate = z.infer<typeof eligibilityUpdateSchema>;

export type EligibilityCreateResponse = Response<EligibilityCreate>;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type EligibilityCreateBody = any;

export type EligibilityCreateProps = {
  body: EligibilityCreateBody & {
    uniqueId: string;
    adminId: string;
    lastVerified: string;
    verificationType: string;
    patientId: string;
    statusflag: string;
  };
};
