import { zodResolver } from "@hookform/resolvers/zod";
import {
  Controller,
  FormProvider,
  SubmitHandler,
  useForm,
  useFormContext,
} from "react-hook-form";
import { toast } from "react-toastify";
import {
  Button,
  Form,
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { usePatientBenefitInformationContext } from ".";
import useDrawerFromLocation from "../../shared/hooks/use-drawer-from-location";
import { EligibilityModalProps } from "../eligibility/eligibility-modal";

export const miscellaneousFormSchema = z.object({
  question: z.string({ required_error: `Question is required.` }),
  answer: z.string({ required_error: `Answer is required.` }),
});

export type MiscellaneousForm = z.infer<typeof miscellaneousFormSchema>;

export type MiscellaneousFieldProps = InputProps & {
  help?: React.ReactNode;
};

export const QuestionField = (props: MiscellaneousFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={"question"}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        Question
      </Label>

      <Controller
        name={"question"}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={"question"}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export const AnswerField = (props: MiscellaneousFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={"answer"}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        Answer
      </Label>

      <Controller
        name={"answer"}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={"answer"}
              type="textarea"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export type AddMiscellaneousProps = EligibilityModalProps;

export const AddMiscellaneous = () => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<MiscellaneousForm>({
    resolver: zodResolver(miscellaneousFormSchema),
  });

  const { open, toggle } = useDrawerFromLocation({
    matchPath:
      "eligibility/patient-benefit-information/:id/:patientId/miscellaneous/add",
    togglePath: "../../../?refresh=true",
    historyPopInstead: true,
  });

  const onSubmit: SubmitHandler<MiscellaneousForm> = async (data) => {
    try {
      context.setMiscellaneous([...context.miscellaneous, data]);

      toast.success("Miscellaneous added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <div>
      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Patient Benefit Information
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack gap-3">
                <QuestionField required />

                <AnswerField required />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary">
                    Cancel
                  </Button>

                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export default AddMiscellaneous;
