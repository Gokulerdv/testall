import { useSearchParams } from "react-router-dom";
import ActiveCoverageTable from "./components/active-coverage-table";
import AdaProcedureTable from "./components/ada-procedure-table";
import BenefitsHistoryTable from "./components/benefits-history-table";
import CoInsuranceTable from "./components/co-insurance-table";
import { DeductibleTable } from "./components/deductible-table";
import LimitationsTable from "./components/limitations-table";
import NotCoveredTable from "./components/not-covered-table";
import PaymentAndPayerInformation from "./components/payment-and-payer-information-card";
import SubscriberInformationCard from "./components/subscriber-information-card";
import Insights from "./components/insights-cards";
import { usePDF } from "react-to-pdf";
import { NotesAndRemarks } from "./components/notes-and-remarks";
import { Miscellaneous } from "./components/miscellaneous";
import { AttachmentTable } from "./components/attachments-table";
import React from "react";
import { Col, Row } from "reactstrap";
import MaximumTable from "./components/maximum-table";
import { Context, usePatientBenefitInformation } from ".";

export const Report = () => {
  const context = usePatientBenefitInformation();
  const [searchParams] = useSearchParams();
  const type = searchParams.get("type");
  const download = searchParams.get("download");
  const { toPDF, targetRef } = usePDF({ filename: "page.pdf" });
  const isFirstLoad = React.useRef(true);

  React.useEffect(() => {
    if (download === "pdf" && isFirstLoad.current) {
      toPDF();
      isFirstLoad.current = false;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [download]);

  return (
    <Context.Provider value={context}>
      <div ref={targetRef} className={`${download === "pdf" ? "p-3" : "p-0"}`}>
        <Row className="g-3 mb-5">
          <Col lg={8}>
            <SubscriberInformationCard />
          </Col>

          <Col>
            <Insights />
          </Col>
        </Row>

        <ActiveCoverageTable showLabel />

        {type === "detailed" ? <CoInsuranceTable showLabel /> : null}

        {type === "detailed" ? <AdaProcedureTable showLabel /> : null}

        <DeductibleTable showLabel />

        {type === "detailed" ? <LimitationsTable showLabel /> : null}

        {type === "detailed" ? <MaximumTable showLabel /> : null}

        <NotCoveredTable showLabel />

        <PaymentAndPayerInformation />

        <Miscellaneous />

        <NotesAndRemarks />

        <AttachmentTable />

        <BenefitsHistoryTable showLabel />
      </div>
    </Context.Provider>
  );
};

export default Report;
