import {
  faDownload,
  faEye,
  faPenToSquare,
  faSave,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import {
  Location,
  NavLink as RouterNavLink,
  useLocation,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Form,
  Input,
  Nav,
  NavItem,
  NavLink,
  Row,
  Spinner,
  TabContent,
  TabPane,
  UncontrolledDropdown,
} from "reactstrap";
import { z } from "zod";
import {
  ActiveCoverage,
  BenefitsHistory,
  CoInsurance,
  Deductible,
  LimitationAndMaximum,
  NotCovered,
  Question,
} from "../../apis/mocks/patients/data";
import { useAuth } from "../../shared/hooks/use-auth";
import { defaultMutateOptions } from "../../utils/default-mutate-options";
import Config from "../../utils/headers-config";
import { TempEligibilityData } from "../eligibility/table/columns";
import { EligibilityCreateProps } from "./apis/eligibility-post";
import {
  EligibilityUpdateProps,
  EligibilityUpdateResponse,
} from "./apis/eligibility-update";
import ActiveCoverageTable from "./components/active-coverage-table";
import AdaProcedureTable from "./components/ada-procedure-table";
import { AttachmentTable } from "./components/attachments-table";
import BenefitsHistoryTable from "./components/benefits-history-table";
import CoInsuranceTable from "./components/co-insurance-table";
import { DeductibleTable } from "./components/deductible-table";
import EmployerInformation from "./components/employer-information";
import Insights from "./components/insights-cards";
import LimitationsTable from "./components/limitations-table";
import MaximumTable from "./components/maximum-table";
import { Miscellaneous } from "./components/miscellaneous";
import NotCoveredTable from "./components/not-covered-table";
import { NotesAndRemarks } from "./components/notes-and-remarks";
import PaymentAndPayerInformation from "./components/payment-and-payer-information-card";
import SubscriberInformationCard from "./components/subscriber-information-card";
import AdaCodeSwitch, {
  adaCodeFilterSchema,
  key as adaCodeKey,
} from "./form/fields/ada-code";
import Network, {
  inNetworkKey,
  networkSchema,
  outNetworkKey,
} from "./form/fields/network";
import Search, {
  searchFilterSchema,
  key as searchKey,
} from "./form/fields/search";

export type ContextType = ReturnType<typeof usePatientBenefitInformation>;

export const Context = React.createContext<ContextType | null>(null);

export const usePatientBenefitInformationContext = () => {
  const context = React.useContext(Context);

  if (!context)
    throw new Error(
      "usePatientBenefitInformationContext must be used within a Provider"
    );

  return context;
};

export const usePatientBenefitInformation = () => {
  const [activeCoverage, setActiveCoverage] = React.useState<ActiveCoverage[]>(
    []
  );
  const [coInsurance, setCoInsurance] = React.useState<CoInsurance[]>([]);
  const [adaProcedure, setAdaProcedure] = React.useState<CoInsurance[]>([]);
  const [deductible, setDeductible] = React.useState<Deductible[]>([]);
  const [limitations, setLimitations] = React.useState<LimitationAndMaximum[]>(
    []
  );
  const [maximum, setMaximum] = React.useState<LimitationAndMaximum[]>([]);
  const [notCovered, setNotCovered] = React.useState<NotCovered[]>([]);
  const [benefitsHistory, setBenefitsHistory] = React.useState<
    BenefitsHistory[]
  >([]);
  const [miscellaneous, setMiscellaneous] = React.useState<Question[]>([]);
  const [notesAndRemarks, setNotesAndRemarks] = React.useState("");

  return {
    activeCoverage,
    coInsurance,
    adaProcedure,
    deductible,
    limitations,
    maximum,
    notCovered,
    benefitsHistory,
    miscellaneous,
    notesAndRemarks,
    setActiveCoverage,
    setCoInsurance,
    setAdaProcedure,
    setDeductible,
    setLimitations,
    setMaximum,
    setNotCovered,
    setBenefitsHistory,
    setMiscellaneous,
    setNotesAndRemarks,
  };
};

export const formSchema = networkSchema
  .merge(adaCodeFilterSchema)
  .merge(searchFilterSchema);

export type FormSchema = z.infer<typeof formSchema>;

export const PatientBenefitInformation = () => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformation();

  const methods = useForm<FormSchema>({ resolver: zodResolver(formSchema) });

  const [searchParams, setSearchParams] = useSearchParams();

  const [editMode, setEditMode] = React.useState(
    searchParams.get("editMode") ?? ""
  );

  const onSubmit: SubmitHandler<FormSchema> = (data) => {
    ({ data });
  };

  const inNetwork = methods.watch(inNetworkKey, false);
  const outNetwork = methods.watch(outNetworkKey, false);
  const adaCode = methods.watch(adaCodeKey, false);
  const search = methods.watch(searchKey, "");
  const auth = useAuth();

  const network = React.useMemo(
    () => ({
      [inNetworkKey]: inNetwork,
      [outNetworkKey]: outNetwork,
      [adaCodeKey]: adaCode,
      [searchKey]: search,
      ["editMode"]: editMode,
    }),
    [inNetwork, outNetwork, adaCode, search, editMode]
  );

  React.useEffect(() => {
    setSearchParams(
      {
        adaCode: String(network[adaCodeKey]),
        network: (
          [inNetworkKey, outNetworkKey] as (keyof typeof network)[]
        ).filter((key) => network[key]),
        search: String(network[searchKey]),
        editMode: String(network["editMode"]),
      },
      { state }
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [network]);

  const eligibilityCreate = async (
    props: EligibilityCreateProps
  ): Promise<void> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/eligibility/create`;

    await fetch(url, {
      method: "POST",
      body: JSON.stringify(props.body),
      headers: {
        "Content-Type": "application/json",
        ...Config(auth),
      },
    });
  };

  const eligibilityUpdate = async (
    props: EligibilityUpdateProps
  ): Promise<EligibilityUpdateResponse> => {
    const url = `${import.meta.env.VITE_API_HOST ?? ""}/eligibility`;

    const response = (await (
      await fetch(url, {
        method: "PUT",
        body: JSON.stringify(props.body),
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
      })
    ).json()) as EligibilityUpdateResponse;

    return response;
  };

  const eligibilityCreateAPI = useMutation({
    mutationKey: [`eligibility/create/${state.row.uniqueId}`],
    mutationFn: eligibilityCreate,
  });

  const eligibilityUpdateAPI = useMutation({
    mutationKey: [`eligibility/update/${state.row.uniqueId}`],
    mutationFn: eligibilityUpdate,
  });

  const handleEditMode = async () => {
    try {
      if (editMode !== "true") {
        setEditMode("true");
        return;
      }

      const metadata = {
        uniqueId: state.row.uniqueId,
        adminId: 12,
        lastVerified: state.row.lastVerified,
        verificationType: state.row.verificationType,
        patientId: state.row.patientId,
        statusflag: state.row.statusflag,
      };

      const body = {
        payer: state.actualResponseData.dentalXchangeResponse.response?.payer,
        subscriber:
          state.actualResponseData.dentalXchangeResponse.response?.subscriber,
        patient:
          state.actualResponseData.dentalXchangeResponse.response?.patient,
        activeCoverage: context.activeCoverage,
        coInsurance: context.coInsurance,
        adaProcedure: context.adaProcedure,
        deductible: context.deductible,
        limitations: context.limitations,
        maximum: context.maximum,
        notCovered: context.notCovered,
        benefitsHistory: context.benefitsHistory,
        miscellaneous: context.miscellaneous,
        notesAndRemarks: context.notesAndRemarks,
        ...metadata,
      };

      if (!state.row.isVerified && !state.row.isScheduled) {
        await eligibilityCreateAPI.mutateAsync(
          {
            body: {
              ...body,
              patientUniqueId: state.row.uniqueId,
            },
          },
          defaultMutateOptions
        );
      } else {
        await Promise.allSettled(
          [
            "payer",
            "subscriber",
            "patient",
            "activeCoverage",
            "coInsurance",
            "adaProcedure",
            "deductible",
            "limitations",
            "maximum",
            "notCovered",
            "benefitsHistory",
            "miscellaneous",
            "notesAndRemarks",
          ].map((key) =>
            eligibilityUpdateAPI.mutateAsync(
              {
                body: {
                  [key]: (body as Record<string, unknown>)?.[key],
                  ...metadata,
                },
              },
              defaultMutateOptions
            )
          )
        );
      }

      toast.success("Eligibility successfully updated");
      setEditMode("");
    } catch (error) {
      console.log(error);
      toast.error("An error occurred!");
    }
  };

  return (
    <>
      <Context.Provider value={context}>
        <FormProvider {...methods}>
          <Form onSubmit={methods.handleSubmit(onSubmit)}>
            <div className="position-relative">
              <div
                className="p-3 bg-white position-fixed z-3 w-100"
                style={{ margin: "-1rem" }}
              >
                <Search
                  setValue={(value) => methods.setValue("search", value)}
                />
              </div>
              <div className="p-3 pb-0">
                <Input style={{ visibility: "hidden" }} />
              </div>
            </div>

            <Card className="mb-4">
              <CardBody>
                <Row>
                  <Col xs={12} md={4} lg={2} className="me-5">
                    <h6>Benefits</h6>
                    <Input type="select">
                      <option>02/24/2023</option>
                    </Input>
                  </Col>

                  <Col xs={12} md={4} lg={2}>
                    <h6>ADA Code Filter</h6>

                    <AdaCodeSwitch />
                  </Col>

                  <Col xs={12} md={4} lg={2}>
                    <h6>Network Filter</h6>

                    <Network />
                  </Col>

                  <Col>
                    <div className="gap-2 hstack justify-content-end align-items-center h-100">
                      <UncontrolledDropdown>
                        <DropdownToggle data-toggle="dropdown" tag="span">
                          <Button outline color="primary">
                            <FontAwesomeIcon
                              icon={faDownload}
                              className="me-2"
                            />
                            PDF
                          </Button>
                        </DropdownToggle>

                        <DropdownMenu>
                          <RouterNavLink
                            to="report?type=basic&download=pdf"
                            state={state}
                            className="text-decoration-none"
                          >
                            <DropdownItem toggle={false}>
                              Basic Report
                            </DropdownItem>
                          </RouterNavLink>

                          <RouterNavLink
                            to="report?type=detailed&download=pdf"
                            state={state}
                            className="text-decoration-none"
                          >
                            <DropdownItem toggle={false}>
                              Detailed Report
                            </DropdownItem>
                          </RouterNavLink>
                        </DropdownMenu>
                      </UncontrolledDropdown>

                      <UncontrolledDropdown>
                        <DropdownToggle data-toggle="dropdown" tag="span">
                          <Button outline color="primary">
                            <FontAwesomeIcon icon={faEye} className="me-2" />
                            Preview
                          </Button>
                        </DropdownToggle>

                        <DropdownMenu>
                          <RouterNavLink
                            to="report?type=basic&mode=preview"
                            state={state}
                            className="text-decoration-none"
                          >
                            <DropdownItem toggle={false}>
                              Basic Report
                            </DropdownItem>
                          </RouterNavLink>

                          <RouterNavLink
                            to="report?type=detailed&mode=preview"
                            state={state}
                            className="text-decoration-none"
                          >
                            <DropdownItem toggle={false}>
                              Detailed Report
                            </DropdownItem>
                          </RouterNavLink>
                        </DropdownMenu>
                      </UncontrolledDropdown>

                      <Button
                        style={{
                          backgroundColor: "#E6F7F3",
                          color: "var(--bs-primary)",
                          borderColor: "#E6F7F3",
                        }}
                        onClick={handleEditMode}
                      >
                        {editMode ? (
                          <p className="gap-2 mb-0 hstack">
                            <FontAwesomeIcon icon={faSave} />

                            {eligibilityUpdateAPI.isPending ? (
                              <>
                                <Spinner size="sm">Saving...</Spinner>
                                <span className="mb-0"> Saving...</span>
                              </>
                            ) : (
                              <span className="mb-0">Save</span>
                            )}
                          </p>
                        ) : (
                          <p className="gap-2 mb-0 hstack">
                            <FontAwesomeIcon icon={faPenToSquare} />

                            <span className="mb-0">Edit</span>
                          </p>
                        )}
                      </Button>
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Form>
        </FormProvider>

        <Row className="mb-5 g-3">
          <Col lg={8}>
            <SubscriberInformationCard />
          </Col>

          <Col>
            <Insights />
          </Col>
        </Row>

        <PatientBenefitInformationTabs />
      </Context.Provider>
    </>
  );
};

export const getTabActiveStyles = (
  activeTab: string,
  tab: string
): React.CSSProperties => {
  return activeTab === tab
    ? {
        backgroundColor: "#EBF2F5",
        color: "var(--bs-text-black)",
        borderRadius: 50,
        boxShadow: "0px 1px 2px 0px rgba(0, 0, 0, 0.20)",
        margin: "0.35rem",
        padding: "0.35rem 0.65rem",
      }
    : {
        backgroundColor: "transparent",
        color: "var(--bs-text-black)",
        borderRadius: 50,
        border: "1px solid black",
        margin: "0.35rem",
        padding: "0.35rem 0.65rem",
      };
};

export default PatientBenefitInformation;

export const PatientBenefitInformationTabs = () => {
  const [searchParams] = useSearchParams();

  const tabId = searchParams.get("tabId");

  const [activeTab, setActiveTab] = React.useState(tabId || "1");

  const toggle = (tab: string) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  return (
    <>
      <Nav pills>
        <NavItem>
          <NavLink
            style={getTabActiveStyles(activeTab, "1")}
            onClick={() => {
              toggle("1");
            }}
          >
            All
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "2")}
            onClick={() => {
              toggle("2");
            }}
          >
            Active Coverage
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "3")}
            onClick={() => {
              toggle("3");
            }}
          >
            Co Insurance
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "4")}
            onClick={() => {
              toggle("4");
            }}
          >
            ADA Procedure
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "5")}
            onClick={() => {
              toggle("5");
            }}
          >
            Deductible
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "6")}
            onClick={() => {
              toggle("6");
            }}
          >
            Limitation & Maximum
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "7")}
            onClick={() => {
              toggle("7");
            }}
          >
            Not Covered
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "8")}
            onClick={() => {
              toggle("8");
            }}
          >
            Patient & Payer Information
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "9")}
            onClick={() => {
              toggle("9");
            }}
          >
            Benefits History
          </NavLink>
        </NavItem>

        <NavItem style={{ cursor: "pointer" }}>
          <NavLink
            style={getTabActiveStyles(activeTab, "10")}
            onClick={() => {
              toggle("10");
            }}
          >
            Employer Information
          </NavLink>
        </NavItem>
      </Nav>

      <TabContent activeTab={activeTab}>
        <TabPane tabId="1">
          <React.Suspense fallback={"loading data..."}>
            <ActiveCoverageTable showLabel />
            <CoInsuranceTable showLabel />
            <AdaProcedureTable showLabel />
            <DeductibleTable showLabel />
            <LimitationsTable showLabel />
            <MaximumTable showLabel />
            <NotCoveredTable showLabel />
            <PaymentAndPayerInformation />
            <BenefitsHistoryTable showLabel />
            <EmployerInformation />
            <Miscellaneous />
            <NotesAndRemarks />
            <AttachmentTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="2">
          <React.Suspense fallback={"loading data..."}>
            <ActiveCoverageTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="3">
          <React.Suspense fallback={"loading data..."}>
            <CoInsuranceTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="4">
          <React.Suspense fallback={"loading data..."}>
            <AdaProcedureTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="5">
          <React.Suspense fallback={"loading data..."}>
            <DeductibleTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="6">
          <React.Suspense fallback={"loading data..."}>
            <LimitationsTable />
            <MaximumTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="7">
          <React.Suspense fallback={"loading data..."}>
            <NotCoveredTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="8">
          <PaymentAndPayerInformation />
        </TabPane>

        <TabPane tabId="9">
          <React.Suspense fallback={"loading data..."}>
            <BenefitsHistoryTable />
          </React.Suspense>
        </TabPane>

        <TabPane tabId="10">
          <React.Suspense fallback={"loading data..."}>
            <EmployerInformation />
          </React.Suspense>
        </TabPane>
      </TabContent>
    </>
  );
};
