import { Card, Row, Col, Label } from "reactstrap";
import TextWithHighlight from "../../../components/text-with-highlight";
import textWithDefault from "../../../utils/text-with-default";
// import { Location, useLocation } from "react-router-dom";
// import { TempEligibilityData } from "../../eligibility/table/columns";

export const EmployerInformation = () => {
  // const { state } = useLocation() as Location<TempEligibilityData>;

  // const data = state.actualResponseData.dentalXchangeResponse;

  return (
    <>
      <Card className="p-4 mt-3">
        <Row>
          <Col xs={12}>
            <h6 className="mb-4 fw-bold">Employer Information</h6>
          </Col>
          <Col xs={12}>
            <Row>
              <Col xs={12} md={6}>
                <Row>
                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Employer Name
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("United States Postal Service")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Enrollment Status
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("Individual")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Employee Identification Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("0000000000000")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Employee Identification Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("0000000000000")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Type of Plan
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault(
                            "Health Maintenance Organization(HMO)"
                          )}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Group or Policy Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("00000000000000")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Network Status
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("In-network")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Network Provider List
                      </Label>
                      <p>
                        <a href="#">Link</a>
                      </p>
                    </div>
                  </Col>
                </Row>
              </Col>

              <Col xs={12} md={6}>
                <Row>
                  <Col xs={12}>
                    <h6 className="mb-4 fw-bold">Contact Details</h6>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">Address</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("7 Rockbridge")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">City</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("Spencerport")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">State</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("NY")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">Zip Code</Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("123214")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">
                        Phone Number
                      </Label>
                      <p>
                        <TextWithHighlight>
                          {textWithDefault("000-000-0000")}
                        </TextWithHighlight>
                      </p>
                    </div>
                  </Col>

                  <Col xs={12} md={6}>
                    <div>
                      <Label className="mb-0 text-secondary">Website</Label>
                      <p>
                        <a href="#">
                          <TextWithHighlight>
                            {textWithDefault("https://usps.com")}
                          </TextWithHighlight>
                        </a>
                      </p>
                    </div>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Col>
        </Row>
      </Card>
    </>
  );
};

export default EmployerInformation;
