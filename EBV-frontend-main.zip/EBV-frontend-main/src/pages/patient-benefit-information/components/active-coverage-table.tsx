import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import { insert, remove } from "ramda";
import React from "react";
import {
  Controller,
  FormProvider,
  SubmitHandler,
  useForm,
  useFormContext,
} from "react-hook-form";
import { Form, Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { usePatientBenefitInformationContext } from "..";
import { ActiveCoverage } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import { TextWithHighlight } from "../../../components/text-with-highlight";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";

export type ActiveCoverageTableProps = {
  showLabel?: boolean;
};

export type TextFieldProps = InputProps & {
  help?: React.ReactNode;
  fieldKey: string;
};

export const TextField = (props: TextFieldProps) => {
  const { control } = useFormContext();
  const key = props.fieldKey;

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>

      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export const activeCoverageSchema = z.object({
  serviceType: z.string().optional(),
  adaCode: z.string().optional(),
  effectiveDate: z.string().optional(),
  planPeriod: z.string().optional(),
  percentage: z.string().optional(),
  waitingPeriodApplies: z.string().optional(),
  auth: z.string().optional(),
});

export type ActiveCoverageForm = z.infer<typeof activeCoverageSchema>;

export const ActiveCoverageTable = (props: ActiveCoverageTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setActiveCoverage([
      ...(data.response?.activeCoverage ?? []),
    ] as ActiveCoverage[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<ActiveCoverage>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue())}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("adaCode", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("effectiveDate", {
        cell: () => (
          <TextWithHighlight>
            {textWithDefault(
              data.response?.subscriber?.plan?.effectiveDateFrom ?? undefined
            )}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("planPeriod", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("percentage", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("waitingPeriodApplies", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("auth", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <ActiveCoverageForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                      effectiveDate:
                        data.response?.subscriber?.plan?.effectiveDateFrom,
                    }}
                  />

                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Active Coverage</h6>

                {editMode ? <ActiveCoverageForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Active Coverage</h6>

                {editMode ? <ActiveCoverageForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table
            data={context.activeCoverage}
            columns={columns}
            getRowCanExpand={(row) => (row.original.message ? true : false)}
            renderSubComponent={({ row }) => <div>{row.original.message}</div>}
          />
        </CardBody>
      </Card>
    </>
  );
};

export default ActiveCoverageTable;

export type ActiveCoverageFormProps = {
  defaultValues?: ActiveCoverageForm;
  isEdit?: number;
};

export const ActiveCoverageForm = ({
  defaultValues,
  isEdit,
}: ActiveCoverageFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<ActiveCoverageForm>({
    resolver: zodResolver(activeCoverageSchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<ActiveCoverageForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newActiveCoverage = insert(
          isEdit,
          data as ActiveCoverage,
          remove(isEdit, 1, context.activeCoverage)
        );

        context.setActiveCoverage(() => newActiveCoverage);
        toast.success("Active coverage updated successfully");
        return;
      }

      context.setActiveCoverage(() => [
        ...context.activeCoverage,
        data as ActiveCoverage,
      ]);
      toast.success("Active coverage added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} Active Coverage
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="adaCode" />
                <TextField fieldKey="effectiveDate" />
                <TextField fieldKey="planPeriod" />
                <TextField fieldKey="percentage" />
                <TextField fieldKey="waitingPeriodApplies" />
                <TextField fieldKey="auth" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    try {
      context.setActiveCoverage(() => remove(index, 1, context.activeCoverage));

      toast.success("Active coverage deleted successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
