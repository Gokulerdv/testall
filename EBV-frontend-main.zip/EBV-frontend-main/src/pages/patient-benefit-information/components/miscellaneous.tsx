import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import React from "react";
import {
  Controller,
  FormProvider,
  SubmitHandler,
  useForm,
  useFormContext,
} from "react-hook-form";
import { Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Col,
  Form,
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  Row,
} from "reactstrap";
import { z } from "zod";
import { usePatientBenefitInformationContext } from "..";
import { Question } from "../../../apis/mocks/patients/data";
import { Patient } from "../../eligibility/apis/patients-all";
import { EligibilityModalProps } from "../../eligibility/eligibility-modal";
import { TempEligibilityData } from "../../eligibility/table/columns";

export const defaultQuestions = [
  {
    question: "Are Limited exams included in exams freq?",
    answer: "No",
  },
  {
    question: "Adult prophy (D1110) is considered at what age?",
    answer: "13",
  },
  {
    question: "Sealants covered on which teeth?",
    answer: "Motor",
  },
  {
    question: "Can all quads of SRP (D4341/D4342) be done on same day?",
    answer: "No",
  },
] as Question[];

export const miscellaneousStorageKeyPrefix = "pbi-miscellaneous-";

export const Miscellaneous = () => {
  const context = usePatientBenefitInformationContext();

  const { state } = useLocation() as Location<
    TempEligibilityData & {
      row: Patient;
    }
  >;

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setMiscellaneous(
      (data.response?.miscellaneous ?? []) as Question[]
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          <h5 className="mb-3">Miscellaneous</h5>
          <div className="hstack gap-3 align-items-baseline">
            <p className="fw-bold mb-4">Caveat Question</p>

            <AddMiscellaneous />
          </div>
          <Row className="g-3">
            {[...defaultQuestions, ...context.miscellaneous].map((question) => (
              <Col xs={12} md={6} key={question.question}>
                <Card>
                  <CardHeader className="bg-transparent">
                    <p className="fw-bold mb-0 mt-1">Q. {question.question}</p>
                  </CardHeader>
                  <CardBody>A: {question.answer}</CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        </CardBody>
      </Card>
    </>
  );
};

export const miscellaneousFormSchema = z.object({
  question: z.string({ required_error: `Question is required.` }),
  answer: z.string({ required_error: `Answer is required.` }),
});

export type MiscellaneousForm = z.infer<typeof miscellaneousFormSchema>;

export type MiscellaneousFieldProps = InputProps & {
  help?: React.ReactNode;
};

export const QuestionField = (props: MiscellaneousFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={"question"}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        Question
      </Label>

      <Controller
        name={"question"}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={"question"}
              type="text"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export const AnswerField = (props: MiscellaneousFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Label for={"answer"}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        Answer
      </Label>

      <Controller
        name={"answer"}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={"answer"}
              type="textarea"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export type AddMiscellaneousProps = EligibilityModalProps;

export const AddMiscellaneous = () => {
  const context = usePatientBenefitInformationContext();

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode");

  const methods = useForm<MiscellaneousForm>({
    resolver: zodResolver(miscellaneousFormSchema),
  });

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const onSubmit: SubmitHandler<MiscellaneousForm> = async (data) => {
    try {
      context.setMiscellaneous([...context.miscellaneous, data]);

      toast.success("Miscellaneous added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {editMode ? (
        <>
          <Button color="primary" style={{ borderRadius: 40 }} onClick={toggle}>
            <FontAwesomeIcon icon={faPlus} className="text-white" />
          </Button>
        </>
      ) : null}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          Patient Benefit Information
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack gap-3">
                <QuestionField required />

                <AnswerField required />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary">
                    Cancel
                  </Button>

                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export default AddMiscellaneous;
