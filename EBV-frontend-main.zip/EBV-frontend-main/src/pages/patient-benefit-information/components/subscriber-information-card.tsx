import { Card, Row, Col, Label, CardBody } from "reactstrap";
import { Location, useLocation } from "react-router-dom";
import { dateFormat } from "../../../utils/date-format";
import { TempEligibilityData } from "../../eligibility/table/columns";
import TextWithHighlight from "../../../components/text-with-highlight";
import textWithDefault from "../../../utils/text-with-default";
import { relationshipTypes } from "../../eligibility/form/fields/relationship";

export const SubscriberInformationCard = () => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const data = state.actualResponseData.dentalXchangeResponse;

  return (
    <Card className="border-2 border-primary bg-primary-subtle">
      <CardBody>
        <Row>
          <Col xs={12} md={6} lg={5}>
            <Row className="g-3">
              <Col xs={12}>
                <h5 className="mb-3">Subscriber Information</h5>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">First Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.firstName ??
                          state.row.firstName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Last Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.lastName ??
                          state.row.lastName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">DOB</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.dateOfBirth ??
                          state.row.dateOfBirth
                          ? dateFormat(
                              new Date(
                                data?.response?.subscriber?.dateOfBirth ??
                                  state.row.dateOfBirth
                              )
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Gender</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.gender ??
                          // eslint-disable-next-line @typescript-eslint/no-explicit-any
                          (state.row as any).Gender ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Relationship</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        state?.row?.relationship
                          ? relationshipTypes.find(
                              (relationship) =>
                                relationship.value === state?.row?.relationship
                            )?.label
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Member ID</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.plan?.subscriberId ??
                          state.row.memberId ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>

          <Col xs={12} md={6} lg={7}>
            <Row className="g-3">
              <Col xs={12}>
                <div className="hstack justify-content-between w-100">
                  <h5 className="mb-3">Coverage</h5>
                  <h6 className="mb-3">
                    <a href="#">Primary Insurance</a>
                  </h6>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Effective Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.plan?.effectiveDateFrom
                          ? dateFormat(
                              new Date(
                                data?.response?.subscriber?.plan?.effectiveDateFrom
                              )
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">End Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Status</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.plan?.effectiveDateFrom
                          ? "Active"
                          : "Inactive"
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Coverage Type</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col xs={6}>
                <div>
                  <Label className="mb-0 text-secondary">Insurance Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.payer?.name ??
                          state.row.insurancePayer ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
          <Row />
        </Row>
      </CardBody>
    </Card>
  );
};

export default SubscriberInformationCard;
