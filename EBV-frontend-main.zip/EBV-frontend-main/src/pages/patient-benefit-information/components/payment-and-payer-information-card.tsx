import { Card, Row, Col, Label } from "reactstrap";
import { Location, useLocation } from "react-router-dom";
import { dateFormat } from "../../../utils/date-format";
import { TempEligibilityData } from "../../eligibility/table/columns";
import TextWithHighlight from "../../../components/text-with-highlight";
import textWithDefault from "../../../utils/text-with-default";
import { relationshipTypes } from "../../eligibility/form/fields/relationship";

export const PaymentAndPayerInformation = () => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const data = state.actualResponseData.dentalXchangeResponse;

  return (
    <>
      <Card className="p-4 mt-3">
        <Row>
          <Col xs={12} md={4} lg={2} className="me-5">
            <h6 className="mb-4 fw-bold">Patient Information</h6>
          </Col>
        </Row>

        <Row>
          <Col>
            <Row>
              <h6 className="mb-3 fw-medium ">Subscriber</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">First Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.firstName ??
                          state.row.firstName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Last Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.lastName ??
                          state.row.lastName ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">DOB</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.dateOfBirth ??
                          state.row.dateOfBirth
                          ? dateFormat(
                              new Date(
                                data?.response?.subscriber?.dateOfBirth ??
                                  state.row.dateOfBirth
                              )
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Gender</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.gender ??
                          // eslint-disable-next-line @typescript-eslint/no-explicit-any
                          (state.row as any).Gender ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Relationship</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        state?.row?.relationship
                          ? relationshipTypes.find(
                              (relationship) =>
                                relationship.value === state?.row?.relationship
                            )?.label
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Member ID</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.plan?.subscriberId ??
                          state.row.memberId ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>

          <Col>
            <Row>
              <h6 className="mb-3 fw-medium ">Address</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">City</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.address?.city ?? undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">State</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.address?.state ?? undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Address</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.address?.address1
                          ? data?.response?.subscriber?.address?.address2
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Zip Code</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.address?.zipCode ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>

        <hr />

        <Row>
          <Col xs={12} md={4} lg={6}>
            <Row>
              <h6 className="mb-3 fw-medium">Coverage</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Effective Date</Label>
                  <p>
                    {textWithDefault(
                      data?.response?.subscriber?.plan?.effectiveDateFrom
                        ? dateFormat(
                            new Date(
                              data?.response?.subscriber?.plan?.effectiveDateFrom
                            )
                          )
                        : undefined
                    )}
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">End Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Status</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.subscriber?.plan?.effectiveDateFrom
                          ? "Active"
                          : "Inactive"
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>

        <Row>
          <Col xs={12} md={4} lg={6}>
            <Row>
              <h6 className="mb-3 fw-medium ">Payer</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">ID</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.payer?.id ?? state.row.insurancePayer
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.payer?.name ?? state.row.insurancePayer
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>

        <hr />

        <Row>
          <Col xs={12} md={4} lg={6}>
            <Row>
              <h6 className="mb-3 fw-medium ">Plan</h6>
            </Row>

            <Row>
              <h6 className="fw-medium">Basic</h6>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Group Name</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.patient?.plan?.groupName ?? undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Effective Date</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.patient?.plan?.effectiveDateFrom
                          ? dateFormat(
                              new Date(
                                data?.response?.patient?.plan?.effectiveDateFrom
                              )
                            )
                          : undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>

            <Row>
              <Col>
                <div>
                  <Label className="mb-0 text-secondary">Group Number</Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(
                        data?.response?.patient?.plan?.groupNumber ??
                          state.row.groupId ??
                          undefined
                      )}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>

              <Col>
                <div>
                  <Label className="mb-0 text-secondary">
                    Req Participation
                  </Label>
                  <p>
                    <TextWithHighlight>
                      {textWithDefault(undefined)}
                    </TextWithHighlight>
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </Card>
    </>
  );
};

export default PaymentAndPayerInformation;
