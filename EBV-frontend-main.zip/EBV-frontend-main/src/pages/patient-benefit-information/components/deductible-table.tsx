import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form, Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { Deductible } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import TextWithHighlight from "../../../components/text-with-highlight";
import { currencyFormat } from "../../../utils/currency-format";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import { TextField } from "./active-coverage-table";
import { usePatientBenefitInformationContext } from "..";
import { insert, remove } from "ramda";

export const deductibleSchema = z.object({
  serviceType: z.string().optional(),
  adaCode: z.string().optional(),
  network: z.string().optional(),
  coverageLevel: z.string().optional(),
  planPeriod: z.string().optional(),
  amount: z.string().optional(),
});

export type DeductibleForm = z.infer<typeof deductibleSchema>;

export type DeductibleTableProps = {
  showLabel?: boolean;
};

export const DeductibleTable = (props: DeductibleTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setDeductible([
      ...(data.response?.deductible ?? []),
    ] as Deductible[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const networkFilters = searchParams.getAll("network");

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<Deductible>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("adaCode", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("network", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("coverageLevel", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("planPeriod", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("amount", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(currencyFormat(parseFloat(info.getValue())))}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <DeductibleForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                    }}
                  />

                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Deductible</h6>

                {editMode ? <DeductibleForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Deductible</h6>

                {editMode ? <DeductibleForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table
            data={context.deductible.filter((deductible) =>
              networkFilters.length > 0 && deductible?.network
                ? networkFilters.includes(deductible.network)
                : true
            )}
            columns={columns}
            getRowCanExpand={(row) => (row.original.message ? true : false)}
            renderSubComponent={({ row }) => <div>{row.original.message}</div>}
          />
        </CardBody>
      </Card>
    </>
  );
};

export type DeductibleFormProps = {
  defaultValues?: DeductibleForm;
  isEdit?: number;
};

export const DeductibleForm = ({
  defaultValues,
  isEdit,
}: DeductibleFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<DeductibleForm>({
    resolver: zodResolver(deductibleSchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<DeductibleForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newDeductible = insert(
          isEdit,
          data as Deductible,
          remove(isEdit, 1, context.deductible)
        );

        context.setDeductible(() => newDeductible);
        toast.success("Deductible updated successfully");
        return;
      }

      context.setDeductible(() => [...context.deductible, data as Deductible]);

      toast.success("Deductible added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} Deductible
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="adaCode" />
                <TextField fieldKey="network" />
                <TextField fieldKey="coverageLevel" />
                <TextField fieldKey="planPeriod" />
                <TextField fieldKey="amount" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    try {
      context.setDeductible(() => remove(index, 1, context.deductible));

      toast.success("Deductible deleted successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
