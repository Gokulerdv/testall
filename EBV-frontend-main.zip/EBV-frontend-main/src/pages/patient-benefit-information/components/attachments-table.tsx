import { faDownload, faPlus, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { createColumnHelper } from "@tanstack/react-table";
import React from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import { Button, Card, Spinner } from "reactstrap";
import TableComponent from "../../../components/table";
import { dateTimeFormat } from "../../../utils/date-time-format";
import { defaultMutateOptions } from "../../../utils/default-mutate-options";
import AddAttachment from "../../eligibility/add-attachment";

import { useAuth } from "../../../shared/hooks/use-auth";
import Config from "../../../utils/headers-config";
import {
  PatientsAttachmentsProps,
  PatientsAttachmentsResponse,
} from "../../eligibility/apis/patients-attachment-all";
import {
  PatientsAttachmentDeleteProps,
  PatientsAttachmentDeleteResponse,
} from "../../eligibility/apis/patients-attachment-delete";
import { AttachmentDataType } from "../../eligibility/attachment-modal";

export const AttachmentTable = () => {
  const { id: patientId } = useParams() as { id: string };
  const auth = useAuth();

  const patientsAttachmentsAll =
    ({ patientId }: PatientsAttachmentsProps) =>
    async (): Promise<PatientsAttachmentsResponse> => {
      const url = `${
        import.meta.env.VITE_API_HOST ?? ""
      }/patients/attachments/${patientId}`;

      const response = (await (
        await fetch(url, {
          headers: {
            "Content-Type": "application/json",
            ...Config(auth),
          },
        })
      ).json()) as PatientsAttachmentsResponse;

      return response;
    };

  const attachments = useSuspenseQuery({
    queryKey: ["attachment", "getAll", patientId],
    queryFn: patientsAttachmentsAll({ patientId }),
  });

  const queryClient = useQueryClient();

  const patientsAttachmentDelete = async ({
    uniqueId,
  }: PatientsAttachmentDeleteProps): Promise<PatientsAttachmentDeleteResponse> => {
    const url = `${
      import.meta.env.VITE_API_HOST ?? ""
    }/patients/attachments/${uniqueId}`;

    const response = (await (
      await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...Config(auth),
        },
        method: "DELETE",
      })
    ).json()) as PatientsAttachmentDeleteResponse;

    return response;
  };

  const data = React.useMemo(() => {
    return attachments.data.data;
  }, [attachments.data.data]);

  const [searchParams] = useSearchParams();
  const download = searchParams.get("download");
  const mode = searchParams.get("mode");
  const patientsAttachmentRemove = useMutation({
    mutationKey: ["attachment", "remove"],
    mutationFn: patientsAttachmentDelete,
  });

  const deletePatientAttachment = async ({
    uniqueId,
  }: {
    uniqueId: string;
  }) => {
    try {
      if (!patientId) return;

      await patientsAttachmentRemove.mutateAsync(
        { uniqueId },
        defaultMutateOptions
      );
      await attachments.refetch();

      toast.success("Attachment deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      await queryClient.invalidateQueries({
        queryKey: ["attachment", "getAll"],
      });
    }
  };

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<AttachmentDataType>();

    const defaultColumns = [
      columnHelper.accessor("fileName", {
        cell: (info) => info.getValue(),
        header: "File",
      }),
      columnHelper.accessor("description", {
        cell: (info) => info.getValue(),
        header: "Description",
      }),
      columnHelper.accessor("updatedAt", {
        cell: (info) => String(dateTimeFormat(new Date(info.getValue()))),
        header: "Attachment Date",
      }),
      columnHelper.display({
        id: "actions",
        header: "Actions",
        cell: (info) => (
          <div className="gap-3 hstack">
            <Button
              color="link"
              className={`rounded-circle p-0`}
              disabled={Boolean(mode || download)}
              onClick={() =>
                deletePatientAttachment({
                  uniqueId: info.row.original.uniqueId,
                })
              }
            >
              {attachments.isPending ? (
                <>
                  <Spinner size="sm">Deleting...</Spinner>
                </>
              ) : (
                <FontAwesomeIcon icon={faTrash} />
              )}
            </Button>
            {mode || download ? (
              <Button color="link" className={`rounded-circle p-0`} disabled>
                <FontAwesomeIcon icon={faDownload} />
              </Button>
            ) : (
              <a
                href={info.row.original.base64File}
                download={info.row.original.fileName}
                target="__blank"
              >
                <Button color="link" className={`rounded-circle p-0`}>
                  <FontAwesomeIcon icon={faDownload} />
                </Button>
              </a>
            )}
          </div>
        ),
      }),
    ];

    return defaultColumns;
  }, []);

  return (
    <>
      <div className="gap-3 mt-3 hstack align-items-baseline">
        <h5>Upload</h5>
        {download || mode ? (
          <Button color="primary" style={{ borderRadius: 40 }} disabled>
            <FontAwesomeIcon icon={faPlus} className="text-white" />
          </Button>
        ) : (
          <AddAttachment id={patientId} />
        )}
      </div>

      <Card className="p-2 mt-3">
        <TableComponent data={data} columns={columns} />
      </Card>
    </>
  );
};
