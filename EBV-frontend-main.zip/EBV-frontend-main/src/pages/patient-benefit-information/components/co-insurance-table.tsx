import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form, Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { CoInsurance } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import TextWithHighlight from "../../../components/text-with-highlight";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { TextField } from "./active-coverage-table";
import { insert, remove } from "ramda";
import { usePatientBenefitInformationContext } from "..";

export const coInsuranceSchema = z.object({
  serviceType: z.string().optional(),
  adaCode: z.string().optional(),
  planPeriod: z.string().optional(),
  network: z.string().optional(),
  coverageLevel: z.string().optional(),
  percent: z.string().optional(),
  amount: z.string().optional(),
});

export type CoInsuranceForm = z.infer<typeof coInsuranceSchema>;

export type CoInsuranceTableProps = {
  showLabel?: boolean;
};

export const CoInsuranceTable = (props: CoInsuranceTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setCoInsurance([
      ...(data.response?.coInsurance?.filter(
        (coInsurance) => !coInsurance?.code
      ) ?? []),
    ] as CoInsurance[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const networkFilters = searchParams.getAll("network");

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<CoInsurance>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("adaCode", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("planPeriod", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("network", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("coverageLevel", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("percent", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(
              info.getValue() ? `${info.getValue() as string}%` : ""
            )}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("amount", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <CoInsuranceForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                    }}
                  />

                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Co Insurance</h6>

                {editMode ? <CoInsuranceForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Co Insurance</h6>

                {editMode ? <CoInsuranceForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table
            data={context.coInsurance
              .filter((coInsurance) => !coInsurance?.code)
              .filter((coInsurance) =>
                networkFilters.length > 0 && coInsurance?.network
                  ? networkFilters.includes(coInsurance.network)
                  : true
              )}
            columns={columns}
            getRowCanExpand={(row) => (row.original.message ? true : false)}
            renderSubComponent={({ row }) => <div>{row.original.message}</div>}
          />
        </CardBody>
      </Card>
    </>
  );
};

export default CoInsuranceTable;

export type CoInsuranceFormProps = {
  defaultValues?: CoInsuranceForm;
  isEdit?: number;
};

export const CoInsuranceForm = ({
  defaultValues,
  isEdit,
}: CoInsuranceFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<CoInsuranceForm>({
    resolver: zodResolver(coInsuranceSchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<CoInsuranceForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newCoInsurance = insert(
          isEdit,
          data as CoInsurance,
          remove(isEdit, 1, context.coInsurance)
        );

        context.setCoInsurance(() => newCoInsurance);
        toast.success("Co Insurance updated successfully");
        return;
      }

      context.setCoInsurance(() => [
        ...context.coInsurance,
        data as CoInsurance,
      ]);

      toast.success("Co Insurance added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} Co Insurance
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="adaCode" />
                <TextField fieldKey="planPeriod" />
                <TextField fieldKey="network" />
                <TextField fieldKey="coverageLevel" />
                <TextField fieldKey="percent" />
                <TextField fieldKey="amount" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    try {
      context.setCoInsurance(() => remove(index, 1, context.coInsurance));

      toast.success("Co Insurance deleted successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
