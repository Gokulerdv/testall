/* eslint-disable @typescript-eslint/no-explicit-any */
import { Card, CardBody, Row, Col, Badge } from "reactstrap";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { Location, useLocation, useMatch } from "react-router-dom";
import textWithDefault from "../../../utils/text-with-default";
import TextWithHighlight from "../../../components/text-with-highlight";
import { dateFormat } from "../../../utils/date-format";
import { getRelativeTime } from "../../../utils/get-relative-time";
export const Insights = () => {
  const reportPage = useMatch(
    "eligibility/patient-benefit-information/:id/report"
  );

  return reportPage ? <InsightsCards /> : <InsightsCards />;
};

export const InsightsCard = () => {
  const { state } = useLocation() as Location<TempEligibilityData>;
  const data = state.actualResponseData.dentalXchangeResponse;

  return (
    <Card className="bg-info-subtle mt-3">
      <CardBody>
        <Row className="g-3">
          <Col>
            <div className="vstack h-100">
              <h6 className="text-center">Dental Coverage</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <Badge
                  className={`border-1 ${
                    data?.status?.code === 0
                      ? "bg-success-subtle border-success text-success"
                      : "bg-danger-subtle border-danger text-danger"
                  }`}
                  style={{ border: "1px solid" }}
                  pill
                >
                  {data?.status?.code === 0 ? "Active" : "Inactive"}
                </Badge>
              </div>
            </div>
          </Col>

          <Col>
            <div className="vstack h-100">
              <h6 className="text-center">Remaining Benefits</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <h5 className="fw-semibold">
                  <TextWithHighlight>
                    {textWithDefault("$800")}
                  </TextWithHighlight>
                  <h6 className="d-inline text-secondary">
                    <TextWithHighlight>
                      {textWithDefault("/$800")}
                    </TextWithHighlight>
                  </h6>
                </h5>
              </div>
            </div>
          </Col>

          <Col>
            <div className="vstack h-100">
              <h6 className="text-center">Last Verified</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <p className="mb-0">
                  <TextWithHighlight>
                    {textWithDefault("01/03/23")}
                  </TextWithHighlight>
                </p>
                <p className="fw-light text-secondary mb-0">
                  {" "}
                  <TextWithHighlight>
                    {textWithDefault("26 days ago")}
                  </TextWithHighlight>
                </p>
              </div>
            </div>
          </Col>

          <Col>
            <div className="vstack h-100">
              <h6 className="text-center">Deductible Remaining</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <h5 className="fw-semibold">
                  <TextWithHighlight>
                    {textWithDefault("$800")}
                  </TextWithHighlight>
                  <h6 className="d-inline text-secondary">
                    <TextWithHighlight>
                      {textWithDefault("$800")}
                    </TextWithHighlight>
                  </h6>
                </h5>
              </div>
            </div>
          </Col>
        </Row>
      </CardBody>
    </Card>
  );
};

export const InsightsCards = () => {
  const { state } = useLocation() as Location<TempEligibilityData>;
  const data = state.actualResponseData.dentalXchangeResponse;

  return (
    <Row lg={2} className="g-3">
      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Dental Coverage</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <Badge
                  className={`border-1 ${
                    data?.response?.subscriber?.plan?.effectiveDateFrom
                      ? "bg-success-subtle border-success text-success"
                      : "bg-danger-subtle border-danger text-danger"
                  }`}
                  style={{ border: "1px solid" }}
                  pill
                >
                  <TextWithHighlight>
                    {textWithDefault(
                      data?.response?.subscriber?.plan?.effectiveDateFrom
                        ? "Active"
                        : "Inactive"
                    )}
                  </TextWithHighlight>
                </Badge>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Remaining Benefits</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <h5 className="fw-semibold">
                  <TextWithHighlight>
                    {textWithDefault("$800")}
                  </TextWithHighlight>
                  <h6 className="d-inline text-secondary">
                    {" "}
                    <TextWithHighlight>
                      {textWithDefault("/$800")}
                    </TextWithHighlight>
                  </h6>
                </h5>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Last Verified</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <p className="mb-0">
                  <TextWithHighlight>
                    {textWithDefault(
                      (
                        state?.actualResponseData?.dentalXchangeResponse
                          .response as any
                      )?.lastverified
                        ? dateFormat(
                            new Date(
                              (
                                state?.actualResponseData?.dentalXchangeResponse
                                  .response as any
                              )?.lastverified
                            )
                          )
                        : undefined
                    )}
                  </TextWithHighlight>
                </p>
                <p className="fw-light text-secondary mb-0">
                  <TextWithHighlight>
                    {textWithDefault(
                      (
                        state?.actualResponseData?.dentalXchangeResponse
                          .response as any
                      )?.lastverified
                        ? getRelativeTime(
                            new Date(
                              (
                                state?.actualResponseData?.dentalXchangeResponse
                                  .response as any
                              )?.lastverified
                            ).getTime()
                          )
                        : undefined
                    )}
                  </TextWithHighlight>
                </p>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      <Col xs={6}>
        <Card style={{ height: "6.625rem" }}>
          <CardBody>
            <div className="vstack h-100">
              <h6 className="text-center">Deductible Remaining</h6>
              <div className="vstack justify-content-center align-items-center h-100">
                <h5 className="fw-semibold">
                  <TextWithHighlight>
                    {textWithDefault("$800")}
                  </TextWithHighlight>
                  <h6 className="d-inline text-secondary">
                    <TextWithHighlight>
                      {textWithDefault("/$800")}
                    </TextWithHighlight>
                  </h6>
                </h5>
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>
    </Row>
  );
};

export default Insights;
