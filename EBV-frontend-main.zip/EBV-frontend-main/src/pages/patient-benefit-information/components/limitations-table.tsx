/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form, Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { LimitationAndMaximum } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import TextWithHighlight from "../../../components/text-with-highlight";
import { currencyFormat } from "../../../utils/currency-format";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import { TextField } from "./active-coverage-table";
import { usePatientBenefitInformationContext } from "..";
import { insert, remove } from "ramda";

export const limitationsSchema = z.object({
  serviceType: z.string().optional(),
  adaCode: z.string().optional(),
  network: z.string().optional(),
  coverageLevel: z.string().optional(),
  planPeriod: z.string().optional(),
  amount: z.string().optional(),
  auth: z.string().optional(),
});

export type LimitationsForm = z.infer<typeof limitationsSchema>;

export type LimitationsTableProps = {
  showLabel?: boolean;
};

export const LimitationsTable = (props: LimitationsTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setLimitations(
      ((data.response as any)?.limitations as LimitationAndMaximum[]) ??
        ([
          ...(data.response?.limitationAndMaximum ?? []),
        ] as LimitationAndMaximum[])
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const networkFilters = searchParams.getAll("network");

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<LimitationAndMaximum>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("adaCode", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("network", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("coverageLevel", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("planPeriod", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("amount", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(currencyFormat(parseFloat(info.getValue())))}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("auth", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <LimitationForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                    }}
                  />

                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Limitation</h6>

                {editMode ? <LimitationForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Limitation</h6>

                {editMode ? <LimitationForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table
            data={context.limitations.filter((limitation) =>
              networkFilters.length > 0 && limitation?.network
                ? networkFilters.includes(limitation.network)
                : true
            )}
            columns={columns}
            getRowCanExpand={(row) => (row.original.message ? true : false)}
            renderSubComponent={({ row }) => (
              <div>{row.original.message as string}</div>
            )}
          />
        </CardBody>
      </Card>
    </>
  );
};

export default LimitationsTable;

export type LimitationsFormProps = {
  defaultValues?: LimitationsForm;
  isEdit?: number;
};

export const LimitationForm = ({
  defaultValues,
  isEdit,
}: LimitationsFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<LimitationsForm>({
    resolver: zodResolver(limitationsSchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<LimitationsForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newLimitations = insert(
          isEdit,
          data as LimitationAndMaximum,
          remove(isEdit, 1, context.deductible)
        );

        context.setLimitations(() => newLimitations);
        toast.success("Limitation updated successfully");
        return;
      }

      context.setLimitations(() => [
        ...context.limitations,
        data as LimitationAndMaximum,
      ]);

      toast.success("Limitation added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} Limitation
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="adaCode" />
                <TextField fieldKey="network" />
                <TextField fieldKey="coverageLevel" />
                <TextField fieldKey="planPeriod" />
                <TextField fieldKey="amount" />
                <TextField fieldKey="auth" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    try {
      context.setLimitations(() => remove(index, 1, context.limitations));

      toast.success("Limitation deleted successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
