import { Location, useLocation, useSearchParams } from "react-router-dom";
import { Button, Card, CardBody, Col, Row } from "reactstrap";
import React from "react";
import { z } from "zod";
import {
  Controller,
  FormProvider,
  SubmitHandler,
  useForm,
  useFormContext,
} from "react-hook-form";
import {
  Form,
  FormGroup,
  Input,
  FormFeedback,
  FormText,
  InputProps,
} from "reactstrap";
import { capitalCase } from "change-case";
import { zodResolver } from "@hookform/resolvers/zod";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { Patient } from "../../eligibility/apis/patients-all";
import { toast } from "react-toastify";
import { usePatientBenefitInformationContext } from "..";

export const key = "notesAndRemarks";

export const notesAndRemarksSchema = z.object({
  [key]: z
    .string({ required_error: `${capitalCase(key)} is required.` })
    .optional(),
});

export type NotesAndRemarksSchema = z.infer<typeof notesAndRemarksSchema>;

export type NotesAndRemarksFieldProps = InputProps & {
  help?: React.ReactNode;
};

export const NotesAndRemarksField = (props: NotesAndRemarksFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormGroup>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="textarea"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            />
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};

export default NotesAndRemarksField;

export const notesAndRemarksStorageKeyPrefix = "pbi-notes-and-remarks-";

export const NotesAndRemarks = () => {
  const context = usePatientBenefitInformationContext();

  const { state } = useLocation() as Location<
    TempEligibilityData & { row: Patient }
  >;

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setNotesAndRemarks(data.response?.notesAndRemarks ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode");

  const methods = useForm<NotesAndRemarksSchema>({
    resolver: zodResolver(notesAndRemarksSchema),
    defaultValues: {
      notesAndRemarks: context.notesAndRemarks,
    },
  });

  const onSubmit: SubmitHandler<NotesAndRemarksSchema> = (data) => {
    try {
      context.setNotesAndRemarks(data["notesAndRemarks"] ?? "");

      toast.success("Notes and remarks saved successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {editMode ? (
            <FormProvider {...methods}>
              <Form onSubmit={methods.handleSubmit(onSubmit)}>
                <Row>
                  <Col xs={12} lg={6}>
                    <h5 className="mb-3">Notes & Remarks</h5>
                    <p className="text-secondary">Notes</p>
                    <NotesAndRemarksField />
                  </Col>

                  <Col xs={12} lg={6}>
                    <div className="hstack gap-2 justify-content-end">
                      <Button
                        outline
                        color="primary"
                        onClick={() => methods.reset()}
                      >
                        Cancel
                      </Button>

                      <Button
                        color="primary"
                        className="text-white"
                        onClick={methods.handleSubmit(onSubmit)}
                      >
                        Save
                      </Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </FormProvider>
          ) : (
            <>
              <h5 className="mb-3">Notes & Remarks</h5>
              <p className="text-secondary">Notes</p>
              <div className="text-secondary">
                {context.notesAndRemarks ?? "Add you notes and remarks here..."}
              </div>
            </>
          )}
        </CardBody>
      </Card>
    </>
  );
};
