import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Form,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { usePatientBenefitInformationContext } from "..";
import { BenefitsHistory } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import TextWithHighlight from "../../../components/text-with-highlight";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { TextField } from "./active-coverage-table";
import { insert, remove } from "ramda";

export const benefitsHistorySchema = z.object({
  serviceType: z.string().optional(),
  doses: z.string().optional(),
  provider: z.string().optional(),
  procedure: z.string().optional(),
  benefitsConsumed: z.string().optional(),
});

export type BenefitsHistoryTableProps = {
  showLabel?: boolean;
};

export type BenefitsHistoryForm = z.infer<typeof benefitsHistorySchema>;

export const BenefitsHistoryTable = (props: BenefitsHistoryTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setBenefitsHistory([
      ...(data.response?.benefitsHistory ?? []),
    ] as BenefitsHistory[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<BenefitsHistory>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("doses", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("provider", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("procedure", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("benefitsConsumed", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <BenefitsHistoryForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                    }}
                  />

                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Benefits History</h6>

                {editMode ? <BenefitsHistoryForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Benefits History</h6>

                {editMode ? <BenefitsHistoryForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table data={context.benefitsHistory} columns={columns} />
        </CardBody>
      </Card>
    </>
  );
};

export default BenefitsHistoryTable;

export type BenefitsHistoryFormProps = {
  defaultValues?: BenefitsHistoryForm;
  isEdit?: number;
};

export const BenefitsHistoryForm = ({
  defaultValues,
  isEdit,
}: BenefitsHistoryFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<BenefitsHistoryForm>({
    resolver: zodResolver(benefitsHistorySchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<BenefitsHistoryForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newBenefitsHistory = insert(
          isEdit,
          data as BenefitsHistory,
          remove(isEdit, 1, context.benefitsHistory)
        );

        context.setBenefitsHistory(() => newBenefitsHistory);
        toast.success("Benefits History updated successfully");
        return;
      }

      context.setBenefitsHistory(() => [
        ...context.benefitsHistory,
        data as BenefitsHistory,
      ]);

      toast.success("Benefits History added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} Benefits History
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="doses" />
                <TextField fieldKey="provider" />
                <TextField fieldKey="procedure" />
                <TextField fieldKey="benefitsConsumed" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();
  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    try {
      context.setBenefitsHistory(() =>
        remove(index, 1, context.benefitsHistory)
      );

      toast.success("Benefits History deleted successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
