/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form, Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { AdaProcedure, CoInsurance } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import TextWithHighlight from "../../../components/text-with-highlight";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import { TextField } from "./active-coverage-table";
import { usePatientBenefitInformationContext } from "..";
import { insert, remove } from "ramda";

export const adaProcedureSchema = z.object({
  serviceType: z.string().optional(),
  code: z.string().optional(),
  network: z.string().optional(),
  coverageLevel: z.string().optional(),
  percent: z.string().optional(),
  authorizationRequired: z.string().optional(),
  frequency: z.string().optional(),
  ageLimit: z.string().optional(),
});

export type AdaProcedureForm = z.infer<typeof adaProcedureSchema>;

export type AdaProcedureTableProps = {
  showLabel?: boolean;
};

export const AdaProcedureTable = (props: AdaProcedureTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setAdaProcedure(
      () =>
        ((data.response as any)?.adaProcedure as CoInsurance[]) ??
        ([
          ...(data.response?.coInsurance?.filter(
            (coInsurance) => coInsurance?.code
          ) ?? []),
        ] as CoInsurance[])
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const networkFilters = searchParams.getAll("network");
  const adaCodeFilter = searchParams.get("adaCode");

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<AdaProcedure>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("code", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("network", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("coverageLevel", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("percent", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(`${info.getValue() as string}%`)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("authorizationRequired", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("frequency", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("ageLimit", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <AdaProcedureForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                    }}
                  />

                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>ADA Procedure</h6>

                {editMode ? <AdaProcedureForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>ADA Procedure</h6>

                {editMode ? <AdaProcedureForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table
            data={context.adaProcedure
              .filter((coInsurance) => coInsurance?.code)
              .filter((coInsurance) =>
                adaCodeFilter === "true" && coInsurance?.code
                  ? state.row.procedureCode.includes(coInsurance?.code)
                  : true
              )
              .filter((coInsurance) =>
                networkFilters.length > 0 && coInsurance?.network
                  ? networkFilters.includes(coInsurance.network)
                  : true
              )}
            columns={columns}
            getRowCanExpand={(row) => (row.original.message ? true : false)}
            renderSubComponent={({ row }) => <div>{row.original.message}</div>}
          />
        </CardBody>
      </Card>
    </>
  );
};

export default AdaProcedureTable;

export type AdaProcedureFormProps = {
  defaultValues?: AdaProcedureForm;
  isEdit?: number;
};

export const AdaProcedureForm = ({
  defaultValues,
  isEdit,
}: AdaProcedureFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<AdaProcedureForm>({
    resolver: zodResolver(adaProcedureSchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<AdaProcedureForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newAdaProcedure = insert(
          isEdit,
          data as CoInsurance,
          remove(isEdit, 1, context.adaProcedure)
        );

        context.setAdaProcedure(() => newAdaProcedure);
        toast.success("ADA Procedure updated successfully");
        return;
      }

      context.setAdaProcedure(() => [
        ...context.adaProcedure,
        data as CoInsurance,
      ]);

      toast.success("ADA Procedure added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} ADA Procedure
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="code" />
                <TextField fieldKey="network" />
                <TextField fieldKey="coverageLevel" />
                <TextField fieldKey="percent" />
                <TextField fieldKey="authorizationRequired" />
                <TextField fieldKey="frequency" />
                <TextField fieldKey="ageLimit" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    try {
      context.setAdaProcedure(() => remove(index, 1, context.adaProcedure));

      toast.success("ADA procedure deleted successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
