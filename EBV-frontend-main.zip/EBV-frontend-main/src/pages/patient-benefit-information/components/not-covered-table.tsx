import {
  faPenToSquare,
  faPlus,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { zodResolver } from "@hookform/resolvers/zod";
import { createColumnHelper } from "@tanstack/react-table";
import { capitalCase } from "change-case";
import React from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";
import { Form, Location, useLocation, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  Button,
  Card,
  CardBody,
  CardTitle,
  Modal,
  ModalBody,
  ModalHeader,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
} from "reactstrap";
import { z } from "zod";
import { NotCovered } from "../../../apis/mocks/patients/data";
import Table from "../../../components/table";
import TextWithHighlight from "../../../components/text-with-highlight";
import { useDialogWithFormReset } from "../../../shared/hooks/use-dialog-with-form-reset";
import textWithDefault from "../../../utils/text-with-default";
import { TempEligibilityData } from "../../eligibility/table/columns";
import { TextField } from "./active-coverage-table";
import { usePatientBenefitInformationContext } from "..";
import { insert, remove } from "ramda";

export const notCoveredSchema = z.object({
  serviceType: z.string().optional(),
  network: z.string().optional(),
  coverageLevel: z.string().optional(),
});

export type NotCoveredForm = z.infer<typeof notCoveredSchema>;

export type NotCoveredTableProps = {
  showLabel?: boolean;
};

export const NotCoveredTable = (props: NotCoveredTableProps) => {
  const { state } = useLocation() as Location<TempEligibilityData>;

  const context = usePatientBenefitInformationContext();

  const data = state.actualResponseData.dentalXchangeResponse;

  React.useEffect(() => {
    context.setNotCovered([
      ...(data.response?.notCovered ?? []),
    ] as NotCovered[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [searchParams] = useSearchParams();

  const editMode = searchParams.get("editMode") ?? "";

  const networkFilters = searchParams.getAll("network");

  const columns = React.useMemo(() => {
    const columnHelper = createColumnHelper<NotCovered>();

    const staticColumns = [
      columnHelper.accessor("serviceType", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("network", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
      columnHelper.accessor("coverageLevel", {
        cell: (info) => (
          <TextWithHighlight>
            {textWithDefault(info.getValue() as string)}
          </TextWithHighlight>
        ),
        header: (props) => capitalCase(props.column.id),
      }),
    ];

    const defaultColumns =
      editMode !== ""
        ? [
            ...staticColumns,
            columnHelper.display({
              id: "actions",
              header: "Actions",
              cell: (info) => (
                <div className="hstack gap-3">
                  <NotCoveredForm
                    isEdit={info.row.index}
                    defaultValues={{
                      ...info.row.original,
                    }}
                  />
                  <DeleteModal index={info.row.index} />
                </div>
              ),
            }),
          ]
        : staticColumns;

    return defaultColumns;
  }, [editMode]);

  return (
    <>
      <Card className="mt-3">
        <CardBody>
          {props.showLabel ? (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Not Covered</h6>

                {editMode ? <NotCoveredForm /> : null}
              </div>
            </CardTitle>
          ) : (
            <CardTitle tag="h6">
              <div className="hstack justify-content-between align-items-center">
                <h6>Not Covered</h6>

                {editMode ? <NotCoveredForm /> : null}
              </div>
            </CardTitle>
          )}

          <Table
            data={context.notCovered.filter((notCovered) =>
              networkFilters.length > 0 && notCovered?.network
                ? networkFilters.includes(notCovered.network)
                : true
            )}
            columns={columns}
            getRowCanExpand={(row) => (row.original.message ? true : false)}
            renderSubComponent={({ row }) => (
              <div>{row.original.message as string}</div>
            )}
          />
        </CardBody>
      </Card>
    </>
  );
};

export default NotCoveredTable;

export type NotCoveredFormProps = {
  defaultValues?: NotCoveredForm;
  isEdit?: number;
};

export const NotCoveredForm = ({
  defaultValues,
  isEdit,
}: NotCoveredFormProps) => {
  const context = usePatientBenefitInformationContext();

  const methods = useForm<NotCoveredForm>({
    resolver: zodResolver(notCoveredSchema),
    defaultValues,
  });

  const { open, toggle } = useDialogWithFormReset(methods);

  const onSubmit: SubmitHandler<NotCoveredForm> = async (data) => {
    try {
      if (isEdit !== undefined) {
        const newNotCovered = insert(
          isEdit,
          data as NotCovered,
          remove(isEdit, 1, context.notCovered)
        );

        context.setNotCovered(() => newNotCovered);
        toast.success("Not Covered updated successfully");
        return;
      }

      context.setNotCovered(() => [...context.notCovered, data as NotCovered]);

      toast.success("Not Covered added successfully");
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    } finally {
      toggle();
    }
  };

  return (
    <div>
      {isEdit !== undefined ? (
        <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
          <FontAwesomeIcon icon={faPenToSquare} />
        </Button>
      ) : (
        <Button outline size="sm" color="primary" onClick={toggle}>
          <FontAwesomeIcon icon={faPlus} />
        </Button>
      )}

      <Offcanvas
        isOpen={open}
        toggle={toggle}
        direction="end"
        style={{ width: "50%" }}
      >
        <OffcanvasHeader toggle={toggle} className="bg-body-tertiary">
          {isEdit !== undefined ? "Edit" : "Add"} Not Covered
        </OffcanvasHeader>

        <OffcanvasBody>
          <FormProvider {...methods}>
            <Form onSubmit={methods.handleSubmit(onSubmit, console.error)}>
              <div className="vstack">
                <TextField fieldKey="serviceType" />
                <TextField fieldKey="network" />
                <TextField fieldKey="coverageLevel" />

                <div className="hstack gap-2 ms-auto">
                  <Button outline color="primary" onClick={toggle}>
                    Cancel
                  </Button>
                  <Button color="primary" className="text-white" type="submit">
                    Save
                  </Button>
                </div>
              </div>
            </Form>
          </FormProvider>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
};

export type DeleteModalProps = {
  index: number;
};

export const DeleteModal = ({ index }: DeleteModalProps) => {
  const context = usePatientBenefitInformationContext();

  const [open, setOpen] = React.useState(false);

  const toggle = () => setOpen(!open);

  const deleteRow = async () => {
    context.setNotCovered(() => remove(index, 1, context.notCovered));

    try {
      toast.success("Not covered deleted successfully");
      toggle();
    } catch (error) {
      toast.error("An error occurred!");
      console.log(error);
    }
  };

  return (
    <>
      <Button color="link" className={`rounded-circle p-0`} onClick={toggle}>
        <FontAwesomeIcon icon={faTrash} />
      </Button>

      <Modal isOpen={open} toggle={toggle} backdrop keyboard size="lg">
        <ModalHeader toggle={toggle} className="bg-primary text-white">
          Delete
        </ModalHeader>
        <ModalBody className="m-auto">
          <p>Are you sure want to delete the details?</p>

          <div className="hstack gap-4 justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button color="primary" className="text-white" onClick={deleteRow}>
              Yes
            </Button>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};
