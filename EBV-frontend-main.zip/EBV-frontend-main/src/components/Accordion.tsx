import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCaretDown, faCaretUp } from "@fortawesome/free-solid-svg-icons";

interface AccordionProps {
  title: string;
  children: React.ReactNode;
  heading?: string;
  editphase?: string;
}

export const Accordion: React.FC<AccordionProps> = (props) => {
  const { title, heading, editphase } = props;
  const [isOpen, setIsOpen] = useState<boolean>(false);

  useEffect(() => {
    if (editphase) {
      setIsOpen(true);
    }
  }, []);
  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };
  return (
    <div className="accordion mt-3">
      <div
        className="accordion-header d-flex justify-content-between cursor-pointer"
        onClick={toggleAccordion}
      >
        <div className="accordion-title bold-2">
          <div>
            <span className="grey-color bold-1">{heading}</span>
          </div>
          <div>
            <span className="dark-blue-txt">{title}</span>
          </div>
        </div>
        <div className="accordion-icon">
          {isOpen ? (
            <FontAwesomeIcon icon={faCaretUp} color="#A1ACC0" />
          ) : (
            <FontAwesomeIcon icon={faCaretDown} color="#A1ACC0" />
          )}
        </div>
      </div>
      {isOpen ? (
        <div className="accordion-content">{props.children}</div>
      ) : null}
    </div>
  );
};
