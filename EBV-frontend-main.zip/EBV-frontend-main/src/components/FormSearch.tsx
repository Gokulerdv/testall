import React from "react";
// import Button from "./Button";

interface FormSearchProps {
  onSearch: (query: string) => void;
}

const FormSearch: React.FC<FormSearchProps> = (props) => {
  const { onSearch } = props;
  //   const [query, setQuery] = useState<string>("");
  //   const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  //     setQuery(e.target.value);
  //   };

  const handleSearch = (query: string) => {
    onSearch(query);
  };
  return (
    <React.Fragment>
      <div className="search-input-wrapper">
        <input
          type="text"
          //   value={query}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Search"
          className="default-style"
        />
      </div>
    </React.Fragment>
  );
};

export default FormSearch;
