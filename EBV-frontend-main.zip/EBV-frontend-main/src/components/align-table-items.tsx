export type AlignItemsProps = {
  children: React.ReactNode;
};
export const AlignTableItems = (props: AlignItemsProps) => {
  const { children } = props;
  return (
    <>
      <div
        style={{
          height: 60,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        {children}
      </div>
    </>
  );
};
export default AlignTableItems;
