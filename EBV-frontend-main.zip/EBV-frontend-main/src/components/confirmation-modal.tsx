/* eslint-disable @typescript-eslint/no-explicit-any */
import { faClose } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Dialog, DialogContent, DialogTitle, IconButton } from "@mui/material";
import React from "react";
import { Button } from "reactstrap";

export type DeleteModalProps = {
  onClick: any;
  value: string;
};

export const ConfirmationModal = (props: DeleteModalProps) => {
  const { onClick, value } = props;

  const [open, setOpen] = React.useState(false);
  const [disable, setDisable] = React.useState(false);
  const toggle = () => setOpen(!open);
  const handleConfirmation = () => {
    setDisable(true);

    onClick();
    toggle();
  };
  React.useEffect(() => {
    if (disable === true) {
      setTimeout(() => {
        setDisable(false);
      }, 3000);
    }
  }, [disable]);
  return (
    <>
      <Button color="primary" className="text-white" onClick={toggle}>
        {value}
      </Button>

      <Dialog open={open} onClose={toggle} maxWidth="md">
        <DialogTitle className="text-white bg-primary">
          Confirmation
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={toggle}
          sx={{
            position: "absolute",
            right: 10,
            top: 10,
          }}
          className="text-white"
        >
          <FontAwesomeIcon icon={faClose} />
        </IconButton>
        <DialogContent className="m-auto" style={{ width: "35rem" }}>
          <p style={{ textAlign: "center" }}>
            Are you sure want to confirm the details?
          </p>

          <div className="gap-4 hstack justify-content-center">
            <Button outline color="secondary" onClick={toggle}>
              No
            </Button>
            <Button
              color="primary"
              onClick={handleConfirmation}
              disabled={disable}
            >
              <span>Yes</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ConfirmationModal;
