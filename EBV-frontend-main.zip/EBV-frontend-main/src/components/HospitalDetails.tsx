

const HospitalDetails = ({
  data,
}: {
  data?: {
    practiceLogo: string | undefined;
    practiceName: string;
    practiceId: string;
  };
}) => {

  ;
  return (
    <>
      <div className="htpl-details-wrapper d-flex align-items-center">
        <div className="htpl-details d-flex gap-2 pe-3 me-3">
          <div className="hspt-img">
            {" "}
            <img
              // src={practiceDetail?.practiceLogo}
              style={{ width: "80px", height: "80px" }}
            />
          </div>
          <div>
            <h5 className="m-0 txt-blue">
              {data ? data.practiceName : "Apollo Dental Hospital"}
            </h5>

            <p className="mb-0 mt-1">
              <span className="grey-color fts-3">ID</span>{" "}
              <span className="fts-3 txt-blue">
                {data ? data.practiceId : "1234"}
              </span>
            </p>
          </div>
        </div>
      </div>
    </>
  );
};
export default HospitalDetails;
