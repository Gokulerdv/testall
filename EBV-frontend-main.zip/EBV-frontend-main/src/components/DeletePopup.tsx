import React from 'react'
import { Modal, ModalBody } from 'reactstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faClose } from '@fortawesome/free-solid-svg-icons'

import Button from './Button'

interface DeletePopupInterface {
  isOpen: boolean
  toggle: () => void
  proceedFunction: () => void
  name:string | undefined
}

const DeletePopup = (props: DeletePopupInterface) => {
  const { isOpen, toggle, proceedFunction,name } = props
  return (
    <React.Fragment>
      <Modal isOpen={isOpen} centered style={{ overflow: 'hidden' }}>
        <div className='alert-header d-flex justify-content-between p-2 align-items-center'>
            <span className='fw-bold'>Delete</span>
            <Button onClick={toggle} btntype='transparent' className='close-btn'>
              <FontAwesomeIcon icon={faClose} color='white' className='fts-3'/>
            </Button>
        </div>
        <ModalBody>
            <div className='d-flex justify-content-center flex-column align-items-center'>
                <p className='text-center fw-normal mb-4'>Are you sure want to delete this location {name} ?</p>
                <div>
                    <Button btntype='outlined' className='me-2' onClick={toggle}>No</Button>
                    <Button btntype='filled' onClick={proceedFunction}>Yes</Button>
                </div>
            </div>
        </ModalBody>
      </Modal>
    </React.Fragment>
  )
}

export default DeletePopup