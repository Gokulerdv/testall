import { capitalCase } from "change-case";
import { Controller, useFormContext } from "react-hook-form";
import {
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  InputProps,
  Label,
} from "reactstrap";

export type FieldProps = InputProps & {
  help?: React.ReactNode;
  name: string;
  data: { key: string; value: string }[];
};

export const DropdownField = (props: FieldProps) => {
  const { control } = useFormContext();
  const key = props.name;

  return (
    <FormGroup>
      <Label for={key}>
        {props.required ? <span className="text-danger">*&nbsp;</span> : null}
        {capitalCase(key)}
      </Label>
      <Controller
        name={key}
        control={control}
        render={({ field, fieldState }) => (
          <>
            <Input
              {...field}
              id={key}
              type="select"
              invalid={Boolean(fieldState.error?.message)}
              {...props}
            >
              <option value="">Select Option</option>
              {props?.data?.map((element: { key: string; value: string }) => (
                <option value={element?.value} key={element?.key}>
                  {element?.value}
                </option>
              ))}
            </Input>
            {fieldState.error?.message ? (
              <FormFeedback>{fieldState.error.message}</FormFeedback>
            ) : null}
            {props.help ? <FormText>{props.help}</FormText> : null}
          </>
        )}
      />
    </FormGroup>
  );
};
