import React from "react";
import { Button } from "reactstrap";

interface PageHeaderProps {
  title: string;
  type?: "heading" | "subheading";
  btnTxt?: string;
  btnClick?: () => void;
  btnTxt2?: string;
  btnClick2?: () => void;
}

const PageHeader: React.FC<PageHeaderProps> = (props) => {
  const {
    title,
    type = "heading",
    btnTxt = null,
    btnClick,
    btnTxt2 = null,
    btnClick2,
  } = props;
  return (
    <React.Fragment>
      <div
        className={
          "page-header " + (type === "heading" ? "page-header-bg" : "")
        }
      >
        <span className="mb-0">{title}</span>
        <div>
          {btnTxt ? (
            <Button btntype="" onClick={btnClick} className="me-2 outlined">
              {btnTxt}
            </Button>
          ) : null}
          {btnTxt2 ? (
            <Button className="filled" onClick={btnClick2}>
              {btnTxt2}
            </Button>
          ) : null}
        </div>
      </div>
    </React.Fragment>
  );
};

export default PageHeader;
