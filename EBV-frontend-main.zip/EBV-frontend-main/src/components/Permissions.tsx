import React from 'react';
import { Badge, Modal, Button } from 'react-bootstrap';

interface PermissionsCellProps {
    permissions: string[];
    showModal: boolean;
    handleCloseModal: () => void;
}

const PermissionsCell: React.FC<PermissionsCellProps> = ({ permissions, showModal, handleCloseModal }) => {


    return (
        <div className='modl-badge'>


            <Modal show={showModal} onHide={handleCloseModal} centered>
                <Modal.Header
                    closeButton
                    closeVariant="white"
                    style={{ backgroundColor: '#3ba2ed', borderBottom: 'none', height: '50px' }}
                >
                    <Modal.Title style={{ color: 'white' }}>Permissions</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ maxHeight: '350px', overflowY: 'auto', padding: '20px' }} className='modl-badge'>
                    {permissions.map((permission, index) => (
                        <Badge key={index} style={{ margin: '5px', color: "black" }}>
                            {permission}
                        </Badge>
                    ))}
                </Modal.Body>
                <Modal.Footer style={{ justifyContent: 'center', borderTop: 'none' }}>
                    <Button
                        variant="secondary"
                        onClick={handleCloseModal}
                        style={{ backgroundColor: '#3ba2ed', borderColor: '#3ba2ed' }}
                    >
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default PermissionsCell;
