import { faCaretDown, faCaretRight } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  CellContext,
  ColumnDef,
  Row,
  RowData,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import React from "react";
import { Button } from "reactstrap";

export type TableProps<TData> = {
  data: TData[];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  columns: ColumnDef<TData, any>[];
  renderSubComponent?: (props: { row: Row<TData> }) => React.ReactElement;
  getRowCanExpand?: (row: Row<TData>) => boolean;
};

export const Table = <TData extends RowData>({
  columns,
  data,
  renderSubComponent,
  getRowCanExpand,
}: TableProps<TData>) => {
  const processedColumns = React.useMemo(() => {
    return [
      ...(getRowCanExpand && renderSubComponent
        ? [
            {
              id: "expander",
              header: () => null,
              cell: ({ row }: CellContext<TData, unknown>) => {
                return row.getCanExpand() ? (
                  <Button
                    color="link"
                    className="p-0 text-black"
                    {...{
                      onClick: row.getToggleExpandedHandler(),
                      style: {
                        cursor: "pointer",
                      },
                    }}
                  >
                    {row.getIsExpanded() ? (
                      <FontAwesomeIcon icon={faCaretDown} />
                    ) : (
                      <FontAwesomeIcon icon={faCaretRight} />
                    )}
                  </Button>
                ) : null;
              },
            },
          ]
        : []),
      ...columns,
    ];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columns]);

  const table = useReactTable({
    columns: processedColumns,
    data,
    getRowCanExpand,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
  });

  return (
    <table className="table table-hover mb-0">
      <thead>
        {table.getHeaderGroups().map((headerGroup) => (
          <tr key={headerGroup.id}>
            {headerGroup.headers.map((header) => (
              <th
                key={header.id}
                colSpan={header.colSpan}
                className="border-bottom"
              >
                {header.isPlaceholder ? null : (
                  <div
                    {...{
                      className: "hstack align-items-center",
                      style: header.column.getCanSort()
                        ? {
                            cursor: "pointer",
                            userSelect: "none",
                          }
                        : undefined,
                      onClick: header.column.getToggleSortingHandler(),
                    }}
                  >
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </div>
                )}
              </th>
            ))}
          </tr>
        ))}
      </thead>

      <tbody>
        {table.getRowModel().rows.map((row) => (
          <React.Fragment key={row.id}>
            <tr>
              {row.getVisibleCells().map((cell) => (
                <td key={cell.id}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>

            {renderSubComponent && row.getIsExpanded() ? (
              <tr>
                {/* 2nd row is a custom 1 cell row */}
                <td colSpan={row.getVisibleCells().length}>
                  {renderSubComponent({ row })}
                </td>
              </tr>
            ) : null}
          </React.Fragment>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
