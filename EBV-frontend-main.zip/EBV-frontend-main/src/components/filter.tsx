/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  faCalendarDays,
  faClose,
  faFile,
  faFileExcel,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Column, RowData, Table } from "@tanstack/react-table";
import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Badge,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
} from "reactstrap";
import { dateStringFormat } from "../utils/date-string-format";

type NumberInputProps = {
  columnFilterValue: [number, number];
  getFacetedMinMaxValues: () => [number, number] | undefined;
  setFilterValue: (updater: any) => void;
};

const NumberInput: React.FC<NumberInputProps> = ({
  columnFilterValue,
  getFacetedMinMaxValues,
  setFilterValue,
}) => {
  const minOpt = getFacetedMinMaxValues()?.[0];
  const min = Number(minOpt ?? "");

  const maxOpt = getFacetedMinMaxValues()?.[1];
  const max = Number(maxOpt);

  return (
    <div>
      <div className="d-flex gx-2">
        <Input
          type="number"
          min={min}
          max={max}
          value={columnFilterValue?.[0] ?? ""}
          onChange={(e) =>
            setFilterValue((old: [number, number]) => [
              e.target.value,
              old?.[1],
            ])
          }
          placeholder={`Min ${minOpt ? `(${min})` : ""}`}
          // className="w-24 border rounded shadow"
        />
        <Input
          type="number"
          min={min}
          max={max}
          value={columnFilterValue?.[1] ?? ""}
          onChange={(e) =>
            setFilterValue((old: [number, number]) => [
              old?.[0],
              e.target.value,
            ])
          }
          placeholder={`Max ${maxOpt ? `(${max})` : ""}`}
          // className="w-24 border rounded shadow"
        />
      </div>
      <div className="mb-1" />
    </div>
  );
};

// const getStartAndEndTimes = (
//   dateString: string
// ): { startISOString: string; endISOString: string } => {
//   // Create a Date object for the start time (00:00:00.000) of the given date
//   const startDate = new Date(dateString);

//   // Create a Date object for the end time (23:59:59.999) of the given date
//   const endDate = new Date(dateString);

//   startDate.setHours(0, 0, 0, 0);
//   endDate.setHours(23, 59, 59, 59);

//   // Convert Date objects to ISO string format
//   const startISOString = startDate.toISOString();
//   const endISOString = endDate.toISOString();

//   return { startISOString, endISOString };
// };
export const convertDateToDDMMYYYY = (dateString: string): string => {
  const [year, month, day] = dateString.split("-");
  return `${day}-${month}-${year}`;
};

type DateInputProps = {
  setFilterValue: (updater: any) => void;
};

const DateInput: React.FC<DateInputProps> = ({ setFilterValue }) => {
  const [selectedValue, setSelectedValue] = React.useState<Date | null>(null);
  const handleChange = (event: any) => {
    const inputValue = event;
    if (!inputValue) {
      setFilterValue(null);
      setSelectedValue(null);
    } else {
      setFilterValue(convertDateToDDMMYYYY(dateStringFormat(inputValue)));
      setSelectedValue(inputValue);
    }
  };

  return (
    <React.Fragment>
      <DatePicker
        className="p-1 ps-4 border border-secondary-subtle rounded calendar-custom w-100"
        showIcon
        selected={selectedValue}
        icon={<FontAwesomeIcon icon={faCalendarDays} />}
        calendarIconClassname="text-primary"
        isClearable
        placeholderText={`Search...`}
        onChange={handleChange}
      />
      <div className="mb-1" />
    </React.Fragment>
  );
};
type TextInputProps = {
  columnId: string;
  columnFilterValue: string;
  columnSize: number;
  setFilterValue: (updater: any) => void;
  sortedUniqueValues: any[];
};

const TextInput: React.FC<TextInputProps> = ({
  columnId,
  columnFilterValue,
  columnSize,
  setFilterValue,
  sortedUniqueValues,
}) => {
  const dataListId = columnId + "list";

  return (
    <React.Fragment>
      <datalist id={dataListId}>
        {sortedUniqueValues.slice(0, 5000).map((value: any) => (
          <option value={value} key={value} />
        ))}
      </datalist>
      <Input
        type="text"
        value={columnFilterValue ?? ""}
        onChange={(e) => setFilterValue(e.target.value)}
        placeholder={`Search... (${columnSize})`}
        list={dataListId}
      />
      <div className="mb-1" />
    </React.Fragment>
  );
};

type SelectInputProps = {
  columnId: string;
  columnFilterValue: string | null;
  setFilterValue: (updater: any) => void;
  uniqueValues: string[];
  columnSize: number;
};

const SelectInput: React.FC<SelectInputProps> = ({
  // columnId,
  setFilterValue,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const toggle = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleOptionClick = (value: string) => {
    setSelectedOption(value);
    setDropdownOpen(true);
    setFilterValue(value); // Set the selected value
  };

  const handleClearSelection = () => {
    setSelectedOption(null);
    setFilterValue("");
  };

  return (
    <Dropdown isOpen={dropdownOpen} toggle={toggle}>
      <DropdownToggle
        color="light"
        style={{
          width: "100%",
          border: "1px solid #dee2e6",
          flex: "start",
          backgroundColor: "#fff",
          textAlign: "left",
          color: "#212529",
        }}
      >
        <div className="d-flex justify-content-between">
          {selectedOption ? selectedOption : `Select... (5)`}

          {selectedOption && (
            <FontAwesomeIcon
              icon={faClose}
              className="mt-1"
              onClick={(e) => {
                e.stopPropagation();
                handleClearSelection();
              }}
            />
          )}
        </div>
      </DropdownToggle>
      <DropdownMenu style={{ width: "100%" }}>
        <DropdownItem
          style={{ width: "100%" }}
          key="Success"
          value="Success"
          onClick={() => handleOptionClick("Success")}
        >
          <>
            <FontAwesomeIcon icon={faFile} className="text-success" />{" "}
            <FontAwesomeIcon icon={faFileExcel} className="text-success" />
          </>{" "}
          {"("}
          Success
          {")"}
        </DropdownItem>
        <DropdownItem
          style={{ width: "100%" }}
          key="Technical Error"
          value="Technical Error"
          onClick={() => handleOptionClick("Technical Error")}
        >
          <>
            <FontAwesomeIcon icon={faFile} className="text-danger" />{" "}
            <FontAwesomeIcon icon={faFileExcel} className="text-success" />
          </>{" "}
          {"("}
          Technical Error
          {")"}
        </DropdownItem>
        <DropdownItem
          style={{ width: "100%" }}
          key="Not Linked"
          value="Not Linked"
          onClick={() => handleOptionClick("Not Linked")}
        >
          <>
            <FontAwesomeIcon icon={faFile} className="text-danger" />{" "}
            <FontAwesomeIcon icon={faFileExcel} className="text-danger" />
          </>{" "}
          {"("}
          Not Linked
          {")"}
        </DropdownItem>
        <DropdownItem
          style={{ width: "100%" }}
          key="Demographics"
          value="Demographics"
          onClick={() => handleOptionClick("Demographics")}
        >
          <>
            <FontAwesomeIcon icon={faFile} className="text-warning" />{" "}
            <FontAwesomeIcon icon={faFileExcel} className="text-danger" />
          </>{" "}
          {"("}
          Demographic
          {")"}
        </DropdownItem>
        <DropdownItem
          style={{ width: "100%" }}
          key="Manual"
          value="Manual"
          onClick={() => handleOptionClick("Manual")}
        >
          <>
            <FontAwesomeIcon icon={faFile} style={{ color: "#067492" }} />{" "}
            <FontAwesomeIcon icon={faFileExcel} style={{ color: "#067492" }} />
          </>{" "}
          {"("}
          Manual
          {")"}
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>
  );
};

const InsuranceStatusSelectInput: React.FC<SelectInputProps> = ({
  // columnId,
  setFilterValue,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const toggle = () => {
    setDropdownOpen((prevState) => !prevState);
  };
  const handleOptionClick = (value: string) => {
    setSelectedOption(value);
    setDropdownOpen(true);
    setFilterValue(value); // Set the selected value
  };
  const handleClearSelection = () => {
    setSelectedOption(null);
    setFilterValue("");
    setDropdownOpen(false);
  };

  return (
    <Dropdown isOpen={dropdownOpen} toggle={toggle}>
      <DropdownToggle
        color="light"
        style={{
          width: "100%",
          border: "1px solid #dee2e6",
          flex: "start",
          backgroundColor: "#fff",
          textAlign: "left",
          color: "#212529",
        }}
      >
        <div className="d-flex justify-content-between">
          {selectedOption ? selectedOption : `Select... (2)`}

          {selectedOption && (
            <FontAwesomeIcon
              icon={faClose}
              className="mt-1"
              onClick={(e) => {
                e.stopPropagation();
                handleClearSelection();
              }}
            />
          )}
        </div>
      </DropdownToggle>
      <DropdownMenu style={{ width: "100%" }}>
        <DropdownItem
          style={{ width: "100%" }}
          key="active"
          value="active"
          onClick={() => handleOptionClick("active")}
        >
          <Badge
            className={`fw-normal border-1 bg-success-subtle border-success text-success`}
            style={{ border: "1px solid" }}
            pill
          >
            Active
          </Badge>
        </DropdownItem>
        <DropdownItem
          style={{ width: "100%" }}
          key="inactive"
          value="inactive"
          onClick={() => handleOptionClick("inactive")}
        >
          <Badge
            className={`fw-normal border-1 bg-danger-subtle border-danger text-danger }`}
            style={{ border: "1px solid" }}
            pill
          >
            Inactive
          </Badge>
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>
  );
};
type Props<T extends RowData> = {
  column: Column<T, unknown>;
  table: Table<T>;
};

export function Filter<T extends RowData>({ column, table }: Props<T>) {
  const firstValue = table
    .getPreFilteredRowModel()
    .flatRows[0]?.getValue(column.id);
  const columnFilterValue = column.getFilterValue();
  const uniqueValues = column.getFacetedUniqueValues();
  const sortedUniqueValues = React.useMemo(
    () =>
      typeof firstValue === "number"
        ? []
        : Array.from(uniqueValues.keys()).sort(),
    [uniqueValues]
  );
  return typeof firstValue === "number" ? (
    <NumberInput
      columnFilterValue={columnFilterValue as [number, number]}
      getFacetedMinMaxValues={column.getFacetedMinMaxValues}
      setFilterValue={column.setFilterValue}
    />
  ) : column.id === "lastVerifiedDate" ||
    column.id === "scheduleAppointmentDate" ||
    column.id === "dateOfBirthDate" ? (
    <>
      <DateInput setFilterValue={column.setFilterValue} />
    </>
  ) : column.id === "status" ? (
    <SelectInput
      columnId={column.id}
      columnFilterValue={columnFilterValue as string}
      setFilterValue={column.setFilterValue}
      uniqueValues={sortedUniqueValues}
      columnSize={sortedUniqueValues.length}
    />
  ) : column.id === "insuranceStatus" ? (
    <InsuranceStatusSelectInput
      columnId={column.id}
      columnFilterValue={columnFilterValue as string}
      setFilterValue={column.setFilterValue}
      uniqueValues={sortedUniqueValues}
      columnSize={sortedUniqueValues.length}
    />
  ) : column.id === "payerLogo" ? null : (
    <TextInput
      columnId={column.id}
      columnFilterValue={columnFilterValue as string}
      columnSize={uniqueValues.size}
      setFilterValue={column.setFilterValue}
      sortedUniqueValues={sortedUniqueValues}
    />
  );
}

export default Filter;
