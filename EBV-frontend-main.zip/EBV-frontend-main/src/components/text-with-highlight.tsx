import Highlighter from "react-highlight-words";
import { useSearchParams } from "react-router-dom";

export type TextWithHighlightProps = {
  children?: string;
};

export const TextWithHighlight = (props: TextWithHighlightProps) => {
  const [searchParams] = useSearchParams();

  const search = searchParams.get("search") ?? "";

  return (
    <Highlighter
      searchWords={[search]}
      autoEscape={true}
      textToHighlight={props.children ?? ""}
    />
  );
};

export default TextWithHighlight;
