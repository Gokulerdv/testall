import React from 'react';
import { Modal, ModalBody } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClose } from '@fortawesome/free-solid-svg-icons';

import Button from './Button';

interface ActivateDeactivatePopupProps {
  isOpen: boolean;
  toggle: () => void;
  proceedFunction: () => void;
  name: string;
  action: string;
}

const ActivateDeactivatePopup: React.FC<ActivateDeactivatePopupProps> = ({
  isOpen,
  toggle,
  proceedFunction,
  name,
  action,
}) => {
  return (
    <React.Fragment>
      <Modal isOpen={isOpen} centered>
        <div className='alert-header'>
          <span className='fw-bold'>{action}</span>
          <button onClick={toggle} className='close-btn'>
            <FontAwesomeIcon icon={faClose} color='white' />
          </button>
        </div>
        <ModalBody>
          <div className='d-flex justify-content-center flex-column align-items-center'>
            <p className='text-center fw-normal mb-4'>
              Are you sure you want to {action.toLowerCase()} this {name}?
            </p>
            <div>
              <Button btntype='outlined' className='me-2' onClick={toggle}>
                No
              </Button>
              <Button btntype='filled' onClick={proceedFunction}>
                Yes
              </Button>
            </div>
          </div>
        </ModalBody>
      </Modal>
    </React.Fragment>
  );
};

export default ActivateDeactivatePopup;
