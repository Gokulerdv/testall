import { z } from "zod";
import sampleEligibilityList from "./sample.json";

export const eligibilityListSchema = z.array(
  z.object({
    adminId: z.string(),
    dentalXchangeResponse: z.string(),
    uniqueId: z.string(),
    verificationType: z.string(),
    patientid: z.string().optional(),
    lastverified: z.string().optional(),
  })
);

export const activeCoverageSchema = z.object({
  serviceType: z.string(),
  planCoverageDescription: z.string(),
  insuranceType: z.string(),
  message: z.string(),
});

export const coInsuranceSchema = z.object({
  code: z.string().optional(),
  network: z.string(),
  serviceType: z.string(),
  coverageLevel: z.string(),
  percent: z.string(),
  insuranceType: z.string(),
  authorizationRequired: z.string().optional(),
  message: z.string().optional(),
});

export const deductibleSchema = z.object({
  serviceType: z.string(),
  network: z.string(),
  coverageLevel: z.string(),
  planPeriod: z.string(),
  amount: z.string(),
  insuranceType: z.string(),
  message: z.string().optional(),
});

export const limitationAndMaximumSchema = z.object({
  serviceType: z.string(),
  network: z.string(),
  coverageLevel: z.string(),
  planPeriod: z.string(),
  amount: z.string(),
  insuranceType: z.string(),
});

export const notCoveredSchema = z.object({
  serviceType: z.string(),
  network: z.string(),
  coverageLevel: z.string(),
  insuranceType: z.string(),
});

export const benefitsHistorySchema = z.object({
  id: z.string(),
  serviceType: z.string(),
  doses: z.string(),
  provider: z.string(),
  procedure: z.string(),
  benefitsConsumed: z.string(),
});

export const questionSchema = z.object({
  question: z.string(),
  answer: z.string(),
});

export type AdaProcedure = z.infer<typeof coInsuranceSchema> & {
  [key: string]: unknown;
};

export type CoInsurance = z.infer<typeof coInsuranceSchema> & {
  [key: string]: unknown;
};

export type ActiveCoverage = z.infer<typeof activeCoverageSchema> & {
  [key: string]: unknown;
};

export type LimitationAndMaximum = z.infer<
  typeof limitationAndMaximumSchema
> & {
  [key: string]: unknown;
};

export type Deductible = z.infer<typeof deductibleSchema> & {
  [key: string]: unknown;
};

export type NotCovered = z.infer<typeof notCoveredSchema> & {
  [key: string]: unknown;
};

export type BenefitsHistory = z.infer<typeof benefitsHistorySchema>;

export type Question = z.infer<typeof questionSchema>;

export const dentalXchangeResponseSchema = z.object({
  status: z.object({ code: z.number(), description: z.string() }),
  messages: z.array(z.unknown()),
  transactionId: z.number(),
  response: z.object({
    payer: z.object({ name: z.string(), id: z.string() }),
    subscriber: z.object({
      firstName: z.string(),
      lastName: z.string(),
      address: z.object({
        address1: z.string(),
        address2: z.string(),
        city: z.string(),
        state: z.string(),
        zipCode: z.string(),
      }),
      dateOfBirth: z.string(),
      gender: z.string(),
      plan: z.object({
        groupNumber: z.string(),
        groupName: z.string(),
        subscriberId: z.string(),
        coverageIndicator: z.string(),
        effectiveDateFrom: z.string(),
      }),
    }),
    patient: z.object({
      firstName: z.string(),
      lastName: z.string(),
      address: z.object({
        address1: z.string(),
        address2: z.string(),
        city: z.string(),
        state: z.string(),
        zipCode: z.string(),
      }),
      dateOfBirth: z.string(),
      relationship: z.string(),
      gender: z.string(),
      plan: z.object({
        groupNumber: z.string(),
        groupName: z.string(),
        subscriberId: z.string(),
        coverageIndicator: z.string(),
        effectiveDateFrom: z.string(),
      }),
    }),
    activeCoverage: z.array(activeCoverageSchema),
    coInsurance: z.array(coInsuranceSchema),
    deductible: z.array(deductibleSchema),
    limitationAndMaximum: z.array(limitationAndMaximumSchema),
    notCovered: z.array(notCoveredSchema),
    benefitsHistory: z.array(benefitsHistorySchema).optional(),
    notesAndRemarks: z.string().optional(),
    miscellaneous: z.array(questionSchema).optional(),
  }),
});

export type DentalXchangeResponse = z.infer<typeof dentalXchangeResponseSchema>;

export type EligibilityList = z.infer<typeof eligibilityListSchema>;

export const generateEligibilityList = (): EligibilityList => {
  return eligibilityListSchema.parse(sampleEligibilityList);
};
