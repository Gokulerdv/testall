import { faker } from "@faker-js/faker";
import { z } from "zod";

export const eligibilitySchema = z.object({
  id: z.string(),
  patientId: z.string(),
  patientName: z.string(),
  appointmentOn: z.union([z.coerce.date(), z.string()]),
  insurancePlan: z.string(),
  remainingBenefits: z.union([z.number(), z.string(), z.null()]),
  deductible: z.union([z.number(), z.string(), z.null()]),
  insuranceStatus: z.enum(["active", "inactive"]),
  status: z.enum(["approved", "declined", "pending"]),
  lastVerifiedOn: z.union([z.coerce.date(), z.string()]),
  typeOfService: z.string().optional(),
  practiceNameAndLocation: z.string().optional(),
  appointmentType: z.string().optional(),
  appointment: z.union([z.coerce.date().optional(), z.string().optional()]),
});

export type Eligibility = z.infer<typeof eligibilitySchema>;

export const generateEligibility = (): Eligibility => {
  return {
    id: faker.string.nanoid(4),
    patientId: faker.string.nanoid(4),
    patientName: faker.person.fullName(),
    appointmentOn: faker.date.past(),
    insurancePlan: faker.company.name(),
    remainingBenefits: faker.number.int(100000),
    deductible: faker.number.int(10000),
    insuranceStatus: faker.helpers.arrayElement(["active", "inactive"]),
    status: faker.helpers.arrayElement(["approved", "declined", "pending"]),
    lastVerifiedOn: faker.date.past(),
  };
};
