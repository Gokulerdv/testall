import { faker } from "@faker-js/faker";
import { z } from "zod";

const serviceTypes = ["N/A"] as const;
const doses = ["N/A"] as const;
const providers = ["N/A"] as const;
const procedures = ["N/A"] as const;
const benefitsConsumed = ["N/A"] as const;

export const benefitHistorySchema = z.object({
  id: z.string(),
  serviceType: z.enum(serviceTypes),
  dos: z.enum(doses),
  provider: z.enum(providers),
  procedure: z.enum(procedures),
  benefitsConsumed: z.enum(benefitsConsumed),
});

export type BenefitHistory = z.infer<typeof benefitHistorySchema>;

export const generateBenefitHistory = (): BenefitHistory => {
  return {
    id: faker.string.nanoid(4),
    serviceType: faker.helpers.arrayElement(serviceTypes),
    dos: faker.helpers.arrayElement(doses),
    provider: faker.helpers.arrayElement(providers),
    procedure: faker.helpers.arrayElement(procedures),
    benefitsConsumed: faker.helpers.arrayElement(benefitsConsumed),
  };
};
