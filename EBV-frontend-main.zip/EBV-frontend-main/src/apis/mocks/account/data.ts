import { z } from "zod";

const userTypes = ["basic"] as const;

export const accountSchema = z.object({
  firstName: z.string().nullable().optional(),
  lastName: z.string().nullable().optional(),
  userType: z.enum(userTypes).nullable().optional(),
  accessToken: z.string().nullable().optional(),
  refreshToken: z.string().nullable().optional(),
  email: z.string().email().nullable().optional(),
  permission: z.array(z.string()).optional(),
  userData: z
    .object({
      userId: z.string(),
    })
    .optional(),
});

export type Account = z.infer<typeof accountSchema>;
