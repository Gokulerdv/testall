export type Response<TData> = {
  scheduledaction: string | undefined;
  weeklydays: string | undefined;
  isweekly: boolean | undefined;
  isdaily: boolean | undefined;
  ismonthly: boolean | undefined;
  everyweek: string | undefined;
  everymonth: string | undefined;
  oncountofdays: string | undefined;
  oncountofweekdays: string | undefined;
  oncountofweeks: string | undefined;
  timetorun: string | undefined;
  numberofpatients: number | undefined;
  notificationData: object | undefined;
  status: true;
  message: string;
  data: TData;
};

export const generateResponse = <TData>(
  response: Response<TData>
): Response<TData> => {
  return response;
};
