from flask import Flask, render_template, request, jsonify, send_file
from flask_cors import CORS
import azure.cognitiveservices.speech as speechsdk
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
import os
from dotenv import load_dotenv
import requests
from io import BytesIO
import urllib.parse
import tempfile
import re
import openai
import threading
from bs4 import BeautifulSoup
from docx import Document


app = Flask(__name__)
CORS(app) 

dotenv_path = os.path.join(os.path.dirname(__file__), 'settings.env')
load_dotenv(dotenv_path)

subscription = os.getenv("subscription")
region = os.getenv("region")
text_analytics_key = os.getenv("text_analytics_key")
text_analytics_endpoint = os.getenv("text_analytics_endpoint")

openai.api_key = os.getenv("AZURE_OPENAI_KEY")
openai.api_base = os.getenv("AZURE_OPENAI_BASE")
openai.api_type = "azure"
openai.api_version = "2024-02-01"
deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT")

speech_config = speechsdk.SpeechConfig(subscription=subscription, region=region)
text_analytics_client = TextAnalyticsClient(
    endpoint=text_analytics_endpoint,
    credential=AzureKeyCredential(text_analytics_key)
)

def download_audio(url):
    try:
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.scheme not in ['http', 'https']:
            return None
        
        response = requests.get(url)
        if response.status_code == 200:
            audio_bytes = BytesIO(response.content)
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_wav_file:
                temp_wav_file.write(audio_bytes.read())
                return temp_wav_file.name
        else:
            return None
    except Exception as e:
        print(f"Error downloading file from {url}: {str(e)}")
        return None


def transcribe_audio(file_path):
    try:
        audio_input = speechsdk.AudioConfig(filename=file_path)
        recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_input)

        recognized_text = []

        def handle_final_result(evt):
            recognized_text.append(evt.result.text)

        recognizer.recognized.connect(handle_final_result)

        done = threading.Event()

        def stop_cb(evt):
            done.set()

        recognizer.session_stopped.connect(stop_cb)
        recognizer.canceled.connect(stop_cb)

        recognizer.start_continuous_recognition()
        done.wait() 
        recognizer.stop_continuous_recognition()

        return ' '.join(recognized_text) if recognized_text else "Unable to transcribe audio"
    except Exception as e:
        print(f"Error transcribing audio: {str(e)}")
        return "Unable to transcribe audio"


def analyze_sentiment_and_emotion(text):
    try:
        
        segments = re.split(r'(?<=[.])\s*', text)

        colored_text = ""
        documents = [{"id": str(i), "text": segment} for i, segment in enumerate(segments) if segment.strip()]

        response = text_analytics_client.analyze_sentiment(documents=documents)
        
        for idx, segment in enumerate(segments):
            if not segment.strip():
                continue
            segment_sentiment = response[idx].sentiment
            color = "black"  
            if segment_sentiment == "positive":
                color = "green"
            elif segment_sentiment == "negative":
                color = "red"
            elif segment_sentiment == "neutral":
                color = "blue"
            
            
            colored_text += f'<span style="color:{color};">{segment}</span> '

        
        overall_sentiment = response[0].sentiment
        scores = response[0].confidence_scores

        return overall_sentiment, colored_text, scores
    except Exception as e:
        print(f"Error analyzing sentiment and emotion: {str(e)}")
        return None, None, None



def summarize_text(text):
    try:
        prompt = (
            f"Summarize the following text in 3 to 5 sentences. Format the summary using bullet points or numbering. ex: 1. Title: Brief summary.\n 2. Title: Brief summary.\n\n "
            f"Highlight key Title/Topics or data by wrapping them in <highlight> tags:\n\n"
            f"{text}\n\n"
            f"Provide the summary with each point clearly separated. Format it as HTML with unordered or ordered lists."
        )

        
        response = openai.ChatCompletion.create(
            deployment_id=deployment_name, 
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,  
            max_tokens=300,   
            top_p=0.9,
            frequency_penalty=0,
            presence_penalty=0
        )

        summary = response.choices[0].message['content'].strip()
        summary = summary.replace("```html", "").replace("<highlight>", "<strong>").replace("</highlight>", "</strong>")
        
        return summary
    except Exception as e:
        print(f"Error summarizing text: {str(e)}")
        return "Unable to generate summary"

@app.route('/')
def index():
    return render_template('zabs7.html')

@app.route('/analyze_url', methods=['POST'])
def analyze_url():
    try:
        url = request.form.get('audioUrl')
        if not url:
            return jsonify({'error': 'No URL provided'}), 400

   
        audio_file_path = download_audio(url)
        if not audio_file_path:
            return jsonify({'error': 'Failed to download or process audio file from URL'}), 400

        try:
            transcribed_text = transcribe_audio(audio_file_path)
            if not transcribed_text:
                return jsonify({'error': 'Failed to transcribe audio'}), 400
        finally:
            if audio_file_path:
                os.remove(audio_file_path) 

        
        sentiment, sentiment_html, scores = analyze_sentiment_and_emotion(transcribed_text)
        if not sentiment or not sentiment_html:
            return jsonify({'error': 'Failed to analyze sentiment and emotion'}), 400

        summary = summarize_text(transcribed_text)
        if not summary:
            return jsonify({'error': 'Failed to summarize text'}), 400

        return jsonify({
            'transcribed_text': transcribed_text,
            'sentiment': sentiment,
            'sentiment_html': sentiment_html,
            'scores': {
                'positive': scores.positive,
                'neutral': scores.neutral,
                'negative': scores.negative
            },
            'summary': summary
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    

@app.route('/download_word', methods=['POST'])
def download_word():
    try:
        
        data = request.json
        summary_html = data.get('summary', '')

        
        soup = BeautifulSoup(summary_html, 'html.parser')

        
        doc = Document()
        doc.add_heading('Analysis Report', 0)

        doc.add_heading('Recognized Text:', level=1)
        doc.add_paragraph(data.get('transcribed_text', ''))

        doc.add_heading('Sentiment:', level=1)
        doc.add_paragraph(data.get('sentiment', ''))

        doc.add_heading('Scores:', level=1)
        scores = data.get('scores', {})
        doc.add_paragraph(f"Positive: {scores.get('positive', 'N/A')}, "
                          f"Neutral: {scores.get('neutral', 'N/A')}, "
                          f"Negative: {scores.get('negative', 'N/A')}")

        doc.add_heading('Summary:', level=1)
        for element in soup:
            if element.name == 'p':
                doc.add_paragraph(element.get_text(strip=True))
            elif element.name == 'strong':
                p = doc.add_paragraph()
                run = p.add_run(element.get_text(strip=True))
                run.bold = True
            elif element.name == 'ul':
                for li in element.find_all('li'):
                    doc.add_paragraph(li.get_text(strip=True), style='List Bullet')
            elif element.name == 'ol':
                for li in element.find_all('li'):
                    doc.add_paragraph(li.get_text(strip=True), style='List Number')
            elif element.name == 'li':
                doc.add_paragraph(element.get_text(strip=True), style='List Bullet')
            elif element.name is None:  
                doc.add_paragraph(element.strip())

        temp_path = tempfile.NamedTemporaryFile(delete=False, suffix='.docx').name
        doc.save(temp_path)

        return send_file(temp_path, as_attachment=True, download_name='analysis_report.docx')

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
